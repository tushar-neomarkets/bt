# Contributing Guidelines

## Code Style
- Explicit > clever
- No hidden side effects
- Type hints required for core logic
- Small, testable functions


