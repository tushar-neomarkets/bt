# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

Django-based automated trading platform for systematic options & futures strategies on Indian exchanges (NSE, BSE, NFO, MCX). Uses Django REST Framework for APIs and PostgreSQL for persistence.

## Commands

```bash
# Activate virtual environment (Windows)
.venv\Scripts\activate

# Run development server
cd src/system && python manage.py runserver

# Database migrations
cd src/system && python manage.py makemigrations
cd src/system && python manage.py migrate

# Run tests
cd src/system && python manage.py test
cd src/system && python manage.py test <app_name>  # e.g., python manage.py test strategy

# Django shell
cd src/system && python manage.py shell
```

**Simulator** (run strategies against synthetic market data without placing real orders):
```bash
cd src/system
python -m simulator.orchestrator --spot 24000
python -m simulator.orchestrator --spot 24000 --start-time 11:20
python -m simulator.orchestrator --strategies ORBSH GEXRT --spot 24100 --start-time 10:17 --date 2026-03-30
python -m simulator.orchestrator --spot 24000 --fault-scenario token_expiry
```

## Architecture

### Core Design Principles
- **Separation of concerns**: Execution (orders), data (datafeed), and strategy logic are strictly separated
- **Strategies are stateless**: Signal generation only, no direct broker API calls or order placement
- **Broker abstraction**: Handler classes delegate to broker-specific implementations via dynamic method dispatch

### Django Apps (`src/system/`)

| App | Purpose |
|-----|---------|
| `strategy` | Signal generation, strategy definitions, position tracking |
| `orders` | ParentOrder (strategy intent) → BrokerOrder (execution per account) |
| `accounts` | Broker credentials, session tokens, strategy-account mappings |
| `instruments` | Standardized instruments + broker-specific mappings (BrokerInstrument) |
| `datafeed` | Market data ingestion, normalized across providers |
| `dashboard` | Frontend templates |
| `utils` | Shared utilities (logging, TTM calculations, trade log parsing) |

### Key Patterns

**Handler Pattern** (broker abstraction):
- `BrokerAccountHandler` (`accounts/brokers/handler.py`) - order placement, positions, funds
- `DataFeedHandler` (`datafeed/rest/handler.py`) - market data (LTP, quotes)
- Methods dispatch to `_<broker>_<action>()` based on account's broker/provider name

**Order Flow**:
1. Strategy creates `ParentOrder` (base quantity, instrument)
2. `OrderManager` queries `StrategyAccountMapping` for all active accounts
3. For each account, creates `BrokerOrder` with `quantity = base_quantity × multiplier`
4. `BrokerAccountHandler` executes via broker-specific API

**Strategy System**:
- `BaseStrategy` abstract class requires `run()`, `verify()`, `stop()` methods
- `StrategyManager` singleton manages running strategies in threads
- Strategy codes: `ORBSH` (ORB Short), `GEXRT` (GEX Regime Trader), `IDXLS` (Index Long/Short), `IDXSH` (Index Short), `CCALL` (Covered Call), `VOLLS` (Vol Long/Short), `NSTRD` (Nifty Straddle)
- `strategy_params.dry_run=True` prevents order placement while testing

**Instrument Symbol Format**:
- Options: `UNDERLYING+EXPIRY(DDMMYYYY)+STRIKE+CE/PE` (e.g., `NIFTY+25042025+24000+CE`)
- Futures: `UNDERLYING+EXPIRY(DDMMYYYY)+FUT`
- Equity: `UNDERLYING`
- `BrokerInstrument` maps broker-specific tokens/symbols to standard `Instrument`

### Simulator (`src/simulator/`)

Runs production strategies against synthetic market data with 5-layer isolation guaranteeing no real orders are placed:
1. `dry_run=True` in strategy params
2. All API calls routed to `MockXTSServer` (localhost)
3. `StrategyManager` bypassed (strategies run directly)
4. No `StrategyAccountMapping` created
5. `SimClock` validates market-hours time (patches `datetime.now()`)

Key components: `PriceEngine` (GBM spot + Black-Scholes options), `TBTWriter` (fake tick data), `SimClock` (virtual clock), `MockXTSServer` (fake XTS HTTP server), `DBSetup` (seeds simulator DB records).

See `src/simulator/arch.md` for full simulator documentation.

### Database

PostgreSQL (default: localhost:5432, database: postgres, user: postgres, password: postgres)

### API Routes

- `/admin/` - Django admin
- `/api/accounts/` - Broker account management
- `/api/instruments/` - Instrument lookups
- `/api/strategy/` - Strategy control
- `/api/datafeed/` - Market data

## Code Style

- Type hints required for core logic
- Explicit over clever
- No hidden side effects
- Small, testable functions
