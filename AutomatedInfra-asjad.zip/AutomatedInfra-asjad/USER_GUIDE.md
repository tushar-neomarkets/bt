# AutomatedInfra User Guide

This guide documents the `AutomatedInfra` repository as it exists in the current codebase snapshot. It is written for operators, developers, and debuggers who need a practical reference for setup, architecture, routes, workflows, runtime artifacts, and failure handling.

Important notes:

- This repo currently has no committed `requirements.txt`, `pyproject.toml`, or equivalent dependency manifest.
- Existing docs such as `ARCHITECTURE.md`, `CLAUDE.md`, and `src/simulator/arch.md` are useful, but some details in them are stale relative to the code.
- The guide below was cross-checked against the source code in this workspace and is intentionally aligned to current implementation details.
- Verification basis: repository source inspection in this workspace on `2026-04-30`.

## 1. What This System Is

`AutomatedInfra` is a Django-based automated trading platform for Indian cash, futures, and options workflows.

Major responsibilities:

- Strategy definition and execution
- Instrument master and broker-instrument mapping
- Broker account token management and order execution
- Market data access through REST and WebSocket handlers
- Dashboard pages for monitoring, manual orders, and PnL
- A simulator that runs production strategy code against synthetic market data

Top-level code areas:

| Path | Purpose |
| --- | --- |
| `src/system/` | Main Django project |
| `src/system/accounts/` | Broker accounts, permissions, token refresh, broker handlers |
| `src/system/datafeed/` | Market data accounts, REST handlers, WebSocket stack |
| `src/system/instruments/` | Instrument master and broker mappings |
| `src/system/orders/` | Parent/Broker order lifecycle, auto-modify, retry, alerts |
| `src/system/strategy/` | Strategy metadata, positions, manager, strategy classes |
| `src/system/dashboard/` | HTML dashboard pages and dashboard AJAX endpoints |
| `src/system/utils/` | Logging, TTM helper, misc utilities |
| `src/simulator/` | Market-data simulator and fake XTS server |
| `helpers/` | Research/backtest/helper scripts outside the Django runtime |

## 2. Runtime Prerequisites

Inferred dependencies from imports:

- Python
- Django 5.2.x
- Django REST Framework
- PostgreSQL
- `requests`
- `pandas`
- `numpy`
- `scipy`
- `kiteconnect`
- `marketdata` (custom/external library used by several strategies)

Database settings are hardcoded in [`src/system/system/settings.py`](src/system/system/settings.py):

- Engine: PostgreSQL
- DB name: `postgres`
- User: `postgres`
- Password: `postgres`
- Host: `localhost`
- Port: `5432`

Other current settings that affect operations:

- `DEBUG = True`
- `ALLOWED_HOSTS = ['127.0.0.1']`
- `TIME_ZONE = 'Asia/Kolkata'`

## 3. How To Run

Standard Django commands from repo guidance:

```powershell
.venv\Scripts\activate
cd src\system
python manage.py runserver
python manage.py migrate
python manage.py test
```

Current test coverage reality:

- `src/system/strategy/tests.py` contains substantive tests around token-refresh retry behavior.
- Other app `tests.py` files are currently minimal scaffolds.

## 4. Access Model

Access is handled in two layers:

- Django login for dashboard pages and dashboard AJAX actions
- per-object filtering through `authorized_users` mappings on accounts and strategies

Practical split:

| Surface | Access pattern |
| --- | --- |
| Dashboard pages under `/` | login-required |
| Dashboard AJAX endpoints under `/dashboard/api/...` | login-required |
| Accounts and strategy APIs | user-scoped through DB permission checks |
| Datafeed and instrument sync APIs | service-style endpoints at the project level |

This means the platform supports both:

- interactive operator usage through the dashboard
- programmatic/service usage through API routes

Admin/UI entry points:

- Django admin: `/admin/`
- Dashboard home: `/`

Important auth note:

- The dashboard uses `@login_required`.
- The project does not include Django auth URL routes like `django.contrib.auth.urls`.
- If you are not already authenticated through admin or another mechanism, `login_required` redirects may point to `/accounts/login/`, which is not wired in this repo.

## 5. Supported Integrations

### Broker execution support

Implemented broker execution path:

- `XTS` only

Where it is enforced:

- `accounts/brokers/handler.py`
- `orders/order_manager.py`

### Datafeed support

Implemented datafeed provider path:

- `XTS` only

Where it is enforced:

- `datafeed/rest/handler.py`
- `datafeed/websocket/handler.py`

### Instrument source support

Implemented/partially implemented:

- Zerodha instrument dump: implemented
- Upstox instrument dump: current implementation reuses Zerodha dump logic
- XTS broker mapping: derived from Zerodha exchange token mapping

## 6. Core Data Model

The models below are the backbone of the system.

### Accounts

| Model | Purpose |
| --- | --- |
| `Broker` | Broker master, e.g. `XTS` |
| `BrokerAccount` | Credentials, token, URLs, allocation, broker config |
| `UserAccountsPermission` | User-to-account access control |
| `StrategyAccountMapping` | Links a strategy to one or more broker accounts with multiplier and auto-execute settings |

Key fields in `BrokerAccount`:

- `client_id`, `api_key`, `api_secret`
- `access_token`, `token_expiry`
- `is_active`, `is_paper_trading`
- `base_url`, `hostlookup_url`, `extra_data`
- `allocation`

### Datafeed

| Model | Purpose |
| --- | --- |
| `DataFeedProvider` | Provider master, e.g. `XTS` |
| `DataFeedAccount` | Market-data credentials, token, base URL |

### Instruments

| Model | Purpose |
| --- | --- |
| `Instrument` | Canonical tradable instrument |
| `BrokerInstrument` | Broker/provider-specific token and exchange mapping to canonical instrument |

Canonical symbol conventions from code comments:

- Option: `UNDERLYING+EXPIRY(DDMMYYYY)+STRIKE+CE/PE`
- Future: `UNDERLYING+EXPIRY(DDMMYYYY)+FUT`
- Equity: `UNDERLYING`

### Strategy

| Model | Purpose |
| --- | --- |
| `Strategy` | Strategy master record and runtime params |
| `UserStrategyPermission` | User-to-strategy access control |
| `StrategyPosition` | Strategy-level position lifecycle and PnL state |

Important `Strategy` fields:

- `strategy_code`
- `strategy_name`
- `entry_time`, `exit_time`
- `strategy_params`
- `extra_data`
- `strategy_class`

### Orders

| Model | Purpose |
| --- | --- |
| `ParentOrder` | Strategy intent before fan-out to broker accounts |
| `BrokerOrder` | Actual broker-specific order for a specific account |
| `StrategyAlert` | Operator-facing alert for stale open orders and rejected/cancelled retries |

Order fan-out logic:

1. A strategy creates a `ParentOrder`.
2. `OrderManager` finds active `StrategyAccountMapping` rows for that strategy.
3. It creates one `BrokerOrder` per mapped account using `quantity * multiplier`.
4. It places the order through `BrokerAccountHandler`.
5. `AutoModifyManager` may later chase price, retry partial terminal orders, and raise alerts.

## 7. Runtime Managers And Background Components

### StrategyManager

File: `src/system/strategy/strategy_manager.py`

What it does:

- Starts strategies in threads
- Ensures WebSocket manager is running
- Ensures token refresh manager is running
- Ensures auto-modify manager is running
- Tracks running strategies in-memory by `strategy_id`

Datafeed selection note:

- strategy startup currently instantiates the strategy with `DataFeedAccount.objects.first()`
- WebSocket streaming separately initializes from all active datafeed accounts
- in multi-account environments, keep the intended primary datafeed account clearly managed

Strategy codes currently wired into `StrategyManager`:

| Code | Class | File |
| --- | --- | --- |
| `CCALL` | `CoveredCall` | `strategy_class/covered_call.py` |
| `VOLLS` | `VolLongShort` | `strategy_class/vol_trading_new.py` |
| `VNEWS` | `VolLongShort` | `strategy_class/vol_trading_new.py` |
| `NSTRD` | `NiftyDeltaHedgedStraddle` | `strategy_class/nifty_straddle.py` |
| `LSTOK` | `LongStock` | `strategy_class/long_stock.py` |
| `SFUT` | `ShortFuture` | `strategy_class/short_future.py` |
| `IDXLS` | `IndexLongShort` | `strategy_class/index_long_short.py` |
| `IDXMA` | `IndexMomLongShort` | `strategy_class/index_mom_long_short_asymm.py` |
| `IDXMS` | `IndexMomLongShortSymm` | `strategy_class/index_mom_long_short_symm.py` |
| `BNKMA` | `BankNiftyMomLongShort` | `strategy_class/index_mom_long_short_asymm_banknifty.py` |
| `BNKMS` | `BankNiftyMomLongShortSymm` | `strategy_class/index_mom_long_short_symm_banknifty.py` |
| `HOTMS` | `HedgedOtmStrangle` | `strategy_class/hedged_otm_strangle.py` |
| `SMSS` | `StateMachineShortStrangle` | `strategy_class/state_machine_strangle.py` |
| `IDXSH` | `IndexShort` | `strategy_class/index_short.py` |
| `ORBSH` | `OrbShort` | `strategy_class/orb_short.py` |
| `GEXRT` | `GexRegimeTrader` | `strategy_class/gex_regime_trader.py` |
| `GEXVL` | `GexRegimeTrader` alias | `strategy_class/gex_vol.py` |

Implemented strategy classes that exist but are not currently wired into `StrategyManager`:

- `DeltaStraddle`
- `PutBearSpread`
- legacy `vol_trading.py`

### TokenRefreshManager

Files:

- `accounts/token_refresh_manager.py`
- `accounts/broker_acc_token_refresher.py`
- `datafeed/datafeed_token_refresher.py`

Behavior:

- Runs in a daemon thread
- Refresh cycle interval: 180 seconds
- Broker tokens refresh on expiry or proactively every 180 seconds
- Datafeed tokens refresh on expiry

### WebSocketManager

Files:

- `datafeed/websocket/manager.py`
- `datafeed/websocket/handler.py`

Behavior:

- Singleton
- Registers all active `DataFeedAccount` rows as streaming clients
- Stores latest tick per instrument
- Supports callback registration
- Reconnects failed clients with exponential backoff

### AutoModifyManager

File: `orders/order_manager.py`

Behavior:

- Runs every 10 seconds once strategies are active
- Refreshes status of all open broker orders for today
- Retries original orders that ended `CANCELLED`/`REJECTED` with `filled_quantity < quantity`
- Raises `StrategyAlert` for retry failures and stale open orders
- Price-chases open `LIMIT`/`SL` orders with `auto_modify=True`

## 8. Logging And Runtime Artifacts

### Log files

Base log directory:

- `src/system/logs/`

Pattern:

- app logs: `logs/<app>/<file>.log`
- strategy logs: `logs/strategy/<strategy_code>.log`

Important files:

- `logs/orders/order_manager.log`
- `logs/orders/auto_modify.log`
- `logs/strategy/<code>.log`

### Strategy file artifacts

| Strategy area | Runtime artifacts |
| --- | --- |
| `ORBSH` | CSV in `dump/orb/` |
| `IDXLS` | CSV in `dump/idxls/` |
| `IDXSH` | CSV in `dump/idxshort/` |
| `IDXMA` | CSV in `dump/idxma/` |
| `IDXMS` | CSV in `dump/idxms/` |
| `BNKMA` | CSV in `dump/bnkma/` |
| `BNKMS` | CSV in `dump/bnkms/` |
| `GEXRT`, `GEXVL` | JSON state in `dump/gex/` |
| `HOTMS` | JSON state in `dump/hotms/` |
| `SMSS` | JSON state in `dump/stmss/` |
| `DeltaStraddle` | JSON state in `dump/delta_straddle/` |
| `PutBearSpread` | JSON state in `dump/put_spread/` |
| `VOLLS` | CSVs in `dump/vol/events/`, `dump/vol/zscores/`, reads `dump/vol/initial_state.csv` |
| `CCALL` | Reads portfolio/positions files from `dump/cov_call` or overrides in `strategy_params` |

### TBT dependencies

Many strategies read TBT files from:

- network source: `\\10.211.8.76\GFD MBM Data\Momentum\logs`
- local copy area: `src/system/dump/tbt_local/`

BankNifty momentum strategies use:

- `src/system/dump/tbt_local_banknifty/`

If that network share is unavailable, TBT-driven strategies should be checked first during operational review.

## 9. HTTP Route Map

Root URL config lives in `src/system/system/urls.py`.

Mounted route groups:

- `/admin/`
- `/`
- `/api/accounts/`
- `/api/instruments/`
- `/api/strategy/`
- `/api/datafeed/`

Additional route files present in the repo:

- `src/system/orders/urls.py`
- `src/system/utils/urls.py`

At present those files are empty and are not mounted in the main project URL config, so the active HTTP surface is the set listed above.

## 10. API Reference

### 10.1 Accounts API

Base path: `/api/accounts/`

| Route | Method | Auth in code | Purpose | Notes |
| --- | --- | --- | --- | --- |
| `/api/accounts/` | `GET` | `LoginRequiredMixin` | List accounts visible to current user | Returns `id`, `account_name`, `client_id`, `broker__broker_name` |
| `/api/accounts/update-token/` | `POST` | `LoginRequiredMixin` | Refresh broker token | Body: `account_id` |
| `/api/accounts/<account_id>` | `GET` | no explicit login mixin | Broker account details | Still filters on `authorized_users__user=request.user` |
| `/api/accounts/<account_id>/funds/` | `GET` | no explicit login mixin | Funds/margin snapshot | Uses broker handler |
| `/api/accounts/<account_id>/positions/` | `GET` | no explicit login mixin | Net positions | Uses broker handler |
| `/api/accounts/<account_id>/orderbook/` | `GET` | no explicit login mixin | Orderbook | Uses broker handler |
| `/api/accounts/<account_id>/place-order` | `POST` | no explicit login mixin | Sample broker connectivity order hook | Currently submits two fixed XTS sample orders |
| `/api/accounts/<account_id>/strategy-pnl/` | `GET` | no explicit login mixin | Per-account PnL across mapped strategies | Uses first active datafeed account for LTP |
| `/api/accounts/<account_id>/strategy-pnl/<strategy_id>/` | `GET` | no explicit login mixin | Per-account PnL for one mapped strategy | Validates strategy-account mapping |

Current behavior notes:

- `PlaceOrderView` is best treated as a sample broker connectivity route in its current form. It submits two fixed instruments with predefined quantities and prices.
- Only `AccountsListView` and `UpdateTokenView` explicitly enforce Django login at the view class level.

Typical response structure from account endpoints:

- top-level `status`
- optional `message`
- `data` payload with account-specific content

### 10.2 Strategy API

Base path: `/api/strategy/`

| Route | Method | Auth in code | Purpose | Notes |
| --- | --- | --- | --- | --- |
| `/api/strategy/` | `GET` | no explicit login mixin | List strategies accessible to current user | Adds in-memory `is_running` flag |
| `/api/strategy/<strategy_id>` | `GET` | no explicit login mixin | Strategy details | Reads `strategy_params`, `extra_data`, class code |
| `/api/strategy/<strategy_id>/start` | `POST` | no explicit login mixin | Start strategy | Calls `strategy_manager.start_strategy` |
| `/api/strategy/<strategy_id>/start` | `DELETE` | no explicit login mixin | Stop strategy | Same view, delete path |
| `/api/strategy/<strategy_id>/stop` | `DELETE` | no explicit login mixin | Stop strategy | Same view, same delete handler |

Current behavior note:

- `/stop` and `/start` both point to the same view class.
- `POST` always starts.
- `DELETE` always stops.
- A `POST` to `/api/strategy/<id>/stop` will still hit `post()` and start the strategy.

Typical strategy response structure:

- `status`
- either `data` for list/detail endpoints or `message` for start/stop actions

### 10.3 Instruments API

Base path: `/api/instruments/`

| Route | Method | Auth in code | Purpose | Notes |
| --- | --- | --- | --- | --- |
| `/api/instruments/update-instruments/` | `POST` | none | Run instrument initialization/sync | Calls `run_initialization()` |

Instrument initialization behavior:

- soft-deactivates expired instruments unless still held by open positions
- fetches standardized instruments from Zerodha
- Upstox path currently reuses Zerodha logic
- creates/updates broker mappings for Zerodha, Upstox, and XTS
- uses Django cache to skip repeat runs on the same day

### 10.4 Datafeed API

Base path: `/api/datafeed/`

| Route | Method | Auth in code | Purpose | Notes |
| --- | --- | --- | --- | --- |
| `/api/datafeed/` | `GET` | none | List active datafeed accounts | No user filtering |
| `/api/datafeed/<account_id>/` | `GET` | none | Datafeed account details | No login wrapper |
| `/api/datafeed/<account_id>/update-token/` | `POST` | none | Refresh datafeed token | Account must be active |
| `/api/datafeed/<account_id>/ltp/?instrument_token=...` | `GET` | none | Get normalized LTP | Requires valid token and `Instrument` row |
| `/api/datafeed/<account_id>/quote/?instrument_token=...` | `GET` | none | Get normalized quote | Requires valid token and `Instrument` row |

Security/ops note:

- These routes are not decorated with `login_required` or `LoginRequiredMixin`.

Typical normalized market-data response shapes:

- LTP: `data.last_updated`, `data.ltp.instrument_token`, `exchange`, `tradingsymbol`, `ltp`, `timestamp`
- Quote: `data.last_updated`, `data.quote.instrument_token`, OHLC, bid/ask, volume, OI, ATP, buy/sell totals, timestamps

## 11. External Integration Endpoint Map

This section is useful when tracing broker/datafeed traffic outside Django.

### Broker-side XTS Interactive endpoints used

Via `src/system/accounts/brokers/xts.py`:

- `POST /interactive/user/session`
- `GET /interactive/user/balance`
- `GET /interactive/portfolio/positions`
- `GET /interactive/orders`
- `POST /interactive/orders`
- `PUT /interactive/orders`
- `DELETE /interactive/orders?appOrderID=...`

Optional hostlookup flow also uses:

- hostlookup base URL stored on the broker account

### Datafeed-side XTS Market Data endpoints used

Via `src/system/datafeed/rest/xts.py` and `datafeed/websocket/xts.py`:

- `POST /apimarketdata/auth/login`
- `POST /apimarketdata/instruments/quotes`
- `GET /apimarketdata/instruments/ohlc`
- `POST /apimarketdata/instruments/subscription`
- `PUT /apimarketdata/instruments/subscription`
- Socket.IO path: `/apimarketdata/socket.io`

### Simulator mock endpoints

Via `src/simulator/mock_xts_server.py`:

- `POST /apimarketdata/auth/login`
- `POST /apimarketdata/instruments/quotes`

The simulator mock is intentionally minimal and is focused on the exact market-data calls used by the strategies.

## 12. Dashboard Route Reference

All dashboard routes in `dashboard/views.py` are `@login_required`.

### Pages

| Route | Method | Purpose |
| --- | --- | --- |
| `/` | `GET` | Dashboard home with broker/datafeed account lists |
| `/accounts/<account_id>/` | `GET` | Account detail page |
| `/accounts/<account_id>/pnl/` | `GET` | Account-level PnL page |
| `/strategies/` | `GET` | Strategy management page |
| `/strategies/<strategy_id>/` | `GET` | Strategy detail with positions, PnL, alerts |
| `/orders/` | `GET` | Parent orders page |
| `/orders/broker/` | `GET` | Broker orders page |
| `/orders/manual/` | `GET` | Manual order UI |
| `/alerts/<alert_id>/dismiss/` | `POST` | Dismiss `StrategyAlert` |

Dashboard templates shipped in the repo:

- `index.html`
- `detail.html`
- `account_pnl.html`
- `strategies.html`
- `strategy_detail.html`
- `parent_orders.html`
- `broker_orders.html`
- `manual_order.html`

### Dashboard instrument AJAX APIs

| Route | Method | Inputs | Purpose |
| --- | --- | --- | --- |
| `/dashboard/api/instruments/segments/` | `GET` | none | Distinct active segments excluding index segments |
| `/dashboard/api/instruments/exchanges/` | `GET` | `segment` | Valid exchanges for a segment |
| `/dashboard/api/instruments/symbols/` | `GET` | `segment`, `exchange` | Equity instruments or derivative underlyings |
| `/dashboard/api/instruments/search/` | `GET` | `segment`, `exchange`, `q` | Typeahead for equities |
| `/dashboard/api/instruments/expiries/` | `GET` | `segment`, `exchange`, `underlying` | Distinct expiries |
| `/dashboard/api/instruments/strikes/` | `GET` | `segment`, `exchange`, `underlying`, `expiry` | Option strikes or futures instrument |

### Dashboard order AJAX APIs

| Route | Method | Inputs | Purpose |
| --- | --- | --- | --- |
| `/dashboard/api/orders/verify/` | `POST` | `instrument_token` | Quote snapshot for manual order verification |
| `/dashboard/api/orders/place/` | `POST` | `account_id`, `instrument_token`, `order_side`, `order_type`, `quantity`, optional prices | Manual order placement via broker handler |
| `/dashboard/api/orders/modify/` | `POST` | `order_id`, `new_price`, optional `new_trigger_price` | Modify tracked `BrokerOrder` by internal DB `order_id` |
| `/dashboard/api/orders/modify-direct/` | `POST` | `account_id`, `app_order_id`, `new_price`, optional quantity/type/product/trigger | Modify live broker order directly |
| `/dashboard/api/orders/cancel-direct/` | `POST` | `account_id`, `app_order_id` | Cancel live broker order directly |

Important behavior details:

- `api_verify_order` uses the first active `DataFeedAccount`, not an account-specific datafeed selection.
- `api_place_order` maps canonical `Instrument` to `BrokerInstrument` and then calls `BrokerAccountHandler.place_order`.
- `api_modify_order` expects internal `BrokerOrder.order_id`, not the broker `AppOrderID`.
- `api_modify_broker_order_direct` and `api_cancel_broker_order_direct` operate on broker `app_order_id`.

Dashboard workflow highlights:

- `parent_orders.html` focuses on strategy intent and broker-order fan-out counts
- `broker_orders.html` supports tracked order modification from the UI for eligible `LIMIT` and `SL` orders
- `manual_order.html` walks the user through account -> segment -> exchange -> symbol/underlying -> expiry -> strike -> verify -> place
- `strategy_detail.html` combines open positions, today’s closed positions, actual-fill PnL overrides, and operator alerts
- `account_pnl.html` presents account-level PnL grouped by strategy

## 13. Strategy Catalog

This is the practical strategy summary for operators.

| Code | Summary | Key runtime dependencies |
| --- | --- | --- |
| `ORBSH` | Opening Range Breakout short on NIFTY options | TBT share/local TBT copy, CSV events in `dump/orb/` |
| `GEXRT` | Negative-gamma regime trader on NIFTY with hourly bar/GEX logic | TBT share, XTS quote chain, JSON state in `dump/gex/` |
| `GEXVL` | GEX variant implemented in `gex_vol.py` | Same family as GEXRT, JSON state in `dump/gex/` |
| `IDXLS` | Index long/short using EMA/candle logic | `marketdata.Index`, TBT share, CSV state in `dump/idxls/` |
| `IDXSH` | Index short with EMA/RSI/ATR logic | `marketdata.FnO`, CSV state in `dump/idxshort/` |
| `IDXMA` | NIFTY momentum long/short asymmetric execution | TBT share, option IV sizing, CSV state in `dump/idxma/` |
| `IDXMS` | NIFTY momentum long/short symmetric execution | TBT share, option IV sizing, CSV state in `dump/idxms/` |
| `BNKMA` | BankNifty monthly momentum asymmetric execution | local BankNifty TBT copy, CSV state in `dump/bnkma/` |
| `BNKMS` | BankNifty monthly momentum symmetric execution | local BankNifty TBT copy, CSV state in `dump/bnkms/` |
| `HOTMS` | Hedged OTM short strangle for weekly expiry day | TBT share, JSON state in `dump/hotms/` |
| `SMSS` | State-machine short strangle with A/B transitions | TBT share, JSON state in `dump/stmss/` |
| `VOLLS` | Volatility long/short basket of stock straddles | reads `dump/vol/initial_state.csv`, emits event/zscore CSVs |
| `CCALL` | Covered-call/collar workflow on portfolio stocks | reads `portfolio.csv` and positions XLS from `dump/cov_call` or overrides |
| `NSTRD` | Delta-hedged short straddle using forwards | XTS quotes, option/future lookup |
| `LSTOK` | Single-stock long example strategy | Looks up the fixed `PERSISTENT` equity symbol |
| `SFUT` | Short nearest NIFTY future | Uses NFO future lookup |

## 14. Broker And Datafeed Request Flow

### Broker execution flow

1. Strategy calls `order_manager.create_and_execute_order(...)`.
2. A `ParentOrder` is created.
3. Active `StrategyAccountMapping` rows are loaded.
4. One `BrokerOrder` per account is created.
5. `BrokerAccountHandler` dispatches to `_xts_place_order`.
6. Broker response updates `broker_order_id`, `exchange_order_id`, `broker_status`.
7. `AutoModifyManager` later refreshes status, retries, alerts, and price-chases if eligible.

### Datafeed REST flow

1. View obtains `DataFeedAccount`.
2. `DataFeedHandler` resolves canonical `Instrument` to `BrokerInstrument`.
3. It dispatches to XTS REST helpers in `datafeed/rest/xts.py`.
4. Response is normalized into `StandardLTP` or `StandardQuote`.

### WebSocket flow

1. `StrategyManager` starts `WebSocketManager`.
2. `WebSocketManager` registers each active `DataFeedAccount`.
3. `DataFeedWebSocketHandler` connects provider-specific client.
4. Ticks are normalized and stored in-memory.

Default WebSocket data mode:

- subscriptions default to XTS message code `1502` for market depth
- touchline `1501` and LTP `1512` handlers are also implemented in the client
- normalized ticks are stored as `StandardTick` objects

## 15. Response Models

The platform uses a few consistent response shapes that are helpful to know when integrating or debugging.

### `StandardLTP`

Fields:

- `instrument_token`
- `exchange`
- `tradingsymbol`
- `ltp`
- `timestamp`

### `StandardQuote`

Fields:

- identity: `instrument_token`, `exchange`, `tradingsymbol`
- prices: `ltp`, `open`, `high`, `low`, `close`
- depth: `best_bid_price`, `best_bid_qty`, `best_ask_price`, `best_ask_qty`
- activity: `volume`, `last_traded_qty`, `atp`
- OI: `oi`, `oi_day_high`, `oi_day_low`
- totals: `total_buy_qty`, `total_sell_qty`
- timestamps: `timestamp`, `last_trade_time`

### `StandardTick`

Fields:

- `instrument_token`
- `exchange`
- `tradingsymbol`
- `ltp`
- `timestamp`
- `source_client`
- optional bid/ask, OI, volume, OHLC, change fields

### Account-level PnL objects

The PnL service builds:

- `AccountPnL`
- `StrategyPnL`
- `AccountPosition`

These power both:

- `/api/accounts/<account_id>/strategy-pnl/`
- dashboard account PnL views

## 16. Simulator Guide

Simulator entry point:

```powershell
cd src\system
python -m simulator.orchestrator --spot 24000 --strategies ORBSH GEXRT
```

Current CLI flags from `src/simulator/orchestrator.py`:

| Flag | Required | Meaning |
| --- | --- | --- |
| `--spot` | yes | Initial spot price |
| `--sigma` | no | Annualized volatility, default `0.15` |
| `--strategies` | yes | Strategy codes to run, matched against `Strategy.strategy_code` |
| `--start-time` | no | Simulated time, default `09:16` |
| `--date` | no | Simulated market date |
| `--status-interval` | no | Status print interval, default `10`, `0` disables |
| `--fault-scenario` | no | One of `token_expiry`, `connection_drop`, `intermittent`, `sustained_401` |

Important simulator realities from code:

- `--strategies` is required now.
- The simulator bypasses `StrategyManager` and instantiates strategy classes directly.
- It creates or updates `DataFeedAccount(account_name='SIM_XTS')`.
- It sets `dry_run=True` in `Strategy.strategy_params` for requested strategies.
- `dry_run=True` persists after simulator shutdown until you remove it.
- On shutdown it deactivates `SIM_XTS`, but does not automatically remove `dry_run`.
- The simulator currently expects instrument master and XTS broker mappings to already exist in the database so it can build its in-memory registry.

## 17. Debugging Playbook

### If a strategy will not start

Check:

- `Strategy` row exists for the requested `strategy_id`
- `strategy.strategy_class` is present in `StrategyManager.strategy_classes`
- at least one active `DataFeedAccount` exists
- datafeed token is valid or refreshable
- required external files exist for that strategy

Common examples:

- `CCALL`: missing `portfolio.csv` or positions XLS
- TBT strategies: network share unavailable or local TBT copy stale
- `LSTOK`: the fixed `PERSISTENT` instrument is not present in the instrument master

### If orders are not being created

Check:

- `dry_run` in `strategy.strategy_params`
- active `StrategyAccountMapping` rows exist
- mapping `multiplier > 0`
- mapping `auto_execute=True` if live placement is expected
- `Instrument.is_active=True`
- `BrokerInstrument` mapping exists for the broker

Primary failure message path:

- `orders/order_manager.py`
- `ParentOrder.error_message`
- `BrokerOrder.error_message`

### If orders are created but not filling

Check:

- `BrokerOrder.status`
- `BrokerOrder.broker_status`
- `BrokerOrder.modification_history`
- `logs/orders/auto_modify.log`
- `StrategyAlert` rows on the strategy detail page

Auto-modify behavior:

- only `LIMIT` and `SL` orders
- only if `auto_modify=True`
- BUY target price becomes `best_ask + 0.1`
- SELL target price becomes `best_bid - 0.1`

### If token-related failures appear

Check:

- `BrokerAccount.token_expiry`
- `DataFeedAccount.token_expiry`
- `TokenRefreshManager` log output
- whether XTS hostlookup mode is active in `BrokerAccount.extra_data`

Files involved:

- `accounts/brokers/xts.py`
- `datafeed/rest/xts.py`
- `accounts/token_refresh_manager.py`

### If PnL looks wrong

Remember:

- strategy detail page rewrites position pricing in-memory using actual `BrokerOrder` fills
- account PnL uses first active `DataFeedAccount` for LTP
- if no active datafeed token is available, open PnL may be incomplete because LTP lookup returns empty

### If instrument lookup fails

Check:

- `Instrument` exists and `is_active=True`
- `BrokerInstrument` exists for the broker/provider
- instrument sync has been run recently
- the instrument was not soft-deactivated as expired

Useful route:

- `POST /api/instruments/update-instruments/`

### If dashboard pages redirect strangely

Cause:

- `@login_required` is used
- no auth URL patterns are mounted in `system/urls.py`

Practical workaround:

- log in through Django admin if available
- or wire auth URLs separately if this repo is being run standalone

## 18. Operational Notes

These notes are intended as implementation guidance for operators and maintainers.

- No dependency manifest is committed, so environment setup is currently derived from imports and local conventions.
- API access control is route-specific: dashboard flows are login-oriented, while some service endpoints are exposed at the project API layer.
- Strategy start/stop behavior is HTTP-method driven on the strategy control view.
- The account `place-order` route is best treated as a broker connectivity utility endpoint in its current form.
- Automated test coverage is centered mainly on strategy token-refresh behavior today.
- Simulator usage should be read from the current `src/simulator/orchestrator.py` implementation first, then supplemented by `src/simulator/arch.md`.

## 19. Useful Files To Open First During Incidents

If you need a short priority list:

1. `src/system/strategy/strategy_manager.py`
2. `src/system/orders/order_manager.py`
3. `src/system/accounts/brokers/handler.py`
4. `src/system/accounts/brokers/xts.py`
5. `src/system/datafeed/rest/handler.py`
6. `src/system/datafeed/rest/xts.py`
7. `src/system/dashboard/views.py`
8. `src/system/utils/logger.py`
9. the relevant strategy file in `src/system/strategy/strategy_class/`
10. the corresponding log file in `src/system/logs/`

## 20. Quick Command Cheat Sheet

```powershell
# Start Django
.venv\Scripts\activate
cd src\system
python manage.py runserver

# Run migrations
python manage.py migrate

# Run tests
python manage.py test

# Start simulator
python -m simulator.orchestrator --spot 24000 --strategies ORBSH GEXRT

# Start simulator with fault injection
python -m simulator.orchestrator --spot 24000 --strategies ORBSH GEXRT --fault-scenario token_expiry
```

## 21. Suggested Next Documentation Additions

If you want this guide extended further, the highest-value additions would be:

- per-strategy `strategy_params` reference with sample DB payloads
- sample `curl`/Postman requests for every endpoint
- schema snapshot for all DB tables
- runbook for live incident response and safe restart order
- explicit environment bootstrap instructions once dependency management is formalized
