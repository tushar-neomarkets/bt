"""
Mock XTS Market Data HTTP Server.

Impersonates the XTS API endpoints that the 4 strategies call:
  POST /apimarketdata/auth/login       
  POST /apimarketdata/instruments/quotes — returns simulated prices/OI/volume

The server knows about every instrument via an instrument_registry dict:
  { broker_token (int) -> {
        "instrument_token": int,
        "strike": float,
        "option_type": str,     # "CE" / "PE" / "FUT" / "IDX"
        "expiry": date | None,
        "instrument_type": str, # same as option_type
        "exchange_segment_code": int,
    } }
"""
import json
import threading
import time
from collections import deque
from http.server import BaseHTTPRequestHandler, HTTPServer
from datetime import datetime
from typing import Optional

from simulator.price_engine import PriceEngine

# XTS message codes
_MSG_TOUCHLINE = 1501
_MSG_MARKET_DEPTH = 1502
_MSG_OI = 1510


def _xts_timestamp() -> str:
    """XTS LastUpdateTime format: 'Jan 01 2026 09:15:00'"""
    return datetime.now().strftime("%b %d %Y %H:%M:%S")


class MockXTSServer:
    """
    Starts a local HTTP  server on the given port (0 = auto-assign).
    Returns the actual port from start() so callers can set base_url.
    """

    def __init__(self, price_engine: PriceEngine, instrument_registry: Optional[dict] = None, port: int = 0):
        self._engine = price_engine
        self._registry: dict = instrument_registry or {}
        self._port = port
        self._server: Optional[HTTPServer] = None
        self._thread: Optional[threading.Thread] = None
        self._actual_port: int = 0

        # Fault injection — consumed sequentially on each quote request
        self._fault_schedule: deque[list] = deque()   # [[remaining, fault_type], ...]
        self._fault_lock = threading.Lock()
        self._stat_faults_injected: int = 0

        # Stats — thread-safe via GIL (int increments are atomic in CPython)
        self._stat_login_requests: int = 0
        self._stat_quote_requests: int = 0
        self._stat_total_quotes_served: int = 0
        self._start_time: Optional[datetime] = None

    def get_stats(self) -> dict:
        """Return a snapshot of server activity counters."""
        return {
            "port": self._actual_port,
            "login_requests": self._stat_login_requests,
            "quote_requests": self._stat_quote_requests,
            "total_quotes_served": self._stat_total_quotes_served,
            "faults_injected": self._stat_faults_injected,
            "start_time": self._start_time,
        }

    def load_fault_schedule(self, schedule: list[tuple[int, str]]) -> None:
        """
        Load a fault schedule. Each entry is (count, fault_type).
        count = -1 means infinite (perpetual fault).
        Faults are consumed in order on each /instruments/quotes request.
        """
        with self._fault_lock:
            self._fault_schedule = deque([count, ftype] for count, ftype in schedule)
        names = [(c, f) for c, f in schedule]
        print(f"[MockXTSServer] Fault schedule loaded: {names}")

    def start(self) -> int:
        """Start the server. Returns the actual port it bound to."""
        handler_factory = self._make_handler()
        self._server = HTTPServer(("127.0.0.1", self._port), handler_factory)
        actual_port = self._server.server_address[1]
        self._actual_port = actual_port
        self._start_time = datetime.now()
        self._thread = threading.Thread(
            target=self._server.serve_forever,
            daemon=True,
            name="mock-xts-server",
        )
        self._thread.start()
        print(f"[MockXTSServer] Listening on http://127.0.0.1:{actual_port}")
        return actual_port

    def stop(self) -> None:
        """Shut down the server."""
        if self._server:
            self._server.shutdown()
        if self._thread:
            self._thread.join(timeout=5.0)

    def update_registry(self, registry: dict) -> None:
        """Replace the instrument registry (called after db_setup seeds the DB)."""
        self._registry = registry

    # ── Internal: build a closure-based handler class ─────────────────────────

    def _make_handler(self):
        """Return a handler class with access to the server's engine and registry."""
        engine = self._engine
        server_ref = self  # mutable reference so update_registry takes effect

        class _Handler(BaseHTTPRequestHandler):
            def do_POST(self):
                try:
                    length = int(self.headers.get("Content-Length", 0))
                    raw = self.rfile.read(length) if length else b"{}"
                    try:
                        body = json.loads(raw)
                    except json.JSONDecodeError:
                        body = {}

                    path = self.path.rstrip("/")

                    if path == "/apimarketdata/auth/login":
                        self._handle_login()
                    elif path == "/apimarketdata/instruments/quotes":
                        self._handle_quotes(body)
                    else:
                        # Unknown endpoint — return empty success so strategies don't crash
                        self._send_json({"type": "success", "result": {}})
                except Exception as e:
                    # Never let a bad request crash the server
                    print(f"[MockXTSServer] Handler error: {e}")
                    try:
                        self._send_json({"type": "error", "description": str(e)}, status=500)
                    except Exception:
                        pass

            # ── Login ──────────────────────────────────────────────────────

            def _handle_login(self):
                server_ref._stat_login_requests += 1
                token = f"SIM_TOKEN_{int(time.time())}"
                self._send_json({
                    "type": "success",
                    "result": {
                        "token": token,
                        "userID": "sim_user",
                        "isInvestorClient": False,
                    }
                })

            # ── Quotes ─────────────────────────────────────────────────────

            def _handle_quotes(self, body: dict):
                server_ref._stat_quote_requests += 1

                # ── Fault injection check ─────────────────────────────────
                fault = self._consume_fault()
                if fault:
                    server_ref._stat_faults_injected += 1
                    print(f"[MockXTSServer] FAULT INJECTED: {fault} (request #{server_ref._stat_quote_requests})")
                    if fault == "http_400":
                        self._send_json({"type": "error", "description": "e-session-0007: Invalid Token"}, status=400)
                        return
                    elif fault == "http_401":
                        self._send_json({"type": "error", "description": "e-session-0007: Invalid Token"}, status=401)
                        return
                    elif fault == "unauthorized_plain":
                        # Return 200 with plain text — strategy's .json() or response parsing
                        # sees "Unauthorized" in the error message, triggering the refresh path
                        raw = b"Unauthorized: Token expired or invalid."
                        self.send_response(200)
                        self.send_header("Content-Type", "text/plain")
                        self.send_header("Content-Length", str(len(raw)))
                        self.end_headers()
                        self.wfile.write(raw)
                        return
                    elif fault == "drop":
                        # Close connection abruptly — strategy gets ConnectionError
                        self.connection.close()
                        return

                # ── Normal quote handling ─────────────────────────────────
                message_code = int(body.get("xtsMessageCode", _MSG_TOUCHLINE))
                instruments = body.get("instruments", [])
                registry = server_ref._registry

                list_quotes = []
                for inst_payload in instruments:
                    try:
                        broker_token = int(inst_payload.get("exchangeInstrumentID", 0))
                        info = registry.get(broker_token)
                        if info is None:
                            continue
                        quote_str = _build_quote(engine, broker_token, info, message_code)
                        list_quotes.append(quote_str)
                    except Exception as e:
                        print(f"[MockXTSServer] Quote build error for token {inst_payload}: {e}")

                server_ref._stat_total_quotes_served += len(list_quotes)
                self._send_json({
                    "type": "success",
                    "result": {"listQuotes": list_quotes}
                })

            def _consume_fault(self) -> Optional[str]:
                """Pop the next fault from the schedule, or return None for normal operation."""
                with server_ref._fault_lock:
                    if not server_ref._fault_schedule:
                        return None
                    entry = server_ref._fault_schedule[0]  # [remaining, fault_type]
                    fault_type = entry[1]
                    if entry[0] == -1:  # perpetual
                        return fault_type
                    entry[0] -= 1
                    if entry[0] <= 0:
                        server_ref._fault_schedule.popleft()
                    return fault_type

            # ── HTTP helpers ───────────────────────────────────────────────

            def _send_json(self, data: dict, status: int = 200):
                payload = json.dumps(data).encode()
                self.send_response(status)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(payload)))
                self.end_headers()
                self.wfile.write(payload)

            def log_message(self, fmt, *args):
                # Suppress default HTTP access log noise
                pass

        return _Handler


# ── Quote builder (module-level, used by handler) ────────────────────────────

def _build_quote(engine: PriceEngine, broker_token: int, info: dict, message_code: int) -> str:
    """Build a JSON-serialized XTS quote string for a single instrument."""
    instrument_type = info.get("instrument_type", "CE")
    strike = float(info.get("strike") or 0.0)
    expiry = info.get("expiry")  # date or None

    ltp = engine.get_ltp(broker_token, instrument_type, strike, expiry)
    volume = engine.get_volume(broker_token)
    oi = engine.get_oi(broker_token, strike) if instrument_type in ("CE", "PE") else 0
    ts = _xts_timestamp()

    # Small spread around LTP
    bid = round(ltp * 0.999, 2)
    ask = round(ltp * 1.001, 2)
    open_price = round(ltp * 0.998, 2)
    high_price = round(ltp * 1.002, 2)
    low_price = round(ltp * 0.997, 2)
    close_price = round(ltp * 0.995, 2)

    quote: dict = {
        "ExchangeInstrumentID": broker_token,
        "LastTradedPrice": round(ltp, 2),
        "LastUpdateTime": ts,
        "LastTradedTime": ts,
        "LastTradedQunatity": 25,   # XTS typo preserved intentionally
        "TotalTradedQuantity": volume,
        "Open": open_price,
        "High": high_price,
        "Low": low_price,
        "Close": close_price,
        "AverageTradedPrice": round(ltp * 0.9995, 2),
        "TotalBuyQuantity": volume // 2,
        "TotalSellQuantity": volume // 2,
        "OpenInterest": oi,
        "OpenInterestDayHigh": int(oi * 1.05),
        "OpenInterestDayLow": int(oi * 0.95),
    }

    if message_code == _MSG_MARKET_DEPTH:
        # Bids/Asks arrays (5 levels)
        quote["Bids"] = [{"Price": round(bid - i * 0.05, 2), "Size": 50 * (i + 1)} for i in range(5)]
        quote["Asks"] = [{"Price": round(ask + i * 0.05, 2), "Size": 50 * (i + 1)} for i in range(5)]
    else:
        # Touchline format
        quote["BidPrice"] = bid
        quote["BidSize"] = 50
        quote["AskPrice"] = ask
        quote["AskSize"] = 50

    return json.dumps(quote)
