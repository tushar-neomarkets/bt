# Market Data Simulator — Architecture & Usage

## What is this?

The simulator lets you run our production strategies against **fake market data** without changing a single line of strategy code. It generates realistic Nifty prices — spot, options, futures, OI, volume — bounded within n% of a spot price you choose. Strategies run their exact production code paths. They just happen to talk to our fake infrastructure instead of the real market. **No real orders are placed. No real broker APIs are called. No real data feeds are touched.**

**Configurable to any day, any time!**

---

## How it works (ELI5)

Imagine the strategies are players in a video game. In production, they play the "real market" game. The simulator swaps in a fake game that looks identical:

1. **Fake stock prices** — Instead of reading real Nifty prices from the network share, strategies read a file we write locally every second with made-up prices that wiggle around the spot you give us.

2. **Fake options/futures server** — Instead of talking to the real XTS API for option prices, OI, volume, etc., strategies hit a tiny HTTP server on `localhost` that makes up prices using Black-Scholes math.

3. **Fake clock** — Strategies check "what time is it?" to decide if the market is open. We swap out the clock so that even at 11 PM, the code thinks it's 9:16 AM.

4. **Real historical data library** — The `marketdata` library (used for warmup) is left untouched. It works as-is.

5. **Safety net** — Every strategy has `dry_run=True`, which means even if a strategy decides to trade, the order placement code returns before making any API call. Plus, all API URLs point to localhost.

```
                         PRODUCTION                          SIMULATOR
                    +------------------+                 +------------------+
                    |  Network Share   |                 |  TBTWriter       |
  Channel 1:       |  \\10.211.8.76   |    replaced     |  writes to       |
  TBT File         |  (Nifty 50 tbt)  | --------------> |  dump/tbt_local/ |
  (spot price)     +--------+---------+                 |  every 1 second  |
                            |                           +--------+---------+
                            v                                    v
                    +------------------+                 +------------------+
                    |   STRATEGY       |                 |   STRATEGY       |
                    |   (same code)    |                 |   (same code)    |
                    +--------+---------+                 +--------+---------+
                            |                                    |
                            v                                    v
  Channel 2:       +------------------+                 +------------------+
  XTS HTTP API     |  Real XTS        |    replaced     |  MockXTSServer   |
  (options/futures |  Market Data     | --------------> |  on localhost     |
   OI, volume)     |  Server          |                 |  (same endpoints)|
                    +------------------+                 +------------------+

  Channel 3:       +------------------+                 +------------------+
  marketdata lib   |  Historical      |   kept real     |  Same library    |
  (warmup data)    |  data library    | --------------> |  (no mock)       |
                    +------------------+                 +------------------+
```

**How strategies don't know the difference:**
- They call `shutil.copy2(network_path, local_path)` to get the TBT file — we patch `shutil.copy2` to be a no-op for network paths, and the local file is already there.
- They hit `self.datafeed_obj.base_url + "/apimarketdata/..."` for XTS quotes — we set `base_url` to `http://127.0.0.1:<port>` so it hits our mock server.
- They call `datetime.now()` / `timezone.now()` — we swap these with offset versions that return market-hours time.
- They use the `marketdata` library for historical warmup — we don't touch that, it works as-is.

---

## Files

All files live in `src/simulator/`. 

| File | What it does |
|------|-------------|
| `__init__.py` | Empty. Makes `simulator` a Python package. |
| `price_engine.py` | Single source of truth for all prices. GBM for spot (clamped +/-3%), Black-Scholes for options (floor 0.05), Gaussian OI, monotonic volume. Thread-safe via `RLock`. |
| `tbt_writer.py` | Background thread writing fake Nifty 50 ticks to `dump/tbt_local/<date>.txt` every 1s. Also patches `shutil.copy2` so network share copies become no-ops. |
| `sim_clock.py` | Virtual clock that shifts wall time into market hours. Patches `datetime.now()`, `date.today()`, and `timezone.now()` in strategy modules without modifying their code. |
| `mock_xts_server.py` | HTTP server on localhost impersonating XTS API. Handles `/auth/login` and `/instruments/quotes` (message codes 1501, 1502, 1510). Supports fault injection via `--fault-scenario`. |
| `db_setup.py` | Seeds `DataFeedAccount("SIM_XTS")` pointing at mock server, creates `BrokerInstrument` records for all active NFO instruments, sets `dry_run=True` on target strategies. |
| `orchestrator.py` | Main entry point. Wires all components, activates virtual clock, runs pre-flight safety checks, instantiates strategies directly (bypasses StrategyManager), shows live monitoring, handles clean shutdown. |

---

## Virtual Clock (SimClock)

**Problem:** Strategies check the current time everywhere — market hours gating, TBT staleness, entry/exit windows, position timestamps. Running post-market means everything gets rejected.

**Solution:** `sim_clock.py` computes a time offset and patches `datetime.now()`, `date.today()`, and `django.utils.timezone.now()` in every strategy and datafeed module — without touching their source code.

### How it works

```
Real time:    20:00:00 (8 PM, after market close)
--start-time: 09:16 (default, just after market open)
Offset:       -10h44m

Every call to datetime.now() in strategy code returns:
  real_time + offset = 20:00:00 - 10:44:00 = 09:16:00

Time advances at real speed:
  1 real second = 1 simulated second
  After 10 real minutes, simulated time = 09:26:00
```

### What gets patched

| Module | Attribute patched | Why |
|--------|------------------|-----|
| `strategy.strategy_class.orb_short` | `datetime`, `date` | TBT staleness check, entry/exit time windows |
| `strategy.strategy_class.gex_regime_trader` | `datetime`, `date` | TBT staleness, GEX surface time-to-maturity |
| `strategy.strategy_class.index_long_short` | `datetime`, `date` | Time windows, position timestamps |
| `strategy.strategy_class.index_short` | `datetime`, `date` | Candle timing, poll loops |
| `strategy.strategy_class.base_strategy` | `datetime`, `date` | `_wait_until()`, `_get_today_datetime()` |
| `datafeed.rest.xts` | `datetime` | Timestamp parsing fallbacks |
| `datafeed.rest.handler` | `datetime` | `last_updated` timestamps |
| `simulator.price_engine` | `date` | TTM calculations for Black-Scholes |
| `simulator.tbt_writer` | `datetime` | TBT tick timestamps (must be in market hours) |
| `simulator.mock_xts_server` | `datetime` | XTS `LastUpdateTime` field |
| `django.utils.timezone` | `now` function | `is_token_expired`, position `entry_time`, `exit_time` |

### Choosing `--start-time`

| Goal | Start time | Why |
|------|-----------|-----|
| Full day from open | `--start-time 09:16` (default) | See range building, signal generation, all phases |
| Skip to OrbShort signals | `--start-time 11:20` | ORB signal phase starts after range-building window |
| Test EOD exits | `--start-time 15:15` | See how strategies handle market close |

---

## Choosing `--date`

Add a --date flag proceeded by YYYY-MM-DD format, to simulate any exact date

## Fault Injection

The mock server supports intentional failure injection via `--fault-scenario` to test how strategies handle edge cases like token expiry, connection drops, and API errors.

### How it works

Each scenario loads a "fault schedule" — a queue of `(count, fault_type)` entries. On each `/instruments/quotes` request, the server consumes the next entry:
- Returns the specified fault instead of real data
- Decrements the count; when count hits 0, moves to the next entry
- When the schedule is empty, normal operation resumes

### Available scenarios

| Scenario | What happens | What it tests |
|----------|-------------|---------------|
| `token_expiry` | 3 consecutive HTTP 401 responses, then normal | Token refresh path: strategy catches 401, calls `DataFeedHandler.update_token()` which POSTs to `/auth/login` (always succeeds), then retries |
| `connection_drop` | 3 consecutive connection drops (TCP close), then normal | `ConnectionError` / `requests.exceptions.ConnectionError` retry logic |
| `intermittent` | 2x HTTP 401, then 2x connection drop, then 2x "Unauthorized" plain text, then normal | Mixed failure modes in sequence |
| `sustained_401` | Perpetual HTTP 401 (never recovers) | Strategy's behavior when token refresh can't fix the problem (graceful degradation) |

### Fault types

| Type | Server behavior | What strategy sees |
|------|----------------|-------------------|
| `http_401` | Returns `{"type": "error", "description": "e-session-0007: Invalid Token"}` with HTTP 401 | `response.status_code == 401`, triggers token refresh |
| `http_400` | Same body, HTTP 400 | Different error code handling path |
| `unauthorized_plain` | Returns `200 OK` with plain text body `"Unauthorized: Token expired or invalid."` | `response.json()` throws, or content check finds "Unauthorized" |
| `drop` | Closes TCP connection immediately | `requests.exceptions.ConnectionError` |

### Usage

```bash
# Test token refresh
python -m simulator.orchestrator --spot 24000 --fault-scenario token_expiry

# Test connection resilience
python -m simulator.orchestrator --spot 24000 --fault-scenario connection_drop

# Test mixed failures
python -m simulator.orchestrator --spot 24000 --fault-scenario intermittent

# Test sustained failure (strategy should degrade gracefully, not crash)
python -m simulator.orchestrator --spot 24000 --fault-scenario sustained_401
```

The status display shows `faults_injected: N` so you can see when faults fired. Strategy logs show the error handling path triggered.

---

## Isolation guarantees

### Layer 1: dry_run=True prevents all orders

Every strategy reads `dry_run` from `strategy_params` and checks it in `_place_order()` BEFORE any call to `order_manager`:

| Strategy | dry_run guard | order_manager call |
|----------|--------------|-------------------|
| OrbShort | `orb_short.py:446-454` — returns `(True, None)` | `orb_short.py:456` — never reached |
| GexRegimeTrader | `gex_regime_trader.py:815-823` — returns `(True, None)` | `gex_regime_trader.py:825` — never reached |
| IndexLongShort | `index_long_short.py:718-726` — returns `(True, None)` | `index_long_short.py:728` — never reached |
| IndexShort | `index_short.py:959-967` — returns `(True, None)` | `index_short.py:969` — never reached |

When `dry_run=True`, strategies log what they WOULD do (tagged `[DRY-RUN]`) and return. `order_manager.create_and_execute_order()` is never called. No `ParentOrder`, no `BrokerOrder`, no broker API call.

The `setup_strategy_params()` function in `db_setup.py` forces `dry_run=True` in the DB before any strategy starts. The pre-flight checker at startup verifies this is set.

### Layer 2: All API calls go to localhost

`DataFeedAccount("SIM_XTS")` is created with:
- `base_url = "http://127.0.0.1:<auto-assigned-port>"`
- `extra_data = {}` (no `hostlookup` key)

Why this matters:
- `datafeed/rest/xts.py:33-40`: `_get_base_url()` checks `extra_data.get('hostlookup')` — it's empty, so it returns `account.base_url` (our localhost URL)
- `gex_regime_trader.py:482-485`: `_xts_request()` does the same check — falls through to `account.base_url`
- All HTTP requests from all 4 strategies land on our mock server

The pre-flight checker verifies `base_url.startswith("http://127.0.0.1")` before starting.

### Layer 3: StrategyManager is completely bypassed

The orchestrator does NOT use `StrategyManager.start_strategy()`. Instead it:
- Instantiates strategy classes directly: `OrbShort(strategy_obj, datafeed_account, ws_manager=None)`
- Runs them in plain `threading.Thread` daemons

This means:
- `websocket_manager` is never started (no WebSocket connections to real servers)
- `auto_modify_manager` is never started (no background order modifications)
- `DataFeedAccount.objects.first()` (strategy_manager.py:51) is never called — strategies use exactly the DataFeedAccount we give them

### Layer 4: No StrategyAccountMapping

Even if `dry_run` were somehow False (it can't be — pre-flight blocks this), `order_manager` would call `_get_active_mappings()` (order_manager.py:533) which queries `StrategyAccountMapping.objects.filter(strategy=..., is_active=True)`. The simulator creates NO StrategyAccountMapping records, so the result would be an empty list and no broker orders would be spawned.

### Layer 5: SimClock is active

The pre-flight checker validates that the virtual clock is active and reports the current simulated time. This confirms strategies will see market-hours timestamps.

### Pre-flight checker (belt AND suspenders)

Before any strategy thread starts, the orchestrator runs `_pre_flight_check()` which validates:

```
[PASS/FAIL] DataFeedAccount.account_name == "SIM_XTS"
[PASS/FAIL] DataFeedAccount.base_url starts with "http://127.0.0.1"
[PASS/FAIL] DataFeedAccount is active
[PASS/FAIL] dry_run=True in strategy_params for EVERY strategy being run
[PASS/WARN] SimClock active with simulated time
[WARN]      Any existing StrategyAccountMapping (advisory — dry_run blocks regardless)
```

If ANY `[FAIL]` check fails, the orchestrator prints a clear error and exits with code 1. Strategies never start.

---

## What it DOES touch

| What | Details | Reversible? |
|------|---------|-------------|
| `DataFeedProvider` table | Creates row `provider_name="XTS"` (get_or_create, likely already exists) | Harmless — already present in prod |
| `DataFeedAccount` table | Creates/updates row `account_name="SIM_XTS"` with `base_url=localhost`. On shutdown, sets `is_active=False`. | Yes — deactivated on exit. Delete row manually if desired. |
| `BrokerInstrument` table | Creates rows with `broker_name="XTS"` for all active NFO instruments (get_or_create) | These may already exist for real XTS. The simulator uses `instrument_token` as `broker_token`, which matches the real mapping. No harm if duplicates exist (unique constraint on broker_name+broker_token+broker_exchange). |
| `Strategy.strategy_params` | Adds `"dry_run": true` to the JSON params for each target strategy | **Important:** This persists after shutdown. You must manually set `dry_run=False` in the DB (or via Django admin) before running strategies in live mode. |
| TBT file | Writes to `src/system/dump/tbt_local/<YYYYMMDD>.txt` | Overwritten daily. Safe to delete. |
| Log files | Writes to `src/system/logs/strategy/<code>.log` (e.g., `orbsh.log`) | Appends to existing log files. No data loss. |
| stdout | Prints status blocks every 10 seconds | N/A |

## What it DOES NOT touch

- Real broker APIs (Zerodha, Upstox, XTS production servers)
- Real market data feeds (no network connections to XTS production)
- `ParentOrder` table (dry_run returns before order_manager is called)
- `BrokerOrder` table (no orders created)
- `StrategyPosition` table (dry_run returns before position tracking)
- `StrategyAccountMapping` table (no records created or read)
- `BrokerAccount` table (no records accessed)
- Network share (`\\10.211.8.76\...`) — `shutil.copy2` is patched to skip it
- WebSocket connections — `ws_manager=None`, never initialized

---

## Usage

### Prerequisites

1. PostgreSQL running locally (same DB as production — the simulator creates its own isolated records)
2. Django migrations up to date: `cd src/system && python manage.py migrate`
3. Strategy records must exist in the `strategies` table with `strategy_class` values matching: `ORBSH`, `GEXRT`, `IDXLS`, `IDXSH`
4. Active NFO `Instrument` records in the DB (options + futures with `expiry >= today`)

### How to run

```bash
# Activate venv
.venv\Scripts\activate

# Run with all 4 strategies at Nifty 24000 (default start: 09:16)
cd src/system
python -m simulator.orchestrator --spot 24000

# Run at a different simulated time (skip to signal phase)
python -m simulator.orchestrator --spot 24000 --start-time 11:20

# Run with custom volatility
python -m simulator.orchestrator --spot 24000 --sigma 0.20

# Run only specific strategies
python -m simulator.orchestrator --spot 24000 --strategies ORBSH GEXRT

# Test edge cases with fault injection
python -m simulator.orchestrator --spot 24000 --fault-scenario token_expiry

# Disable live status display
python -m simulator.orchestrator --spot 24000 --status-interval 0

# Status every 30 seconds instead of 10
python -m simulator.orchestrator --spot 24000 --status-interval 30

# Specific Scenario
python -m simulator.orchestrator --strategies IDXLS_SIM --spot 24100 --start-time 10:17 --date 2026-03-30
```

### CLI flags

| Flag | Required | Default | Description |
|------|----------|---------|-------------|
| `--spot` | Yes | — | Initial Nifty spot price (e.g. 24000) |
| `--sigma` | No | 0.15 | Annualized volatility for GBM simulation and Black-Scholes pricing |
| `--strategies` | No | All 4 | Space-separated strategy codes: `ORBSH GEXRT IDXLS IDXSH` |
| `--start-time` | No | 09:16 | Simulated market start time HH:MM (virtual clock offset) |
| `--fault-scenario` | No | None | Inject faults: `token_expiry`, `connection_drop`, `intermittent`, `sustained_401` |
| `--status-interval` | No | 10 | Seconds between status prints (0 to disable) |

### What you'll see on screen

```
============================================================
  Market Data Simulator
  Spot: 24000.0  |  Sigma: 0.15
  Strategies: ['ORBSH', 'GEXRT', 'IDXLS', 'IDXSH']
  Simulated start: 09:16:00
============================================================

[SimClock] Activated: real time 20:00:00 -> simulated 09:16:00 (offset: -10:44:00)
[SimClock] Installed: patched 8 modules, django.utils.timezone.now: yes
[orchestrator] PriceEngine initialized -- spot=24000.0, sigma=0.15
[MockXTSServer] Listening on http://127.0.0.1:54321
[orchestrator] DB seeded -- 4832 instruments in registry
...
[pre-flight] Running isolation checks...
  [PASS] DataFeedAccount is 'SIM_XTS'
  [PASS] base_url -> http://127.0.0.1:54321
  [PASS] Account active, token_expiry=2027-03-26 ...
  [PASS] Strategy 'ORBSH': dry_run=True confirmed
  [PASS] SimClock active -- simulated time: 09:16:02
[pre-flight] All checks passed -- safe to run.
```

Then every 10 seconds:

```
==========================================================
  SIMULATOR STATUS  [sim: 09:26:15  real: 20:10:15]
==========================================================
  PRICE ENGINE
    Spot:        24113.5  (initial: 24000.0  drift: +0.47%)

  TBT WRITER
    Ticks:    600 written  |  last: 0.8s ago  |  errors: 0
    File:     ...tbt_local/20260326.txt

  MOCK XTS SERVER  [127.0.0.1:54321]
    Logins:   1  |  Quote requests: 1200  |  Quotes served: 60000

  STRATEGIES
    ORBSH  [ALIVE]  thread: strategy-orbsh
    GEXRT  [ALIVE]  thread: strategy-gexrt
    IDXLS  [ALIVE]  thread: strategy-idxls
    IDXSH  [ALIVE]  thread: strategy-idxsh

  ISOLATION
    dry_run:  True on all strategies
    account:  SIM_XTS -> http://127.0.0.1:54321
    clock:    sim=09:26:15 real=20:10:15 offset=-10:44:00
==========================================================
```

### Monitoring in detail

**Live status** (stdout): Shows sim vs real time, spot price drift, TBT tick freshness, mock server request counts, fault injection count, and whether each strategy thread is alive or dead.

**Strategy logs** (one per strategy): Each strategy writes to its own log file in `src/system/logs/strategy/`. Open another terminal and run:
```bash
tail -f src/system/logs/strategy/orbsh.log
```

You'll see strategy-specific logs including `[DRY-RUN]` entries when the strategy would have placed an order:
```
2026-03-26 09:42:15 | INFO | strategy/orb_short.py:447 | _place_order |
  [DRY-RUN][CE_ENTRY] ENTRY SELL 25 x NIFTY26MAR24050CE | LIMIT @ 145.30 | NRML | expiry=2026-03-26
```

---

## Cleanup

### On Ctrl+C (graceful shutdown)

The orchestrator shuts down in order:
1. Calls `stop()` on each strategy instance (signals them to exit their `run()` loop)
2. Waits up to 10s per strategy thread to join
3. Stops TBTWriter (restores original `shutil.copy2`)
4. Stops MockXTSServer
5. Uninstalls SimClock (restores original `datetime`/`timezone` references)
6. Calls `teardown_simulator_db()` which sets `DataFeedAccount("SIM_XTS").is_active = False`

### What persists after exit

| Record | Persists? | How to clean up |
|--------|-----------|-----------------|
| `DataFeedAccount("SIM_XTS")` | Yes (with `is_active=False`) | `DELETE FROM datafeed_datafeedaccount WHERE account_name='SIM_XTS';` |
| `DataFeedProvider("XTS")` | Yes (was likely already there) | Leave it |
| `BrokerInstrument` rows | Yes | Leave them (harmless, may overlap with real XTS records) |
| `Strategy.strategy_params.dry_run` | **Yes -- stays True** | **Must manually set to False before going live** |
| TBT file (`dump/tbt_local/`) | Yes | Safe to delete, overwritten daily |
| Log files | Yes (appended) | Safe to leave |

### IMPORTANT: Re-enabling live trading after simulation

```sql
-- Remove dry_run from each strategy you want to trade live
UPDATE strategies SET strategy_params = strategy_params - 'dry_run'
WHERE strategy_class IN ('ORBSH', 'GEXRT', 'IDXLS', 'IDXSH');
```

Or via Django admin: edit each Strategy, remove `"dry_run": true` from `strategy_params` JSON.

---

## Troubleshooting

### "TBT REJECTED (stale)" in strategy logs

The TBT staleness check rejects ticks older than 120 seconds. Causes:
- **SimClock not active or wrong start time**. Check stdout for `[SimClock] Activated` line. The TBT timestamps must fall within 09:15-15:30 simulated time.
- **TBTWriter thread crashed**. Check stdout for `[TBTWriter] ERROR` lines. The status display shows `errors: N`.

### "No Strategy record with strategy_class='XXXX' found"

The `strategies` table has no row where `strategy_class = 'XXXX'`. Create one via Django admin or:
```sql
INSERT INTO strategies (strategy_code, strategy_name, description, entry_time, exit_time, strategy_params, strategy_class)
VALUES ('ORBSH', 'ORB Short', 'Opening Range Breakout Short', '09:15', '15:30', '{}', 'ORBSH');
```

### Pre-flight check fails with "[FAIL] dry_run is NOT set"

This should never happen — `setup_strategy_params()` runs before the pre-flight check. If it does:
1. The Strategy record exists but `strategy_class` doesn't match the code being passed
2. Check: `SELECT strategy_code, strategy_class, strategy_params FROM strategies;`

### "ModuleNotFoundError: No module named 'system.settings'"

You're running from the wrong directory. Must run from `src/system`:
```bash
cd src/system
python -m simulator.orchestrator --spot 24000
```

### Mock server returns empty quotes for an instrument

The instrument's `broker_token` is not in the registry. This means either:
- The `Instrument` record has `is_active=False` or `expiry < today`
- The instrument is not in NFO exchange
- `db_setup.py` didn't find it during seeding

Check: `SELECT COUNT(*) FROM instrument WHERE exchange='NFO' AND is_active=True AND expiry >= CURRENT_DATE;`

### Strategy thread shows [DEAD !!] in status

The strategy's `run()` method exited — either crashed or finished. Check the strategy's log file:
```bash
tail -100 src/system/logs/strategy/orbsh.log
```

Common causes: missing instrument data, `marketdata` library connection failure during warmup, unhandled exception in strategy logic.

### How to verify nothing was affected

After a simulation run, confirm:
```sql
-- No orders created during the sim window
SELECT COUNT(*) FROM parent_orders WHERE created_at > NOW() - INTERVAL '1 hour';
-- Should be 0 (or only orders from other sources)

-- No broker orders
SELECT COUNT(*) FROM broker_orders WHERE created_at > NOW() - INTERVAL '1 hour';
-- Should be 0

-- SIM account is deactivated
SELECT account_name, is_active, base_url FROM datafeed_datafeedaccount WHERE account_name = 'SIM_XTS';
-- is_active should be False after shutdown
```

---

## Price engine details

For the curious — how fake prices are generated:

- **Spot**: Geometric Brownian Motion. Each second: `S = S * exp((r - 0.5*sigma^2)*dt + sigma*sqrt(dt)*Z)` where Z ~ N(0,1). Hard-clamped to [initial_spot * 0.97, initial_spot * 1.03].
- **Options**: Black-Scholes formula (same `_bs_call`/`_bs_put` from `gex_regime_trader.py`). Uses the same sigma (default 0.15) that GEX will invert via its IV solver — so the solver always recovers sigma ~= 0.15 (mathematically guaranteed).
- **Futures**: `spot * exp(r * T/365)`. With default r=0, equals spot.
- **OI**: Gaussian distribution centered at ATM (initial spot). Cached per session (static).
- **Volume**: Monotonically increasing counter per instrument. Increments by 50-500 on each query.
