"""
DB Setup — seeds the database for simulation.

Creates a DataFeedAccount pointing at the mock XTS server, seeds BrokerInstrument
records for all active NFO instruments, and sets dry_run on the target strategies.

Run once before strategies are instantiated. Idempotent (get_or_create everywhere).
"""
import os
import sys

# Ensure Django is configured before any model imports
_SYSTEM_DIR = os.path.join(os.path.dirname(__file__), '..', 'system')
sys.path.insert(0, os.path.abspath(_SYSTEM_DIR))

import django
import django.conf
if not django.conf.settings.configured:
    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "system.settings")
    django.setup()

from datetime import date
from django.utils import timezone

from datafeed.models import DataFeedProvider, DataFeedAccount
from instruments.models import Instrument, BrokerInstrument
from strategy.models import Strategy


# ── Constants ─────────────────────────────────────────────────────────────────

SIM_ACCOUNT_NAME = "SIM_XTS"
SIM_BROKER_NAME = "XTS"
SIM_EXCHANGE = "NSEFO"
SIM_EXCHANGE_SEGMENT_CODE = 2   # XTS code for NSEFO


# ── Main setup ────────────────────────────────────────────────────────────────

def setup_simulator_db(mock_server_port: int) -> tuple:
    """
    Seed the DB for simulation. Returns (DataFeedAccount, instrument_registry).

    instrument_registry: { broker_token (int) -> {
        "instrument_token": int,
        "strike": float,
        "option_type": str,
        "expiry": date | None,
        "instrument_type": str,
        "exchange_segment_code": int,
    } }
    """
    # ── DataFeedProvider ──────────────────────────────────────────────────────
    provider, _ = DataFeedProvider.objects.get_or_create(provider_name="XTS")

    # ── DataFeedAccount ───────────────────────────────────────────────────────
    base_url = f"http://127.0.0.1:{mock_server_port}"
    token_expiry = timezone.now() + timezone.timedelta(days=365)

    account, created = DataFeedAccount.objects.get_or_create(
        account_name=SIM_ACCOUNT_NAME,
        defaults={
            "provider": provider,
            "client_id": "sim_client",
            "api_key": "sim_api_key",
            "api_secret": "sim_api_secret",
            "access_token": "SIM_TOKEN_INITIAL",
            "token_expiry": token_expiry,
            "is_active": True,
            "base_url": base_url,
            "extra_data": {},   # NO hostlookup key — critical
        },
    )

    if not created:
        # Update mutable fields in case port changed or was previously torn down
        account.provider = provider
        account.base_url = base_url
        account.access_token = "SIM_TOKEN_INITIAL"
        account.token_expiry = token_expiry
        account.is_active = True
        account.extra_data = {}
        account.save(update_fields=["provider", "base_url", "access_token", "token_expiry", "is_active", "extra_data", "updated_at"])

    print(f"[db_setup] DataFeedAccount '{SIM_ACCOUNT_NAME}' {'created' if created else 'updated'} → {base_url}")

    # ── BrokerInstruments ─────────────────────────────────────────────────────
    today = date.today()

    # Build registry keyed by BrokerInstrument.broker_token (the value the XTS
    # handler sends as exchangeInstrumentID). For NFO CE/PE/FUT with expiry>=today.
    broker_insts = BrokerInstrument.objects.filter(
        broker_name=SIM_BROKER_NAME,
        is_active=True,
        instrument__exchange="NFO",
        instrument__is_active=True,
        instrument__instrument_type__in=("CE", "PE", "FUT"),
        instrument__expiry__gte=today,
    ).select_related("instrument")

    registry: dict[int, dict] = {}
    skipped = 0

    for bi in broker_insts:
        try:
            token = int(bi.broker_token)
        except (TypeError, ValueError):
            skipped += 1
            continue
        inst = bi.instrument
        strike = float(inst.strike) if inst.strike is not None else 0.0
        registry[token] = {
            "instrument_token": inst.instrument_token,
            "strike": strike,
            "option_type": inst.instrument_type,
            "expiry": inst.expiry,
            "instrument_type": inst.instrument_type,
            "exchange_segment_code": SIM_EXCHANGE_SEGMENT_CODE,
        }

    print(f"[db_setup] Registry built in-memory: {len(registry)} instruments "
          f"(skipped {skipped} non-numeric broker_tokens; no DB writes)")
    return account, registry


def setup_strategy_params(strategy_codes: list[str]) -> dict:
    """
    Set dry_run=True in strategy_params for each strategy class code.
    Only updates existing Strategy records — does NOT create new ones.
    Returns dict of {code -> updated} booleans.
    """
    results = {}
    for code in strategy_codes:
        try:
            strat = Strategy.objects.get(strategy_code=code)
            params = strat.strategy_params or {}
            if not params.get("dry_run"):
                params["dry_run"] = True
                strat.strategy_params = params
                strat.save(update_fields=["strategy_params"])
                print(f"[db_setup] Strategy '{code}': dry_run=True set")
            else:
                print(f"[db_setup] Strategy '{code}': dry_run already True")
            results[code] = True
        except Strategy.DoesNotExist:
            print(f"[db_setup] WARNING: No Strategy with strategy_code='{code}' found in DB — skipping")
            results[code] = False
    return results


def teardown_simulator_db() -> None:
    """Deactivate the SIM_XTS DataFeedAccount on clean shutdown."""
    try:
        account = DataFeedAccount.objects.get(account_name=SIM_ACCOUNT_NAME)
        account.is_active = False
        account.save(update_fields=["is_active", "updated_at"])
        print(f"[db_setup] DataFeedAccount '{SIM_ACCOUNT_NAME}' deactivated")
    except DataFeedAccount.DoesNotExist:
        pass
