"""
Virtual Clock for post-market-hours simulation.

Shifts wall-clock time so strategies think it's market hours (09:15–15:30 IST).
Time advances at real speed: 1 real second = 1 simulated second.

How it works:
    Real time:  20:00:00 (8 PM)
    Start time: 09:15:01 (configured)
    Offset:     -10h44m
    → datetime.now() returns 09:16:00 and ticks forward normally

Usage:
    SimClock.activate(start_time=time(9, 16))
    SimClock.install()   # patches datetime/date/timezone in strategy modules
    ...
    SimClock.uninstall() # restores originals
"""
from datetime import datetime, date, time as dt_time, timedelta
import threading
from typing import Optional


# Save REAL references before anything gets patched
_real_datetime_class = datetime
_real_date_class = date


class FakeDatetime(datetime):
    """datetime subclass where .now() returns offset time."""
    _offset: timedelta = timedelta(0)

    @classmethod
    def now(cls, tz=None):
        real = _real_datetime_class.now(tz)
        return real + cls._offset

    # strptime must return real datetime, not FakeDatetime, to avoid issues
    # with pandas and other libraries that check exact types
    @classmethod
    def strptime(cls, date_string, fmt):
        return _real_datetime_class.strptime(date_string, fmt)


class FakeDate(date):
    """date subclass where .today() returns the date consistent with FakeDatetime.now()."""

    @classmethod
    def today(cls):
        return FakeDatetime.now().date()


class SimClock:
    """
    Virtual clock manager. Call activate() then install() before starting strategies.
    """
    _offset: timedelta = timedelta(0)
    _active: bool = False
    _patched_modules: list = []
    _original_tz_now = None

    @classmethod
    def activate(cls, start_time: Optional[dt_time] = None, start_date: Optional[date] = None):
        """
        Compute the time offset so that datetime.now() returns start_time on start_date.

        Args:
            start_time: Target simulated time (default: 09:15:01)
            start_date: Target simulated date (default: today)
        """
        if start_time is None:
            start_time = dt_time(9, 15, 1)

        real_now = _real_datetime_class.now()
        
        # Determine target date
        target_date = start_date if start_date is not None else real_now.date()
        
        target_dt = _real_datetime_class.combine(target_date, start_time)
        
        cls._offset = target_dt - real_now
        FakeDatetime._offset = cls._offset
        cls._active = True

        simulated_now = real_now + cls._offset
        print(f"[SimClock] Activated: real time {real_now.strftime('%Y-%m-%d %H:%M:%S')} "
              f"→ simulated {simulated_now.strftime('%Y-%m-%d %H:%M:%S')} "
              f"(offset: {cls._offset})")

    @classmethod
    def now(cls, tz=None) -> datetime:
        """Get current simulated time."""
        return _real_datetime_class.now(tz) + cls._offset

    @classmethod
    def real_now(cls) -> datetime:
        """Get actual wall-clock time (for logging/debugging)."""
        return _real_datetime_class.now()

    @classmethod
    def install(cls):
        """
        Monkey-patch datetime/date/timezone.now in all strategy and datafeed modules.
        Must be called AFTER all modules are imported but BEFORE strategies run.
        """
        import importlib

        # ── Strategy modules to patch ──────────────────────────────────────
        strategy_modules = [
            "strategy.strategy_class.orb_short",
            "strategy.strategy_class.gex_regime_trader",
            "strategy.strategy_class.index_long_short",
            "strategy.strategy_class.index_short",
            "strategy.strategy_class.vol_trading_new",
            "strategy.strategy_class.covered_call",
            "strategy.strategy_class.index_mom_long_short_asymm",
            "strategy.strategy_class.state_machine_strangle",
            "strategy.strategy_class.hedged_otm_strangle",
            "strategy.strategy_class.base_strategy",
        ]

        # ── Datafeed modules (used by strategies at runtime) ──────────────
        datafeed_modules = [
            "datafeed.rest.xts",
            "datafeed.rest.handler",
            "datafeed.rest.data_types",
            "utils.ttm_helper",
        ]

        # ── Simulator modules (our own files need sim time too) ───────────
        simulator_modules = [
            "simulator.price_engine",
            "simulator.tbt_writer",
            "simulator.mock_xts_server",
        ]

        all_modules = strategy_modules + datafeed_modules + simulator_modules
        cls._patched_modules = []

        import sys
        for mod_name in all_modules:
            mod = sys.modules.get(mod_name)
            if mod is None:
                try:
                    mod = importlib.import_module(mod_name)
                except ImportError:
                    continue

            originals = {}

            # Patch datetime class (for .now() calls)
            if hasattr(mod, "datetime") and mod.datetime is _real_datetime_class:
                originals["datetime"] = mod.datetime
                mod.datetime = FakeDatetime

            # Patch date class (for .today() calls)
            if hasattr(mod, "date") and mod.date is _real_date_class:
                originals["date"] = mod.date
                mod.date = FakeDate

            if originals:
                cls._patched_modules.append((mod, originals))

        # ── Patch django.utils.timezone.now ────────────────────────────────
        try:
            import django.utils.timezone as tz_mod
            cls._original_tz_now = tz_mod.now

            def _patched_tz_now():
                return cls._original_tz_now() + cls._offset

            tz_mod.now = _patched_tz_now
        except ImportError:
            pass

        patched_count = len(cls._patched_modules)
        tz_patched = "yes" if cls._original_tz_now else "no"
        print(f"[SimClock] Installed: patched {patched_count} modules, "
              f"django.utils.timezone.now: {tz_patched}")

    @classmethod
    def uninstall(cls):
        """Restore all original datetime/date/timezone references."""
        for mod, originals in cls._patched_modules:
            for attr, original_val in originals.items():
                setattr(mod, attr, original_val)
        cls._patched_modules = []

        if cls._original_tz_now is not None:
            try:
                import django.utils.timezone as tz_mod
                tz_mod.now = cls._original_tz_now
            except ImportError:
                pass
            cls._original_tz_now = None

        cls._active = False
        print("[SimClock] Uninstalled: all originals restored")

    @classmethod
    def is_active(cls) -> bool:
        return cls._active

    @classmethod
    def get_offset(cls) -> timedelta:
        return cls._offset
