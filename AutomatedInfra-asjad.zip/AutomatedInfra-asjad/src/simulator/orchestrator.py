"""
Market Data Simulator — Orchestrator

Wires all simulator components and runs the 4 production strategies against
fake market data, without modifying any strategy code.

Usage:
    cd src/system
    python -m simulator.orchestrator --spot 24000 [--start-time 09:16] [--strategies ORBSH GEXRT]

Works ANY time of day — the virtual clock shifts wall time into market hours.
All strategies run in dry_run mode (no real orders placed).
Press Ctrl+C to stop cleanly.
"""
import argparse
import os
import signal
import sys
import threading
import time
from datetime import datetime as _real_datetime, time as dt_time, date

# ── Django bootstrap ──────────────────────────────────────────────────────────
_SYSTEM_DIR = os.path.join(os.path.dirname(__file__), '..', 'system')
sys.path.insert(0, os.path.abspath(_SYSTEM_DIR))

import django
import django.conf
if not django.conf.settings.configured:
    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "system.settings")
    django.setup()

# ── Simulator imports (after Django setup) ────────────────────────────────────
from simulator.price_engine import PriceEngine
from simulator.tbt_writer import TBTWriter, LOCAL_TBT_DIR
from simulator.mock_xts_server import MockXTSServer
from simulator.db_setup import setup_simulator_db, setup_strategy_params, teardown_simulator_db, SIM_ACCOUNT_NAME
from simulator.sim_clock import SimClock

# ── Strategy imports ──────────────────────────────────────────────────────────
from strategy.strategy_class.orb_short import OrbShort
from strategy.strategy_class.gex_regime_trader import GexRegimeTrader
from strategy.strategy_class.index_long_short import IndexLongShort
from strategy.strategy_class.index_short import IndexShort
from strategy.strategy_class.vol_trading_new import VolLongShort
from strategy.strategy_class.covered_call import CoveredCall
from strategy.strategy_class.index_mom_long_short_asymm import IndexMomLongShort
from strategy.strategy_class.hedged_otm_strangle import HedgedOtmStrangle
from strategy.strategy_class.state_machine_strangle import StateMachineShortStrangle
from strategy.models import Strategy

# Strategy class registry — same codes as StrategyManager
_STRATEGY_CLASSES = {
    "ORBSH": OrbShort,
    "GEXRT": GexRegimeTrader,
    "IDXLS": IndexLongShort,
    "IDXSH": IndexShort,
    "IDXMA": IndexMomLongShort,
    "VOLLS": VolLongShort,
    "CCALL": CoveredCall,
    "HOTMS": HedgedOtmStrangle,
    "SMSS": StateMachineShortStrangle,
}

# Log directory relative to src/system
_LOG_DIR = os.path.join(os.path.abspath(_SYSTEM_DIR), "logs", "strategy")

# ── Fault injection scenarios ─────────────────────────────────────────────────
# Each scenario maps to a list of (count, fault_type) tuples consumed sequentially.
# count = number of consecutive quote requests to fail; -1 = perpetual.
# Supported fault types: "http_400", "http_401", "unauthorized_plain", "drop"

_FAULT_SCENARIOS = [
    "token_expiry",       # 3x 401 → normal (tests token refresh + retry)
    "connection_drop",    # 3x drop → normal (tests ConnectionError retry)
    "intermittent",       # mixed: 2x 401, 5 normal, 2x drop, 5 normal, 2x 401, then normal
    "sustained_401",      # perpetual 401 (tests strategy giving up gracefully)
]


def _build_fault_schedule(scenario: str) -> list[tuple[int, str]]:
    """Convert a named scenario into a fault schedule for MockXTSServer."""
    if scenario == "token_expiry":
        # 3 consecutive 401s then back to normal
        return [(3, "http_401")]
    elif scenario == "connection_drop":
        # 3 consecutive connection drops then back to normal
        return [(3, "drop")]
    elif scenario == "intermittent":
        # Alternating faults and normal periods
        # (normal periods happen automatically when schedule is empty between entries)
        return [
            (2, "http_401"),
            (2, "drop"),
            (2, "unauthorized_plain"),
        ]
    elif scenario == "sustained_401":
        # Perpetual 401 — never recovers
        return [(-1, "http_401")]
    else:
        print(f"[orchestrator] WARNING: Unknown fault scenario '{scenario}'")
        return []


def _parse_time(s: str) -> dt_time:
    """Parse HH:MM or HH:MM:SS string to time object."""
    parts = s.split(":")
    if len(parts) == 2:
        return dt_time(int(parts[0]), int(parts[1]), 0)
    elif len(parts) == 3:
        return dt_time(int(parts[0]), int(parts[1]), int(parts[2]))
    raise argparse.ArgumentTypeError(f"Invalid time format '{s}'. Use HH:MM or HH:MM:SS")


def main():
    parser = argparse.ArgumentParser(description="Market Data Simulator")
    parser.add_argument("--spot", type=float, required=True, help="Initial Nifty spot price (e.g. 24000)")
    parser.add_argument("--sigma", type=float, default=0.15, help="Annualized volatility for GBM + BS pricing (default: 0.15)")
    parser.add_argument("--strategies", nargs="+", required=True,
                        help="Strategy codes to run, by DB strategy_code field (e.g. IDXLS_SIM ORBSH_SIM)")
    parser.add_argument("--start-time", type=_parse_time, default="09:16",
                        help="Simulated market start time HH:MM (default: 09:16, just after open)")
    parser.add_argument("--date", type=date.fromisoformat, default=None,
                        help="Simulated market date YYYY-MM-DD (default: today)")
    parser.add_argument("--status-interval", type=int, default=10,
                        help="Seconds between live status prints (default: 10, 0=off)")
    parser.add_argument("--fault-scenario", type=str, default=None, choices=_FAULT_SCENARIOS,
                        help=f"Inject faults into mock server: {_FAULT_SCENARIOS}")
    args = parser.parse_args()

    strategy_codes = [c.upper() for c in args.strategies]

    print(f"\n{'=' * 60}")
    print(f"  Market Data Simulator")
    print(f"  Spot: {args.spot}  |  Sigma: {args.sigma}")
    print(f"  Strategies: {strategy_codes}")
    print(f"  Simulated start: {args.start_time.strftime('%H:%M:%S')}")
    if args.fault_scenario:
        print(f"  Fault scenario: {args.fault_scenario}")
    print(f"{'=' * 60}\n")

    # ── Step 1: Activate virtual clock ────────────────────────────────────────
    SimClock.activate(start_time=args.start_time, start_date=args.date)
    SimClock.install()

    # ── Step 2: Price Engine ──────────────────────────────────────────────────
    engine = PriceEngine(initial_spot=args.spot, sigma=args.sigma)
    print(f"[orchestrator] PriceEngine initialized — spot={args.spot}, sigma={args.sigma}")

    # ── Step 3: Mock XTS Server (port=0 → OS picks a free port) ──────────────
    mock_server = MockXTSServer(price_engine=engine, port=0)
    port = mock_server.start()

    # ── Step 4: Seed DB ───────────────────────────────────────────────────────
    print("[orchestrator] Seeding database...")
    datafeed_account, registry = setup_simulator_db(port)
    print(f"[orchestrator] DB seeded — {len(registry)} instruments in registry")

    # ── Step 5: Give registry to mock server ─────────────────────────────────
    mock_server.update_registry(registry)
    print("[orchestrator] Instrument registry loaded into mock server")

    # ── Step 5.5: Load fault schedule if requested ───────────────────────
    if args.fault_scenario:
        schedule = _build_fault_schedule(args.fault_scenario)
        mock_server.load_fault_schedule(schedule)

    # ── Step 6: Set dry_run on strategies ────────────────────────────────────
    print("[orchestrator] Setting dry_run=True on target strategies...")
    setup_strategy_params(strategy_codes)

    # ── Step 7: Pre-flight safety checks ─────────────────────────────────────
    _pre_flight_check(strategy_codes, datafeed_account)

    # ── Step 8: Start TBT writer ──────────────────────────────────────────────
    tbt_writer = TBTWriter(price_engine=engine, write_interval=1.0)
    tbt_writer.start()
    print("[orchestrator] TBTWriter started — writing ticks every 1s, shutil.copy2 patched")

    # ── Step 9: Let TBT file accumulate a few ticks ───────────────────────────
    print("[orchestrator] Waiting 5s for TBT file to accumulate initial ticks...")
    time.sleep(5)

    # ── Step 10: Instantiate and run strategies ───────────────────────────────
    strategy_instances = []
    strategy_threads = []

    for code in strategy_codes:
        try:
            strat_obj = Strategy.objects.get(strategy_code=code)
        except Strategy.DoesNotExist:
            print(f"[orchestrator] WARNING: No Strategy record with strategy_code='{code}' found — skipping")
            continue

        class_code = strat_obj.strategy_class
        if class_code not in _STRATEGY_CLASSES:
            print(f"[orchestrator] ERROR: strategy_class='{class_code}' for '{code}' is not a supported simulator class. "
                  f"Valid: {list(_STRATEGY_CLASSES)}")
            continue

        strat_class = _STRATEGY_CLASSES[class_code]
        try:
            instance = strat_class(strat_obj, datafeed_account, ws_manager=None)
        except Exception as e:
            print(f"[orchestrator] ERROR instantiating {code}: {e}")
            continue

        t = threading.Thread(
            target=instance.run,
            daemon=True,
            name=f"strategy-{code.lower()}",
        )
        t.start()
        strategy_instances.append((code, instance))
        strategy_threads.append(t)
        print(f"[orchestrator] Strategy {code} ({strat_obj.strategy_name}) started in thread")

    if not strategy_instances:
        print("[orchestrator] No strategies running — exiting")
        _shutdown(tbt_writer, mock_server, [], [])
        SimClock.uninstall()
        return

    # Print log file locations
    print(f"\n[orchestrator] Strategy log files (tail -f to follow):")
    for code, _ in strategy_instances:
        log_path = os.path.join(_LOG_DIR, f"{code.lower()}.log")
        print(f"  {log_path}")
    print()

    print(f"[orchestrator] {len(strategy_instances)} strategies running. Press Ctrl+C to stop.\n")

    # ── Step 11: Start status display ─────────────────────────────────────────
    stop_event = threading.Event()

    if args.status_interval > 0:
        status_thread = threading.Thread(
            target=_status_display_loop,
            args=(engine, tbt_writer, mock_server, strategy_instances, strategy_threads,
                  args.spot, stop_event, args.status_interval),
            daemon=True,
            name="status-display",
        )
        status_thread.start()

    # ── Step 12: Wait for SIGINT/SIGTERM ──────────────────────────────────────
    def _signal_handler(sig, frame):
        print(f"\n[orchestrator] Signal {sig} received — initiating shutdown...")
        stop_event.set()

    signal.signal(signal.SIGINT, _signal_handler)
    signal.signal(signal.SIGTERM, _signal_handler)

    stop_event.wait()

    # ── Shutdown ──────────────────────────────────────────────────────────────
    instances_only = [inst for _, inst in strategy_instances]
    _shutdown(tbt_writer, mock_server, instances_only, strategy_threads)
    SimClock.uninstall()
    teardown_simulator_db()
    print("[orchestrator] Shutdown complete.")


# ── Pre-flight safety checker ─────────────────────────────────────────────────

def _pre_flight_check(strategy_codes: list[str], datafeed_account) -> None:
    """
    Validate isolation before strategies start. Aborts with sys.exit(1) on any FAIL.
    """
    from accounts.models import StrategyAccountMapping
    from strategy.models import Strategy

    print("\n[pre-flight] Running isolation checks...")
    failures = []

    # 1. DataFeedAccount must be SIM_XTS
    if datafeed_account.account_name != SIM_ACCOUNT_NAME:
        failures.append(f"  [FAIL] DataFeedAccount is '{datafeed_account.account_name}', expected '{SIM_ACCOUNT_NAME}'")
    else:
        print(f"  [PASS] DataFeedAccount is '{SIM_ACCOUNT_NAME}'")

    # 2. base_url must point to localhost
    base_url = datafeed_account.base_url or ""
    if not base_url.startswith("http://127.0.0.1"):
        failures.append(f"  [FAIL] base_url '{base_url}' does not point to 127.0.0.1 — would hit a real server")
    else:
        print(f"  [PASS] base_url → {base_url}")

    # 3. Account must be active and token not expired
    if not datafeed_account.is_active:
        failures.append(f"  [FAIL] DataFeedAccount is_active=False")
    else:
        print(f"  [PASS] Account active, token_expiry={datafeed_account.token_expiry}")

    # 4. dry_run=True must be set for every strategy being run
    for code in strategy_codes:
        try:
            strat = Strategy.objects.get(strategy_code=code)
            params = strat.strategy_params or {}
            if not params.get("dry_run"):
                failures.append(f"  [FAIL] Strategy '{code}': dry_run is NOT set in strategy_params — real orders possible")
            else:
                print(f"  [PASS] Strategy '{code}': dry_run=True confirmed")
        except Strategy.DoesNotExist:
            print(f"  [SKIP] Strategy '{code}': no DB record found")

    # 5. WARN if StrategyAccountMapping exists
    for code in strategy_codes:
        try:
            strat = Strategy.objects.get(strategy_code=code)
            mapping_count = StrategyAccountMapping.objects.filter(strategy=strat, is_active=True).count()
            if mapping_count > 0:
                print(f"  [WARN] Strategy '{code}' has {mapping_count} active StrategyAccountMapping(s). "
                      f"dry_run=True blocks order_manager, but verify before going live.")
        except Strategy.DoesNotExist:
            pass

    # 6. Sim clock must be active
    if SimClock.is_active():
        sim_now = SimClock.now()
        print(f"  [PASS] SimClock active — simulated time: {sim_now.strftime('%H:%M:%S')}")
    else:
        print(f"  [WARN] SimClock not active — will only work during market hours")

    if failures:
        print("\n[pre-flight] ISOLATION CHECKS FAILED — aborting to protect production:\n")
        for f in failures:
            print(f)
        print()
        sys.exit(1)

    print("[pre-flight] All checks passed — safe to run.\n")


# ── Live status display ───────────────────────────────────────────────────────

def _status_display_loop(engine, tbt_writer, mock_server, strategy_instances,
                          strategy_threads, initial_spot, stop_event, interval):
    """Background thread that prints a status block every `interval` seconds."""
    while not stop_event.wait(timeout=interval):
        try:
            _print_status(engine, tbt_writer, mock_server, strategy_instances,
                          strategy_threads, initial_spot)
        except Exception as e:
            print(f"[status] Error rendering status: {e}")


def _print_status(engine, tbt_writer, mock_server, strategy_instances, strategy_threads, initial_spot):
    tbt_stats = tbt_writer.get_stats()
    xts_stats = mock_server.get_stats()
    spot = engine.get_spot()
    drift_pct = (spot - initial_spot) / initial_spot * 100

    sim_now = SimClock.now() if SimClock.is_active() else _real_datetime.now()
    real_now = _real_datetime.now()
    sim_str = sim_now.strftime("%H:%M:%S")
    real_str = real_now.strftime("%H:%M:%S")
    sep = "=" * 58

    lines = [
        "",
        sep,
        f"  SIMULATOR STATUS  [sim: {sim_str}  real: {real_str}]",
        sep,
        "  PRICE ENGINE",
        f"    Spot:     {spot:>10.1f}  (initial: {initial_spot:.1f}  drift: {drift_pct:+.2f}%)",
        "",
        "  TBT WRITER",
    ]

    tick_age = tbt_stats.get("last_tick_age_secs")
    tick_age_str = f"{tick_age:.1f}s ago" if tick_age is not None else "n/a"
    lines.append(
        f"    Ticks:    {tbt_stats['ticks_written']} written  |  "
        f"last: {tick_age_str}  |  errors: {tbt_stats['failure_count']}"
    )
    today_file = sim_now.strftime("%Y%m%d") + ".txt"
    lines.append(f"    File:     ...tbt_local/{today_file}")

    lines += [
        "",
        f"  MOCK XTS SERVER  [127.0.0.1:{xts_stats['port']}]",
        f"    Logins:   {xts_stats['login_requests']}  |  "
        f"Quote requests: {xts_stats['quote_requests']}  |  "
        f"Quotes served: {xts_stats['total_quotes_served']}",
        "",
        "  STRATEGIES",
    ]

    all_alive = True
    for (code, _inst), thread in zip(strategy_instances, strategy_threads):
        alive = thread.is_alive()
        if not alive:
            all_alive = False
        status = "[ALIVE]" if alive else "[DEAD !!]"
        lines.append(f"    {code:<6} {status}  thread: {thread.name}")

    lines += [
        "",
        "  ISOLATION",
        f"    dry_run:  True on all strategies",
        f"    account:  SIM_XTS -> http://127.0.0.1:{xts_stats['port']}",
        f"    clock:    sim={sim_str} real={real_str} offset={SimClock.get_offset()}",
        sep,
        "",
    ]

    print("\n".join(lines))


# ── Shutdown ──────────────────────────────────────────────────────────────────

def _shutdown(tbt_writer, mock_server, strategy_instances, strategy_threads):
    """Ordered shutdown: strategies -> TBT writer -> mock server."""
    print("[orchestrator] Stopping strategies...")
    for instance in strategy_instances:
        try:
            instance.stop()
        except Exception as e:
            print(f"[orchestrator] Error stopping strategy {instance}: {e}")

    for t in strategy_threads:
        t.join(timeout=10.0)
        if t.is_alive():
            print(f"[orchestrator] WARNING: Thread {t.name} did not stop within 10s")

    print("[orchestrator] Stopping TBT writer...")
    try:
        tbt_writer.stop()
    except Exception as e:
        print(f"[orchestrator] Error stopping TBTWriter: {e}")

    print("[orchestrator] Stopping mock XTS server...")
    try:
        mock_server.stop()
    except Exception as e:
        print(f"[orchestrator] Error stopping MockXTSServer: {e}")


if __name__ == "__main__":
    main()
