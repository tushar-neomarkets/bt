"""
Price Engine — single source of truth for all simulated market prices.
Thread-safe: all state protected by threading.RLock.
"""
import math
import random
import threading
from datetime import date, datetime
from typing import Optional


# Import BS formulas from the GEX strategy
# These are module-level functions: _bs_call(S, K, r, T, sigma), _bs_put(S, K, r, T, sigma)
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'system'))
from strategy.strategy_class.gex_regime_trader import _bs_call, _bs_put


class PriceEngine:
    """
    Generates consistent simulated prices for spot, options, futures, OI, and volume.

    - Spot: Geometric Brownian Motion, clamped within ±3% of initial_spot
    - Options: Black-Scholes from current spot (same sigma used for pricing and GEX IV inversion)
    - Futures: spot * exp(r * T/365)
    - OI: static Gaussian distribution centered at ATM, cached on first access
    - Volume: monotonically increasing counter per instrument
    """

    # GBM: simulate at 1-second resolution. dt = 1s / (252 trading days * 6.5 hours * 3600s)
    _DT_SECONDS = 1.0
    _SECONDS_PER_YEAR = 252 * 6.5 * 3600  # ~5,896,800

    def __init__(self, initial_spot: float, sigma: float = 0.15, r: float = 0.0):
        self._lock = threading.RLock()
        self._initial_spot = initial_spot
        self._spot = initial_spot
        self._sigma = sigma          # annualized vol
        self._r = r                  # risk-free rate
        self._dt = self._DT_SECONDS / self._SECONDS_PER_YEAR
        self._rng = random.Random()  # not seeded → different each run

        # Per-instrument state
        self._volume_counters: dict[int, int] = {}   # broker_token -> cumulative volume
        self._oi_cache: dict[int, int] = {}           # broker_token -> OI (static)

        # Track OI distribution parameters (set once on first get_oi call)
        self._atm_oi_base = 5_000_000   # lots at ATM
        self._oi_sigma_pts = 500        # strike width of OI distribution (in points)

    # ── Spot ──────────────────────────────────────────────────────────────────

    def advance_spot(self) -> float:
        """One GBM step. Clamps within ±3% of initial_spot. Returns new spot. Thread-safe."""
        with self._lock:
            z = self._rng.gauss(0, 1)
            drift = (self._r - 0.5 * self._sigma ** 2) * self._dt
            diffusion = self._sigma * math.sqrt(self._dt) * z
            new_spot = self._spot * math.exp(drift + diffusion)

            # Forced Crash:
            # new_spot = self._spot * 0.9999  # Force 1% drop EVERY tick (instant crash)

            # Hard clamp ±3%
            lower = self._initial_spot * 0.90
            upper = self._initial_spot * 1.10
            self._spot = max(lower, min(upper, new_spot))
            return self._spot

    def get_spot(self) -> float:
        """Current spot price. Thread-safe."""
        with self._lock:
            return self._spot

    # ── Options ───────────────────────────────────────────────────────────────

    def get_option_price(self, strike: float, option_type: str, expiry: date) -> float:
        """
        Black-Scholes option price from current spot.
        Minimum floor of 0.05 to prevent LTP=0 rejection in strategies.
        """
        with self._lock:
            spot = self._spot

        today = date.today()
        ttm_days = max((expiry - today).days, 1)  # min 1 day to avoid division by zero

        try:
            if option_type == "CE":
                price = _bs_call(spot, strike, self._r, ttm_days, self._sigma)
            else:  # PE
                price = _bs_put(spot, strike, self._r, ttm_days, self._sigma)
        except Exception:
            price = 0.0

        return max(price, 0.05)

    # ── Futures ───────────────────────────────────────────────────────────────

    def get_future_price(self, expiry: Optional[date]) -> float:
        """
        FM futures price = spot * exp(r * T/365).
        For r=0 (default), equals spot.
        """
        with self._lock:
            spot = self._spot

        if expiry is None:
            return spot

        today = date.today()
        ttm_days = max((expiry - today).days, 0)
        return spot * math.exp(self._r * ttm_days / 365.0)

    # ── OI ────────────────────────────────────────────────────────────────────

    def get_oi(self, broker_token: int, strike: float) -> int:
        """
        Open Interest — Gaussian distribution centered at initial ATM.
        Cached on first access (static per session).
        """
        with self._lock:
            if broker_token not in self._oi_cache:
                # Gaussian OI: peaks at ATM, decays for OTM strikes
                distance = abs(strike - self._initial_spot)
                scale = math.exp(-0.5 * (distance / self._oi_sigma_pts) ** 2)
                base = int(self._atm_oi_base * scale)
                # Add small random variation, minimum 10k
                jitter = self._rng.randint(-50_000, 50_000)
                self._oi_cache[broker_token] = max(10_000, base + jitter)

            return self._oi_cache[broker_token]

    # ── Volume ────────────────────────────────────────────────────────────────

    def get_volume(self, broker_token: int) -> int:
        """
        Cumulative traded volume — monotonically increasing per instrument per session.
        Increments by a random amount on each call.
        """
        with self._lock:
            if broker_token not in self._volume_counters:
                self._volume_counters[broker_token] = self._rng.randint(10_000, 50_000)
            else:
                self._volume_counters[broker_token] += self._rng.randint(50, 500)
            return self._volume_counters[broker_token]

    # ── Convenience ───────────────────────────────────────────────────────────

    def get_ltp(self, broker_token: int, instrument_type: str, strike: float,
                expiry: Optional[date]) -> float:
        """Route to the correct price function based on instrument type."""
        if instrument_type in ("CE", "PE"):
            return self.get_option_price(strike, instrument_type, expiry)
        elif instrument_type == "FUT":
            return self.get_future_price(expiry)
        else:  # EQ, IDX, unknown
            return self.get_spot()
