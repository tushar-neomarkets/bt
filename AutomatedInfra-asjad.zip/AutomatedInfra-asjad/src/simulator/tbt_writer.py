"""
TBT Writer — writes fake Nifty 50 tick-by-tick data to the local TBT file.

Two responsibilities:
1. Continuously write tick lines to LOCAL_TBT_DIR/<YYYYMMDD>.txt so strategies
   see a fresh, non-stale TBT file.
2. Patch shutil.copy2 globally so that strategy code attempting to copy from
   the network share (\\10.211.8.76\...) becomes a no-op — the local file is
   already in place.
"""
import os
import shutil
import threading
import time
from datetime import datetime
from typing import Optional

from simulator.price_engine import PriceEngine


# Mirrors the LOCAL_TBT_DIR computed by every strategy
_SYSTEM_DIR = os.path.join(os.path.dirname(__file__), '..', 'system')
LOCAL_TBT_DIR = os.path.join(
    os.path.abspath(_SYSTEM_DIR),
    "dump", "tbt_local",
)

# Network share prefix that strategies try to copy FROM
_NETWORK_PREFIX = r"\\10.211.8.76"

# Sequence number for the fake ticks (incrementing integer)
_SEQ_BASE = 1_769_918_554


class TBTWriter:
    """
    Writes Nifty 50 spot ticks to the local TBT file every `write_interval` seconds.

    Also patches shutil.copy2 so that strategy calls like:
        shutil.copy2(r"\\10.211.8.76\...\20260326.txt", "/local/path/20260326.txt")
    become silent no-ops (the local file is already written by this writer).
    """

    def __init__(self, price_engine: PriceEngine, write_interval: float = 1.0):
        self._engine = price_engine
        self._interval = write_interval
        self._thread: Optional[threading.Thread] = None
        self._stop_event = threading.Event()
        self._original_copy2 = None
        self._last_ts: Optional[datetime] = None
        self._seq = _SEQ_BASE
        self._failure_count = 0

        # Stats
        self._ticks_written: int = 0
        self._last_spot: float = 0.0
        self._start_time: Optional[datetime] = None

    def get_stats(self) -> dict:
        """Return a snapshot of writer activity."""
        last_tick_age: Optional[float] = None
        if self._last_ts is not None:
            last_tick_age = (datetime.now() - self._last_ts).total_seconds()
        return {
            "ticks_written": self._ticks_written,
            "last_tick_time": self._last_ts,
            "last_tick_age_secs": last_tick_age,
            "last_spot": self._last_spot,
            "failure_count": self._failure_count,
            "tbt_dir": LOCAL_TBT_DIR,
            "start_time": self._start_time,
        }

    # ── Public API ────────────────────────────────────────────────────────────

    def start(self) -> None:
        """Patch shutil.copy2 and start the writer thread."""
        self._start_time = datetime.now()
        os.makedirs(LOCAL_TBT_DIR, exist_ok=True)

        # Monkey-patch shutil.copy2 globally
        self._original_copy2 = shutil.copy2
        shutil.copy2 = self._patched_copy2  # type: ignore[assignment]

        self._stop_event.clear()
        self._thread = threading.Thread(target=self._write_loop, daemon=True, name="tbt-writer")
        self._thread.start()

    def stop(self) -> None:
        """Stop writer thread and restore original shutil.copy2."""
        self._stop_event.set()
        if self._thread:
            self._thread.join(timeout=5.0)
        if self._original_copy2 is not None:
            shutil.copy2 = self._original_copy2  # type: ignore[assignment]
            self._original_copy2 = None

    # ── shutil patch ─────────────────────────────────────────────────────────

    def _patched_copy2(self, src, dst, *args, **kwargs):
        """
        Intercept copy2 calls targeting the network share.
        - If src is a network path → the local file is already written; no-op.
        - Otherwise → delegate to original copy2.
        """
        if isinstance(src, str) and src.startswith(_NETWORK_PREFIX):
            # Network path: our writer already maintains the local file — skip.
            return dst
        return self._original_copy2(src, dst, *args, **kwargs)

    # ── Writer loop ──────────────────────────────────────────────────────────

    def _write_loop(self) -> None:
        """Daemon loop: write one tick per interval, advance spot each tick."""
        while not self._stop_event.is_set():
            try:
                spot = self._engine.advance_spot()
                self._write_tick(spot)
                self._failure_count = 0
            except Exception as e:
                self._failure_count += 1
                # Log but never crash — staleness guard in strategy handles gaps
                print(f"[TBTWriter] ERROR (#{self._failure_count}): {e}")
            self._stop_event.wait(timeout=self._interval)

    def _write_tick(self, spot: float) -> None:
        """Append one tick line to today's TBT file."""
        now = datetime.now()

        # Monotonic timestamp guarantee: clamp to last_ts + 1ms if clock regresses
        if self._last_ts is not None:
            from datetime import timedelta
            min_ts = self._last_ts + timedelta(milliseconds=1)
            if now < min_ts:
                now = min_ts
        self._last_ts = now

        ts_str = now.strftime("%Y-%m-%d %H:%M:%S.%f")
        filename = now.strftime("%Y%m%d") + ".txt"
        file_path = os.path.join(LOCAL_TBT_DIR, filename)

        self._seq += 1
        line = f"{ts_str} | Nifty 50 | {spot:.1f} | {self._seq}\n"

        with open(file_path, "a", encoding="utf-8") as f:
            f.write(line)

        self._ticks_written += 1
        self._last_spot = spot
