import time

from accounts.models import BrokerAccount
from accounts.brokers.handler import BrokerAccountHandler
from utils.logger import get_logger

logger = get_logger(__name__)

PROACTIVE_REFRESH_SECS = 3600

class BrokerAccountTokenRefresher:
    """
    Refreshes tokens for all active broker accounts.
    Called periodically by TokenRefreshManager.
    """

    def __init__(self):
        self._last_refreshed: dict[int, float] = {}

    def refresh_all(self) -> dict:
        """
        Check all active broker accounts and refresh any expired tokens.
        Also proactively refreshes tokens every PROACTIVE_REFRESH_SECS
        to catch broker-side invalidations not reflected in the database.

        Returns a dict with counts: {'healthy': int, 'refreshed': int, 'failed': int}
        """
        accounts = BrokerAccount.objects.filter(is_active=True).select_related('broker')
        counts = {'healthy': 0, 'refreshed': 0, 'failed': 0}
        now = time.monotonic()

        for ba in accounts:
            ba.refresh_from_db()

            # Immediate refresh if DB says expired
            if ba.is_token_expired:
                self._do_refresh(ba, counts, now, reason="expired")
                continue

            # Proactive refresh if it's been too long since last refresh
            last = self._last_refreshed.get(ba.id, 0)
            if (now - last) >= PROACTIVE_REFRESH_SECS:
                self._do_refresh(ba, counts, now, reason="proactive")
                continue

            counts['healthy'] += 1
            logger.debug(f"Broker token OK for {ba.account_name} (expires {ba.token_expiry})")

        return counts

    def _do_refresh(self, ba, counts: dict, now: float, reason: str = "") -> None:
        logger.warning(f"Broker token refresh for {ba.account_name} ({reason})")
        try:
            BrokerAccountHandler(ba).update_token()
            ba.refresh_from_db()
            self._last_refreshed[ba.id] = now
            counts['refreshed'] += 1
            logger.info(f"Broker token refreshed for {ba.account_name} (new expiry: {ba.token_expiry})")
        except Exception as e:
            counts['failed'] += 1
            logger.error(f"Broker token refresh failed for {ba.account_name}: {e}")
