from django.contrib import admin

# Register your models here.
from accounts.models import Broker,BrokerAccount,UserAccountsPermission,StrategyAccountMapping

admin.site.register(UserAccountsPermission)
admin.site.register(Broker)
admin.site.register(BrokerAccount)
admin.site.register(StrategyAccountMapping)