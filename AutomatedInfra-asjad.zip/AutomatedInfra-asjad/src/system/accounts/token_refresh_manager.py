import threading
import time

from utils.logger import get_logger

logger = get_logger(__name__)

REFRESH_INTERVAL_SECS = 3600


class TokenRefreshManager:
    """
    Singleton that runs a daemon thread to periodically refresh
    broker account tokens and datafeed tokens.

    Started by StrategyManager when the first strategy launches.
    Stopped when no strategies are running.
    """

    _instance = None
    _lock = threading.Lock()

    def __new__(cls):
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = super().__new__(cls)
                    cls._instance._initialized = False
        return cls._instance

    def __init__(self):
        if self._initialized:
            return
        self._initialized = True
        self._running = False
        self._thread = None
        self._broker_refresher = None
        self._datafeed_refresher = None

    def start(self) -> bool:
        """
        Start the background token refresh thread.
        Idempotent — safe to call if already running.
        """
        if self._running:
            return True

        # Lazy import to avoid circular imports at module load time
        from accounts.broker_acc_token_refresher import BrokerAccountTokenRefresher
        from datafeed.datafeed_token_refresher import DataFeedTokenRefresher

        self._broker_refresher = BrokerAccountTokenRefresher()
        self._datafeed_refresher = DataFeedTokenRefresher()

        self._running = True
        self._thread = threading.Thread(
            target=self._run_loop,
            daemon=True,
            name="TokenRefreshManager",
        )
        self._thread.start()
        logger.info("TokenRefreshManager started")
        return True

    def stop(self) -> None:
        """
        Stop the background token refresh thread.
        Blocks for up to 5 seconds for a clean shutdown.
        """
        self._running = False
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=5)
        logger.info("TokenRefreshManager stopped")

    def is_running(self) -> bool:
        return self._running

    def _run_loop(self) -> None:
        """
        Main loop: refresh all tokens, then sleep REFRESH_INTERVAL_SECS.
        Sleeps in 1-second increments so stop() takes effect quickly.
        """
        while self._running:
            broker_counts = {'healthy': 0, 'refreshed': 0, 'failed': 0}
            datafeed_counts = {'healthy': 0, 'refreshed': 0, 'failed': 0}

            try:
                broker_counts = self._broker_refresher.refresh_all()
            except Exception as e:
                logger.error(f"Broker token refresh cycle failed: {e}")

            try:
                datafeed_counts = self._datafeed_refresher.refresh_all()
            except Exception as e:
                logger.error(f"Datafeed token refresh cycle failed: {e}")

            logger.info(
                f"Token health check — "
                f"Broker: {broker_counts['healthy']} healthy, {broker_counts['refreshed']} refreshed, {broker_counts['failed']} failed | "
                f"Datafeed: {datafeed_counts['healthy']} healthy, {datafeed_counts['refreshed']} refreshed, {datafeed_counts['failed']} failed"
            )

            for _ in range(REFRESH_INTERVAL_SECS):
                if not self._running:
                    break
                time.sleep(1)


# Module-level singleton instance
token_refresh_manager = TokenRefreshManager()
