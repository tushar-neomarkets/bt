"""
Account-Level PnL Calculator Service

Calculates per-account PnL by analyzing BrokerOrder records and matching
ENTRY/EXIT orders. Uses actual fill prices from BrokerOrder.average_price.

Key Features:
- Per-account PnL (not strategy-level aggregated)
- Based on actual fill prices (accounts may get different fills)
- Live unrealized PnL using LTP for open positions
- Respects multiplier (already applied in BrokerOrder.quantity)
- Filters to today's orders only
"""

from dataclasses import dataclass, field
from decimal import Decimal
from typing import Optional, Callable
from datetime import datetime
from django.utils import timezone
from django.db.models import Q

from orders.models import BrokerOrder, ParentOrder
from accounts.models import BrokerAccount, StrategyAccountMapping
from strategy.models import Strategy
from instruments.models import Instrument


@dataclass
class AccountPosition:
    """Represents a position for a specific instrument within an account."""
    instrument_token: int
    tradingsymbol: str
    exchange: str
    position_type: str  # 'LONG' or 'SHORT'
    quantity: int
    entry_avg_price: Decimal
    current_ltp: Optional[Decimal] = None
    unrealized_pnl: Decimal = Decimal('0.00')
    realized_pnl: Decimal = Decimal('0.00')
    status: str = 'OPEN'  # 'OPEN' or 'CLOSED'
    entry_broker_orders: list = field(default_factory=list)
    exit_broker_orders: list = field(default_factory=list)


@dataclass
class StrategyPnL:
    """PnL summary for a specific strategy within an account."""
    strategy_id: int
    strategy_code: str
    strategy_name: str
    open_pnl: Decimal = Decimal('0.00')
    closed_pnl: Decimal = Decimal('0.00')
    total_pnl: Decimal = Decimal('0.00')
    positions: list = field(default_factory=list)


@dataclass
class AccountPnL:
    """Complete PnL summary for a broker account."""
    account_id: int
    account_name: str
    strategies: list = field(default_factory=list)
    total_pnl: Decimal = Decimal('0.00')
    total_open_pnl: Decimal = Decimal('0.00')
    total_closed_pnl: Decimal = Decimal('0.00')
    last_updated: datetime = None


class AccountPnLCalculator:
    """
    Service class for calculating account-level PnL.

    Usage:
        calculator = AccountPnLCalculator(broker_account)
        result = calculator.calculate_pnl()

        # Or with LTP provider for live unrealized PnL:
        calculator = AccountPnLCalculator(broker_account, ltp_provider=ltp_func)
        result = calculator.calculate_pnl()
    """

    def __init__(
        self,
        broker_account: BrokerAccount,
        ltp_provider: Optional[Callable[[list], dict]] = None,
        strategy_filter: Optional[Strategy] = None
    ):
        """
        Args:
            broker_account: The BrokerAccount to calculate PnL for
            ltp_provider: Optional function(instrument_tokens: list[int]) -> dict[int, float]
                         Returns mapping of instrument_token to LTP
            strategy_filter: Optional Strategy to filter results to single strategy
        """
        self.broker_account = broker_account
        self.ltp_provider = ltp_provider
        self.strategy_filter = strategy_filter

    def calculate_pnl(self) -> AccountPnL:
        """
        Calculate complete PnL for the broker account.

        Returns:
            AccountPnL with all strategies and positions
        """
        # 1. Get all completed BrokerOrders for this account (today only)
        broker_orders = self._get_broker_orders()

        if not broker_orders:
            return AccountPnL(
                account_id=self.broker_account.id,
                account_name=self.broker_account.account_name,
                strategies=[],
                total_pnl=Decimal('0.00'),
                total_open_pnl=Decimal('0.00'),
                total_closed_pnl=Decimal('0.00'),
                last_updated=timezone.now()
            )

        # 2. Build instrument map for LTP lookups
        instrument_map: dict[int, Instrument] = {}
        for order in broker_orders:
            inst = order.parent_order.instrument
            instrument_map[inst.instrument_token] = inst

        # 3. Group orders by strategy and instrument
        grouped_orders = self._group_orders_by_strategy_and_instrument(broker_orders)

        # 4. Calculate positions for each group
        all_positions: dict[int, list[AccountPosition]] = {}
        for (strategy_id, instrument_token), orders in grouped_orders.items():
            positions = self._calculate_instrument_positions(orders)
            if strategy_id not in all_positions:
                all_positions[strategy_id] = []
            all_positions[strategy_id].extend(positions)

        # 5. Fetch LTPs for open positions if provider available
        if self.ltp_provider:
            self._update_unrealized_pnl(all_positions, instrument_map)

        # 6. Build result structure
        return self._build_account_pnl(all_positions)

    def _get_broker_orders(self) -> list[BrokerOrder]:
        """Get all completed broker orders for this account (today only)."""
        today = timezone.now().date()

        queryset = BrokerOrder.objects.filter(
            broker_account=self.broker_account,
            status='COMPLETED',
            filled_quantity__gt=0,
            created_at__date=today  # Today only filter
        ).select_related(
            'parent_order',
            'parent_order__strategy',
            'parent_order__instrument',
            'broker_instrument',
            'broker_instrument__instrument'
        ).order_by('created_at')

        if self.strategy_filter:
            queryset = queryset.filter(
                parent_order__strategy=self.strategy_filter
            )

        return list(queryset)

    def _group_orders_by_strategy_and_instrument(
        self,
        broker_orders: list[BrokerOrder]
    ) -> dict[tuple, list[BrokerOrder]]:
        """Group orders by (strategy_id, instrument_token)."""
        grouped = {}
        for order in broker_orders:
            strategy_id = order.parent_order.strategy_id
            instrument_token = order.parent_order.instrument.instrument_token
            key = (strategy_id, instrument_token)
            if key not in grouped:
                grouped[key] = []
            grouped[key].append(order)
        return grouped

    def _calculate_instrument_positions(
        self,
        orders: list[BrokerOrder]
    ) -> list[AccountPosition]:
        """
        Calculate positions from a list of orders for same instrument.
        Uses FIFO matching of entry/exit orders.

        Returns list of positions (may include both open and closed).
        """
        # Separate entry and exit orders
        entry_orders = []
        exit_orders = []

        for order in orders:
            if order.parent_order.order_intent == 'ENTRY':
                entry_orders.append({
                    'order': order,
                    'remaining_qty': order.filled_quantity
                })
            else:
                exit_orders.append({
                    'order': order,
                    'remaining_qty': order.filled_quantity
                })

        # If no entries, return empty
        if not entry_orders:
            return []

        # Get instrument info from first order
        instrument = orders[0].parent_order.instrument

        positions = []

        for entry_data in entry_orders:
            entry_order = entry_data['order']

            # Determine position type based on entry side
            # BUY entry = LONG position, SELL entry = SHORT position
            position_type = 'LONG' if entry_order.side == 'BUY' else 'SHORT'

            entry_qty = entry_order.filled_quantity
            entry_price = entry_order.average_price or Decimal('0.00')
            remaining_qty = entry_qty

            realized_pnl = Decimal('0.00')
            matched_exit_orders = []

            # FIFO match against exit orders
            for exit_data in exit_orders:
                if remaining_qty <= 0:
                    break

                if exit_data['remaining_qty'] <= 0:
                    continue

                exit_order = exit_data['order']

                # Check if this exit matches the entry
                # For LONG: exit is SELL
                # For SHORT: exit is BUY
                expected_exit_side = 'SELL' if position_type == 'LONG' else 'BUY'
                if exit_order.side != expected_exit_side:
                    continue

                exit_price = exit_order.average_price or Decimal('0.00')

                # Calculate matched quantity
                match_qty = min(remaining_qty, exit_data['remaining_qty'])

                # Calculate realized PnL for matched portion
                if position_type == 'LONG':
                    # LONG: profit = (exit - entry) * qty
                    pnl = (exit_price - entry_price) * match_qty
                else:
                    # SHORT: profit = (entry - exit) * qty
                    pnl = (entry_price - exit_price) * match_qty

                realized_pnl += pnl
                remaining_qty -= match_qty
                exit_data['remaining_qty'] -= match_qty

                # Track matched exit
                matched_exit_orders.append({
                    'order_id': exit_order.order_id,
                    'quantity': match_qty,
                    'price': float(exit_price)
                })

            # Create position record
            status = 'CLOSED' if remaining_qty == 0 else 'OPEN'

            position = AccountPosition(
                instrument_token=instrument.instrument_token,
                tradingsymbol=instrument.tradingsymbol,
                exchange=instrument.exchange,
                position_type=position_type,
                quantity=remaining_qty if status == 'OPEN' else entry_qty,
                entry_avg_price=entry_price,
                realized_pnl=realized_pnl,
                status=status,
                entry_broker_orders=[{
                    'order_id': entry_order.order_id,
                    'quantity': entry_qty,
                    'price': float(entry_price)
                }],
                exit_broker_orders=matched_exit_orders
            )

            positions.append(position)

        return positions

    def _update_unrealized_pnl(
        self,
        all_positions: dict[int, list[AccountPosition]],
        instrument_map: dict[int, Instrument]
    ):
        """Update unrealized PnL for open positions using LTP."""
        # Collect all instruments for open positions
        open_instruments = []
        for positions in all_positions.values():
            for pos in positions:
                if pos.status == 'OPEN' and pos.instrument_token in instrument_map:
                    open_instruments.append(instrument_map[pos.instrument_token])

        if not open_instruments:
            return

        # Fetch LTPs using the provider (takes Instrument objects)
        try:
            ltp_map = self.ltp_provider(open_instruments)
        except Exception:
            # If LTP fetch fails, leave unrealized as 0
            return

        if not ltp_map:
            return

        # Update positions
        for positions in all_positions.values():
            for pos in positions:
                if pos.status == 'OPEN' and pos.instrument_token in ltp_map:
                    ltp = ltp_map.get(pos.instrument_token)
                    if ltp is None:
                        continue

                    ltp = Decimal(str(ltp))
                    pos.current_ltp = ltp

                    if pos.position_type == 'LONG':
                        pos.unrealized_pnl = (ltp - pos.entry_avg_price) * pos.quantity
                    else:
                        pos.unrealized_pnl = (pos.entry_avg_price - ltp) * pos.quantity

    def _build_account_pnl(self, all_positions: dict[int, list[AccountPosition]]) -> AccountPnL:
        """Build the final AccountPnL structure."""
        strategies_pnl = []
        total_open = Decimal('0.00')
        total_closed = Decimal('0.00')

        # Cache strategy lookups
        strategy_cache = {}

        for strategy_id, positions in all_positions.items():
            # Get strategy info (with caching)
            if strategy_id not in strategy_cache:
                try:
                    strategy_cache[strategy_id] = Strategy.objects.get(id=strategy_id)
                except Strategy.DoesNotExist:
                    continue

            strategy = strategy_cache[strategy_id]

            strategy_open = sum((p.unrealized_pnl for p in positions), Decimal('0.00'))
            strategy_closed = sum((p.realized_pnl for p in positions), Decimal('0.00'))

            strategy_pnl = StrategyPnL(
                strategy_id=strategy_id,
                strategy_code=strategy.strategy_code,
                strategy_name=strategy.strategy_name,
                open_pnl=strategy_open,
                closed_pnl=strategy_closed,
                total_pnl=strategy_open + strategy_closed,
                positions=positions
            )

            strategies_pnl.append(strategy_pnl)
            total_open += strategy_open
            total_closed += strategy_closed

        return AccountPnL(
            account_id=self.broker_account.id,
            account_name=self.broker_account.account_name,
            strategies=strategies_pnl,
            total_pnl=total_open + total_closed,
            total_open_pnl=total_open,
            total_closed_pnl=total_closed,
            last_updated=timezone.now()
        )