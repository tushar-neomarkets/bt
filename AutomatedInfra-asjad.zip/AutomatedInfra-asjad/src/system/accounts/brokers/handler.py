from django.utils import timezone

class BrokerAccountHandler:

    def __init__(self, broker_account):
        self.broker_account = broker_account

    def update_token(self):
        print(f"--- UPDATE TOKEN REQUEST --- for broker account: {self.broker_account}")
        safe_broker_name = self.broker_account.broker.broker_name.lower().replace(' ', '_')
        func_name = f"_{safe_broker_name}_update_token"

        handler_func = getattr(self, func_name, None)
        if callable(handler_func):
            try:
                result = handler_func()
                print(f"--- REQUEST COMPLETE ---")
                return result
            except Exception as e:
                print(f"Error updating token: {e}")
                raise e
        else:
            error_msg = f"Broker Not Supported: No handler found for '{self.broker_account.broker.broker_name}' (looked for {func_name})"
            print(error_msg)
            raise NotImplementedError(error_msg)

    def _xts_update_token(self):
        if self.broker_account.extra_data and self.broker_account.extra_data.get('hostlookup'):
            from accounts.brokers.xts import hostlookup_login, interactive_login_for_hostlookup

            # Step 1: HostLookup
            res = hostlookup_login(self.broker_account)
            if not res:
                raise Exception("HostLookup failed")
            print(f"[1/5] HostLookup OK")

            # Steps 2-4: Only if TOTP credentials are configured
            if self.broker_account.extra_data.get('totp_secret'):
                from accounts.brokers.xts import validate_user, validate_password, verify_totp
                self.broker_account.refresh_from_db()
                conn = self.broker_account.extra_data['connectionString']

                # Step 2: Validate User - get imageIndex
                image_index = validate_user(self.broker_account, conn)
                print(f"[2/5] Validate User OK - imageIndex: {image_index}")

                # Step 3: Validate Password
                validate_password(self.broker_account, conn, image_index)
                print(f"[3/5] Validate Password OK")

                # Step 4: Verify TOTP - get accessToken (saved to extra_data)
                verify_totp(self.broker_account, conn)
                print(f"[4/5] Verify TOTP OK")

            # Step 5: Interactive Session Login
            res = interactive_login_for_hostlookup(self.broker_account)
            print(f"[5/5] Interactive Login - {res}")
            return res

        from accounts.brokers.xts import interactive_login
        res = interactive_login(self.broker_account)
        print(res)
        return res

    def get_broker_account(self):
        print(f"--- GET BROKER TOKEN --- for broker account: {self.broker_account}")

        return {
            "id":self.broker_account.id,
            "account_name": self.broker_account.account_name,
            "client_id": self.broker_account.client_id,
            "broker": {
                "id": self.broker_account.broker.id,
                "name": self.broker_account.broker.broker_name,
            },
            "is_active": self.broker_account.is_active,
            "token_status": {
                "is_valid": not self.broker_account.is_token_expired,
                "expires_at": self.broker_account.token_expiry,
                "last_refreshed": self.broker_account.updated_at
            },
            "created_at":self.broker_account.created_at,
        }

    def get_funds(self):
        """
        Public method to fetch funds/margins.
        Delegates to the specific broker implementation.
        """
        print(f"--- GET FUNDS REQUEST --- for broker account: {self.broker_account}")
        safe_broker_name = self.broker_account.broker.broker_name.lower().replace(' ', '_')
        func_name = f"_{safe_broker_name}_get_funds"

        handler_func = getattr(self, func_name, None)

        if callable(handler_func):
            try:
                # 3. Call the broker specific function
                fund_data = handler_func()

                # 4. Wrap in the standardized API response structure
                response = {
                    "data": {
                        "account_id": self.broker_account.id,
                        "last_updated": timezone.now().isoformat(),
                        "summary": fund_data
                    }
                }
                print(f"--- REQUEST COMPLETE ---")
                return response
            except Exception as e:
                print(f"Error fetching funds: {e}")
                raise e
        else:
            error_msg = f"Broker Not Supported: No fund handler found for '{self.broker_account.broker.broker_name}'"
            raise NotImplementedError(error_msg)

    def get_net_positions(self):
        safe_broker_name = self.broker_account.broker.broker_name.lower().replace(' ', '_')
        func_name = f"_{safe_broker_name}_get_net_positions"
        handler_func = getattr(self, func_name, None)

        if callable(handler_func):
            try:
                net_positions = handler_func()
                print(net_positions)
                response = {
                    "data": {
                        "account_id": self.broker_account.id,
                        "last_updated": timezone.now().isoformat(),
                        "summary": net_positions

                    }
                }
                print(f"--- REQUEST COMPLETE ---")
                return response
            except Exception as e:
                print(f"Error fetching net positions: {e}")
                raise e
        else:
            error_msg = f"Broker Not Supported:"
            raise NotImplementedError(error_msg)

    def _xts_get_funds(self):
        from accounts.brokers.xts import xts_get_funds
        return xts_get_funds(self.broker_account)

    def _xts_get_net_positions(self):
        from accounts.brokers.xts import xts_get_positions
        return xts_get_positions(self.broker_account, position_type='NetWise')

    def get_order_book(self):
        """
        Public method to fetch the order book.
        Delegates to the specific broker implementation.
        """
        safe_broker_name = self.broker_account.broker.broker_name.lower().replace(' ', '_')
        func_name = f"_{safe_broker_name}_get_order_book"
        handler_func = getattr(self, func_name, None)

        if callable(handler_func):
            try:
                order_book = handler_func()
                response = {
                    "data": {
                        "account_id": self.broker_account.id,
                        "last_updated": timezone.now().isoformat(),
                        "orderbook": order_book
                    }
                }
                print(f"--- REQUEST COMPLETE (OrderBook) ---")
                return response
            except Exception as e:
                print(f"Error fetching order book: {e}")
                raise e
        else:
            error_msg = f"Broker Not Supported: No order book handler found for '{self.broker_account.broker.broker_name}'"
            raise NotImplementedError(error_msg)

    def _xts_get_order_book(self):
        """
        XTS Specific internal handler
        """
        from accounts.brokers.xts import xts_get_orders
        # Passing None or specific args if XTS requires filters in the future
        return xts_get_orders(self.broker_account)

    def place_order(self, order_params):
        """
        Public method to place an order.
        Delegates to the specific broker implementation.

        Args:
            order_params (dict): Order parameters including:
                - exchange_segment: str (e.g., 'NSECM', 'NSEFO')
                - exchange_instrument_id: int
                - product_type: str (e.g., 'NRML', 'MIS', 'CNC')
                - order_type: str ('LIMIT', 'MARKET', 'STOPLIMIT', 'STOPMARKET')
                - order_side: str ('BUY', 'SELL')
                - time_in_force: str ('DAY', 'IOC')
                - disclosed_quantity: int
                - order_quantity: int
                - limit_price: float (required for LIMIT orders)
                - stop_price: float (required for STOP orders)
                - order_unique_identifier: str (optional, max 20 chars)

        Returns:
            dict: Standardized response with order details
        """
        print(f"--- PLACE ORDER REQUEST --- for broker account: {self.broker_account}")
        safe_broker_name = self.broker_account.broker.broker_name.lower().replace(' ', '_')
        func_name = f"_{safe_broker_name}_place_order"
        handler_func = getattr(self, func_name, None)

        if callable(handler_func):
            try:
                # Call the broker-specific function
                order_result = handler_func(order_params)

                # Wrap in standardized API response structure
                response = {
                    "data": {
                        "account_id": self.broker_account.id,
                        "timestamp": timezone.now().isoformat(),
                        "order": order_result
                    }
                }
                print(f"--- ORDER PLACED SUCCESSFULLY ---")
                return response
            except Exception as e:
                print(f"Error placing order: {e}")
                raise e
        else:
            error_msg = f"Broker Not Supported: No order placement handler found for '{self.broker_account.broker.broker_name}'"
            raise NotImplementedError(error_msg)

    def _xts_place_order(self, order_params):
        """
        XTS Specific internal handler for placing orders
        """
        from accounts.brokers.xts import xts_place_order
        return xts_place_order(self.broker_account, order_params)

    def modify_order(self, order_id, modify_params):
        """
        Public method to modify an existing order.
        Delegates to the specific broker implementation.

        Args:
            order_id (str/int): The broker's order ID (AppOrderID)
            modify_params (dict): Parameters to modify including:
                - orderQuantity (optional): New quantity
                - limitPrice (optional): New limit price
                - stopPrice (optional): New stop price
                - orderType (optional): Order type (LIMIT, MARKET, etc.)
                - productType (optional): Product type (NRML, MIS, etc.)
                - disclosedQuantity (optional): New disclosed quantity
                - timeInForce (optional): Time in force (DAY, IOC)
                - orderUniqueIdentifier (optional): Unique identifier

        Returns:
            dict: Standardized response with modification details
        """
        print(f"--- MODIFY ORDER REQUEST --- for broker account: {self.broker_account}")
        safe_broker_name = self.broker_account.broker.broker_name.lower().replace(' ', '_')
        func_name = f"_{safe_broker_name}_modify_order"
        handler_func = getattr(self, func_name, None)

        if callable(handler_func):
            try:
                modify_result = handler_func(order_id, modify_params)

                response = {
                    "data": {
                        "account_id": self.broker_account.id,
                        "timestamp": timezone.now().isoformat(),
                        "modification": modify_result
                    }
                }
                print(f"--- ORDER MODIFIED SUCCESSFULLY ---")
                return response
            except Exception as e:
                print(f"Error modifying order: {e}")
                raise e
        else:
            error_msg = f"Broker Not Supported: No order modification handler found for '{self.broker_account.broker.broker_name}'"
            raise NotImplementedError(error_msg)

    def _xts_modify_order(self, order_id, modify_params):
        """
        XTS Specific internal handler for modifying orders
        """
        from accounts.brokers.xts import xts_modify_order
        return xts_modify_order(self.broker_account, order_id, modify_params)

    def cancel_order(self, order_id):
        """
        Public method to cancel an existing order.
        Delegates to the specific broker implementation.

        Args:
            order_id (str/int): The broker's order ID (AppOrderID)

        Returns:
            dict: Standardized response with cancellation details
        """
        print(f"--- CANCEL ORDER REQUEST --- for broker account: {self.broker_account}")
        safe_broker_name = self.broker_account.broker.broker_name.lower().replace(' ', '_')
        func_name = f"_{safe_broker_name}_cancel_order"
        handler_func = getattr(self, func_name, None)

        if callable(handler_func):
            try:
                cancel_result = handler_func(order_id)
                response = {
                    "data": {
                        "account_id": self.broker_account.id,
                        "timestamp": timezone.now().isoformat(),
                        "cancellation": cancel_result
                    }
                }
                print(f"--- ORDER CANCELLED SUCCESSFULLY ---")
                return response
            except Exception as e:
                print(f"Error cancelling order: {e}")
                raise e
        else:
            error_msg = f"Broker Not Supported: No order cancellation handler found for '{self.broker_account.broker.broker_name}'"
            raise NotImplementedError(error_msg)

    def _xts_cancel_order(self, order_id):
        """
        XTS Specific internal handler for cancelling orders
        """
        from accounts.brokers.xts import xts_cancel_order
        return xts_cancel_order(self.broker_account, order_id)

    def get_order_history(self, order_id):
        """
        Public method to fetch complete order history (all events/modifications).
        Delegates to the specific broker implementation.

        Args:
            order_id (str/int): The broker's order ID (AppOrderID)

        Returns:
            dict: Standardized response with order history events
        """
        print(f"--- GET ORDER HISTORY REQUEST --- for broker account: {self.broker_account}")
        safe_broker_name = self.broker_account.broker.broker_name.lower().replace(' ', '_')
        func_name = f"_{safe_broker_name}_get_order_history"
        handler_func = getattr(self, func_name, None)

        if callable(handler_func):
            try:
                history = handler_func(order_id)
                response = {
                    "data": {
                        "account_id": self.broker_account.id,
                        "timestamp": timezone.now().isoformat(),
                        "order_id": order_id,
                        "history": history
                    }
                }
                print(f"--- ORDER HISTORY RETRIEVED ---")
                return response
            except Exception as e:
                print(f"Error fetching order history: {e}")
                raise e
        else:
            error_msg = f"Broker Not Supported: No order history handler found for '{self.broker_account.broker.broker_name}'"
            raise NotImplementedError(error_msg)

    def _xts_get_order_history(self, order_id):
        """
        XTS Specific internal handler for fetching order history
        """
        from accounts.brokers.xts import xts_get_order_history
        return xts_get_order_history(self.broker_account, order_id)
