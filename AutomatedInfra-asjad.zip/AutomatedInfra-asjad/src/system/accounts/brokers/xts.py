import requests
import json
import pyotp
from urllib.parse import urlparse
from django.utils import timezone

DEFAULT_XTS_SOURCE = "TWSAPI"
DEFAULT_HOSTLOOKUP_VERSION = "interactive_1.0.3"
REQUEST_TIMEOUT = 10


def _join_url(base_url, path):
    return f"{str(base_url).rstrip('/')}/{str(path).lstrip('/')}"


def _is_success_response(data):
    response_type = data.get('type')
    return response_type is True or str(response_type).lower() in ('success', 'true')


def _get_extra_data(account):
    return account.extra_data or {}


def _get_source(account, default=DEFAULT_XTS_SOURCE):
    return _get_extra_data(account).get('source', default)


def _verify_ssl(account):
    return not bool(_get_extra_data(account).get('disable_ssl', False))


def _get_hostlookup_url(account):
    base_url = account.hostlookup_url or account.base_url
    if not base_url:
        raise ValueError("XTS hostlookup requires hostlookup_url or base_url.")

    parsed = urlparse(str(base_url))
    if parsed.path.rstrip('/').lower().endswith('hostlookup'):
        return str(base_url).rstrip('/')
    return _join_url(base_url, 'hostlookup')


def _get_interactive_base_url(base_url):
    """
    HostLookup responses differ by broker/version. Some return the full
    interactive instance URL, while older XTS responses return only host:port.
    Normalize to a base ending at the interactive instance.
    """
    if not base_url:
        raise ValueError("XTS connectionString/base_url is missing.")

    base = str(base_url).rstrip('/')
    parsed = urlparse(base)
    last_path_part = parsed.path.rstrip('/').split('/')[-1].lower()

    if 'interactive' in last_path_part:
        return base
    if last_path_part.isdigit():
        return f"{base}interactive"
    return _join_url(base, 'interactive')


def _get_account_interactive_base_url(account):
    extra_data = _get_extra_data(account)
    if extra_data.get('hostlookup'):
        return _get_interactive_base_url(extra_data.get('connectionString'))
    return _get_interactive_base_url(account.base_url)


def _generate_totp(secret):
    normalized_secret = str(secret).replace(' ', '').upper()
    return pyotp.TOTP(normalized_secret).now()


def hostlookup_login(account):
    """
    Performs the HostLookUp to get the uniqueKey and connectionString.
    Stores these in the account.extra_data field for subsequent requests.
    """
    print(f"Hostlookup login for {account} ...")
    extra_data = _get_extra_data(account)
    url = _get_hostlookup_url(account)
    params = {
        "accesspassword": "2021HostLookUpAccess",
        "version": extra_data.get('hostlookup_version', DEFAULT_HOSTLOOKUP_VERSION)
    }
    headers = {'Content-Type': 'application/json'}
    try:
        response = requests.post(
            url,
            headers=headers,
            json=params,
            timeout=REQUEST_TIMEOUT,
            verify=_verify_ssl(account),
        )
        response.raise_for_status()  # Raise error for bad status codes

        data = response.json()
        if _is_success_response(data) and 'result' in data:
            result = data['result']

            if account.extra_data is None:
                account.extra_data = {}

            account.extra_data['uniqueKey'] = result.get('uniqueKey')
            account.extra_data['connectionString'] = result.get('connectionString')

            account.save(update_fields=['extra_data', 'updated_at'])
            print(f"HostLookUp Successful. UniqueKey obtained.")
            return True
        else:
            print(f"HostLookUp Failed: {data.get('description')}")
            return False
    except Exception as e:
        print(f"Exception in HostLookUp: {e}")
        return False


def validate_user(account, connection_string):
    """
    Step 2: Validate User.
    Returns the imageIndex needed for Step 3.
    """
    print(f"[TOTP Step 2] Validating user {account.client_id} ...")
    url = _join_url(_get_interactive_base_url(connection_string), 'auth/validateUser')
    params = {
        "userID": account.client_id,
        "appKey": account.api_key,
        "source": _get_source(account)
    }
    headers = {'Content-Type': 'application/json'}
    try:
        response = requests.post(
            url,
            headers=headers,
            json=params,
            timeout=REQUEST_TIMEOUT,
            verify=_verify_ssl(account),
        )
        response.raise_for_status()
        data = response.json()
        if _is_success_response(data) and 'result' in data:
            image_index = data['result']['imageIndex']
            print(f"Validate User Successful. imageIndex: {image_index}")
            return image_index
        else:
            raise Exception(f"Validate User Failed: {data.get('description')} (code: {data.get('code')})")
    except Exception as e:
        print(f"Exception in Validate User: {e}")
        raise


def validate_password(account, connection_string, image_index):
    """
    Step 3: Validate Password.
    Uses the imageIndex from Step 2 and password from extra_data.
    """
    print(f"[TOTP Step 3] Validating password for {account.client_id} ...")
    extra_data = _get_extra_data(account)
    password = extra_data.get('password')
    if not password:
        raise ValueError("XTS TOTP login requires extra_data['password'].")

    url = _join_url(_get_interactive_base_url(connection_string), 'auth/validatepassword')
    params = {
        "deviceType": "WEB",
        "imageIndex": image_index,
        "password": password,
        "userID": account.client_id,
        "source": _get_source(account)
    }
    headers = {'Content-Type': 'application/json'}
    try:
        response = requests.post(
            url,
            headers=headers,
            json=params,
            timeout=REQUEST_TIMEOUT,
            verify=_verify_ssl(account),
        )
        response.raise_for_status()
        data = response.json()
        if _is_success_response(data):
            print("Validate Password Successful.")
            return True
        else:
            raise Exception(f"Validate Password Failed: {data.get('description')} (code: {data.get('code')})")
    except Exception as e:
        print(f"Exception in Validate Password: {e}")
        raise


def verify_totp(account, connection_string):
    """
    Step 4: Verify TOTP.
    Generates a TOTP pin and returns the accessToken.
    Saves accessToken to account.extra_data for Step 5.
    """
    print(f"[TOTP Step 4] Verifying TOTP for {account.client_id} ...")
    extra_data = _get_extra_data(account)
    password = extra_data.get('password')
    totp_secret = extra_data.get('totp_secret')
    if not password:
        raise ValueError("XTS TOTP login requires extra_data['password'].")
    if not totp_secret:
        raise ValueError("XTS TOTP login requires extra_data['totp_secret'].")

    pin = _generate_totp(totp_secret)
    url = _join_url(_get_interactive_base_url(connection_string), 'auth/verifytotp')
    params = {
        "source": _get_source(account),
        "userID": account.client_id,
        "appKey": account.api_key,
        "password": password,
        "pin": pin
    }
    headers = {'Content-Type': 'application/json'}
    try:
        response = requests.post(
            url,
            headers=headers,
            json=params,
            timeout=REQUEST_TIMEOUT,
            verify=_verify_ssl(account),
        )
        response.raise_for_status()
        data = response.json()
        if _is_success_response(data) and 'result' in data:
            access_token = data['result']['accessToken']
            if account.extra_data is None:
                account.extra_data = {}
            account.extra_data['accessToken'] = access_token
            account.save(update_fields=['extra_data', 'updated_at'])
            print("Verify TOTP Successful. accessToken obtained.")
            return access_token
        else:
            raise Exception(f"Verify TOTP Failed: {data.get('description')} (code: {data.get('code')})")
    except Exception as e:
        print(f"Exception in Verify TOTP: {e}")
        raise


def interactive_login_for_hostlookup(account):
    """
    Uses the uniqueKey obtained from HostLookUp to perform the actual Interactive Login.
    This saves the access_token to the database.
    """
    print(f"Interactive login using HostLookUp keys for {account} ...")
    extra_data = _get_extra_data(account)
    unique_key = extra_data.get('uniqueKey')
    connection_string = extra_data.get('connectionString')
    if not unique_key or not connection_string:
        print("Error: Missing UniqueKey or ConnectionString. Run hostlookup_login first.")
        return False
    url = _join_url(_get_interactive_base_url(connection_string), 'user/session')
    params = {
        "appKey": account.api_key,
        "secretKey": account.api_secret,
        "uniqueKey": unique_key,
    }
    # Include accessToken from TOTP verification (Step 4) if available
    if extra_data.get('accessToken'):
        params["accessToken"] = extra_data['accessToken']
    headers = {'Content-Type': 'application/json'}
    try:
        response = requests.post(
            url,
            headers=headers,
            json=params,
            timeout=REQUEST_TIMEOUT,
            verify=_verify_ssl(account),
        )
        response.raise_for_status()
        data = response.json()
        if _is_success_response(data) and 'result' in data:
            result = data['result']
            account.access_token = result.get('token')
            account.token_expiry = timezone.now().replace(hour=23, minute=59, second=59, microsecond=0)
            account.save(update_fields=['access_token', 'token_expiry', 'updated_at'])
            print("Interactive Login Successful. Token updated.")
            return True
        else:
            print(f"Interactive Login Failed: {data.get('description')}")
            return False
    except Exception as e:
        print(f"Exception in Interactive Login: {e}")
        return False

def interactive_login(account):
    url = _join_url(_get_interactive_base_url(account.base_url), 'user/session')
    params = {
        "appKey": account.api_key,
        "secretKey": account.api_secret,
        "source": _get_source(account, "WEBAPI")
    }
    headers = {'Content-Type': 'application/json'}
    try:
        response = requests.post(
            url,
            headers=headers,
            json=params,
            timeout=REQUEST_TIMEOUT,
            verify=_verify_ssl(account),
        )
        response.raise_for_status()
        data = response.json()
        if _is_success_response(data) and 'result' in data:
            result = data['result']
            account.access_token = result.get('token')
            account.token_expiry = timezone.now().replace(hour=23, minute=59, second=59, microsecond=0)
            account.save(update_fields=['access_token', 'token_expiry', 'updated_at'])
            print("Interactive Login Successful. Token updated.")
            return True
        else:
            print(f"Interactive Login Failed: {data.get('description')}")
            return False
    except Exception as e:
        print(f"Exception in Interactive Login: {e}")
        return False

def marketdata_login(account):
    print("Marketdata login ...")


def xts_get_funds(account):
    """
    Fetches balance from XTS Interactive API matching the Connect.py logic.
    """
    print(f"Fetching XTS funds for {account} ...")

    base_url = _get_account_interactive_base_url(account)
    url = _join_url(base_url, 'user/balance')


    params = {
        "clientID": account.client_id
    }

    headers = {
        'Content-Type': 'application/json',
        'Authorization': account.access_token
    }

    try:
        response = requests.get(url, headers=headers, params=params)


        if response.status_code == 401:
            raise Exception("Unauthorized: Token expired or invalid.")

        response.raise_for_status()
        data = response.json()

        if data.get('type') == 'success' and 'result' in data:
            result_data = data['result']

            balance_list = result_data.get('BalanceList', [])
            if not balance_list:
                raw_bal = result_data
            else:
                raw_bal = balance_list[0]

            if 'limitObject' in raw_bal:
                raw_bal = raw_bal['limitObject']

            def get_nested(root, section, key):
                """Safely attempts to find root[section][key] or root[key]"""
                val = 0.0
                try:
                    if section in root:
                        val = root[section].get(key, 0)
                    else:
                        val = root.get(key, 0)

                    return round(float(val))
                except (ValueError, TypeError):
                    return 0.0

            net_margin_avail = get_nested(raw_bal, 'RMSSubLimits', 'netMarginAvailable')
            margin_utilized = get_nested(raw_bal, 'RMSSubLimits', 'marginUtilized')
            cash_avail = get_nested(raw_bal, 'marginAvailable', 'CashMarginAvailable')

            summary = {
                "total_available": net_margin_avail,

                "total_used": margin_utilized,

                "total_margin": net_margin_avail + margin_utilized,

                "cash_balance": cash_avail,

                "net_available": net_margin_avail
            }

            return summary
        else:
            raise Exception(f"XTS Balance Failed: {data.get('description')}")

    except Exception as e:
        print(f"Exception in XTS get_funds: {e}")
        raise e

def xts_get_positions(account, position_type='NetWise'):
    """
    Fetches positions from XTS.
    position_type: 'NetWise' or 'DayWise'
    """
    print(f"Fetching XTS {position_type} positions for {account} ...")
    base_url = _get_account_interactive_base_url(account)
    url = _join_url(base_url, 'portfolio/positions')

    params = {
        "dayOrNet": position_type,
        "clientID": account.client_id
    }
    headers = {
        'Content-Type': 'application/json',
        'Authorization': account.access_token
    }

    try:
        response = requests.get(url, headers=headers, params=params)

        if response.status_code == 401:
            raise Exception("Unauthorized: Token expired or invalid.")

        response.raise_for_status()
        data = response.json()

        if data.get('type') == 'success' and 'result' in data:
            # Return the list of positions directly
            return data['result'].get('positionList', [])
        else:
            raise Exception(f"XTS Positions Failed: {data.get('description')}")

    except Exception as e:
        print(f"Exception in XTS get_positions ({position_type}): {e}")
        raise e


def xts_get_orders(account):
    """
    Fetches the Order Book from XTS Interactive API.
    """
    print(f"Fetching XTS Order Book for {account} ...")

    base_url = _get_account_interactive_base_url(account)
    url = _join_url(base_url, 'orders')

    params = {
        "clientID": account.client_id
    }

    headers = {
        'Content-Type': 'application/json',
        'Authorization': account.access_token
    }

    try:
        response = requests.get(url, headers=headers, params=params)

        if response.status_code == 401:
            raise Exception("Unauthorized: Token expired or invalid.")

        response.raise_for_status()
        data = response.json()

        if data.get('type') == 'success' and 'result' in data:
            return data['result']
        else:
            raise Exception(f"XTS Order Book Failed: {data.get('description')}")

    except Exception as e:
        print(f"Exception in XTS get_orders: {e}")
        raise e

def xts_get_order_status(account, app_order_id):
    """
    Fetches the status of a specific order from XTS Interactive API.

    Args:
        account: BrokerAccount instance
        app_order_id: The AppOrderID of the order to check

    Returns:
        dict: Order status info including OrderStatus, OrderQuantity,
              LeavesQuantity (pending), CumulativeQuantity (filled), etc.
              Returns None if order not found.
    """
    account.refresh_from_db()
    base_url = _get_account_interactive_base_url(account)
    url = _join_url(base_url, 'orders')

    params = {
        "clientID": account.client_id,
        "appOrderID": int(app_order_id)
    }

    headers = {
        'Content-Type': 'application/json',
        'Authorization': account.access_token
    }

    try:
        response = requests.get(url, headers=headers, params=params)

        if response.status_code == 401:
            raise Exception("Unauthorized: Token expired or invalid.")

        response.raise_for_status()
        data = response.json()

        if data.get('type') == 'success' and 'result' in data:
            result = data['result']
            # Result can be a list or single order
            if isinstance(result, list):
                # Find the order with matching AppOrderID
                for order in result[::-1]:
                    if str(order.get('AppOrderID')) == str(app_order_id):
                        return order
                return None
            else:
                return result
        else:
            raise Exception(f"XTS Order Status Failed: {data.get('description')}")

    except Exception as e:
        print(f"Exception in XTS get_order_status: {e}")
        raise e


def xts_get_order_history(account, app_order_id):
    """
    Fetches the complete order history (all events/modifications) for a specific order from XTS.

    Args:
        account: BrokerAccount instance
        app_order_id: The AppOrderID of the order

    Returns:
        list: List of order history events showing all modifications, fills, status changes
              Each event contains: AppOrderID, OrderQuantity, OrderPrice, OrderStatus,
              CumulativeQuantity, LeavesQuantity, OrderGeneratedDateTime, etc.
    """
    base_url = _get_account_interactive_base_url(account)
    url = _join_url(base_url, 'orders')

    headers = {
        'Content-Type': 'application/json',
        'Authorization': account.access_token
    }

    try:
        response = requests.get(url, headers=headers)

        if response.status_code == 401:
            raise Exception("Unauthorized: Token expired or invalid.")

        response.raise_for_status()
        data = response.json()

        if data.get('type') == 'success' and 'result' in data:
            result = data['result']
            # Filter all entries for this AppOrderID (includes all modifications)
            if isinstance(result, list):
                history = [
                    order for order in result
                    if str(order.get('AppOrderID')) == str(app_order_id)
                ]
                # Sort by OrderGeneratedDateTime
                history.sort(key=lambda x: x.get('OrderGeneratedDateTime', ''))
                return history
            else:
                return [result] if str(result.get('AppOrderID')) == str(app_order_id) else []
        else:
            raise Exception(f"XTS Order History Failed: {data.get('description')}")

    except Exception as e:
        print(f"Exception in XTS get_order_history: {e}")
        raise e


def xts_place_order(account, order_params):
    """
    Places a limit order via XTS Interactive API.

    Args:
        account: BrokerAccount instance
        order_params (dict): Order parameters

    Returns:
        dict: Order response from XTS
    """
    account.refresh_from_db()
    print(f"Placing XTS order for {account} ...with {order_params} ...")
    base_url = _get_account_interactive_base_url(account)
    url = _join_url(base_url, 'orders')

    required_fields = [
        'exchangeSegment',
        'exchangeInstrumentID',
        'productType',
        'orderType',
        'orderSide',
        'timeInForce',
        'orderQuantity'
    ]
    for field in required_fields:
        if field not in order_params:
            raise ValueError(f"Missing required field: {field}")

    if order_params['orderType'] in ['LIMIT', 'STOPLIMIT']:
        if 'limitPrice' not in order_params:
            raise ValueError(f"limitPrice is required for {order_params['orderType']} orders")

    if order_params['orderType'] in ['STOPLIMIT', 'STOPMARKET']:
        if 'stopPrice' not in order_params and 'limitPrice' not in order_params:
            raise ValueError(f"stopPrice & limitPrice is required for {order_params['orderType']} orders")

    payload = {
        "exchangeSegment": order_params['exchangeSegment'],
        "exchangeInstrumentID": order_params['exchangeInstrumentID'],
        "productType": order_params['productType'],
        "orderType": order_params['orderType'],
        "orderSide": order_params['orderSide'],
        "timeInForce": order_params['timeInForce'],
        "disclosedQuantity": order_params.get('disclosedQuantity', 0),
        "orderQuantity": order_params['orderQuantity'],
        "limitPrice": order_params.get('limitPrice', 0.0),
        "stopPrice": order_params.get('stopPrice', 0.0),
        "orderUniqueIdentifier": order_params.get('orderUniqueIdentifier', '')[:20]
    }
    headers = {
        'Content-Type': 'application/json',
        'Authorization': account.access_token
    }
    try:
        response = requests.post(url, headers=headers, data=json.dumps(payload))

        if response.status_code == 401:
            raise Exception("Unauthorized: Token expired or invalid.")
        response.raise_for_status()
        data = response.json()

        if data.get('type') == 'success' and 'result' in data:
            result = data['result']

            # Return standardized order result
            return {
                "order_id": result.get('AppOrderID'),
                "exchange_order_id": result.get('OrderID'),
                "order_status": result.get('OrderStatus'),
                "message": result.get('Message', 'Order placed successfully'),
                "raw_response": result
            }
        else:
            raise Exception(f"XTS Order Placement Failed: {data.get('description')}")

    except Exception as e:
        print(f"Exception in XTS place_order: {e}")
        raise e


def xts_modify_order(account, order_id, modify_params):
    """
    Modifies an existing order via XTS Interactive API.

    Args:
        account: BrokerAccount instance
        order_id (int): The AppOrderID to modify
        modify_params (dict): Parameters to modify including:
            - orderQuantity (required): New/pending quantity
            - limitPrice (optional): New limit price
            - stopPrice (optional): New stop price
            - orderType (optional): New order type (LIMIT, MARKET, STOPLIMIT, STOPMARKET)
            - productType (optional): Product type (NRML, MIS, CNC)
            - disclosedQuantity (optional): New disclosed quantity

    Returns:
        dict: Modification response from XTS
    """
    account.refresh_from_db()
    print(f"Modifying XTS order {order_id} for {account} with params {modify_params} ...")

    # Validate required params
    order_quantity = modify_params.get('orderQuantity')
    if not order_quantity or int(order_quantity) <= 0:
        raise ValueError("orderQuantity is required and must be greater than 0")

    base_url = _get_account_interactive_base_url(account)
    url = _join_url(base_url, 'orders')

    # Generate unique identifier if not provided
    order_unique_id = modify_params.get('orderUniqueIdentifier', '')
    if not order_unique_id:
        order_unique_id = f"MOD{order_id}"

    # Build modification payload with XTS-specific parameter names
    payload = {
        "appOrderID": int(order_id),
        "modifiedProductType": modify_params.get('productType', 'NRML'),
        "modifiedOrderType": modify_params.get('orderType', 'LIMIT'),
        "modifiedOrderQuantity": int(order_quantity),
        "modifiedDisclosedQuantity": int(modify_params.get('disclosedQuantity', 0)),
        "modifiedLimitPrice": float(modify_params.get('limitPrice', 0.0)),
        "modifiedStopPrice": float(modify_params.get('stopPrice', 0.0)),
        "modifiedTimeInForce": modify_params.get('timeInForce', 'DAY'),
        "orderUniqueIdentifier": str(order_unique_id)[:20]
    }

    # Add clientID for dealer/non-investor accounts
    if account.client_id:
        payload["clientID"] = account.client_id

    print(f"XTS Modify Order Payload: {payload}")

    headers = {
        'Content-Type': 'application/json',
        'Authorization': account.access_token
    }

    try:
        response = requests.put(url, headers=headers, data=json.dumps(payload))

        print(f"XTS Modify Order Response Status: {response.status_code}")
        print(f"XTS Modify Order Response: {response.text}")

        if response.status_code == 401:
            raise Exception("Unauthorized: Token expired or invalid.")

        response.raise_for_status()
        data = response.json()

        if data.get('type') == 'success' and 'result' in data:
            result = data['result']

            return {
                "order_id": result.get('AppOrderID'),
                "message": result.get('Message', 'Order modified successfully'),
                "raw_response": result
            }
        else:
            error_desc = data.get('description', 'Unknown error')
            raise Exception(f"XTS Order Modification Failed: {error_desc}")

    except requests.exceptions.HTTPError as e:
        # Try to extract error details from response
        try:
            error_data = e.response.json()
            error_desc = error_data.get('description', str(e))
        except Exception:
            error_desc = str(e)
        print(f"HTTP Error in XTS modify_order: {error_desc}")
        raise Exception(f"Order modification failed: {error_desc}")

    except Exception as e:
        print(f"Exception in XTS modify_order: {e}")
        raise e


def xts_cancel_order(account, order_id, order_unique_identifier=""):
    """
    Cancels an existing order via XTS Interactive API.

    Args:
        account: BrokerAccount instance
        order_id (int): The AppOrderID to cancel
        order_unique_identifier (str): Optional unique identifier for the order

    Returns:
        dict: Cancellation response from XTS
    """
    account.refresh_from_db()
    print(f"Cancelling XTS order {order_id} for {account} ...")

    base_url = _get_account_interactive_base_url(account)
    url = f"{_join_url(base_url, 'orders')}?appOrderID={order_id}"


    payload = json.dumps({
        "appOrderID": int(order_id),
        "orderUniqueIdentifier": "order_unique_identifier"
    })

    headers = {
        'Content-Type': 'application/json',
        'Authorization': account.access_token
    }

    try:
        # For DELETE requests, XTS expects params in the request body as JSON
        response = requests.delete(url, headers=headers, data=payload)

        if response.status_code == 401:
            raise Exception("Unauthorized: Token expired or invalid.")

        response.raise_for_status()
        data = response.json()

        if data.get('type') == 'success' and 'result' in data:
            result = data['result']

            return {
                "order_id": result.get('AppOrderID'),
                "message": result.get('Message', 'Order cancelled successfully'),
                "raw_response": result
            }
        else:
            raise Exception(f"XTS Order Cancellation Failed: {data.get('description')}")

    except Exception as e:
        print(f"Exception in XTS cancel_order: {e}")
        raise e
