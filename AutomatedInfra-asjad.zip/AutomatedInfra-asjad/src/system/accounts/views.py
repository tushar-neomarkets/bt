from django.contrib.auth.mixins import LoginRequiredMixin
from rest_framework.views import APIView
from rest_framework.response import Response
from accounts.models import BrokerAccount, StrategyAccountMapping
from django.shortcuts import get_object_or_404
from rest_framework import status
from accounts.brokers.handler import BrokerAccountHandler
from accounts.services.pnl_calculator import AccountPnLCalculator
from strategy.models import Strategy
class AccountsListView(LoginRequiredMixin, APIView):
    def get(self, request):
        user = request.user
        accounts = BrokerAccount.objects.filter(
            authorized_users__user=user
        ).values('id', 'account_name', 'client_id', 'broker__broker_name')

        return Response({
            "status": "success",
            "user": user.username,
            "count": accounts.count(),
            "data": list(accounts)
        })

class UpdateTokenView(LoginRequiredMixin, APIView):
    def post(self, request):
        account_id = request.data.get('account_id')

        if not account_id:
            return Response(
                {"error": "account_id is required"},
                status=status.HTTP_400_BAD_REQUEST
            )

        try:
            account = BrokerAccount.objects.get(
                id=account_id,
                authorized_users__user=request.user
            )
        except BrokerAccount.DoesNotExist:
            return Response(
                {"error": "Account not found or access denied"},
                status=status.HTTP_403_FORBIDDEN
            )

        try:
            handler = BrokerAccountHandler(account)
            res = handler.update_token()

            return Response({"status": "success", "message": "Token updated successfully","data": res})
        except NotImplementedError as e:
            return Response({"error": str(e)}, status=status.HTTP_501_NOT_IMPLEMENTED)
        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

class AccountView(APIView):
    def get(self, request, account_id):
        user = request.user
        if not account_id:
            return Response(
                {"error": "account_id is required"},
            )
        try:
            account = BrokerAccount.objects.get(
                id=account_id,
                authorized_users__user=request.user
            )
        except BrokerAccount.DoesNotExist:
            return Response(
                {"error": "Account not found or access denied"},
                status=status.HTTP_403_FORBIDDEN
            )
        try:
            handler = BrokerAccountHandler(account)
            res = handler.get_broker_account()
            return Response({"status": "success", "data": res})
        except NotImplementedError as e:
            return Response({"error": str(e)}, status=status.HTTP_501_NOT_IMPLEMENTED)

class AccountFundsView(APIView):
    def get(self, request, account_id):
        user = request.user
        if not account_id:
            return Response(
                {"error": "account_id is required"},
            )
        try:
            account = BrokerAccount.objects.get(
                id=account_id,
                authorized_users__user=request.user
            )
        except BrokerAccount.DoesNotExist:
            return Response(
                {"error": "Account not found or access denied"},
                status=status.HTTP_403_FORBIDDEN
            )
        try:
            handler = BrokerAccountHandler(account)
            res = handler.get_funds()
            return Response({"status": "success", "data": res})
        except NotImplementedError as e:
            return Response({"error": str(e)}, status=status.HTTP_501_NOT_IMPLEMENTED)
        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class AccountNetPositionsView(APIView):
    def get(self, request, account_id):
        return self._handle_broker_request(request, account_id, 'get_net_positions')

    def _handle_broker_request(self, request, account_id, method_name):
        """
        Reusable handler to avoid code duplication across similar views
        """
        if not account_id:
            return Response({"error": "account_id is required"}, status=status.HTTP_400_BAD_REQUEST)

        try:
            account = BrokerAccount.objects.get(
                id=account_id,
                authorized_users__user=request.user
            )
        except BrokerAccount.DoesNotExist:
            return Response(
                {"error": "Account not found or access denied"},
                status=status.HTTP_403_FORBIDDEN
            )

        try:
            handler = BrokerAccountHandler(account)
            # Dynamically call the method on the handler (e.g., handler.get_net_positions())
            action = getattr(handler, method_name)
            res = action()
            return Response({"status": "success", "data": res})
        except NotImplementedError as e:
            return Response({"error": str(e)}, status=status.HTTP_501_NOT_IMPLEMENTED)
        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

class AccountOrderBookView(APIView):
    def get(self, request, account_id):
        # Dispatch to the 'get_order_book' method in the handler
        return self._handle_broker_request(request, account_id, 'get_order_book')

    def _handle_broker_request(self, request, account_id, method_name):
        """
        Reusable handler logic (Same as AccountNetPositionsView).
        """
        if not account_id:
            return Response({"error": "account_id is required"}, status=status.HTTP_400_BAD_REQUEST)

        try:
            account = BrokerAccount.objects.get(
                id=account_id,
                authorized_users__user=request.user
            )
        except BrokerAccount.DoesNotExist:
            return Response(
                {"error": "Account not found or access denied"},
                status=status.HTTP_403_FORBIDDEN
            )

        try:
            handler = BrokerAccountHandler(account)
            action = getattr(handler, method_name)
            res = action()
            return Response({"status": "success", "data": res})
        except NotImplementedError as e:
            return Response({"error": str(e)}, status=status.HTTP_501_NOT_IMPLEMENTED)
        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

class PlaceOrderView(APIView):
    def post(self, request, account_id):
        return self._handle_broker_request(request, account_id, 'place_order')
    def _handle_broker_request(self, request, account_id, method_name):
        """
        Reusable handler logic (Same as AccountNetPositionsView).
        """
        if not account_id:
            return Response({"error": "account_id is required"}, status=status.HTTP_400_BAD_REQUEST)

        try:
            account = BrokerAccount.objects.get(
                id=account_id,
                authorized_users__user=request.user
            )
        except BrokerAccount.DoesNotExist:
            return Response(
                {"error": "Account not found or access denied"},
                status=status.HTTP_403_FORBIDDEN
            )

        try:
            handler = BrokerAccountHandler(account)
            action = getattr(handler, method_name)
            res1 = action({
                "exchangeSegment":"NSEFO",
                "exchangeInstrumentID":"128817", #CE
                "productType":"NRML",
                "orderType": "LIMIT",
                'orderSide': 'BUY',
                'timeInForce': 'DAY',
                'orderQuantity': 2350,
                'disclosedQuantity': 0,
                'orderUniqueIdentifier': 'QUANT',
                'limitPrice':0.95
            })
            res2 = action({
                "exchangeSegment": "NSEFO",
                "exchangeInstrumentID": "128818", #PE
                "productType": "NRML",
                "orderType": "LIMIT",
                'orderSide': 'BUY',
                'timeInForce': 'DAY',
                'orderQuantity': 2350,
                'disclosedQuantity': 0,
                'orderUniqueIdentifier': 'QUANT',
                'limitPrice': 0.95
            })
            return Response({"status": "success", "data": [res1,res2]})
        except NotImplementedError as e:
            return Response({"error": str(e)}, status=status.HTTP_501_NOT_IMPLEMENTED)
        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class AccountStrategyPnLView(APIView):
    """
    Get PnL for all strategies for a specific broker account.

    GET /api/accounts/<account_id>/strategy-pnl/

    Returns per-account PnL calculated from actual BrokerOrder fill prices,
    not strategy-level prices. Shows today's orders only.
    """

    def get(self, request, account_id):
        try:
            account = BrokerAccount.objects.get(
                id=account_id,
                authorized_users__user=request.user
            )
        except BrokerAccount.DoesNotExist:
            return Response(
                {"error": "Account not found or access denied"},
                status=status.HTTP_403_FORBIDDEN
            )

        try:
            ltp_provider = self._get_ltp_provider()
            calculator = AccountPnLCalculator(
                broker_account=account,
                ltp_provider=ltp_provider
            )
            result = calculator.calculate_pnl()

            return Response({
                "status": "success",
                "data": self._serialize_account_pnl(result)
            })

        except Exception as e:
            return Response(
                {"error": str(e)},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

    def _get_ltp_provider(self):
        """
        Get LTP provider function using REST-based DataFeedHandler.
        Returns a function that takes list[Instrument] and returns dict[int, float].
        """
        try:
            from datafeed.models import DataFeedAccount
            from datafeed.rest.handler import DataFeedHandler

            datafeed_account = DataFeedAccount.objects.filter(is_active=True).first()
            if not datafeed_account:
                return None

            if datafeed_account.is_token_expired:
                return None

            handler = DataFeedHandler(datafeed_account)

            def fetch_ltp(instruments: list) -> dict:
                if not instruments:
                    return {}
                try:
                    response = handler.get_multiple_ltp(instruments)
                    if response and 'data' in response:
                        ltp_list = response['data'].get('ltp_list', [])
                        return {
                            item.get('instrument_token'): item.get('ltp')
                            for item in ltp_list
                            if item.get('instrument_token') and item.get('ltp')
                        }
                except Exception:
                    pass
                return {}

            return fetch_ltp

        except Exception:
            pass

        return None

    def _serialize_account_pnl(self, account_pnl) -> dict:
        return {
            "account_id": account_pnl.account_id,
            "account_name": account_pnl.account_name,
            "strategies": [
                self._serialize_strategy_pnl(s)
                for s in account_pnl.strategies
            ],
            "total_pnl": float(account_pnl.total_pnl),
            "total_open_pnl": float(account_pnl.total_open_pnl),
            "total_closed_pnl": float(account_pnl.total_closed_pnl),
            "last_updated": account_pnl.last_updated.isoformat() if account_pnl.last_updated else None
        }

    def _serialize_strategy_pnl(self, strategy_pnl) -> dict:
        return {
            "strategy_id": strategy_pnl.strategy_id,
            "strategy_code": strategy_pnl.strategy_code,
            "strategy_name": strategy_pnl.strategy_name,
            "open_pnl": float(strategy_pnl.open_pnl),
            "closed_pnl": float(strategy_pnl.closed_pnl),
            "total_pnl": float(strategy_pnl.total_pnl),
            "positions": [
                self._serialize_position(p)
                for p in strategy_pnl.positions
            ]
        }

    def _serialize_position(self, position) -> dict:
        return {
            "instrument_token": position.instrument_token,
            "instrument": position.tradingsymbol,
            "exchange": position.exchange,
            "position_type": position.position_type,
            "quantity": position.quantity,
            "entry_avg_price": float(position.entry_avg_price),
            "current_ltp": float(position.current_ltp) if position.current_ltp else None,
            "unrealized_pnl": float(position.unrealized_pnl),
            "realized_pnl": float(position.realized_pnl),
            "status": position.status
        }


class AccountSingleStrategyPnLView(AccountStrategyPnLView):
    """
    Get PnL for a specific strategy within a broker account.

    GET /api/accounts/<account_id>/strategy-pnl/<strategy_id>/
    """

    def get(self, request, account_id, strategy_id):
        try:
            account = BrokerAccount.objects.get(
                id=account_id,
                authorized_users__user=request.user
            )
        except BrokerAccount.DoesNotExist:
            return Response(
                {"error": "Account not found or access denied"},
                status=status.HTTP_403_FORBIDDEN
            )

        try:
            strategy = Strategy.objects.get(
                id=strategy_id,
                authorized_users__user=request.user
            )
        except Strategy.DoesNotExist:
            return Response(
                {"error": "Strategy not found or access denied"},
                status=status.HTTP_403_FORBIDDEN
            )

        mapping_exists = StrategyAccountMapping.objects.filter(
            strategy=strategy,
            broker_account=account
        ).exists()

        if not mapping_exists:
            return Response(
                {"error": "Strategy is not mapped to this account"},
                status=status.HTTP_400_BAD_REQUEST
            )

        try:
            ltp_provider = self._get_ltp_provider()
            calculator = AccountPnLCalculator(
                broker_account=account,
                ltp_provider=ltp_provider,
                strategy_filter=strategy
            )
            result = calculator.calculate_pnl()

            return Response({
                "status": "success",
                "data": self._serialize_account_pnl(result)
            })

        except Exception as e:
            return Response(
                {"error": str(e)},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )