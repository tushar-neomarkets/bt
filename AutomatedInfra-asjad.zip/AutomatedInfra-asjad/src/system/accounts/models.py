from django.core.validators import MinValueValidator, MaxValueValidator
from django.db import models
from django.utils import timezone
from django.contrib.auth.models import User

class Broker(models.Model):
    broker_name = models.CharField('Broker Name', max_length=100, unique=True)

    def __str__(self):
        return self.broker_name


class BrokerAccount(models.Model):
    broker = models.ForeignKey(Broker, on_delete=models.PROTECT)
    account_name = models.CharField('Account Friendly Name', max_length=100, unique=True)

    # Core Credentials
    client_id = models.CharField('Client ID / User ID', max_length=100, help_text="XTS_USER_ID")
    api_key = models.CharField('API Key', max_length=255)
    api_secret = models.CharField('API Secret', max_length=255)

    # Session Management
    access_token = models.TextField('Access Token', blank=True, null=True)
    token_expiry = models.DateTimeField('Access Token Expiry', blank=True,
                                        null=True)

    # Configuration
    is_active = models.BooleanField('Is Active', default=True)
    is_paper_trading = models.BooleanField('Paper Trading', default=False)

    base_url = models.URLField('Base URL', blank=True, null=True)
    hostlookup_url = models.URLField('Host Lookup URL', blank=True, null=True)

    extra_data = models.JSONField('Extra Data', default=dict, blank=True)

    # Money Management
    allocation = models.DecimalField('Max Allocation', max_digits=12, decimal_places=2, default=0.00)

    # Timestamps
    created_at = models.DateTimeField('Created At', auto_now_add=True)
    updated_at = models.DateTimeField('Updated At', auto_now=True)

    class Meta:
        verbose_name = 'Broker Account'
        verbose_name_plural = 'Broker Accounts'
        ordering = ['broker__broker_name', 'account_name']

    def __str__(self):
        return f"{self.broker.broker_name} - {self.account_name} ({self.client_id})"

    @property
    def is_token_expired(self):
        if not self.token_expiry:
            return True
        return timezone.now() > self.token_expiry




class UserAccountsPermission(models.Model):
    user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='account_permissions'
    )

    account = models.ForeignKey(
        BrokerAccount,
        on_delete=models.CASCADE,
        related_name='authorized_users'
    )

    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ('user', 'account')
        verbose_name = "User Account Permission"

    def __str__(self):
        return f"{self.user.username} {self.account}"


class StrategyAccountMapping(models.Model):
    """
    Defines which broker accounts execute which strategies and how.
    Controls multipliers and execution parameters.
    """
    id = models.AutoField(primary_key=True)
    strategy = models.ForeignKey(
        'strategy.Strategy',
        on_delete=models.CASCADE,
        related_name='account_mappings'
    )
    broker_account = models.ForeignKey(
        BrokerAccount,
        on_delete=models.CASCADE,
        related_name='strategy_mappings'
    )
    multiplier = models.IntegerField(
        default=1,
        help_text="Order quantity multiplier for this account",
        validators=[MinValueValidator(0), MaxValueValidator(100)],
    )
    is_active = models.BooleanField(default=True, db_index=True)

    auto_execute = models.BooleanField(
        default=True,
        help_text="Auto-execute orders from this strategy"
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        unique_together = ('strategy', 'broker_account')
        indexes = [
            models.Index(fields=['strategy', 'is_active']),
            models.Index(fields=['broker_account', 'is_active']),
        ]
        db_table = 'strategy_account_mapping'
        verbose_name = "Strategy Account Mapping"
        verbose_name_plural = "Strategy Account Mappings"

    def __str__(self):
        return f"{self.strategy.strategy_name} → {self.broker_account.account_name} (x{self.multiplier})"