from accounts.views import (
    AccountsListView, UpdateTokenView, AccountView, AccountFundsView,
    AccountNetPositionsView, AccountOrderBookView, PlaceOrderView,
    AccountStrategyPnLView, AccountSingleStrategyPnLView
)
from django.urls import path

urlpatterns = [
    path('', AccountsListView.as_view(), name='accounts-list'),
    path('<int:account_id>/funds/', AccountFundsView.as_view(), name='account-funds'),
    path('<int:account_id>/positions/', AccountNetPositionsView.as_view(), name='account-positions'),
    path('<int:account_id>/orderbook/', AccountOrderBookView.as_view(), name='account-orderbook'),
    path('<int:account_id>', AccountView.as_view(), name='accounts-detail'),
    path('update-token/', UpdateTokenView.as_view(), name='update-token'),
    path('<int:account_id>/place-order', PlaceOrderView.as_view(), name='broker-place-order'),
    # Account-level PnL endpoints
    path('<int:account_id>/strategy-pnl/', AccountStrategyPnLView.as_view(), name='account-strategy-pnl'),
    path('<int:account_id>/strategy-pnl/<int:strategy_id>/', AccountSingleStrategyPnLView.as_view(), name='account-strategy-pnl-single'),
]