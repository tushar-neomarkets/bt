from django.db import models
from django.utils import timezone


class DataFeedProvider(models.Model):
    """Represents a market data provider (XTS, Zerodha, etc.)"""
    provider_name = models.CharField('Provider Name', max_length=100, unique=True)

    def __str__(self):
        return self.provider_name


class DataFeedAccount(models.Model):
    """
    Stores credentials and configuration for market data feeds.
    Similar structure to BrokerAccount but specialized for data feeds.
    """
    provider = models.ForeignKey(DataFeedProvider, on_delete=models.PROTECT)
    account_name = models.CharField('Account Friendly Name', max_length=100, unique=True)

    # Core Credentials
    client_id = models.CharField('Client ID / User ID', max_length=100)
    api_key = models.CharField('API Key', max_length=255)
    api_secret = models.CharField('API Secret', max_length=255)

    # Session Management
    access_token = models.TextField('Access Token', blank=True, null=True)
    token_expiry = models.DateTimeField('Access Token Expiry', blank=True, null=True)

    # Configuration
    is_active = models.BooleanField('Is Active', default=True)
    base_url = models.URLField('Base URL', blank=True, null=True)

    extra_data = models.JSONField('Extra Data', default=dict, blank=True)

    # Timestamps
    created_at = models.DateTimeField('Created At', auto_now_add=True)
    updated_at = models.DateTimeField('Updated At', auto_now=True)

    class Meta:
        verbose_name = 'Data Feed Account'
        verbose_name_plural = 'Data Feed Accounts'
        ordering = ['provider__provider_name', 'account_name']

    def __str__(self):
        return f"{self.provider.provider_name} - {self.account_name} ({self.client_id})"

    @property
    def is_token_expired(self) -> bool:
        if not self.token_expiry:
            return True
        return timezone.now() > self.token_expiry
