"""
DataFeed app for market data ingestion.
Provides normalized data independent of brokers/datavendors.
"""
