from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status

from datafeed.models import DataFeedAccount
from datafeed.rest.handler import DataFeedHandler


class DataFeedAccountListView(APIView):
    """List all datafeed accounts."""

    def get(self, request):
        accounts = DataFeedAccount.objects.filter(
            is_active=True
        ).values(
            'id',
            'account_name',
            'client_id',
            'provider__provider_name',
            'is_active',
            'token_expiry'
        )

        return Response({
            "status": "success",
            "count": accounts.count(),
            "data": list(accounts)
        })


class DataFeedAccountDetailView(APIView):
    """Get details of a specific datafeed account."""

    def get(self, request, account_id):
        try:
            account = DataFeedAccount.objects.get(id=account_id)
        except DataFeedAccount.DoesNotExist:
            return Response(
                {"status": "error", "message": "Account not found"},
                status=status.HTTP_404_NOT_FOUND
            )

        try:
            handler = DataFeedHandler(account)
            data = handler.get_datafeed_account()
            return Response({"status": "success", "data": data})
        except Exception as e:
            return Response(
                {"status": "error", "message": str(e)},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )


class DataFeedUpdateTokenView(APIView):
    """Update access token for a datafeed account."""

    def post(self, request, account_id):
        # Validate account exists
        try:
            account = DataFeedAccount.objects.get(id=account_id)
        except DataFeedAccount.DoesNotExist:
            return Response(
                {"status": "error", "message": "Account not found"},
                status=status.HTTP_404_NOT_FOUND
            )

        # Check if account is active
        if not account.is_active:
            return Response(
                {"status": "error", "message": "Account is not active"},
                status=status.HTTP_400_BAD_REQUEST
            )

        # Attempt to update token
        try:
            handler = DataFeedHandler(account)
            result = handler.update_token()

            if result:
                # Refresh account from DB to get updated token info
                account.refresh_from_db()
                return Response({
                    "status": "success",
                    "message": "Token updated successfully",
                    "data": {
                        "account_id": account.id,
                        "account_name": account.account_name,
                        "provider": account.provider.provider_name,
                        "token_expiry": account.token_expiry.isoformat() if account.token_expiry else None,
                        "is_token_valid": not account.is_token_expired
                    }
                })
            else:
                return Response(
                    {"status": "error", "message": "Token update failed"},
                    status=status.HTTP_500_INTERNAL_SERVER_ERROR
                )

        except NotImplementedError as e:
            return Response(
                {"status": "error", "message": str(e)},
                status=status.HTTP_501_NOT_IMPLEMENTED
            )
        except Exception as e:
            return Response(
                {"status": "error", "message": str(e)},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )


class DataFeedLTPView(APIView):
    """Get LTP for an instrument from a datafeed account."""

    def get(self, request, account_id):
        from instruments.models import Instrument

        # Get instrument_token from query params
        instrument_token = request.query_params.get('instrument_token')
        if not instrument_token:
            return Response(
                {"status": "error", "message": "instrument_token query parameter is required"},
                status=status.HTTP_400_BAD_REQUEST
            )

        # Validate account
        try:
            account = DataFeedAccount.objects.get(id=account_id)
        except DataFeedAccount.DoesNotExist:
            return Response(
                {"status": "error", "message": "Account not found"},
                status=status.HTTP_404_NOT_FOUND
            )

        # Validate instrument
        try:
            instrument = Instrument.objects.get(instrument_token=int(instrument_token))
        except Instrument.DoesNotExist:
            return Response(
                {"status": "error", "message": "Instrument not found"},
                status=status.HTTP_404_NOT_FOUND
            )

        # Check token validity
        if account.is_token_expired:
            return Response(
                {"status": "error", "message": "Token expired. Please update token first."},
                status=status.HTTP_401_UNAUTHORIZED
            )

        # Fetch LTP
        try:
            handler = DataFeedHandler(account)
            result = handler.get_single_ltp(instrument)
            return Response({"status": "success", **result})
        except NotImplementedError as e:
            return Response(
                {"status": "error", "message": str(e)},
                status=status.HTTP_501_NOT_IMPLEMENTED
            )
        except Exception as e:
            return Response(
                {"status": "error", "message": str(e)},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )


class DataFeedQuoteView(APIView):
    """Get full quote for an instrument from a datafeed account."""

    def get(self, request, account_id):
        from instruments.models import Instrument

        # Get instrument_token from query params
        instrument_token = request.query_params.get('instrument_token')
        if not instrument_token:
            return Response(
                {"status": "error", "message": "instrument_token query parameter is required"},
                status=status.HTTP_400_BAD_REQUEST
            )

        # Validate account
        try:
            account = DataFeedAccount.objects.get(id=account_id)
        except DataFeedAccount.DoesNotExist:
            return Response(
                {"status": "error", "message": "Account not found"},
                status=status.HTTP_404_NOT_FOUND
            )

        # Validate instrument
        try:
            instrument = Instrument.objects.get(instrument_token=int(instrument_token))
        except Instrument.DoesNotExist:
            return Response(
                {"status": "error", "message": "Instrument not found"},
                status=status.HTTP_404_NOT_FOUND
            )

        # Check token validity
        if account.is_token_expired:
            return Response(
                {"status": "error", "message": "Token expired. Please update token first."},
                status=status.HTTP_401_UNAUTHORIZED
            )

        # Fetch quote
        try:
            handler = DataFeedHandler(account)
            result = handler.get_single_quote(instrument)
            return Response({"status": "success", **result})
        except NotImplementedError as e:
            return Response(
                {"status": "error", "message": str(e)},
                status=status.HTTP_501_NOT_IMPLEMENTED
            )
        except Exception as e:
            return Response(
                {"status": "error", "message": str(e)},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )
