from datafeed.models import DataFeedAccount
from datafeed.rest.handler import DataFeedHandler
from utils.logger import get_logger

logger = get_logger(__name__)


class DataFeedTokenRefresher:
    """
    Refreshes tokens for all active datafeed accounts.
    Called periodically by TokenRefreshManager.
    """

    def refresh_all(self) -> dict:
        """
        Check all active datafeed accounts and refresh any expired tokens.

        Returns a dict with counts: {'healthy': int, 'refreshed': int, 'failed': int}
        """
        accounts = DataFeedAccount.objects.filter(is_active=True).select_related('provider')
        counts = {'healthy': 0, 'refreshed': 0, 'failed': 0}

        for account in accounts:
            account.refresh_from_db()

            if account.is_token_expired:
                self._do_refresh(account, counts, reason="expired")
                continue

            counts['healthy'] += 1
            logger.debug(f"Datafeed token OK for {account.account_name} (expires {account.token_expiry})")

        return counts

    def _do_refresh(self, account, counts: dict, reason: str = "") -> None:
        logger.warning(f"Datafeed token refresh for {account.account_name} ({reason})")
        try:
            DataFeedHandler(account).update_token()
            account.refresh_from_db()
            counts['refreshed'] += 1
            logger.info(f"Datafeed token refreshed for {account.account_name} (new expiry: {account.token_expiry})")
        except Exception as e:
            counts['failed'] += 1
            logger.error(f"Datafeed token refresh failed for {account.account_name}: {e}")
