"""
DataFeed WebSocket Handler - Broker-agnostic interface for real-time market data.
Follows the same delegation pattern as datafeed/rest/handler.py
"""
import logging
import threading
from typing import Optional, Callable

from instruments.models import Instrument, BrokerInstrument

logger = logging.getLogger(__name__)


class DataFeedWebSocketHandler:
    """
    Public interface for WebSocket-based market data streaming.
    Delegates to provider-specific implementations based on the account's provider.
    """

    def __init__(self, datafeed_account):
        self.datafeed_account = datafeed_account
        self._client = None
        self._connected = False
        self._subscribed_instruments: dict[int, Instrument] = {}  # token -> Instrument
        self._on_tick_callback: Optional[Callable] = None
        self._connection_thread: Optional[threading.Thread] = None

    def _get_safe_provider_name(self) -> str:
        """Returns normalized provider name for method dispatch."""
        return self.datafeed_account.provider.provider_name.lower().replace(' ', '_')

    def _get_broker_instrument(self, instrument: Instrument) -> Optional[BrokerInstrument]:
        """Get the broker-specific instrument mapping."""
        broker_name = self.datafeed_account.provider.provider_name.upper()
        return BrokerInstrument.get_by_instrument_and_broker(
            instrument.instrument_token,
            broker_name
        )

    def _get_broker_instruments(self, instruments: list[Instrument]) -> dict:
        """Bulk get broker-specific instrument mappings."""
        broker_name = self.datafeed_account.provider.provider_name.upper()
        instrument_tokens = [inst.instrument_token for inst in instruments]
        return BrokerInstrument.bulk_get_by_instruments_and_broker(
            instrument_tokens,
            broker_name
        )

    # -------------------------------------------------------------------------
    # Connection Management
    # -------------------------------------------------------------------------

    def connect(self, on_tick: Optional[Callable] = None) -> bool:
        """
        Establish WebSocket connection to the datafeed provider.

        Args:
            on_tick: Optional callback function called when tick data is received.
                     Signature: on_tick(tick_data: dict)

        Returns:
            bool: True if connection initiated successfully
        """
        print(f"--- WEBSOCKET CONNECT --- for datafeed account: {self.datafeed_account}")
        self._on_tick_callback = on_tick

        safe_provider_name = self._get_safe_provider_name()
        func_name = f"_{safe_provider_name}_connect"

        handler_func = getattr(self, func_name, None)
        if callable(handler_func):
            try:
                result = handler_func()
                print(f"--- CONNECTION INITIATED ---")
                return result
            except Exception as e:
                logger.error(f"Error connecting to WebSocket: {e}")
                raise e
        else:
            error_msg = f"Provider Not Supported: No WebSocket handler found for '{self.datafeed_account.provider.provider_name}'"
            logger.error(error_msg)
            raise NotImplementedError(error_msg)

    def disconnect(self) -> bool:
        """
        Close WebSocket connection.

        Returns:
            bool: True if disconnection successful
        """
        print(f"--- WEBSOCKET DISCONNECT --- for datafeed account: {self.datafeed_account}")

        safe_provider_name = self._get_safe_provider_name()
        func_name = f"_{safe_provider_name}_disconnect"

        handler_func = getattr(self, func_name, None)
        if callable(handler_func):
            try:
                result = handler_func()
                self._connected = False
                print(f"--- DISCONNECTED ---")
                return result
            except Exception as e:
                logger.error(f"Error disconnecting from WebSocket: {e}")
                raise e
        else:
            error_msg = f"Provider Not Supported: No disconnect handler found for '{self.datafeed_account.provider.provider_name}'"
            logger.error(error_msg)
            raise NotImplementedError(error_msg)

    @property
    def is_connected(self) -> bool:
        """Check if WebSocket is currently connected."""
        return self._connected

    # -------------------------------------------------------------------------
    # Subscription Management
    # -------------------------------------------------------------------------

    def subscribe(self, instruments: list[Instrument]) -> dict:
        """
        Subscribe to market data for given instruments.

        Args:
            instruments: List of Instrument model instances to subscribe

        Returns:
            dict: Subscription result with success/failure status
        """
        print(f"--- SUBSCRIBE REQUEST --- for {len(instruments)} instruments")

        safe_provider_name = self._get_safe_provider_name()
        func_name = f"_{safe_provider_name}_subscribe"

        handler_func = getattr(self, func_name, None)
        if callable(handler_func):
            try:
                broker_instruments = self._get_broker_instruments(instruments)
                if not broker_instruments:
                    raise ValueError("No broker mappings found for any instruments")

                result = handler_func(instruments, broker_instruments)

                # Track subscribed instruments
                for inst in instruments:
                    self._subscribed_instruments[inst.instrument_token] = inst

                print(f"--- SUBSCRIPTION COMPLETE ---")
                return result
            except Exception as e:
                logger.error(f"Error subscribing to instruments: {e}")
                raise e
        else:
            error_msg = f"Provider Not Supported: No subscribe handler found for '{self.datafeed_account.provider.provider_name}'"
            logger.error(error_msg)
            raise NotImplementedError(error_msg)

    def unsubscribe(self, instruments: list[Instrument]) -> dict:
        """
        Unsubscribe from market data for given instruments.

        Args:
            instruments: List of Instrument model instances to unsubscribe

        Returns:
            dict: Unsubscription result with success/failure status
        """
        print(f"--- UNSUBSCRIBE REQUEST --- for {len(instruments)} instruments")

        safe_provider_name = self._get_safe_provider_name()
        func_name = f"_{safe_provider_name}_unsubscribe"

        handler_func = getattr(self, func_name, None)
        if callable(handler_func):
            try:
                broker_instruments = self._get_broker_instruments(instruments)
                if not broker_instruments:
                    raise ValueError("No broker mappings found for any instruments")

                result = handler_func(instruments, broker_instruments)

                # Remove from tracked instruments
                for inst in instruments:
                    self._subscribed_instruments.pop(inst.instrument_token, None)

                print(f"--- UNSUBSCRIPTION COMPLETE ---")
                return result
            except Exception as e:
                logger.error(f"Error unsubscribing from instruments: {e}")
                raise e
        else:
            error_msg = f"Provider Not Supported: No unsubscribe handler found for '{self.datafeed_account.provider.provider_name}'"
            logger.error(error_msg)
            raise NotImplementedError(error_msg)

    def get_subscribed_instruments(self) -> list[Instrument]:
        """Returns list of currently subscribed instruments."""
        return list(self._subscribed_instruments.values())

    # -------------------------------------------------------------------------
    # XTS Provider Implementation
    # -------------------------------------------------------------------------

    def _xts_connect(self) -> bool:
        """XTS-specific WebSocket connection."""
        from datafeed.websocket.xts import XTSWebSocketClient

        self._client = XTSWebSocketClient(
            datafeed_account=self.datafeed_account,
            on_tick_callback=self._on_tick_callback,
        )

        # Start connection in a background thread
        self._connection_thread = threading.Thread(
            target=self._client.connect,
            daemon=True
        )
        self._connection_thread.start()
        self._connected = True
        return True

    def _xts_disconnect(self) -> bool:
        """XTS-specific WebSocket disconnection."""
        if self._client:
            self._client.disconnect()
            self._client = None
        self._connected = False
        return True

    def _xts_subscribe(self, instruments: list[Instrument], broker_instruments: dict) -> dict:
        """XTS-specific subscription."""
        from datafeed.websocket.xts import xts_subscribe
        return xts_subscribe(self.datafeed_account, instruments, broker_instruments)

    def _xts_unsubscribe(self, instruments: list[Instrument], broker_instruments: dict) -> dict:
        """XTS-specific unsubscription."""
        from datafeed.websocket.xts import xts_unsubscribe
        return xts_unsubscribe(self.datafeed_account, instruments, broker_instruments)
