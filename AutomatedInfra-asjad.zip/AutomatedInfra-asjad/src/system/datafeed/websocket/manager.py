"""
WebSocket Manager - Singleton for managing multiple WebSocket client connections.
Provides redundancy, automatic failover, and standardized tick access for strategies.
"""
import json
import logging
import threading
import time
import uuid
from datetime import datetime
from enum import Enum
from typing import Optional, Callable, Any

from datafeed.websocket.data_types import StandardTick, TickCallback

logger = logging.getLogger(__name__)


class ConnectionState(Enum):
    """WebSocket client connection states."""
    DISCONNECTED = "disconnected"
    CONNECTING = "connecting"
    CONNECTED = "connected"
    RECONNECTING = "reconnecting"
    FAILED = "failed"


class WebSocketManager:
    """
    Singleton WebSocket Manager for real-time market data.

    Manages multiple WebSocket clients (XTS1, XTS2, Kite, etc.) for redundancy.
    Provides both pull (get_ltp) and push (callbacks) APIs for strategies.
    """
    _instance = None
    _lock = threading.Lock()

    def __new__(cls):
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = super().__new__(cls)
                    cls._instance._initialized = False
        return cls._instance

    def __init__(self):
        if self._initialized:
            return
        self._initialized = True

        # Client management
        self._clients: dict[str, Any] = {}  # client_id -> DataFeedWebSocketHandler
        self._client_accounts: dict[str, Any] = {}  # client_id -> DataFeedAccount
        self._client_states: dict[str, ConnectionState] = {}  # client_id -> state

        # Tick storage (last-write-wins)
        self._tick_store: dict[int, StandardTick] = {}  # instrument_token -> last tick

        # Subscription tracking
        self._subscriptions: set[int] = set()  # subscribed instrument tokens
        self._instrument_map: dict[int, Any] = {}  # token -> Instrument model

        # Callback management
        self._callbacks: dict[str, TickCallback] = {}  # callback_id -> TickCallback
        self._token_callbacks: dict[int, set[str]] = {}  # token -> set of callback_ids

        # Thread safety
        self._state_lock = threading.RLock()
        self._tick_lock = threading.RLock()
        self._callback_lock = threading.RLock()

        # Connection monitoring
        self._monitor_thread: Optional[threading.Thread] = None
        self._monitor_running = False

        # Reconnection settings
        self._reconnect_initial_delay = 1.0  # seconds
        self._reconnect_max_delay = 60.0  # seconds
        self._reconnect_backoff_factor = 2.0
        self._reconnect_max_attempts = 10

        # Running state
        self._running = False

        logger.info("WebSocketManager initialized")

    # -------------------------------------------------------------------------
    # Lifecycle Management
    # -------------------------------------------------------------------------

    def is_running(self) -> bool:
        """Check if the manager is running."""
        return self._running

    def initialize_and_connect(self) -> bool:
        """
        Initialize and connect all active datafeed accounts.
        Called when first strategy starts.
        """
        if self._running:
            logger.warning("WebSocketManager already running")
            return True

        logger.info("Initializing WebSocketManager...")

        try:
            # Import here to avoid circular imports
            from datafeed.models import DataFeedAccount

            # Load active datafeed accounts
            accounts = DataFeedAccount.objects.filter(is_active=True)

            if not accounts.exists():
                logger.warning("No active DataFeedAccounts found")
                return False

            # Register each account as a client
            for account in accounts:
                client_id = self._generate_client_id(account)
                self.register_client(client_id, account)

            # Connect all clients
            self.connect_all()

            # Start connection monitor
            self._start_connection_monitor()

            self._running = True
            logger.info(f"WebSocketManager started with {len(self._clients)} clients")
            return True

        except Exception as e:
            logger.error(f"Failed to initialize WebSocketManager: {e}")
            return False

    def shutdown(self):
        """
        Shutdown the manager and disconnect all clients.
        Can be called when last strategy stops or for manual cleanup.
        """
        logger.info("Shutting down WebSocketManager...")

        self._running = False
        self._stop_connection_monitor()
        self.disconnect_all()

        # Clear state
        with self._state_lock:
            self._clients.clear()
            self._client_accounts.clear()
            self._client_states.clear()

        with self._tick_lock:
            self._tick_store.clear()
            self._subscriptions.clear()
            self._instrument_map.clear()

        with self._callback_lock:
            self._callbacks.clear()
            self._token_callbacks.clear()

        logger.info("WebSocketManager shutdown complete")

    def restart(self):
        """Manual restart for failure recovery."""
        logger.info("Restarting WebSocketManager...")
        self.shutdown()
        time.sleep(1)  # Brief pause before restart
        self.initialize_and_connect()

    def _generate_client_id(self, account) -> str:
        """Generate a client ID from account name."""
        return account.account_name.lower().replace(' ', '_').replace('-', '_')

    # -------------------------------------------------------------------------
    # Client Management
    # -------------------------------------------------------------------------

    def register_client(self, client_id: str, datafeed_account) -> bool:
        """
        Register a WebSocket client.

        Args:
            client_id: Unique identifier (e.g., 'xts1', 'xts2', 'kite1')
            datafeed_account: DataFeedAccount model instance

        Returns:
            bool: True if registration successful
        """
        with self._state_lock:
            if client_id in self._clients:
                logger.warning(f"Client {client_id} already registered")
                return False

            # Import here to avoid circular imports
            from datafeed.websocket.handler import DataFeedWebSocketHandler

            # Create handler with tick callback
            handler = DataFeedWebSocketHandler(datafeed_account)

            self._clients[client_id] = handler
            self._client_accounts[client_id] = datafeed_account
            self._client_states[client_id] = ConnectionState.DISCONNECTED

            logger.info(f"Registered client: {client_id}")
            return True

    def unregister_client(self, client_id: str) -> bool:
        """Unregister and disconnect a client."""
        with self._state_lock:
            if client_id not in self._clients:
                return False

            # Disconnect first
            self.disconnect_client(client_id)

            del self._clients[client_id]
            del self._client_accounts[client_id]
            del self._client_states[client_id]

            logger.info(f"Unregistered client: {client_id}")
            return True

    def get_client_ids(self) -> list[str]:
        """Get list of registered client IDs."""
        with self._state_lock:
            return list(self._clients.keys())

    def get_client_states(self) -> dict[str, ConnectionState]:
        """Get connection states for all clients."""
        with self._state_lock:
            return dict(self._client_states)

    # -------------------------------------------------------------------------
    # Connection Management
    # -------------------------------------------------------------------------

    def connect_all(self) -> dict[str, bool]:
        """
        Connect all registered clients.

        Returns:
            dict: client_id -> success status
        """
        results = {}
        for client_id in self.get_client_ids():
            results[client_id] = self.connect_client(client_id)
        return results

    def connect_client(self, client_id: str) -> bool:
        """
        Connect a specific client.

        Args:
            client_id: Client identifier

        Returns:
            bool: True if connection initiated successfully
        """
        with self._state_lock:
            if client_id not in self._clients:
                logger.error(f"Client {client_id} not registered")
                return False

            if self._client_states[client_id] == ConnectionState.CONNECTED:
                logger.debug(f"Client {client_id} already connected")
                return True

            self._client_states[client_id] = ConnectionState.CONNECTING

        try:
            handler = self._clients[client_id]

            # Create tick callback that routes to manager
            def on_tick(tick_data: dict):
                self._on_tick_received(client_id, tick_data)

            # Connect in background thread
            handler.connect(on_tick=on_tick)

            with self._state_lock:
                self._client_states[client_id] = ConnectionState.CONNECTED

            logger.info(f"Client {client_id} connected")
            return True

        except Exception as e:
            logger.error(f"Failed to connect client {client_id}: {e}")
            with self._state_lock:
                self._client_states[client_id] = ConnectionState.FAILED
            return False

    def disconnect_all(self):
        """Disconnect all clients gracefully."""
        for client_id in self.get_client_ids():
            self.disconnect_client(client_id)

    def disconnect_client(self, client_id: str) -> bool:
        """Disconnect a specific client."""
        with self._state_lock:
            if client_id not in self._clients:
                return False

            handler = self._clients[client_id]

        try:
            handler.disconnect()
            with self._state_lock:
                self._client_states[client_id] = ConnectionState.DISCONNECTED
            logger.info(f"Client {client_id} disconnected")
            return True
        except Exception as e:
            logger.error(f"Error disconnecting client {client_id}: {e}")
            return False

    # -------------------------------------------------------------------------
    # Subscription Management
    # -------------------------------------------------------------------------

    def subscribe(self, instruments: list) -> dict[str, Any]:
        """
        Subscribe to instruments on ALL connected clients.

        Args:
            instruments: List of Instrument model instances

        Returns:
            dict: Results per client
        """
        results = {}

        # Track instruments
        for inst in instruments:
            self._subscriptions.add(inst.instrument_token)
            self._instrument_map[inst.instrument_token] = inst

        # Subscribe on all connected clients
        for client_id, handler in self._clients.items():
            if self._client_states.get(client_id) != ConnectionState.CONNECTED:
                results[client_id] = {'success': False, 'reason': 'not connected'}
                continue

            try:
                result = handler.subscribe(instruments)
                results[client_id] = result
                logger.info(f"Subscribed {len(instruments)} instruments on {client_id}")
            except Exception as e:
                logger.error(f"Subscription failed on {client_id}: {e}")
                results[client_id] = {'success': False, 'error': str(e)}

        return results

    def unsubscribe(self, instruments: list) -> dict[str, Any]:
        """
        Unsubscribe from instruments on ALL clients.

        Args:
            instruments: List of Instrument model instances

        Returns:
            dict: Results per client
        """
        results = {}

        # Remove from tracking
        for inst in instruments:
            self._subscriptions.discard(inst.instrument_token)
            self._instrument_map.pop(inst.instrument_token, None)
            # Also remove from tick store
            with self._tick_lock:
                self._tick_store.pop(inst.instrument_token, None)

        # Unsubscribe on all clients
        for client_id, handler in self._clients.items():
            if self._client_states.get(client_id) != ConnectionState.CONNECTED:
                continue

            try:
                result = handler.unsubscribe(instruments)
                results[client_id] = result
            except Exception as e:
                logger.error(f"Unsubscription failed on {client_id}: {e}")
                results[client_id] = {'success': False, 'error': str(e)}

        return results

    def get_subscribed_tokens(self) -> set[int]:
        """Get all currently subscribed instrument tokens."""
        return set(self._subscriptions)

    def _resubscribe_client(self, client_id: str):
        """Re-subscribe a reconnected client to all instruments."""
        if not self._subscriptions:
            return

        instruments = list(self._instrument_map.values())
        if not instruments:
            return

        try:
            handler = self._clients.get(client_id)
            if handler and self._client_states.get(client_id) == ConnectionState.CONNECTED:
                handler.subscribe(instruments)
                logger.info(f"Re-subscribed {len(instruments)} instruments on {client_id}")
        except Exception as e:
            logger.error(f"Re-subscription failed on {client_id}: {e}")

    # -------------------------------------------------------------------------
    # Tick Access - Pull API
    # -------------------------------------------------------------------------

    def get_ltp(self, instrument_token: int) -> Optional[float]:
        """
        Get last traded price for an instrument.

        Args:
            instrument_token: Instrument token

        Returns:
            float or None: Last traded price, or None if not available
        """
        with self._tick_lock:
            tick = self._tick_store.get(instrument_token)
            return tick.ltp if tick else None

    def get_tick(self, instrument_token: int) -> Optional[StandardTick]:
        """
        Get full tick data for an instrument.

        Args:
            instrument_token: Instrument token

        Returns:
            StandardTick or None: Full tick data, or None if not available
        """
        with self._tick_lock:
            return self._tick_store.get(instrument_token)

    def get_multiple_ltp(self, tokens: list[int]) -> dict[int, float]:
        """
        Batch get LTPs for multiple instruments.

        Args:
            tokens: List of instrument tokens

        Returns:
            dict: token -> LTP mapping (only includes available data)
        """
        result = {}
        with self._tick_lock:
            for token in tokens:
                tick = self._tick_store.get(token)
                if tick:
                    result[token] = tick.ltp
        return result

    def get_multiple_ticks(self, tokens: list[int]) -> dict[int, StandardTick]:
        """
        Batch get full tick data for multiple instruments.

        Args:
            tokens: List of instrument tokens

        Returns:
            dict: token -> StandardTick mapping
        """
        result = {}
        with self._tick_lock:
            for token in tokens:
                tick = self._tick_store.get(token)
                if tick:
                    result[token] = tick
        return result

    def get_all_ticks(self) -> dict[int, StandardTick]:
        """Get all stored ticks."""
        with self._tick_lock:
            return dict(self._tick_store)

    # -------------------------------------------------------------------------
    # Tick Callbacks - Push API
    # -------------------------------------------------------------------------

    def register_tick_callback(
        self,
        tokens: list[int],
        callback: Callable[[StandardTick], None]
    ) -> str:
        """
        Register a callback for tick updates.

        Args:
            tokens: List of instrument tokens to receive updates for
            callback: Function to call when tick received. Signature: callback(tick: StandardTick)

        Returns:
            str: Callback ID for unregistering
        """
        callback_id = str(uuid.uuid4())

        with self._callback_lock:
            # Create callback record
            tick_callback = TickCallback(
                callback_id=callback_id,
                tokens=set(tokens),
                callback=callback
            )
            self._callbacks[callback_id] = tick_callback

            # Map tokens to callback
            for token in tokens:
                if token not in self._token_callbacks:
                    self._token_callbacks[token] = set()
                self._token_callbacks[token].add(callback_id)

        logger.debug(f"Registered callback {callback_id} for {len(tokens)} tokens")
        return callback_id

    def unregister_tick_callback(self, callback_id: str) -> bool:
        """
        Remove a registered callback.

        Args:
            callback_id: ID returned from register_tick_callback

        Returns:
            bool: True if callback was found and removed
        """
        with self._callback_lock:
            if callback_id not in self._callbacks:
                return False

            tick_callback = self._callbacks[callback_id]

            # Remove from token mapping
            for token in tick_callback.tokens:
                if token in self._token_callbacks:
                    self._token_callbacks[token].discard(callback_id)
                    if not self._token_callbacks[token]:
                        del self._token_callbacks[token]

            del self._callbacks[callback_id]

        logger.debug(f"Unregistered callback {callback_id}")
        return True

    def _notify_callbacks(self, tick: StandardTick):
        """Notify registered callbacks about a tick update."""
        with self._callback_lock:
            callback_ids = self._token_callbacks.get(tick.instrument_token, set())

            for callback_id in callback_ids:
                tick_callback = self._callbacks.get(callback_id)
                if tick_callback:
                    try:
                        # Execute callback in separate thread to avoid blocking
                        threading.Thread(
                            target=tick_callback.callback,
                            args=(tick,),
                            daemon=True
                        ).start()
                    except Exception as e:
                        logger.error(f"Callback {callback_id} error: {e}")

    # -------------------------------------------------------------------------
    # Internal Tick Handler
    # -------------------------------------------------------------------------

    def _on_tick_received(self, client_id: str, tick_data: dict):
        """
        Called by WebSocket clients when tick is received.

        Args:
            client_id: Source client identifier
            tick_data: Raw tick data from client
        """
        try:
            # Parse to StandardTick
            tick = self._parse_tick(client_id, tick_data)
            if not tick:
                return

            # Store tick (last-write-wins)
            with self._tick_lock:
                self._tick_store[tick.instrument_token] = tick

            # Log tick
            timestamp = tick.timestamp.strftime("%H:%M:%S.%f")[:-3]
            logger.debug(f"[{timestamp}] [{client_id}] {tick.tradingsymbol}: {tick.ltp}")

            # Notify callbacks
            self._notify_callbacks(tick)

        except Exception as e:
            logger.error(f"Error processing tick from {client_id}: {e}")

    def _parse_tick(self, client_id: str, tick_data: dict) -> Optional[StandardTick]:
        """
        Parse raw tick data to StandardTick.

        Args:
            client_id: Source client
            tick_data: Raw tick data

        Returns:
            StandardTick or None
        """
        try:
            # Handle different tick data formats
            data = tick_data.get('data', tick_data)

            # Parse based on message code
            message_code = tick_data.get('message_code', 0)

            # Try to extract instrument info
            if isinstance(data, str):
                data = json.loads(data)

            # XTS format uses ExchangeInstrumentID
            instrument_id = data.get('ExchangeInstrumentID') or data.get('instrument_token')
            if not instrument_id:
                return None

            # Get instrument from map
            instrument = self._instrument_map.get(int(instrument_id))
            if not instrument:
                # Try to find by broker token
                instrument_token = int(instrument_id)
                exchange = 'NSE'  # Default
                tradingsymbol = str(instrument_id)
            else:
                instrument_token = instrument.instrument_token
                exchange = instrument.exchange
                tradingsymbol = instrument.tradingsymbol

            # Extract LTP
            ltp = float(data.get('LastTradedPrice') or data.get('ltp') or 0)

            # Parse timestamp
            timestamp_str = tick_data.get('timestamp') or data.get('LastUpdateTime')
            if timestamp_str:
                try:
                    if isinstance(timestamp_str, str) and ':' in timestamp_str:
                        timestamp = datetime.strptime(timestamp_str.split('.')[0], "%H:%M:%S")
                        timestamp = timestamp.replace(
                            year=datetime.now().year,
                            month=datetime.now().month,
                            day=datetime.now().day
                        )
                    else:
                        timestamp = datetime.now()
                except:
                    timestamp = datetime.now()
            else:
                timestamp = datetime.now()

            # Extract bid/ask if available
            bids = data.get('Bids', [])
            asks = data.get('Asks', [])

            bid_price = float(bids[0].get('Price', 0)) if bids else 0.0
            bid_qty = int(bids[0].get('Size', 0)) if bids else 0
            ask_price = float(asks[0].get('Price', 0)) if asks else 0.0
            ask_qty = int(asks[0].get('Size', 0)) if asks else 0

            return StandardTick(
                instrument_token=instrument_token,
                exchange=exchange,
                tradingsymbol=tradingsymbol,
                ltp=ltp,
                timestamp=timestamp,
                source_client=client_id,
                bid_price=bid_price,
                bid_qty=bid_qty,
                ask_price=ask_price,
                ask_qty=ask_qty,
                volume=int(data.get('TotalTradedQuantity', 0) or data.get('volume', 0)),
                oi=int(data.get('OpenInterest', 0) or data.get('oi', 0)),
                open=float(data.get('Open', 0) or data.get('open', 0)),
                high=float(data.get('High', 0) or data.get('high', 0)),
                low=float(data.get('Low', 0) or data.get('low', 0)),
                close=float(data.get('Close', 0) or data.get('close', 0)),
            )

        except Exception as e:
            logger.error(f"Error parsing tick: {e}")
            return None

    # -------------------------------------------------------------------------
    # Reconnection Logic
    # -------------------------------------------------------------------------

    def _reconnect_with_backoff(self, client_id: str) -> bool:
        """
        Reconnect a failed client with exponential backoff.

        Args:
            client_id: Client to reconnect

        Returns:
            bool: True if reconnection successful
        """
        delay = self._reconnect_initial_delay
        attempt = 0

        while attempt < self._reconnect_max_attempts and self._running:
            attempt += 1

            with self._state_lock:
                self._client_states[client_id] = ConnectionState.RECONNECTING

            logger.info(f"[{client_id}] Reconnection attempt {attempt}/{self._reconnect_max_attempts} (delay: {delay}s)")

            time.sleep(delay)

            try:
                if self.connect_client(client_id):
                    logger.info(f"[{client_id}] Reconnection successful")
                    # Re-subscribe to instruments
                    self._resubscribe_client(client_id)
                    return True
            except Exception as e:
                logger.error(f"[{client_id}] Reconnection attempt {attempt} failed: {e}")

            # Increase delay with backoff
            delay = min(delay * self._reconnect_backoff_factor, self._reconnect_max_delay)

        # Max attempts reached
        with self._state_lock:
            self._client_states[client_id] = ConnectionState.FAILED

        logger.error(f"[{client_id}] Reconnection failed after {self._reconnect_max_attempts} attempts")
        # TODO: Add Telegram notification here
        return False

    # -------------------------------------------------------------------------
    # Connection Monitoring
    # -------------------------------------------------------------------------

    def _start_connection_monitor(self):
        """Start the connection monitoring thread."""
        if self._monitor_running:
            return

        self._monitor_running = True
        self._monitor_thread = threading.Thread(
            target=self._monitor_connections,
            daemon=True,
            name="WebSocketManager-Monitor"
        )
        self._monitor_thread.start()
        logger.info("Connection monitor started")

    def _stop_connection_monitor(self):
        """Stop the connection monitoring thread."""
        self._monitor_running = False
        if self._monitor_thread and self._monitor_thread.is_alive():
            self._monitor_thread.join(timeout=5)
        logger.info("Connection monitor stopped")

    def _monitor_connections(self):
        """
        Background thread monitoring client health.
        Triggers reconnection for failed clients.
        """
        check_interval = 30  # seconds

        while self._monitor_running:
            try:
                time.sleep(check_interval)

                if not self._running:
                    break

                for client_id in self.get_client_ids():
                    state = self._client_states.get(client_id)

                    # Check if client needs reconnection
                    if state == ConnectionState.FAILED:
                        logger.info(f"[{client_id}] Attempting auto-reconnect...")
                        threading.Thread(
                            target=self._reconnect_with_backoff,
                            args=(client_id,),
                            daemon=True
                        ).start()

                    # Check client health (if connected)
                    elif state == ConnectionState.CONNECTED:
                        handler = self._clients.get(client_id)
                        if handler and not handler.is_connected:
                            logger.warning(f"[{client_id}] Connection lost, triggering reconnect")
                            with self._state_lock:
                                self._client_states[client_id] = ConnectionState.FAILED

            except Exception as e:
                logger.error(f"Connection monitor error: {e}")

    # -------------------------------------------------------------------------
    # Status & Diagnostics
    # -------------------------------------------------------------------------

    def get_status(self) -> dict:
        """Get manager status summary."""
        return {
            'running': self._running,
            'clients': {
                client_id: state.value
                for client_id, state in self._client_states.items()
            },
            'subscriptions': len(self._subscriptions),
            'ticks_stored': len(self._tick_store),
            'callbacks_registered': len(self._callbacks),
        }

    def print_status(self):
        """Print current status to console."""
        status = self.get_status()
        print("\n=== WebSocket Manager Status ===")
        print(f"Running: {status['running']}")
        print(f"Clients:")
        for client_id, state in status['clients'].items():
            print(f"  - {client_id}: {state}")
        print(f"Subscriptions: {status['subscriptions']}")
        print(f"Ticks stored: {status['ticks_stored']}")
        print(f"Callbacks: {status['callbacks_registered']}")
        print("================================\n")


# Module-level singleton instance
websocket_manager = WebSocketManager()
