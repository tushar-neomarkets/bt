"""
XTS WebSocket Client Implementation.
Handles real-time market data streaming via Socket.IO.
"""
import json
import logging
import requests
from datetime import datetime
from typing import Optional, Callable

import socketio

from instruments.models import Instrument, BrokerInstrument

logger = logging.getLogger(__name__)

# XTS Message Codes
XTS_MESSAGE_CODE_TOUCHLINE = 1501      # LTP + Best Bid/Ask
XTS_MESSAGE_CODE_MARKET_DEPTH = 1502   # Market Depth (5 levels) - DEFAULT
XTS_MESSAGE_CODE_CANDLE = 1505         # Candle/OHLC data
XTS_MESSAGE_CODE_OI = 1510             # Open Interest
XTS_MESSAGE_CODE_FULL = 1512           # Full market data

# Default message code for subscriptions
DEFAULT_MESSAGE_CODE = XTS_MESSAGE_CODE_MARKET_DEPTH

# NIFTY 50 default instrument (NSE Index)
NIFTY_50_EXCHANGE_SEGMENT = 1  # NSECM
NIFTY_50_INSTRUMENT_ID = 26000  # NIFTY 50 Index


class XTSWebSocketClient:
    """
    XTS WebSocket client for real-time market data.
    Uses Socket.IO for connection management.
    """

    def __init__(
        self,
        datafeed_account,
        on_tick_callback: Optional[Callable] = None,
        broadcast_mode: str = "Full",
    ):
        """
        Initialize XTS WebSocket client.

        Args:
            datafeed_account: DataFeedAccount instance with credentials
            on_tick_callback: Callback function for tick data
            broadcast_mode: "Full" or "Partial" for data updates
        """
        self.datafeed_account = datafeed_account
        self.on_tick_callback = on_tick_callback
        self.broadcast_mode = broadcast_mode

        self._sio: Optional[socketio.Client] = None
        self._connected = False
        self._user_id: Optional[str] = None

    def _get_base_url(self) -> str:
        """Get the WebSocket base URL from account."""
        account = self.datafeed_account
        if account.extra_data and account.extra_data.get('hostlookup'):
            base_url = account.extra_data.get('connectionString')
            if not base_url:
                raise ValueError("HostLookup enabled but connectionString missing.")
            return base_url
        return account.base_url

    def _get_user_id(self) -> str:
        """Extract user ID from access token or account."""
        # XTS stores userID in the login response, often in extra_data
        if self.datafeed_account.extra_data:
            user_id = self.datafeed_account.extra_data.get('userID')
            if user_id:
                return user_id
        # Fallback to client_id
        return self.datafeed_account.client_id

    def _build_connection_url(self) -> str:
        """Build the WebSocket connection URL with auth params."""
        base_url = self._get_base_url()
        token = self.datafeed_account.access_token
        user_id = self._get_user_id()

        # Build query string
        url = f"{base_url}/?token={token}&userID={user_id}&publishFormat=JSON&broadcastMode={self.broadcast_mode}"
        return url

    def connect(self):
        """
        Establish WebSocket connection to XTS market data server.
        This method blocks until disconnected.
        """
        print("Connecting to XTS WebSocket...")
        logger.info("Connecting to XTS WebSocket...")

        self._sio = socketio.Client(logger=False, engineio_logger=False)
        self._register_event_handlers()

        connection_url = self._build_connection_url()
        socketio_path = '/apimarketdata/socket.io'

        try:
            self._sio.connect(
                connection_url,
                transports=['websocket'],
                socketio_path=socketio_path
            )
            self._connected = True
            # Block and wait for events
            self._sio.wait()
        except Exception as e:
            logger.error(f"WebSocket connection error: {e}")
            print(f"WebSocket connection error: {e}")
            self._connected = False
            raise

    def disconnect(self):
        """Disconnect from WebSocket server."""
        if self._sio and self._connected:
            print("Disconnecting from XTS WebSocket...")
            logger.info("Disconnecting from XTS WebSocket...")
            self._sio.disconnect()
            self._connected = False

    def _register_event_handlers(self):
        """Register Socket.IO event handlers."""
        sio = self._sio

        @sio.event
        def connect():
            self._on_connect()

        @sio.event
        def disconnect():
            self._on_disconnect()

        @sio.event
        def message(data):
            self._on_message(data)

        # 1502 Market Depth events (default)
        @sio.on('1502-json-full')
        def on_1502_full(data):
            self._on_market_depth(data, partial=False)

        @sio.on('1502-json-partial')
        def on_1502_partial(data):
            self._on_market_depth(data, partial=True)

        # Register other message codes for completeness
        @sio.on('1501-json-full')
        def on_1501_full(data):
            self._on_touchline(data, partial=False)

        @sio.on('1501-json-partial')
        def on_1501_partial(data):
            self._on_touchline(data, partial=True)

        @sio.on('1512-json-full')
        def on_1512_full(data):
            self._on_ltp(data, partial=False)

        @sio.on('1512-json-partial')
        def on_1512_partial(data):
            self._on_ltp(data, partial=True)

    def _on_connect(self):
        """Handle successful connection."""
        self._connected = True
        timestamp = datetime.now().strftime("%H:%M:%S")
        print(f"[{timestamp}] XTS WebSocket connected successfully!")
        logger.info("XTS WebSocket connected successfully!")

    def _on_disconnect(self):
        """Handle disconnection."""
        self._connected = False
        timestamp = datetime.now().strftime("%H:%M:%S")
        print(f"[{timestamp}] XTS WebSocket disconnected!")
        logger.info("XTS WebSocket disconnected!")

    def _on_message(self, data):
        """Handle generic messages."""
        timestamp = datetime.now().strftime("%H:%M:%S")
        print(f"[{timestamp}] Message received: {data}")
        logger.debug(f"Message received: {data}")

    def _on_market_depth(self, data: str, partial: bool = False):
        """
        Handle 1502 Market Depth tick data.

        Args:
            data: JSON string with market depth data
            partial: True if this is a partial/delta update
        """
        update_type = "partial" if partial else "full"
        timestamp = datetime.now().strftime("%H:%M:%S.%f")[:-3]

        # Parse the tick data
        try:
            tick_data = json.loads(data) if isinstance(data, str) else data
        except json.JSONDecodeError:
            tick_data = data

        # Log the tick
        print(f"[{timestamp}] 1502 Market Depth ({update_type}): {data}")
        logger.info(f"1502 Market Depth ({update_type}): {data}")

        # Call the callback if registered
        if self.on_tick_callback:
            self.on_tick_callback({
                'message_code': 1502,
                'update_type': update_type,
                'timestamp': timestamp,
                'data': tick_data
            })

    def _on_touchline(self, data: str, partial: bool = False):
        """Handle 1501 Touchline tick data."""
        update_type = "partial" if partial else "full"
        timestamp = datetime.now().strftime("%H:%M:%S.%f")[:-3]

        print(f"[{timestamp}] 1501 Touchline ({update_type}): {data}")
        logger.info(f"1501 Touchline ({update_type}): {data}")

        if self.on_tick_callback:
            try:
                tick_data = json.loads(data) if isinstance(data, str) else data
            except json.JSONDecodeError:
                tick_data = data

            self.on_tick_callback({
                'message_code': 1501,
                'update_type': update_type,
                'timestamp': timestamp,
                'data': tick_data
            })

    def _on_ltp(self, data: str, partial: bool = False):
        """Handle 1512 LTP tick data."""
        update_type = "partial" if partial else "full"
        timestamp = datetime.now().strftime("%H:%M:%S.%f")[:-3]

        print(f"[{timestamp}] 1512 LTP ({update_type}): {data}")
        logger.info(f"1512 LTP ({update_type}): {data}")

        if self.on_tick_callback:
            try:
                tick_data = json.loads(data) if isinstance(data, str) else data
            except json.JSONDecodeError:
                tick_data = data

            self.on_tick_callback({
                'message_code': 1512,
                'update_type': update_type,
                'timestamp': timestamp,
                'data': tick_data
            })

    @property
    def is_connected(self) -> bool:
        """Check if currently connected."""
        return self._connected


# -----------------------------------------------------------------------------
# Subscription Functions (REST API)
# -----------------------------------------------------------------------------

def _get_base_url(account) -> str:
    """Get the appropriate base URL for the account."""
    if account.extra_data and account.extra_data.get('hostlookup'):
        base_url = account.extra_data.get('connectionString')
        if not base_url:
            raise ValueError("HostLookup enabled but connectionString missing.")
        return base_url
    return account.base_url


def _build_instrument_payload(broker_inst: BrokerInstrument) -> dict:
    """Build the XTS instrument payload for API calls."""
    return {
        "exchangeSegment": broker_inst.extra_data['exchange_segment_code'],
        "exchangeInstrumentID": int(broker_inst.broker_token)
    }


def xts_subscribe(
    account,
    instruments: list[Instrument],
    broker_instruments: dict,
    message_code: int = DEFAULT_MESSAGE_CODE
) -> dict:
    """
    Subscribe to instruments for streaming data via REST API.

    Args:
        account: DataFeedAccount instance
        instruments: List of Instrument model instances
        broker_instruments: Dict mapping instrument_token -> BrokerInstrument
        message_code: XTS message code (default: 1502 Market Depth)

    Returns:
        dict: Subscription result
    """
    base_url = _get_base_url(account)
    url = f"{base_url}/apimarketdata/instruments/subscription"

    # Build instrument payloads
    instrument_payloads = []
    for inst in instruments:
        broker_inst = broker_instruments.get(inst.instrument_token)
        if broker_inst:
            instrument_payloads.append(_build_instrument_payload(broker_inst))

    if not instrument_payloads:
        return {'success': False, 'message': 'No valid instruments to subscribe'}

    payload = {
        "instruments": instrument_payloads,
        "xtsMessageCode": message_code
    }

    headers = {
        'Content-Type': 'application/json',
        'Authorization': account.access_token
    }

    print(f"Subscribing to {len(instrument_payloads)} instruments with message code {message_code}")
    logger.info(f"Subscribing to {len(instrument_payloads)} instruments with message code {message_code}")

    try:
        response = requests.post(url, headers=headers, data=json.dumps(payload))
        data = response.json()

        if data.get('type') == 'success':
            print(f"Subscription successful: {data.get('description')}")
            logger.info(f"Subscription successful: {data.get('description')}")
            return {'success': True, 'data': data}
        else:
            print(f"Subscription failed: {data.get('description')}")
            logger.warning(f"Subscription failed: {data.get('description')}")
            return {'success': False, 'message': data.get('description'), 'data': data}
    except Exception as e:
        logger.error(f"Subscription error: {e}")
        return {'success': False, 'message': str(e)}


def xts_unsubscribe(
    account,
    instruments: list[Instrument],
    broker_instruments: dict,
    message_code: int = DEFAULT_MESSAGE_CODE
) -> dict:
    """
    Unsubscribe from instruments via REST API.

    Args:
        account: DataFeedAccount instance
        instruments: List of Instrument model instances
        broker_instruments: Dict mapping instrument_token -> BrokerInstrument
        message_code: XTS message code (default: 1502 Market Depth)

    Returns:
        dict: Unsubscription result
    """
    base_url = _get_base_url(account)
    url = f"{base_url}/apimarketdata/instruments/subscription"

    # Build instrument payloads
    instrument_payloads = []
    for inst in instruments:
        broker_inst = broker_instruments.get(inst.instrument_token)
        if broker_inst:
            instrument_payloads.append(_build_instrument_payload(broker_inst))

    if not instrument_payloads:
        return {'success': False, 'message': 'No valid instruments to unsubscribe'}

    payload = {
        "instruments": instrument_payloads,
        "xtsMessageCode": message_code
    }

    headers = {
        'Content-Type': 'application/json',
        'Authorization': account.access_token
    }

    print(f"Unsubscribing from {len(instrument_payloads)} instruments with message code {message_code}")
    logger.info(f"Unsubscribing from {len(instrument_payloads)} instruments with message code {message_code}")

    try:
        # XTS uses PUT for unsubscription
        response = requests.put(url, headers=headers, data=json.dumps(payload))
        data = response.json()

        if data.get('type') == 'success':
            print(f"Unsubscription successful: {data.get('description')}")
            logger.info(f"Unsubscription successful: {data.get('description')}")
            return {'success': True, 'data': data}
        else:
            print(f"Unsubscription failed: {data.get('description')}")
            logger.warning(f"Unsubscription failed: {data.get('description')}")
            return {'success': False, 'message': data.get('description'), 'data': data}
    except Exception as e:
        logger.error(f"Unsubscription error: {e}")
        return {'success': False, 'message': str(e)}


def get_nifty50_subscription_payload() -> list[dict]:
    """
    Get the default NIFTY 50 subscription payload.

    Returns:
        list: List containing NIFTY 50 instrument payload
    """
    return [{
        "exchangeSegment": NIFTY_50_EXCHANGE_SEGMENT,
        "exchangeInstrumentID": NIFTY_50_INSTRUMENT_ID
    }]


def xts_subscribe_nifty50(account, message_code: int = DEFAULT_MESSAGE_CODE) -> dict:
    """
    Subscribe to NIFTY 50 index directly (without Instrument model).

    Args:
        account: DataFeedAccount instance
        message_code: XTS message code (default: 1502 Market Depth)

    Returns:
        dict: Subscription result
    """
    base_url = _get_base_url(account)
    url = f"{base_url}/apimarketdata/instruments/subscription"

    payload = {
        "instruments": get_nifty50_subscription_payload(),
        "xtsMessageCode": message_code
    }

    headers = {
        'Content-Type': 'application/json',
        'Authorization': account.access_token
    }

    print(f"Subscribing to NIFTY 50 with message code {message_code}")
    logger.info(f"Subscribing to NIFTY 50 with message code {message_code}")

    try:
        response = requests.post(url, headers=headers, data=json.dumps(payload))
        data = response.json()

        if data.get('type') == 'success':
            print(f"NIFTY 50 subscription successful: {data.get('description')}")
            logger.info(f"NIFTY 50 subscription successful: {data.get('description')}")
            return {'success': True, 'data': data}
        else:
            print(f"NIFTY 50 subscription failed: {data.get('description')}")
            logger.warning(f"NIFTY 50 subscription failed: {data.get('description')}")
            return {'success': False, 'message': data.get('description'), 'data': data}
    except Exception as e:
        logger.error(f"NIFTY 50 subscription error: {e}")
        return {'success': False, 'message': str(e)}
