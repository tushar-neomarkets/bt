"""
Standardized data types for WebSocket market data.
"""
from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional


@dataclass
class StandardTick:
    """
    Standardized tick data structure.
    All WebSocket clients convert their tick data to this format.
    """
    # Core identification
    instrument_token: int
    exchange: str
    tradingsymbol: str

    # Price data
    ltp: float
    timestamp: datetime

    # Source tracking
    source_client: str  # Which client provided this tick (e.g., 'xts1', 'kite1')

    # Best bid/ask (optional - from 1502 depth data)
    bid_price: float = 0.0
    bid_qty: int = 0
    ask_price: float = 0.0
    ask_qty: int = 0

    # Volume and OI (optional)
    volume: int = 0
    oi: int = 0

    # Additional price data (optional)
    open: float = 0.0
    high: float = 0.0
    low: float = 0.0
    close: float = 0.0

    # Change metrics (optional)
    change: float = 0.0
    change_percent: float = 0.0

    def to_dict(self) -> dict:
        """Convert to dictionary representation."""
        return {
            'instrument_token': self.instrument_token,
            'exchange': self.exchange,
            'tradingsymbol': self.tradingsymbol,
            'ltp': self.ltp,
            'timestamp': self.timestamp.isoformat() if self.timestamp else None,
            'source_client': self.source_client,
            'bid_price': self.bid_price,
            'bid_qty': self.bid_qty,
            'ask_price': self.ask_price,
            'ask_qty': self.ask_qty,
            'volume': self.volume,
            'oi': self.oi,
            'open': self.open,
            'high': self.high,
            'low': self.low,
            'close': self.close,
            'change': self.change,
            'change_percent': self.change_percent,
        }


@dataclass
class TickCallback:
    """
    Registered tick callback information.
    """
    callback_id: str
    tokens: set[int]  # Instrument tokens this callback is interested in
    callback: callable
    created_at: datetime = field(default_factory=datetime.now)

    def __hash__(self):
        return hash(self.callback_id)
