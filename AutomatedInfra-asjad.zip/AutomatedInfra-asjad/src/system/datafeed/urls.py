from django.urls import path

from datafeed.views import (
    DataFeedAccountListView,
    DataFeedAccountDetailView,
    DataFeedUpdateTokenView,
    DataFeedLTPView,
    DataFeedQuoteView,
)

urlpatterns = [
    # List all datafeed accounts
    path('', DataFeedAccountListView.as_view(), name='datafeed-accounts-list'),

    # Get specific account details
    path('<int:account_id>/', DataFeedAccountDetailView.as_view(), name='datafeed-account-detail'),

    # Update token for an account (POST)
    path('<int:account_id>/update-token/', DataFeedUpdateTokenView.as_view(), name='datafeed-update-token'),

    # Get LTP for an instrument (GET with ?instrument_token=xxx)
    path('<int:account_id>/ltp/', DataFeedLTPView.as_view(), name='datafeed-ltp'),

    # Get full quote for an instrument (GET with ?instrument_token=xxx)
    path('<int:account_id>/quote/', DataFeedQuoteView.as_view(), name='datafeed-quote'),
]
