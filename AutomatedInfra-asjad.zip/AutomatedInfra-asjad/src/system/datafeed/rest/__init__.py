"""
DataFeed REST API module.
Provides broker-agnostic market data access through standardized interfaces.
"""
from datafeed.rest.handler import DataFeedHandler
from datafeed.rest.data_types import StandardLTP, StandardQuote, StandardMarketDepth, MarketDepthLevel

__all__ = [
    'DataFeedHandler',
    'StandardLTP',
    'StandardQuote',
    'StandardMarketDepth',
    'MarketDepthLevel',
]
