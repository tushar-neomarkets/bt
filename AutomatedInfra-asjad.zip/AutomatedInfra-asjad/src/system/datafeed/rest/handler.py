"""
DataFeed Handler - Broker-agnostic interface for market data.
Follows the same delegation pattern as accounts/brokers/handler.py
"""
from typing import Optional
from django.utils import timezone

from instruments.models import Instrument, BrokerInstrument
from datafeed.rest.data_types import StandardLTP, StandardQuote


class DataFeedHandler:
    """
    Public interface for fetching market data from various providers.
    Delegates to provider-specific implementations based on the account's provider.
    """

    def __init__(self, datafeed_account):
        self.datafeed_account = datafeed_account

    def _get_safe_provider_name(self) -> str:
        """Returns normalized provider name for method dispatch."""
        return self.datafeed_account.provider.provider_name.lower().replace(' ', '_')

    def _get_broker_instrument(self, instrument: Instrument) -> Optional[BrokerInstrument]:
        """Get the broker-specific instrument mapping."""
        broker_name = self.datafeed_account.provider.provider_name.upper()
        return BrokerInstrument.get_by_instrument_and_broker(
            instrument.instrument_token,
            broker_name
        )

    def _get_broker_instruments(self, instruments: list[Instrument]) -> dict:
        """Bulk get broker-specific instrument mappings."""
        broker_name = self.datafeed_account.provider.provider_name.upper()
        instrument_tokens = [inst.instrument_token for inst in instruments]
        return BrokerInstrument.bulk_get_by_instruments_and_broker(
            instrument_tokens,
            broker_name
        )

    # -------------------------------------------------------------------------
    # Token Management
    # -------------------------------------------------------------------------

    def update_token(self) -> bool:
        """
        Refresh the access token for the datafeed account.
        Delegates to provider-specific implementation.
        """
        print(f"--- UPDATE TOKEN REQUEST --- for datafeed account: {self.datafeed_account}")
        safe_provider_name = self._get_safe_provider_name()
        func_name = f"_{safe_provider_name}_update_token"

        handler_func = getattr(self, func_name, None)
        if callable(handler_func):
            try:
                result = handler_func()
                print(f"--- REQUEST COMPLETE ---")
                return result
            except Exception as e:
                print(f"Error updating token: {e}")
                raise e
        else:
            error_msg = f"Provider Not Supported: No handler found for '{self.datafeed_account.provider.provider_name}' (looked for {func_name})"
            print(error_msg)
            raise NotImplementedError(error_msg)

    def _xts_update_token(self) -> bool:
        """XTS-specific token update."""
        from datafeed.rest.xts import marketdata_login
        return marketdata_login(self.datafeed_account)

    # -------------------------------------------------------------------------
    # Single Instrument LTP
    # -------------------------------------------------------------------------

    def get_single_ltp(self, instrument: Instrument) -> dict:
        """
        Fetch Last Traded Price for a single instrument.

        Args:
            instrument: Instrument model instance

        Returns:
            dict: Standardized response with LTP data
        """
        self.datafeed_account.refresh_from_db()
        print(f"--- GET LTP REQUEST --- for instrument: {instrument}")
        safe_provider_name = self._get_safe_provider_name()
        func_name = f"_{safe_provider_name}_get_single_ltp"

        handler_func = getattr(self, func_name, None)
        if callable(handler_func):
            try:
                broker_inst = self._get_broker_instrument(instrument)
                if not broker_inst:
                    raise ValueError(f"No broker mapping found for instrument {instrument}")

                ltp_data: StandardLTP = handler_func(instrument, broker_inst)

                response = {
                    "data": {
                        "last_updated": timezone.now().isoformat(),
                        "ltp": ltp_data.to_dict()
                    }
                }
                print(f"--- REQUEST COMPLETE ---")
                return response
            except Exception as e:
                print(f"Error fetching LTP: {e}")
                raise e
        else:
            error_msg = f"Provider Not Supported: No LTP handler found for '{self.datafeed_account.provider.provider_name}'"
            raise NotImplementedError(error_msg)

    def _xts_get_single_ltp(self, instrument: Instrument, broker_inst: BrokerInstrument) -> StandardLTP:
        """XTS-specific single LTP fetch."""
        from datafeed.rest.xts import xts_get_ltp
        return xts_get_ltp(self.datafeed_account, instrument, broker_inst)

    # -------------------------------------------------------------------------
    # Multiple Instruments LTP
    # -------------------------------------------------------------------------

    def get_multiple_ltp(self, instrument_list: list[Instrument]) -> dict:
        """
        Fetch Last Traded Price for multiple instruments.

        Args:
            instrument_list: List of Instrument model instances

        Returns:
            dict: Standardized response with LTP data for all instruments
        """
        self.datafeed_account.refresh_from_db()
        print(f"--- GET MULTIPLE LTP REQUEST --- for {len(instrument_list)} instruments")
        safe_provider_name = self._get_safe_provider_name()
        func_name = f"_{safe_provider_name}_get_multiple_ltp"

        handler_func = getattr(self, func_name, None)
        if callable(handler_func):
            try:
                broker_instruments = self._get_broker_instruments(instrument_list)
                if not broker_instruments:
                    raise ValueError("No broker mappings found for any instruments")

                ltp_list: list[StandardLTP] = handler_func(instrument_list, broker_instruments)

                response = {
                    "data": {
                        "last_updated": timezone.now().isoformat(),
                        "count": len(ltp_list),
                        "ltp_list": [ltp.to_dict() for ltp in ltp_list]
                    }
                }
                print(f"--- REQUEST COMPLETE ---")
                return response
            except Exception as e:
                print(f"Error fetching multiple LTP: {e}")
                raise e
        else:
            error_msg = f"Provider Not Supported: No multiple LTP handler found for '{self.datafeed_account.provider.provider_name}'"
            raise NotImplementedError(error_msg)

    def _xts_get_multiple_ltp(self, instruments: list[Instrument], broker_instruments: dict) -> list[StandardLTP]:
        """XTS-specific multiple LTP fetch."""
        from datafeed.rest.xts import xts_get_multiple_ltp
        return xts_get_multiple_ltp(self.datafeed_account, instruments, broker_instruments)

    # -------------------------------------------------------------------------
    # Single Instrument Quote
    # -------------------------------------------------------------------------

    def get_single_quote(self, instrument: Instrument) -> dict:
        """
        Fetch full quote (OHLC, volume, depth) for a single instrument.

        Args:
            instrument: Instrument model instance

        Returns:
            dict: Standardized response with full quote data
        """
        self.datafeed_account.refresh_from_db()
        print(f"--- GET QUOTE REQUEST --- for instrument: {instrument}")
        safe_provider_name = self._get_safe_provider_name()
        func_name = f"_{safe_provider_name}_get_single_quote"

        handler_func = getattr(self, func_name, None)
        if callable(handler_func):
            try:
                broker_inst = self._get_broker_instrument(instrument)
                if not broker_inst:
                    raise ValueError(f"No broker mapping found for instrument {instrument}")

                quote_data: StandardQuote = handler_func(instrument, broker_inst)

                response = {
                    "data": {
                        "last_updated": timezone.now().isoformat(),
                        "quote": quote_data.to_dict()
                    }
                }
                print(f"--- REQUEST COMPLETE ---")
                return response
            except Exception as e:
                print(f"Error fetching quote: {e}")
                raise e
        else:
            error_msg = f"Provider Not Supported: No quote handler found for '{self.datafeed_account.provider.provider_name}'"
            raise NotImplementedError(error_msg)

    def _xts_get_single_quote(self, instrument: Instrument, broker_inst: BrokerInstrument) -> StandardQuote:
        """XTS-specific single quote fetch."""
        from datafeed.rest.xts import xts_get_quote
        return xts_get_quote(self.datafeed_account, instrument, broker_inst)

    # -------------------------------------------------------------------------
    # Multiple Instruments Quote
    # -------------------------------------------------------------------------

    def get_multiple_quote(self, instrument_list: list[Instrument]) -> dict:
        """
        Fetch full quotes for multiple instruments.

        Args:
            instrument_list: List of Instrument model instances

        Returns:
            dict: Standardized response with quote data for all instruments
        """
        self.datafeed_account.refresh_from_db()
        print(f"--- GET MULTIPLE QUOTE REQUEST --- for {len(instrument_list)} instruments")
        safe_provider_name = self._get_safe_provider_name()
        func_name = f"_{safe_provider_name}_get_multiple_quote"

        handler_func = getattr(self, func_name, None)
        if callable(handler_func):
            try:
                broker_instruments = self._get_broker_instruments(instrument_list)
                if not broker_instruments:
                    raise ValueError("No broker mappings found for any instruments")

                quote_list: list[StandardQuote] = handler_func(instrument_list, broker_instruments)

                response = {
                    "data": {
                        "last_updated": timezone.now().isoformat(),
                        "count": len(quote_list),
                        "quote_list": [quote.to_dict() for quote in quote_list]
                    }
                }
                print(f"--- REQUEST COMPLETE ---")
                return response
            except Exception as e:
                print(f"Error fetching multiple quotes: {e}")
                raise e
        else:
            error_msg = f"Provider Not Supported: No multiple quote handler found for '{self.datafeed_account.provider.provider_name}'"
            raise NotImplementedError(error_msg)

    def _xts_get_multiple_quote(self, instruments: list[Instrument], broker_instruments: dict) -> list[StandardQuote]:
        """XTS-specific multiple quote fetch."""
        from datafeed.rest.xts import xts_get_multiple_quotes
        return xts_get_multiple_quotes(self.datafeed_account, instruments, broker_instruments)

    # -------------------------------------------------------------------------
    # Multiple Instruments Touchline (LTP + Best Bid/Ask + Volume)
    # -------------------------------------------------------------------------

    def get_multiple_touchline(self, instrument_list: list[Instrument]) -> dict:
        """
        Fetch Touchline data (LTP + best bid/ask + volume) for multiple instruments.
        Uses Touchline message code instead of Market Depth, ensuring LTP is populated.

        Args:
            instrument_list: List of Instrument model instances

        Returns:
            dict: Standardized response with quote data for all instruments
        """
        self.datafeed_account.refresh_from_db()
        print(f"--- GET MULTIPLE TOUCHLINE REQUEST --- for {len(instrument_list)} instruments")
        safe_provider_name = self._get_safe_provider_name()
        func_name = f"_{safe_provider_name}_get_multiple_touchline"

        handler_func = getattr(self, func_name, None)
        if callable(handler_func):
            try:
                broker_instruments = self._get_broker_instruments(instrument_list)
                if not broker_instruments:
                    raise ValueError("No broker mappings found for any instruments")

                quote_list: list[StandardQuote] = handler_func(instrument_list, broker_instruments)

                response = {
                    "data": {
                        "last_updated": timezone.now().isoformat(),
                        "count": len(quote_list),
                        "quote_list": [quote.to_dict() for quote in quote_list]
                    }
                }
                print(f"--- REQUEST COMPLETE ---")
                return response
            except Exception as e:
                print(f"Error fetching multiple touchline: {e}")
                raise e
        else:
            error_msg = f"Provider Not Supported: No multiple touchline handler found for '{self.datafeed_account.provider.provider_name}'"
            raise NotImplementedError(error_msg)

    def _xts_get_multiple_touchline(self, instruments: list[Instrument], broker_instruments: dict) -> list[StandardQuote]:
        """XTS-specific multiple touchline fetch."""
        from datafeed.rest.xts import xts_get_multiple_touchline
        return xts_get_multiple_touchline(self.datafeed_account, instruments, broker_instruments)

    # -------------------------------------------------------------------------
    # Account Info
    # -------------------------------------------------------------------------

    def get_datafeed_account(self) -> dict:
        """Returns account info and token status."""
        print(f"--- GET DATAFEED ACCOUNT --- for: {self.datafeed_account}")

        return {
            "id": self.datafeed_account.id,
            "account_name": self.datafeed_account.account_name,
            "client_id": self.datafeed_account.client_id,
            "provider": {
                "id": self.datafeed_account.provider.id,
                "name": self.datafeed_account.provider.provider_name,
            },
            "is_active": self.datafeed_account.is_active,
            "token_status": {
                "is_valid": not self.datafeed_account.is_token_expired,
                "expires_at": self.datafeed_account.token_expiry,
                "last_refreshed": self.datafeed_account.updated_at
            },
            "created_at": self.datafeed_account.created_at,
        }
