"""
Standardized market data types independent of datafeed provider.
These structures normalize data from various sources (XTS, Zerodha, etc.)
"""
from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional


@dataclass
class StandardLTP:
    """
    Standardized Last Traded Price format.
    Broker-agnostic representation of LTP data.
    """
    instrument_token: int
    exchange: str
    tradingsymbol: str
    ltp: float
    timestamp: datetime

    def to_dict(self) -> dict:
        return {
            "instrument_token": self.instrument_token,
            "exchange": self.exchange,
            "tradingsymbol": self.tradingsymbol,
            "ltp": self.ltp,
            "timestamp": self.timestamp.isoformat() if self.timestamp else None,
        }


@dataclass
class StandardQuote:
    """
    Standardized Quote format with full market depth.
    Broker-agnostic representation of quote data.
    """
    # Identification
    instrument_token: int
    exchange: str
    tradingsymbol: str

    # Price data
    ltp: float
    open: float
    high: float
    low: float
    close: float

    # Volume data
    volume: int
    last_traded_qty: int

    # Best bid/ask
    best_bid_price: float
    best_bid_qty: int
    best_ask_price: float
    best_ask_qty: int

    # Change metrics
    change: float
    change_percent: float

    # Open interest (for derivatives)
    oi: int = 0
    oi_day_high: int = 0
    oi_day_low: int = 0

    # Timestamps
    timestamp: Optional[datetime] = None
    last_trade_time: Optional[datetime] = None

    # Average trade price
    atp: float = 0.0

    # Total buy/sell quantities
    total_buy_qty: int = 0
    total_sell_qty: int = 0

    def to_dict(self) -> dict:
        return {
            "instrument_token": self.instrument_token,
            "exchange": self.exchange,
            "tradingsymbol": self.tradingsymbol,
            "ltp": self.ltp,
            "open": self.open,
            "high": self.high,
            "low": self.low,
            "close": self.close,
            "volume": self.volume,
            "last_traded_qty": self.last_traded_qty,
            "best_bid_price": self.best_bid_price,
            "best_bid_qty": self.best_bid_qty,
            "best_ask_price": self.best_ask_price,
            "best_ask_qty": self.best_ask_qty,
            "change": self.change,
            "change_percent": self.change_percent,
            "oi": self.oi,
            "oi_day_high": self.oi_day_high,
            "oi_day_low": self.oi_day_low,
            "atp": self.atp,
            "total_buy_qty": self.total_buy_qty,
            "total_sell_qty": self.total_sell_qty,
            "timestamp": self.timestamp.isoformat() if self.timestamp else None,
            "last_trade_time": self.last_trade_time.isoformat() if self.last_trade_time else None,
        }


@dataclass
class MarketDepthLevel:
    """Single level of market depth (bid or ask)."""
    price: float
    quantity: int
    orders: int = 0


@dataclass
class StandardMarketDepth:
    """
    Full market depth with 5 levels of bid/ask.
    """
    instrument_token: int
    exchange: str
    tradingsymbol: str
    bids: list[MarketDepthLevel] = field(default_factory=list)
    asks: list[MarketDepthLevel] = field(default_factory=list)
    timestamp: Optional[datetime] = None

    def to_dict(self) -> dict:
        return {
            "instrument_token": self.instrument_token,
            "exchange": self.exchange,
            "tradingsymbol": self.tradingsymbol,
            "bids": [{"price": b.price, "quantity": b.quantity, "orders": b.orders} for b in self.bids],
            "asks": [{"price": a.price, "quantity": a.quantity, "orders": a.orders} for a in self.asks],
            "timestamp": self.timestamp.isoformat() if self.timestamp else None,
        }
