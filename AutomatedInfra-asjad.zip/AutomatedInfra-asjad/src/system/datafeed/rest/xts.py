"""
XTS Market Data API Implementation.
Handles all XTS-specific market data operations.
"""
import requests
import json
from datetime import datetime
from typing import Optional

from django.utils import timezone

from instruments.models import Instrument, BrokerInstrument
from datafeed.rest.data_types import StandardLTP, StandardQuote


# XTS Exchange Segment Mapping
XTS_EXCHANGE_SEGMENT = {
    "NSE": "NSECM",
    "BSE": "BSECM",
    "NFO": "NSEFO",
    "BFO": "BSEFO",
    "MCX": "MCXFO",
}

# XTS Message Codes for different data types
XTS_MESSAGE_CODE_TOUCHLINE = 1501      # LTP + Best Bid/Ask
XTS_MESSAGE_CODE_MARKET_DEPTH = 1502   # Market Depth (5 levels)
XTS_MESSAGE_CODE_CANDLE = 1505         # Candle/OHLC data
XTS_MESSAGE_CODE_OI = 1510             # Open Interest
XTS_MESSAGE_CODE_FULL = 1512           # Full market data (includes all)


def _get_base_url(account) -> str:
    """Get the appropriate base URL for the account."""
    if account.extra_data and account.extra_data.get('hostlookup'):
        base_url = account.extra_data.get('connectionString')
        if not base_url:
            raise ValueError("HostLookup enabled but connectionString missing.")
        return base_url
    return account.base_url


def _get_xts_exchange_segment(exchange: str) -> str:
    """Convert standard exchange code to XTS segment format."""
    return XTS_EXCHANGE_SEGMENT.get(exchange, exchange)


def _build_instrument_payload(broker_inst: BrokerInstrument) -> dict:
    """Build the XTS instrument payload for API calls."""
    return {
        "exchangeSegment": broker_inst.extra_data['exchange_segment_code'],
        "exchangeInstrumentID": int(broker_inst.broker_token)
    }


def _parse_xts_timestamp(timestamp_str: Optional[str]) -> Optional[datetime]:
    """Parse XTS timestamp format to datetime."""
    if not timestamp_str:
        return None
    try:
        # XTS format: "Jan 01 2026 09:15:00"
        return datetime.strptime(timestamp_str, "%b %d %Y %H:%M:%S")
    except (ValueError, TypeError):
        return None


# -----------------------------------------------------------------------------
# Authentication
# -----------------------------------------------------------------------------

def marketdata_login(account) -> bool:
    """
    Authenticate with XTS Market Data API and store the token.

    Args:
        account: DataFeedAccount instance

    Returns:
        bool: True if login successful, False otherwise
    """
    print(f"Market data login for {account} ...")

    url = f"{account.base_url}/apimarketdata/auth/login"
    payload = {
        "appKey": account.api_key,
        "secretKey": account.api_secret,
        "source": "WEBAPI"
    }
    headers = {'Content-Type': 'application/json'}

    try:
        response = requests.post(url, headers=headers, data=json.dumps(payload))
        data = response.json()

        if data.get('type') == 'success' and 'result' in data:
            result = data['result']
            account.access_token = result.get('token')
            account.token_expiry = timezone.now().replace(hour=23, minute=59, second=59)
            account.save(update_fields=['access_token', 'token_expiry', 'updated_at'])
            print("Market Data Login Successful. Token updated.")
            return True
        else:
            # print(f"{data}")
            print(f"Market Data Login Failed: {data.get('description')}")
            return False
    except Exception as e:
        print(f"Exception in Market Data Login: {e}")
        return False


# -----------------------------------------------------------------------------
# LTP Functions
# -----------------------------------------------------------------------------

def xts_get_ltp(account, instrument: Instrument, broker_inst: BrokerInstrument) -> StandardLTP:
    """
    Fetch LTP for a single instrument from XTS.

    Args:
        account: DataFeedAccount instance
        instrument: Instrument model instance
        broker_inst: BrokerInstrument mapping

    Returns:
        StandardLTP: Normalized LTP data
    """
    print(f"Fetching XTS LTP for {instrument} ...")

    base_url = _get_base_url(account)
    url = f"{base_url}/apimarketdata/instruments/quotes"

    # XTS requires instruments, xtsMessageCode, and publishFormat
    payload = {
        "instruments": [_build_instrument_payload(broker_inst)],
        "xtsMessageCode": XTS_MESSAGE_CODE_TOUCHLINE,
        "publishFormat": "JSON"
    }

    headers = {
        'Content-Type': 'application/json',
        'Authorization': account.access_token
    }

    try:
        response = requests.post(url, headers=headers, data=json.dumps(payload))
        # print(response)
        if response.status_code == 401:
            raise Exception("Unauthorized: Token expired or invalid.")

        response.raise_for_status()
        data = response.json()

        if data.get('type') == 'success' and 'result' in data:
            result = data['result']

            if 'listQuotes' in result and len(result['listQuotes']) > 0:

                quote_data = json.loads(result['listQuotes'][0])
                print(quote_data)
                return StandardLTP(
                    instrument_token=instrument.instrument_token,
                    exchange=instrument.exchange,
                    tradingsymbol=instrument.tradingsymbol,
                    ltp=float(quote_data.get('LastTradedPrice', 0)),
                    timestamp=_parse_xts_timestamp(quote_data.get('LastUpdateTime')) or timezone.now()
                )
            else:
                raise Exception("No quote data returned from XTS")
        else:
            raise Exception(f"XTS LTP Failed: {data.get('description')}")

    except Exception as e:
        print(f"Exception in XTS get_ltp: {e}")
        raise e


def xts_get_multiple_ltp(account, instruments: list[Instrument], broker_instruments: dict) -> list[StandardLTP]:
    """
    Fetch LTP for multiple instruments from XTS.

    Args:
        account: DataFeedAccount instance
        instruments: List of Instrument model instances
        broker_instruments: Dict mapping instrument_token -> BrokerInstrument

    Returns:
        list[StandardLTP]: List of normalized LTP data
    """
    print(f"Fetching XTS LTP for {len(instruments)} instruments ...")

    base_url = _get_base_url(account)
    url = f"{base_url}/apimarketdata/instruments/quotes"

    # Build instruments payload
    instrument_payloads = []
    token_to_instrument = {}

    for inst in instruments:
        broker_inst = broker_instruments.get(inst.instrument_token)
        if broker_inst:
            instrument_payloads.append(_build_instrument_payload(broker_inst))
            token_to_instrument[int(broker_inst.broker_token)] = inst

    if not instrument_payloads:
        return []

    # XTS requires instruments, xtsMessageCode, and publishFormat
    payload = {
        "instruments": instrument_payloads,
        "xtsMessageCode": XTS_MESSAGE_CODE_TOUCHLINE,
        "publishFormat": "JSON"
    }
    headers = {
        'Content-Type': 'application/json',
        'Authorization': account.access_token
    }

    try:
        response = requests.post(url, headers=headers, data=json.dumps(payload))

        if response.status_code == 401:
            raise Exception("Unauthorized: Token expired or invalid.")

        response.raise_for_status()
        data = response.json()

        if data.get('type') == 'success' and 'result' in data:
            result = data['result']
            ltp_list = []

            for quote_str in result.get('listQuotes', []):
                quote_data = json.loads(quote_str)
                exchange_inst_id = int(quote_data.get('ExchangeInstrumentID', 0))

                # Find the matching instrument
                inst = token_to_instrument.get(exchange_inst_id)
                if inst:
                    ltp_list.append(StandardLTP(
                        instrument_token=inst.instrument_token,
                        exchange=inst.exchange,
                        tradingsymbol=inst.tradingsymbol,
                        ltp=float(quote_data.get('LastTradedPrice', 0)),
                        timestamp=_parse_xts_timestamp(quote_data.get('LastUpdateTime')) or timezone.now()
                    ))

            return ltp_list
        else:
            raise Exception(f"XTS Multiple LTP Failed: {data.get('description')}")

    except Exception as e:
        print(f"Exception in XTS get_multiple_ltp: {e}")
        raise e


# -----------------------------------------------------------------------------
# Quote Functions
# -----------------------------------------------------------------------------

def xts_get_quote(account, instrument: Instrument, broker_inst: BrokerInstrument) -> StandardQuote:
    """
    Fetch full quote for a single instrument from XTS.

    Args:
        account: DataFeedAccount instance
        instrument: Instrument model instance
        broker_inst: BrokerInstrument mapping

    Returns:
        StandardQuote: Normalized quote data
    """
    print(f"Fetching XTS Quote for {instrument} ...")

    base_url = _get_base_url(account)
    url = f"{base_url}/apimarketdata/instruments/quotes"

    # XTS requires instruments, xtsMessageCode, and publishFormat
    payload = {
        "instruments": [_build_instrument_payload(broker_inst)],
        "xtsMessageCode": XTS_MESSAGE_CODE_MARKET_DEPTH,
        "publishFormat": "JSON"
    }

    headers = {
        'Content-Type': 'application/json',
        'Authorization': account.access_token
    }

    try:
        response = requests.post(url, headers=headers, data=json.dumps(payload))

        if response.status_code == 401:
            raise Exception("Unauthorized: Token expired or invalid.")

        response.raise_for_status()
        data = response.json()

        if data.get('type') == 'success' and 'result' in data:
            result = data['result']

            if 'listQuotes' in result and len(result['listQuotes']) > 0:
                quote_data = json.loads(result['listQuotes'][0])
                return _parse_xts_quote(instrument, quote_data)
            else:
                raise Exception("No quote data returned from XTS")
        else:
            raise Exception(f"XTS Quote Failed: {data.get('description')}")

    except Exception as e:
        print(f"Exception in XTS get_quote: {e}")
        raise e


def xts_get_multiple_quotes(account, instruments: list[Instrument], broker_instruments: dict) -> list[StandardQuote]:
    """
    Fetch full quotes for multiple instruments from XTS.

    Args:
        account: DataFeedAccount instance
        instruments: List of Instrument model instances
        broker_instruments: Dict mapping instrument_token -> BrokerInstrument

    Returns:
        list[StandardQuote]: List of normalized quote data
    """
    print(f"Fetching XTS Quotes for {len(instruments)} instruments ...")

    base_url = _get_base_url(account)
    url = f"{base_url}/apimarketdata/instruments/quotes"

    # Build instruments payload
    instrument_payloads = []
    token_to_instrument = {}

    for inst in instruments:
        broker_inst = broker_instruments.get(inst.instrument_token)
        if broker_inst:
            instrument_payloads.append(_build_instrument_payload(broker_inst))
            token_to_instrument[int(broker_inst.broker_token)] = inst

    if not instrument_payloads:
        return []

    # XTS requires instruments, xtsMessageCode, and publishFormat
    payload = {
        "instruments": instrument_payloads,
        "xtsMessageCode": XTS_MESSAGE_CODE_MARKET_DEPTH,
        "publishFormat": "JSON"
    }

    headers = {
        'Content-Type': 'application/json',
        'Authorization': account.access_token
    }

    try:
        response = requests.post(url, headers=headers, data=json.dumps(payload))

        if response.status_code == 400:
            raise Exception(f"XTS 400 from quotes: body={response.text} payload_count={len(instrument_payloads)}")
        if response.status_code == 401:
            raise Exception(f"Unauthorized: {response.text}")

        response.raise_for_status()
        data = response.json()

        if data.get('type') == 'success' and 'result' in data:
            result = data['result']

            quote_list = []

            for quote_str in result.get('listQuotes', []):
                quote_data = json.loads(quote_str)
                exchange_inst_id = int(quote_data.get('ExchangeInstrumentID', 0))

                # Find the matching instrument
                inst = token_to_instrument.get(exchange_inst_id)
                if inst:
                    quote_list.append(_parse_xts_quote(inst, quote_data))
            return quote_list
        else:
            raise Exception(f"XTS Multiple Quotes Failed: {data.get('description')}")

    except Exception as e:
        print(f"Exception in XTS get_multiple_quotes: {e}")
        raise e


def xts_get_multiple_touchline(account, instruments: list[Instrument], broker_instruments: dict) -> list[StandardQuote]:
    """
    Fetch Touchline data (LTP + best bid/ask + volume) for multiple instruments from XTS.
    Uses XTS_MESSAGE_CODE_TOUCHLINE (1501) instead of MARKET_DEPTH (1502).

    Args:
        account: DataFeedAccount instance
        instruments: List of Instrument model instances
        broker_instruments: Dict mapping instrument_token -> BrokerInstrument

    Returns:
        list[StandardQuote]: List of normalized quote data with LTP populated
    """
    print(f"Fetching XTS Touchline for {len(instruments)} instruments ...")

    base_url = _get_base_url(account)
    url = f"{base_url}/apimarketdata/instruments/quotes"

    # Build instruments payload
    instrument_payloads = []
    token_to_instrument = {}

    for inst in instruments:
        broker_inst = broker_instruments.get(inst.instrument_token)
        if broker_inst:
            instrument_payloads.append(_build_instrument_payload(broker_inst))
            token_to_instrument[int(broker_inst.broker_token)] = inst

    if not instrument_payloads:
        return []

    payload = {
        "instruments": instrument_payloads,
        "xtsMessageCode": XTS_MESSAGE_CODE_TOUCHLINE,
        "publishFormat": "JSON"
    }

    headers = {
        'Content-Type': 'application/json',
        'Authorization': account.access_token
    }

    try:
        response = requests.post(url, headers=headers, data=json.dumps(payload))

        if response.status_code == 401:
            raise Exception("Unauthorized: Token expired or invalid.")

        response.raise_for_status()
        data = response.json()

        if data.get('type') == 'success' and 'result' in data:
            result = data['result']

            quote_list = []

            for quote_str in result.get('listQuotes', []):
                quote_data = json.loads(quote_str)
                exchange_inst_id = int(quote_data.get('ExchangeInstrumentID', 0))

                # Find the matching instrument
                inst = token_to_instrument.get(exchange_inst_id)
                if inst:
                    quote_list.append(_parse_xts_quote(inst, quote_data))
            return quote_list
        else:
            raise Exception(f"XTS Multiple Touchline Failed: {data.get('description')}")

    except Exception as e:
        print(f"Exception in XTS get_multiple_touchline: {e}")
        raise e


def _parse_xts_quote(instrument: Instrument, quote_data: dict) -> StandardQuote:
    """
    Parse XTS quote response to StandardQuote format.

    Args:
        instrument: Instrument model instance
        quote_data: Raw XTS quote data

    Returns:
        StandardQuote: Normalized quote data
    """
    ltp = float(quote_data.get('LastTradedPrice', 0))
    close = float(quote_data.get('Close', 0))

    # Calculate change
    change = ltp - close if close else 0
    change_percent = (change / close * 100) if close else 0

    # Parse bid/ask - handle both TOUCHLINE format (BidPrice/AskPrice) and MARKET_DEPTH format (Bids/Asks arrays)
    bids = quote_data.get('Bids', [])
    asks = quote_data.get('Asks', [])

    if bids and asks:
        # MARKET_DEPTH format
        best_bid_price = float(bids[0].get('Price', 0)) if bids else 0
        best_bid_qty = int(bids[0].get('Size', 0)) if bids else 0
        best_ask_price = float(asks[0].get('Price', 0)) if asks else 0
        best_ask_qty = int(asks[0].get('Size', 0)) if asks else 0
    else:
        # TOUCHLINE format
        best_bid_price = float(quote_data.get('BidPrice', 0))
        best_bid_qty = int(quote_data.get('BidSize', 0))
        best_ask_price = float(quote_data.get('AskPrice', 0))
        best_ask_qty = int(quote_data.get('AskSize', 0))

    return StandardQuote(
        instrument_token=instrument.instrument_token,
        exchange=instrument.exchange,
        tradingsymbol=instrument.tradingsymbol,
        ltp=ltp,
        open=float(quote_data.get('Open', 0)),
        high=float(quote_data.get('High', 0)),
        low=float(quote_data.get('Low', 0)),
        close=close,
        volume=int(quote_data.get('TotalTradedQuantity', 0)),
        last_traded_qty=int(quote_data.get('LastTradedQunatity', 0)),  # XTS typo in API
        best_bid_price=best_bid_price,
        best_bid_qty=best_bid_qty,
        best_ask_price=best_ask_price,
        best_ask_qty=best_ask_qty,
        change=round(change, 2),
        change_percent=round(change_percent, 2),
        oi=int(quote_data.get('OpenInterest', 0)),
        oi_day_high=int(quote_data.get('OpenInterestDayHigh', 0)),
        oi_day_low=int(quote_data.get('OpenInterestDayLow', 0)),
        atp=float(quote_data.get('AverageTradedPrice', 0)),
        total_buy_qty=int(quote_data.get('TotalBuyQuantity', 0)),
        total_sell_qty=int(quote_data.get('TotalSellQuantity', 0)),
        timestamp=_parse_xts_timestamp(quote_data.get('LastUpdateTime')) or timezone.now(),
        last_trade_time=_parse_xts_timestamp(quote_data.get('LastTradedTime'))
    )


# -----------------------------------------------------------------------------
# OHLC Functions
# -----------------------------------------------------------------------------

def xts_get_ohlc(account, instrument: Instrument, broker_inst: BrokerInstrument) -> dict:
    """
    Fetch OHLC data for a single instrument from XTS.

    Args:
        account: DataFeedAccount instance
        instrument: Instrument model instance
        broker_inst: BrokerInstrument mapping

    Returns:
        dict: OHLC data
    """
    print(f"Fetching XTS OHLC for {instrument} ...")

    base_url = _get_base_url(account)
    url = f"{base_url}/apimarketdata/instruments/ohlc"

    payload = {
        "exchangeSegment": broker_inst.broker_exchange,
        "exchangeInstrumentID": int(broker_inst.broker_token)
    }

    headers = {
        'Content-Type': 'application/json',
        'Authorization': account.access_token
    }

    try:
        response = requests.get(url, headers=headers, params=payload)

        if response.status_code == 401:
            raise Exception("Unauthorized: Token expired or invalid.")

        response.raise_for_status()
        data = response.json()

        if data.get('type') == 'success' and 'result' in data:
            result = data['result']
            return {
                "instrument_token": instrument.instrument_token,
                "exchange": instrument.exchange,
                "tradingsymbol": instrument.tradingsymbol,
                "open": float(result.get('Open', 0)),
                "high": float(result.get('High', 0)),
                "low": float(result.get('Low', 0)),
                "close": float(result.get('Close', 0)),
            }
        else:
            raise Exception(f"XTS OHLC Failed: {data.get('description')}")

    except Exception as e:
        print(f"Exception in XTS get_ohlc: {e}")
        raise e


# -----------------------------------------------------------------------------
# Subscription Functions
# -----------------------------------------------------------------------------

def xts_subscribe_instruments(account, instruments: list[Instrument], broker_instruments: dict, message_code: int = XTS_MESSAGE_CODE_MARKET_DEPTH) -> dict:
    """
    Subscribe to instruments for streaming data.

    Args:
        account: DataFeedAccount instance
        instruments: List of Instrument model instances
        broker_instruments: Dict mapping instrument_token -> BrokerInstrument
        message_code: XTS message code (use XTS_MESSAGE_CODE_* constants)

    Returns:
        dict: Subscription result
    """
    print(f"Subscribing to {len(instruments)} instruments on XTS ...")

    base_url = _get_base_url(account)
    url = f"{base_url}/apimarketdata/instruments/subscription"

    instrument_payloads = []
    for inst in instruments:
        broker_inst = broker_instruments.get(inst.instrument_token)
        if broker_inst:
            instrument_payloads.append(_build_instrument_payload(broker_inst))

    if not instrument_payloads:
        raise ValueError("No valid broker instrument mappings found")

    payload = {
        "instruments": instrument_payloads,
        "xtsMessageCode": message_code
    }

    headers = {
        'Content-Type': 'application/json',
        'Authorization': account.access_token
    }

    try:
        response = requests.post(url, headers=headers, data=json.dumps(payload))

        if response.status_code == 401:
            raise Exception("Unauthorized: Token expired or invalid.")

        response.raise_for_status()
        data = response.json()

        if data.get('type') == 'success':
            return {
                "subscribed_count": len(instrument_payloads),
                "message_code": message_code,
                "result": data.get('result')
            }
        else:
            raise Exception(f"XTS Subscription Failed: {data.get('description')}")

    except Exception as e:
        print(f"Exception in XTS subscribe: {e}")
        raise e


def xts_unsubscribe_instruments(account, instruments: list[Instrument], broker_instruments: dict, message_code: int = XTS_MESSAGE_CODE_MARKET_DEPTH) -> dict:
    """
    Unsubscribe from instruments.

    Args:
        account: DataFeedAccount instance
        instruments: List of Instrument model instances
        broker_instruments: Dict mapping instrument_token -> BrokerInstrument
        message_code: XTS message code (use XTS_MESSAGE_CODE_* constants)

    Returns:
        dict: Unsubscription result
    """
    print(f"Unsubscribing from {len(instruments)} instruments on XTS ...")

    base_url = _get_base_url(account)
    url = f"{base_url}/apimarketdata/instruments/subscription"

    instrument_payloads = []
    for inst in instruments:
        broker_inst = broker_instruments.get(inst.instrument_token)
        if broker_inst:
            instrument_payloads.append(_build_instrument_payload(broker_inst))

    if not instrument_payloads:
        raise ValueError("No valid broker instrument mappings found")

    payload = {
        "instruments": instrument_payloads,
        "xtsMessageCode": message_code
    }

    headers = {
        'Content-Type': 'application/json',
        'Authorization': account.access_token
    }

    try:
        response = requests.put(url, headers=headers, data=json.dumps(payload))

        if response.status_code == 401:
            raise Exception("Unauthorized: Token expired or invalid.")

        response.raise_for_status()
        data = response.json()

        if data.get('type') == 'success':
            return {
                "unsubscribed_count": len(instrument_payloads),
                "message_code": message_code,
                "result": data.get('result')
            }
        else:
            raise Exception(f"XTS Unsubscription Failed: {data.get('description')}")

    except Exception as e:
        print(f"Exception in XTS unsubscribe: {e}")
        raise e
