from django.contrib import admin

# Register your models here.

from datafeed.models import DataFeedProvider,DataFeedAccount

admin.site.register(DataFeedProvider)
admin.site.register(DataFeedAccount)
