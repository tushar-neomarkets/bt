""" State-Machine Short Strangle (A ↔ B) — Weekly Expiry Day Only

State A — short non-directional strangle (CE+PE) at offset x.
State B — single-leg short (CE or PE) at offset x, opened on A's SL.
A → B   — fires when (cur_ce + cur_pe) >= a_entry_gross * (1 + y%).
          New B leg is PE if forward moved up since A's entry, else CE.
B → A   — fires when cur_b_price >= b_entry_price * (1 + z%).
          Re-opens non-dir strangle at offset x1 around CURRENT forward.
Halt    — once transition_count >= max_cycles or local time >= 15:10:59,
          no further (re)entries; we just wait to EOD-close whatever is open.
EOD     — at 15:24:59, close anything still open.
"""

import json
import os
import shutil
import time
import uuid
from datetime import date, datetime, time as dt_time
from decimal import Decimal
from typing import Optional

import pandas as pd

from django.db.models import Min
from django.utils import timezone

from instruments.models import Instrument
from orders.order_manager import order_manager
from strategy.models import StrategyPosition
from strategy.strategy_class.base_strategy import BaseStrategy


# =============================================================================
# CONSTANTS
# =============================================================================

INDEX_NAME = "NIFTY 50"
TICKER = "NIFTY"

# ── TBT (Tick-By-Tick) ──────────────────────────────────────────────────────
TBT_DATA_PATH = r"\\10.211.8.76\GFD MBM Data\Momentum\logs"
TBT_INDEX_NAME = "Nifty 50"
LOCAL_TBT_DIR = os.path.join(
    os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))),
    "dump", "tbt_local",
)

TBT_MARKET_OPEN = dt_time(9, 15, 0)
TBT_MARKET_CLOSE = dt_time(15, 29, 10)
TBT_MAX_STALENESS_SECS = 120

# ── Strategy parameter defaults ──────────────────────────────────────────────
DEFAULT_X            = 0.5          # initial / A→B strangle offset, in straddles
DEFAULT_X1           = 1.0          # B→A re-entry strangle offset, in straddles
DEFAULT_Y_PCT        = 30.0         # State A SL %  (combined CE+PE premium)
DEFAULT_Z_PCT        = 10.0         # State B SL %  (single-leg premium)
DEFAULT_ENTRY_TIME   = dt_time(9, 16, 59)
DEFAULT_MAX_CYCLES   = 5            # max A↔B transitions per day
DEFAULT_POLL_INTERVAL_SECS = 5

EXIT_TIME            = dt_time(15, 24, 59)   # mirrors backtest EXIT_TIME
NO_NEW_ENTRY_AFTER   = dt_time(15, 10, 59)   # mirrors backtest NO_NEW_ENTRY_AFTER
PRICE_OFFSET = Decimal("0.05")

_BASE_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
STMSS_DUMP_DIR = os.path.join(_BASE_DIR, 'dump', 'stmss')

LEG_A_CE = "A_CE"
LEG_A_PE = "A_PE"
LEG_B    = "B_LEG"
A_LEGS = (LEG_A_CE, LEG_A_PE)


class StateMachineShortStrangle(BaseStrategy):
    """
    See module docstring for the full state-machine spec.
    """

    def __init__(self, strategy_obj, datafeed_obj, ws_manager=None):
        super().__init__(strategy_obj, datafeed_obj, ws_manager)
        self.is_running = False

        # ── Resolved params ──────────────────────────────────────────
        self.x: float = DEFAULT_X
        self.x1: float = DEFAULT_X1
        self.y_pct: float = DEFAULT_Y_PCT
        self.z_pct: float = DEFAULT_Z_PCT
        self.entry_time: dt_time = DEFAULT_ENTRY_TIME
        self.max_cycles: int = DEFAULT_MAX_CYCLES
        self.poll_interval_secs: int = DEFAULT_POLL_INTERVAL_SECS

        # ── Day-level state ──────────────────────────────────────────
        self.expiry: Optional[date] = None
        self.state: Optional[str] = None     # 'A', 'B', or None
        self.transition_count: int = 0
        self.halted: bool = False

        # ── State A fields (short non-dir strangle) ──────────────────
        self.a_call_strike: Optional[Decimal] = None
        self.a_put_strike: Optional[Decimal] = None
        self.a_entry_ce_price: float = 0.0
        self.a_entry_pe_price: float = 0.0
        self.a_entry_gross: float = 0.0
        self.a_entry_forward: Optional[float] = None

        # ── State B fields (single-leg short) ────────────────────────
        self.b_strike: Optional[Decimal] = None
        self.b_leg_type: Optional[str] = None        # 'CE' or 'PE'
        self.b_entry_price: float = 0.0

        # ── DB position handles, keyed by leg name ───────────────────
        self.open_positions: dict[str, StrategyPosition] = {}
        self._last_good_max_ts: Optional[datetime] = None

        # ── Cached strike list for the day ───────────────────────────
        self._available_strikes: list[Decimal] = []

        self.log_info(
            f"Initializing {self.strategy_obj.strategy_code} — "
            f"{self.strategy_obj.strategy_name}"
        )

    # =========================================================================
    # INSTRUMENT LOOKUPS
    # =========================================================================

    def _get_nearest_option_expiry(self) -> Optional[date]:
        today = date.today()
        result = Instrument.objects.filter(
            name=TICKER,
            exchange="NFO",
            instrument_type__in=["CE", "PE"],
            is_active=True,
            expiry__gte=today,
        ).aggregate(min_expiry=Min("expiry"))
        return result.get("min_expiry")

    def _load_available_strikes(self, expiry: date) -> None:
        strikes = (
            Instrument.objects.filter(
                name=TICKER, exchange="NFO",
                instrument_type__in=["CE", "PE"],
                expiry=expiry, is_active=True,
            )
            .values_list("strike", flat=True)
            .distinct()
        )
        self._available_strikes = sorted([s for s in strikes if s is not None])

    def _nearest_strike(self, target: float) -> Optional[Decimal]:
        """Mirrors np.argmin(|strikes - target|) in the backtest."""
        if not self._available_strikes:
            return None
        return min(self._available_strikes, key=lambda s: abs(float(s) - target))

    def _get_option_instrument(
        self, strike: Decimal, option_type: str
    ) -> Optional[Instrument]:
        return Instrument.objects.filter(
            name=TICKER,
            exchange="NFO",
            instrument_type=option_type,
            expiry=self.expiry,
            strike=strike,
            is_active=True,
        ).first()

    # =========================================================================
    # TBT SPOT PRICE
    # =========================================================================

    def _copy_tbt_file(self, file_date: Optional[date] = None) -> Optional[str]:
        target_date = file_date or date.today()
        filename = target_date.strftime("%Y%m%d") + ".txt"
        source = os.path.join(TBT_DATA_PATH, filename)

        os.makedirs(LOCAL_TBT_DIR, exist_ok=True)
        dest = os.path.join(LOCAL_TBT_DIR, filename)

        try:
            shutil.copy2(source, dest)
            return dest
        except FileNotFoundError:
            self.log_error(f"TBT file not found: {source}")
            return None
        except Exception as e:
            self.log_error(f"Failed to copy TBT file: {e}")
            return None

    def _parse_tbt_data(self, file_path: str) -> Optional[pd.DataFrame]:
        try:
            df = pd.read_csv(
                file_path,
                sep=r"\s*\|\s*",
                header=None,
                names=["timestamp", "index_name", "price", "seq_id"],
                engine="python",
            )
        except Exception as e:
            self.log_error(f"Failed to parse TBT file: {e}")
            return None

        df = df[df["index_name"] == TBT_INDEX_NAME].copy()
        if df.empty:
            self.log_error(f"No '{TBT_INDEX_NAME}' ticks in TBT file.")
            return None

        df["timestamp"] = pd.to_datetime(df["timestamp"], format="mixed")
        df["price"] = pd.to_numeric(df["price"], errors="coerce")
        df = df.dropna(subset=["price"])
        df = df.sort_values("timestamp").reset_index(drop=True)

        pre = len(df)
        df = df[
            (df["timestamp"].dt.time >= TBT_MARKET_OPEN)
            & (df["timestamp"].dt.time <= TBT_MARKET_CLOSE)
        ].reset_index(drop=True)
        rejected = pre - len(df)
        if rejected > 0:
            self.log_info(f"Market hours filter: rejected {rejected} ticks outside 09:15–15:30")

        if df.empty:
            self.log_error("No ticks remain after market hours filter.")
            return None
        return df[["timestamp", "price"]]

    def _validate_tbt_data(self, tbt_df: pd.DataFrame) -> bool:
        max_ts: datetime = tbt_df["timestamp"].max().to_pydatetime()
        now = datetime.now()

        staleness = (now - max_ts).total_seconds()
        if staleness > TBT_MAX_STALENESS_SECS:
            self.log_error(
                f"TBT REJECTED (stale): latest tick {max_ts.strftime('%H:%M:%S')} "
                f"is {staleness:.0f}s behind wall clock"
            )
            return False

        if self._last_good_max_ts is not None and max_ts < self._last_good_max_ts:
            regression = (self._last_good_max_ts - max_ts).total_seconds()
            self.log_error(
                f"TBT REJECTED (regression): max tick {max_ts.strftime('%H:%M:%S')} "
                f"< previous good {self._last_good_max_ts.strftime('%H:%M:%S')} "
                f"(regressed {regression:.0f}s)"
            )
            return False

        self._last_good_max_ts = max_ts
        return True

    def _fetch_spot_from_tbt(self) -> Optional[float]:
        local_path = self._copy_tbt_file()
        if local_path is None:
            return None
        df = self._parse_tbt_data(local_path)
        if df is None or df.empty:
            return None
        if not self._validate_tbt_data(df):
            return None
        return float(df["price"].iloc[-1])

    # =========================================================================
    # DATA FEED
    # =========================================================================

    def _fetch_ltp(self, datafeed_handler, instrument: Instrument) -> Optional[float]:
        attempt = 0
        while self.is_running:
            attempt += 1
            try:
                self.datafeed_obj.refresh_from_db()
                from datafeed.rest.handler import DataFeedHandler
                datafeed_handler = DataFeedHandler(self.datafeed_obj)
                response = datafeed_handler.get_multiple_ltp([instrument])
                if response and "data" in response:
                    for item in response["data"].get("ltp_list", []):
                        if item.get("instrument_token") == instrument.instrument_token:
                            return item.get("ltp")
                return None
            except Exception as e:
                status = getattr(getattr(e, "response", None), "status_code", None)
                is_auth_error = status in (400, 401) or "Unauthorized" in str(e)
                if is_auth_error:
                    self.log_warning(
                        f"LTP fetch failed (attempt {attempt}: {e}) — refreshing token..."
                    )
                    try:
                        from datafeed.rest.handler import DataFeedHandler
                        DataFeedHandler(self.datafeed_obj).update_token()
                        self.datafeed_obj.refresh_from_db()
                        datafeed_handler = DataFeedHandler(self.datafeed_obj)
                    except Exception as refresh_err:
                        self.log_error(f"Token refresh failed: {refresh_err}")
                    time.sleep(2)
                    continue
                self.log_error(f"Error fetching LTP for {instrument}: {e}")
                return None
        return None

    def _fetch_multiple_ltp(
        self, datafeed_handler, instruments: list[Instrument]
    ) -> dict[int, float]:
        if not instruments:
            return {}
        attempt = 0
        while self.is_running:
            attempt += 1
            try:
                self.datafeed_obj.refresh_from_db()
                from datafeed.rest.handler import DataFeedHandler
                datafeed_handler = DataFeedHandler(self.datafeed_obj)
                response = datafeed_handler.get_multiple_ltp(instruments)
                result: dict[int, float] = {}
                if response and "data" in response:
                    for item in response["data"].get("ltp_list", []):
                        token = item.get("instrument_token")
                        ltp = item.get("ltp")
                        if token and ltp:
                            result[token] = ltp
                return result
            except Exception as e:
                status = getattr(getattr(e, "response", None), "status_code", None)
                is_auth_error = status in (400, 401) or "Unauthorized" in str(e)
                if is_auth_error:
                    self.log_warning(
                        f"Multi LTP fetch failed (attempt {attempt}: {e}) — refreshing token..."
                    )
                    try:
                        from datafeed.rest.handler import DataFeedHandler
                        DataFeedHandler(self.datafeed_obj).update_token()
                        self.datafeed_obj.refresh_from_db()
                        datafeed_handler = DataFeedHandler(self.datafeed_obj)
                    except Exception as refresh_err:
                        self.log_error(f"Token refresh failed: {refresh_err}")
                    time.sleep(2)
                    continue
                self.log_error(f"Error fetching multiple LTP: {e}")
                return {}
        return {}

    # =========================================================================
    # ATM STRADDLE FETCH
    # =========================================================================

    def _fetch_atm_straddle(
        self, datafeed_handler, spot: float
    ) -> Optional[tuple[Decimal, float, float, float]]:
        """
        Returns (atm_strike, ce_ltp, pe_ltp, atm_straddle_price) or None.
        Mirrors backtest: pick nearest strike to spot, take CE+PE close.
        """
        atm_strike = self._nearest_strike(spot)
        if atm_strike is None:
            self.log_error("ATM straddle: no available strikes")
            return None
        ce_inst = self._get_option_instrument(atm_strike, "CE")
        pe_inst = self._get_option_instrument(atm_strike, "PE")
        if not ce_inst or not pe_inst:
            self.log_error(f"ATM straddle: missing CE/PE for strike {atm_strike}")
            return None
        ltps = self._fetch_multiple_ltp(datafeed_handler, [ce_inst, pe_inst])
        ce_ltp = ltps.get(ce_inst.instrument_token)
        pe_ltp = ltps.get(pe_inst.instrument_token)
        if ce_ltp is None or pe_ltp is None or ce_ltp <= 0 or pe_ltp <= 0:
            self.log_error(
                f"ATM straddle: invalid LTPs ce={ce_ltp} pe={pe_ltp} (strike {atm_strike})"
            )
            return None
        return atm_strike, float(ce_ltp), float(pe_ltp), float(ce_ltp + pe_ltp)

    # =========================================================================
    # ORDER PLACEMENT
    # =========================================================================

    def _limit_price(self, side: str, ltp: float) -> Decimal:
        base = Decimal(str(ltp))
        return base + PRICE_OFFSET if side == "SELL" else base - PRICE_OFFSET

    def _place_order(
        self,
        instrument: Instrument,
        side: str,
        quantity: int,
        price: Optional[Decimal],
        order_intent: str,
        tag: str = "",
        dry_run: bool = False,
    ) -> tuple[bool, object]:
        order_type = "LIMIT" if price is not None else "MARKET"
        price_str = str(price) if price is not None else "MKT"

        if dry_run:
            self.log_info(
                f"  [DRY-RUN][{tag}] {order_intent} {side} {quantity} x"
                f" {instrument.tradingsymbol} | {order_type} @ {price_str}"
                f" | NRML | expiry={instrument.expiry}"
            )
            return True, None

        success, msg, parent_order, _ = order_manager.create_and_execute_order(
            strategy=self.strategy_obj,
            instrument=instrument,
            side=side,
            quantity=quantity,
            order_type=order_type,
            product_type="NRML",
            price=price,
            order_intent=order_intent,
            metadata={
                "strategy_code": self.strategy_obj.strategy_code,
                "instrument_type": instrument.instrument_type,
                "stock_name": instrument.name,
                "tag": tag,
            },
        )
        if success:
            self.log_info(
                f"  [{tag}] {side} {quantity} x {instrument.tradingsymbol} @ {price_str}"
            )
        else:
            self.log_error(f"  [{tag}] FAILED {side} {instrument.tradingsymbol}: {msg}")
        return success, parent_order

    # =========================================================================
    # LEG OPEN / CLOSE
    # =========================================================================

    def _open_leg(
        self,
        leg_name: str,
        side: str,
        instrument: Instrument,
        entry_ltp: float,
        dry_run: bool,
        meta_extra: Optional[dict] = None,
    ) -> bool:
        lot_size = instrument.lot_size
        price = self._limit_price(side, entry_ltp)
        tag = f"STMSS_{leg_name}"

        success, parent_order = self._place_order(
            instrument, side, lot_size, price,
            order_intent="ENTRY", tag=tag, dry_run=dry_run,
        )
        if not success:
            return False

        pos_type = "SHORT" if side == "SELL" else "LONG"
        now = timezone.now()
        meta = {
            "leg_name": leg_name,
            "strike": float(instrument.strike),
            "expiry": str(instrument.expiry),
            "option_type": instrument.instrument_type,
            "transition_idx": self.transition_count,
            "state_at_entry": self.state,
        }
        if meta_extra:
            meta.update(meta_extra)

        pos = StrategyPosition.objects.create(
            trade_id=f"STMSS_{self.strategy_obj.id}_{uuid.uuid4().hex[:8]}",
            strategy=self.strategy_obj,
            instrument=instrument,
            position_type=pos_type,
            status="OPEN",
            quantity=lot_size,
            entry_price=Decimal(str(entry_ltp)),
            entry_time=now,
            entry_parent_order=parent_order,
            last_price=Decimal(str(entry_ltp)),
            last_price_updated_at=now,
            strategy_metadata=meta,
        )
        self.open_positions[leg_name] = pos
        self.log_info(
            f"  [{leg_name}] OPENED {side} strike={instrument.strike} "
            f"entry={entry_ltp:.2f} lot_size={lot_size}"
        )
        return True

    def _close_leg(
        self,
        leg_name: str,
        reason: str,
        datafeed_handler,
        dry_run: bool,
    ) -> bool:
        pos = self.open_positions.get(leg_name)
        if pos is None:
            return False

        instrument = pos.instrument
        lot_size = pos.quantity
        side = "BUY" if pos.position_type == "SHORT" else "SELL"

        exit_ltp = self._fetch_ltp(datafeed_handler, instrument)
        price = self._limit_price(side, exit_ltp) if exit_ltp is not None else None
        tag = f"STMSS_{leg_name}_{reason}"

        if exit_ltp is None:
            self.log_warning(
                f"  [{leg_name}] EXIT ({reason}): LTP unavailable — placing MARKET order"
            )

        success, parent_order = self._place_order(
            instrument, side, lot_size, price,
            order_intent="EXIT", tag=tag, dry_run=dry_run,
        )
        if not success:
            return False

        pos.status = "CLOSED"
        pos.exit_time = timezone.now()
        pos.exit_parent_order = parent_order
        pos.unrealized_pnl = Decimal("0.00")
        if exit_ltp is not None:
            pos.exit_price = Decimal(str(exit_ltp))
            if pos.position_type == "SHORT":
                pnl = (float(pos.entry_price) - exit_ltp) * lot_size
            else:
                pnl = (exit_ltp - float(pos.entry_price)) * lot_size
            pos.realized_pnl = Decimal(str(pnl))

        meta = pos.strategy_metadata or {}
        meta["exit_reason"] = reason
        meta["exit_ltp"] = exit_ltp
        pos.strategy_metadata = meta
        pos.save()

        del self.open_positions[leg_name]
        self.log_info(
            f"  [{leg_name}] CLOSED ({reason}) "
            f"strike={instrument.strike} "
            f"entry={pos.entry_price} exit={exit_ltp}"
        )
        return True

    # =========================================================================
    # STATE A / B LIFECYCLE
    # =========================================================================

    def _open_state_a(
        self,
        datafeed_handler,
        dry_run: bool,
        spot: float,
        cur_straddle: float,
        offset_mult: float,
    ) -> bool:
        """
        Open the non-directional short strangle (State A).
        Strikes picked at spot ± offset_mult × cur_straddle.
        Mirrors backtest pick_strikes() + entry block.
        """
        offset_pts = offset_mult * cur_straddle
        call_k = self._nearest_strike(spot + offset_pts)
        put_k  = self._nearest_strike(spot - offset_pts)

        if call_k is None or put_k is None:
            self.log_error("State A: could not resolve strikes")
            return False

        ce_inst = self._get_option_instrument(call_k, "CE")
        pe_inst = self._get_option_instrument(put_k,  "PE")
        if not ce_inst or not pe_inst:
            self.log_error(
                f"State A: missing instruments (CE@{call_k}, PE@{put_k})"
            )
            return False

        ltps = self._fetch_multiple_ltp(datafeed_handler, [ce_inst, pe_inst])
        ce_ltp = ltps.get(ce_inst.instrument_token)
        pe_ltp = ltps.get(pe_inst.instrument_token)
        if not ce_ltp or not pe_ltp or ce_ltp <= 0 or pe_ltp <= 0:
            self.log_error(f"State A: invalid LTPs ce={ce_ltp} pe={pe_ltp}")
            return False

        self.log_info(
            f"Opening STATE A: CE {call_k}@{ce_ltp:.2f}, PE {put_k}@{pe_ltp:.2f} "
            f"(offset={offset_pts:.2f} from spot={spot:.2f}, cur_straddle={cur_straddle:.2f})"
        )

        meta = {"a_entry_forward": spot, "cur_straddle_at_entry": cur_straddle}
        ok_ce = self._open_leg(LEG_A_CE, "SELL", ce_inst, ce_ltp, dry_run, meta_extra=meta)
        ok_pe = self._open_leg(LEG_A_PE, "SELL", pe_inst, pe_ltp, dry_run, meta_extra=meta)
        if not (ok_ce and ok_pe):
            self.log_error("State A: one or both legs failed to open")
            return False

        # Lock A entry fields per backtest lines 213-218 / 244-249
        self.a_call_strike    = call_k
        self.a_put_strike     = put_k
        self.a_entry_ce_price = float(ce_ltp)
        self.a_entry_pe_price = float(pe_ltp)
        self.a_entry_gross    = float(ce_ltp) + float(pe_ltp)
        self.a_entry_forward  = spot
        self.state            = 'A'
        return True

    def _close_state_a(self, reason: str, datafeed_handler, dry_run: bool) -> None:
        for leg in A_LEGS:
            if leg in self.open_positions:
                self._close_leg(leg, reason, datafeed_handler, dry_run)
        self.a_call_strike = None
        self.a_put_strike  = None
        self.a_entry_ce_price = 0.0
        self.a_entry_pe_price = 0.0
        self.a_entry_gross    = 0.0
        self.a_entry_forward  = None

    def _open_state_b(
        self,
        datafeed_handler,
        dry_run: bool,
        spot: float,
        cur_straddle: float,
        leg_type: str,
        offset_mult: float,
    ) -> bool:
        """
        Open single-leg short (State B). Leg type is 'CE' (forward fell)
        or 'PE' (forward rose) — chosen by caller. Strike at spot ± offset.
        Mirrors backtest lines 165-187.
        """
        offset_pts = offset_mult * cur_straddle
        if leg_type == 'PE':
            strike = self._nearest_strike(spot - offset_pts)
        else:
            strike = self._nearest_strike(spot + offset_pts)

        if strike is None:
            self.log_error(f"State B: could not resolve strike for {leg_type}")
            return False

        inst = self._get_option_instrument(strike, leg_type)
        if not inst:
            self.log_error(f"State B: missing instrument {leg_type}@{strike}")
            return False

        ltp = self._fetch_ltp(datafeed_handler, inst)
        if not ltp or ltp <= 0:
            self.log_error(f"State B: invalid LTP {ltp} for {leg_type}@{strike}")
            return False

        self.log_info(
            f"Opening STATE B: {leg_type} {strike}@{ltp:.2f} "
            f"(offset={offset_pts:.2f} from spot={spot:.2f}, cur_straddle={cur_straddle:.2f})"
        )

        meta = {"b_leg_type": leg_type, "cur_straddle_at_entry": cur_straddle}
        ok = self._open_leg(LEG_B, "SELL", inst, float(ltp), dry_run, meta_extra=meta)
        if not ok:
            return False

        self.b_strike      = strike
        self.b_leg_type    = leg_type
        self.b_entry_price = float(ltp)
        self.state         = 'B'
        return True

    def _close_state_b(self, reason: str, datafeed_handler, dry_run: bool) -> None:
        if LEG_B in self.open_positions:
            self._close_leg(LEG_B, reason, datafeed_handler, dry_run)
        self.b_strike      = None
        self.b_leg_type    = None
        self.b_entry_price = 0.0

    def _close_all_legs(self, reason: str, datafeed_handler, dry_run: bool) -> None:
        if self.state == 'A':
            self._close_state_a(reason, datafeed_handler, dry_run)
        elif self.state == 'B':
            self._close_state_b(reason, datafeed_handler, dry_run)
        else:
            # Defensive — close anything left in open_positions regardless.
            for leg in list(self.open_positions.keys()):
                self._close_leg(leg, reason, datafeed_handler, dry_run)
        self.state = None

    # =========================================================================
    # INITIAL ENTRY + TRANSITIONS
    # =========================================================================

    def _initial_entry(self, datafeed_handler, dry_run: bool) -> bool:
        """First entry of the day → State A at offset x. (Backtest lines 228-253.)"""
        spot = self._fetch_spot_from_tbt()
        if spot is None:
            self.log_error("Initial entry: could not fetch spot")
            return False

        atm = self._fetch_atm_straddle(datafeed_handler, spot)
        if atm is None:
            return False
        _atm_strike, _ce_ltp, _pe_ltp, cur_straddle = atm
        if cur_straddle <= 0.1:
            self.log_warning(f"Initial entry: cur_straddle={cur_straddle} too small — skipping")
            return False

        self.log_info(
            f"INITIAL ENTRY: spot={spot:.2f} cur_straddle={cur_straddle:.2f} "
            f"x={self.x} x1={self.x1} y%={self.y_pct} z%={self.z_pct} "
            f"max_cycles={self.max_cycles}"
        )

        if not self._open_state_a(datafeed_handler, dry_run, spot, cur_straddle, self.x):
            return False

        self._save_state()
        return True

    def _transition_a_to_b(
        self,
        datafeed_handler,
        dry_run: bool,
        spot: float,
        cur_ce: float,
        cur_pe: float,
    ) -> None:
        """
        State A SL hit → close A, then open State B at offset x.
        Direction (CE vs PE for B) determined by spot vs a_entry_forward.
        Mirrors backtest lines 153-188.
        """
        a_entry_forward = self.a_entry_forward    # capture before we close
        self._close_state_a("SL_A", datafeed_handler, dry_run)

        # Halt gate per backtest line 162.
        local_now = timezone.localtime(timezone.now()).time()
        if self.transition_count >= self.max_cycles or local_now >= NO_NEW_ENTRY_AFTER:
            self.halted = True
            self.log_info(
                f"HALTED after A SL — transitions={self.transition_count}/"
                f"{self.max_cycles}, time={local_now}"
            )
            self._save_state()
            return

        # Recompute cur_straddle for new strike picking — backtest line 168.
        atm = self._fetch_atm_straddle(datafeed_handler, spot)
        if atm is None:
            self.halted = True
            self._save_state()
            return
        _atm_strike, _, _, cur_straddle = atm
        if cur_straddle <= 0.1:
            self.halted = True
            self.log_warning("A→B: cur_straddle too small, halting")
            self._save_state()
            return

        # Direction-aware leg selection — backtest lines 165-166.
        move_up = a_entry_forward is not None and spot > a_entry_forward
        b_leg_type = 'PE' if move_up else 'CE'

        self.log_info(
            f"A→B: cur_ce+pe={cur_ce + cur_pe:.2f} >= "
            f"a_entry_gross*(1+{self.y_pct}%)  | move_up={move_up} → short {b_leg_type}"
        )

        if not self._open_state_b(datafeed_handler, dry_run, spot, cur_straddle, b_leg_type, self.x):
            self.halted = True
            self._save_state()
            return

        self.transition_count += 1
        self._save_state()

    def _transition_b_to_a(
        self,
        datafeed_handler,
        dry_run: bool,
        spot: float,
        cur_b_price: float,
    ) -> None:
        """
        State B SL hit → close B, then open State A at offset x1.
        Mirrors backtest lines 194-222.
        """
        self._close_state_b("SL_B", datafeed_handler, dry_run)

        local_now = timezone.localtime(timezone.now()).time()
        if self.transition_count >= self.max_cycles or local_now >= NO_NEW_ENTRY_AFTER:
            self.halted = True
            self.log_info(
                f"HALTED after B SL — transitions={self.transition_count}/"
                f"{self.max_cycles}, time={local_now}"
            )
            self._save_state()
            return

        atm = self._fetch_atm_straddle(datafeed_handler, spot)
        if atm is None:
            self.halted = True
            self._save_state()
            return
        _atm_strike, _, _, cur_straddle = atm
        if cur_straddle <= 0.1:
            self.halted = True
            self.log_warning("B→A: cur_straddle too small, halting")
            self._save_state()
            return

        self.log_info(
            f"B→A: cur_b_price={cur_b_price:.2f} >= "
            f"b_entry_price*(1+{self.z_pct}%)  | re-opening State A at x1={self.x1}"
        )

        # Backtest uses x1 for B→A re-entry — line 207.
        if not self._open_state_a(datafeed_handler, dry_run, spot, cur_straddle, self.x1):
            self.halted = True
            self._save_state()
            return

        self.transition_count += 1
        self._save_state()

    # =========================================================================
    # POSITION LAST-PRICE SYNC + SL CHECK
    # =========================================================================

    def _check_state_a_sl(
        self, datafeed_handler, dry_run: bool, spot: float
    ) -> bool:
        """
        Returns True if SL fired (caller should NOT continue this tick).
        Updates last_price + unrealized_pnl on both A legs as a side effect.
        Mirrors backtest lines 146-188.
        """
        ce_pos = self.open_positions.get(LEG_A_CE)
        pe_pos = self.open_positions.get(LEG_A_PE)
        if not ce_pos or not pe_pos:
            return False

        ltps = self._fetch_multiple_ltp(
            datafeed_handler, [ce_pos.instrument, pe_pos.instrument]
        )
        cur_ce = ltps.get(ce_pos.instrument.instrument_token)
        cur_pe = ltps.get(pe_pos.instrument.instrument_token)
        if cur_ce is None or cur_pe is None:
            return False

        now = timezone.now()
        for pos, ltp in ((ce_pos, cur_ce), (pe_pos, cur_pe)):
            pos.last_price = Decimal(str(ltp))
            pos.last_price_updated_at = now
            pos.unrealized_pnl = (pos.entry_price - pos.last_price) * pos.quantity
            pos.save(update_fields=["last_price", "last_price_updated_at", "unrealized_pnl"])

        cur_gross = float(cur_ce) + float(cur_pe)
        threshold = self.a_entry_gross * (1.0 + self.y_pct / 100.0)
        self.log_debug(
            f"A-SL chk: cur={cur_gross:.2f} thr={threshold:.2f} "
            f"(entry_gross={self.a_entry_gross:.2f}, y%={self.y_pct})"
        )
        if cur_gross >= threshold:
            self._transition_a_to_b(
                datafeed_handler, dry_run, spot, float(cur_ce), float(cur_pe)
            )
            return True
        return False

    def _check_state_b_sl(
        self, datafeed_handler, dry_run: bool, spot: float
    ) -> bool:
        """Mirrors backtest lines 190-223."""
        b_pos = self.open_positions.get(LEG_B)
        if not b_pos:
            return False

        cur_price = self._fetch_ltp(datafeed_handler, b_pos.instrument)
        if cur_price is None:
            return False

        now = timezone.now()
        b_pos.last_price = Decimal(str(cur_price))
        b_pos.last_price_updated_at = now
        b_pos.unrealized_pnl = (b_pos.entry_price - b_pos.last_price) * b_pos.quantity
        b_pos.save(update_fields=["last_price", "last_price_updated_at", "unrealized_pnl"])

        threshold = self.b_entry_price * (1.0 + self.z_pct / 100.0)
        self.log_debug(
            f"B-SL chk: cur={cur_price:.2f} thr={threshold:.2f} "
            f"(entry={self.b_entry_price:.2f}, z%={self.z_pct})"
        )
        if float(cur_price) >= threshold:
            self._transition_b_to_a(datafeed_handler, dry_run, spot, float(cur_price))
            return True
        return False

    # =========================================================================
    # STATE PERSISTENCE
    # =========================================================================

    def _get_state_path(self) -> str:
        code = self.strategy_obj.strategy_code.lower()
        return os.path.join(STMSS_DUMP_DIR, f"{code}_{date.today().strftime('%Y%m%d')}.json")

    def _save_state(self) -> None:
        path = self._get_state_path()
        os.makedirs(os.path.dirname(path), exist_ok=True)
        state = {
            "date": str(date.today()),
            "expiry": str(self.expiry) if self.expiry else None,
            "x": self.x, "x1": self.x1,
            "y_pct": self.y_pct, "z_pct": self.z_pct,
            "entry_time": self.entry_time.strftime("%H:%M:%S"),
            "max_cycles": self.max_cycles,
            "state": self.state,
            "transition_count": self.transition_count,
            "halted": self.halted,
            # State A
            "a_call_strike":    float(self.a_call_strike) if self.a_call_strike else None,
            "a_put_strike":     float(self.a_put_strike)  if self.a_put_strike  else None,
            "a_entry_ce_price": self.a_entry_ce_price,
            "a_entry_pe_price": self.a_entry_pe_price,
            "a_entry_gross":    self.a_entry_gross,
            "a_entry_forward":  self.a_entry_forward,
            # State B
            "b_strike":         float(self.b_strike) if self.b_strike else None,
            "b_leg_type":       self.b_leg_type,
            "b_entry_price":    self.b_entry_price,
        }
        try:
            with open(path, "w") as f:
                json.dump(state, f)
        except Exception as e:
            self.log_error(f"Failed to save state: {e}")

    def _load_state(self) -> bool:
        path = self._get_state_path()
        if not os.path.isfile(path):
            return False
        try:
            with open(path, "r") as f:
                state = json.load(f)
        except Exception as e:
            self.log_error(f"Failed to load state: {e}")
            return False

        if state.get("date") != str(date.today()):
            self.log_info("State file stale (wrong date). Ignoring.")
            return False

        self.transition_count = int(state.get("transition_count", 0) or 0)
        self.halted = bool(state.get("halted", False))

        acs = state.get("a_call_strike"); aps = state.get("a_put_strike")
        self.a_call_strike    = Decimal(str(acs)) if acs is not None else None
        self.a_put_strike     = Decimal(str(aps)) if aps is not None else None
        self.a_entry_ce_price = float(state.get("a_entry_ce_price", 0.0) or 0.0)
        self.a_entry_pe_price = float(state.get("a_entry_pe_price", 0.0) or 0.0)
        self.a_entry_gross    = float(state.get("a_entry_gross", 0.0) or 0.0)
        self.a_entry_forward  = state.get("a_entry_forward")

        bs = state.get("b_strike")
        self.b_strike      = Decimal(str(bs)) if bs is not None else None
        self.b_leg_type    = state.get("b_leg_type")
        self.b_entry_price = float(state.get("b_entry_price", 0.0) or 0.0)

        self.log_info(
            f"RECOVERY: state restored — state={state.get('state')} "
            f"transitions={self.transition_count} halted={self.halted} "
            f"a_entry_gross={self.a_entry_gross} a_entry_fwd={self.a_entry_forward} "
            f"b_entry={self.b_entry_price} b_leg={self.b_leg_type}"
        )
        return True

    def _bootstrap_from_db(self) -> None:
        """Restore open positions from DB and re-derive self.state."""
        db_positions = StrategyPosition.objects.filter(
            strategy=self.strategy_obj, status="OPEN",
        ).select_related("instrument")

        if not db_positions.exists():
            self.log_info("No existing open positions. Fresh run.")
            return

        for pos in db_positions:
            meta = pos.strategy_metadata or {}
            leg_name = meta.get("leg_name")
            if leg_name in (LEG_A_CE, LEG_A_PE, LEG_B):
                self.open_positions[leg_name] = pos
                self.log_warning(
                    f"RECOVERY: restored {leg_name} @ entry={pos.entry_price} "
                    f"({pos.instrument.tradingsymbol})"
                )
            else:
                self.log_warning(
                    f"RECOVERY: skipping position {pos.trade_id} — unknown leg_name={leg_name}"
                )

        # Derive state from which legs are present.
        has_a = LEG_A_CE in self.open_positions and LEG_A_PE in self.open_positions
        has_b = LEG_B in self.open_positions
        if has_a and has_b:
            self.log_error(
                "RECOVERY: both A and B legs present — impossible state. "
                "Will treat as State A and ignore stray B."
            )
            self.state = 'A'
        elif has_a:
            self.state = 'A'
            self.a_call_strike = self.open_positions[LEG_A_CE].instrument.strike
            self.a_put_strike  = self.open_positions[LEG_A_PE].instrument.strike
        elif has_b:
            self.state = 'B'
            self.b_strike   = self.open_positions[LEG_B].instrument.strike
            self.b_leg_type = self.open_positions[LEG_B].instrument.instrument_type

    # =========================================================================
    # TIME UTILITIES
    # =========================================================================

    def _get_today_datetime(self, time_obj) -> datetime:
        today = timezone.now().date()
        naive_dt = datetime.combine(today, time_obj)
        return timezone.make_aware(naive_dt)

    def _wait_until(self, target_time: datetime) -> bool:
        while self.is_running:
            now = timezone.now()
            if now >= target_time:
                return True
            remaining = (target_time - now).total_seconds()
            if remaining > 60:
                self.log_info(
                    f"Waiting {int(remaining // 60)}m {int(remaining % 60)}s "
                    f"until {target_time.strftime('%H:%M:%S')}"
                )
                time.sleep(30)
            else:
                time.sleep(1)
        return False

    # =========================================================================
    # BASE STRATEGY INTERFACE
    # =========================================================================

    def verify(self) -> bool:
        if not self.datafeed_obj:
            self.log_error("No datafeed object provided.")
            return False
        if self.datafeed_obj.is_token_expired:
            self.log_warning("Datafeed token expired — attempting refresh...")
            from datafeed.rest.handler import DataFeedHandler
            handler = DataFeedHandler(self.datafeed_obj)
            if not handler.update_token():
                self.log_error("Failed to refresh datafeed token.")
                return False
        self.log_info("Verification passed.")
        return True

    def stop(self):
        self.log_info("Stopping StateMachineShortStrangle...")
        self.is_running = False

    # =========================================================================
    # MAIN RUN LOOP
    # =========================================================================

    def _resolve_params(self) -> None:
        params = self.strategy_obj.strategy_params or {}
        self.x          = float(params.get("x",          DEFAULT_X))
        self.x1         = float(params.get("x1",         DEFAULT_X1))
        self.y_pct      = float(params.get("y_pct",      DEFAULT_Y_PCT))
        self.z_pct      = float(params.get("z_pct",      DEFAULT_Z_PCT))
        self.max_cycles = int(params.get("max_cycles",   DEFAULT_MAX_CYCLES))
        self.poll_interval_secs = int(params.get("poll_interval_secs", DEFAULT_POLL_INTERVAL_SECS))

        et_str = params.get("entry_time")
        if et_str:
            try:
                self.entry_time = datetime.strptime(et_str, "%H:%M:%S").time()
            except ValueError:
                self.log_error(f"Invalid entry_time '{et_str}', using default {DEFAULT_ENTRY_TIME}")
                self.entry_time = DEFAULT_ENTRY_TIME
        else:
            self.entry_time = DEFAULT_ENTRY_TIME

    def run(self):
        params = self.strategy_obj.strategy_params or {}
        dry_run = bool(params.get("dry_run", False))
        self._resolve_params()

        self.log_info("=" * 60)
        self.log_info("Starting StateMachineShortStrangle (Weekly Expiry Day Only)")
        self.log_info(
            f"x={self.x} x1={self.x1} y%={self.y_pct} z%={self.z_pct} "
            f"max_cycles={self.max_cycles}"
        )
        self.log_info(
            f"entry={self.entry_time} no_new_after={NO_NEW_ENTRY_AFTER} "
            f"exit={EXIT_TIME} poll={self.poll_interval_secs}s"
        )
        self.log_info(f"Mode: {'DRY-RUN' if dry_run else 'LIVE'}")
        self.log_info("=" * 60)

        if not self.verify():
            self.log_error("Verification failed. Exiting.")
            return

        self.is_running = True

        from datafeed.rest.handler import DataFeedHandler
        datafeed_handler = DataFeedHandler(self.datafeed_obj)

        # ── Step 1: Resolve expiry — must equal today (weekly expiry day) ─
        cw_expiry = self._get_nearest_option_expiry()
        if cw_expiry is None:
            self.log_error("No NIFTY option expiry found. Exiting.")
            self.is_running = False
            return
        if cw_expiry != date.today():
            self.log_info(
                f"Today ({date.today()}) is NOT weekly expiry day "
                f"(next expiry: {cw_expiry}). Strategy will not run today."
            )
            self.is_running = False
            return

        self.expiry = cw_expiry
        self.log_info(f"Weekly expiry day confirmed: {self.expiry}")

        # ── Step 2: Cache available strikes for the expiry ────────────────
        self._load_available_strikes(self.expiry)
        if not self._available_strikes:
            self.log_error(f"No strikes found for expiry {self.expiry}. Exiting.")
            self.is_running = False
            return
        self.log_info(f"Loaded {len(self._available_strikes)} strikes for expiry {self.expiry}")

        # ── Step 3: Recover from prior crash (DB + JSON state) ────────────
        self._bootstrap_from_db()
        self._load_state()

        # ── Step 4: Wait for entry time (skip if we already have positions) ─
        if self.state is None and not self.halted:
            entry_dt = self._get_today_datetime(self.entry_time)
            if timezone.now() < entry_dt:
                self.log_info(f"Waiting for entry time: {entry_dt.strftime('%H:%M:%S')}")
                if not self._wait_until(entry_dt):
                    return
            if not self.is_running:
                return

            # No new entries past NO_NEW_ENTRY_AFTER — backtest line 228.
            local_now = timezone.localtime(timezone.now()).time()
            if local_now >= NO_NEW_ENTRY_AFTER:
                self.log_info(
                    f"Past NO_NEW_ENTRY_AFTER ({NO_NEW_ENTRY_AFTER}); skipping initial entry"
                )
                self.halted = True
            else:
                # ── Step 5: Initial entry → State A ──────────────────────
                if not self._initial_entry(datafeed_handler, dry_run):
                    self.log_error("Initial entry failed. Exiting.")
                    self.is_running = False
                    return

        # ── Step 6: Monitor + state-machine loop ──────────────────────────
        exit_dt = self._get_today_datetime(EXIT_TIME)
        self.log_info("Entering monitoring loop (state-machine SL + EOD exit)...")

        while self.is_running:
            now = timezone.now()

            # ── EOD: close everything (mirror of backtest lines 121-141) ─
            if now >= exit_dt:
                self.log_info(">>> EXIT TIME REACHED <<<")
                self._close_all_legs("EOD", datafeed_handler, dry_run)
                break

            try:
                spot = self._fetch_spot_from_tbt()
                if spot is None:
                    self.log_warning("Spot fetch failed; skipping tick")
                    time.sleep(self.poll_interval_secs)
                    continue

                # ── SL check by current state ─────────────────────────
                if self.state == 'A':
                    self._check_state_a_sl(datafeed_handler, dry_run, spot)
                elif self.state == 'B':
                    self._check_state_b_sl(datafeed_handler, dry_run, spot)
                # If state is None and halted, just wait for EOD.

            except Exception as e:
                self.log_exception(f"Main loop error: {e}")

            time.sleep(self.poll_interval_secs)

        # EOD safety net
        now_t = timezone.localtime(timezone.now()).time()
        if self.state is not None and now_t >= EXIT_TIME:
            self.log_warning("EOD safety net: forcing close of any remaining legs")
            self._close_all_legs("EOD_FORCE", datafeed_handler, dry_run)
        elif self.state is not None:
            self.log_info(
                f"Loop exited but NOT EOD — keeping state={self.state} "
                f"in DB for recovery"
            )

        self.is_running = False
        self.log_info("StateMachineShortStrangle completed.")
