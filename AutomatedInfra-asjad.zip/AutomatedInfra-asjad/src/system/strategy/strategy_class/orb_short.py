""" Opening Range Breakout - Short """

import csv
import os
import shutil
import time
import uuid
from datetime import date, datetime, time as dt_time, timedelta
from decimal import Decimal
from typing import Optional

import pandas as pd

from django.db.models import Min
from django.utils import timezone

from instruments.models import Instrument
from orders.order_manager import order_manager
from strategy.models import StrategyPosition
from strategy.strategy_class.base_strategy import BaseStrategy

# ── TBT (Tick-By-Tick) ────────────────────────────────────────────────────────
TBT_DATA_PATH = r"\\10.211.8.76\GFD MBM Data\Momentum\logs"
TBT_INDEX_NAME = "Nifty 50"
LOCAL_TBT_DIR = os.path.join(
    os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))),
    "dump", "tbt_local",
)

# ── TBT Guard Constants ──────────────────────────────────────────────────────
TBT_MARKET_OPEN = dt_time(9, 15, 0)
TBT_MARKET_CLOSE = dt_time(15, 30, 0)
TBT_MAX_STALENESS_SECS = 120          # Reject if latest tick > 2 min behind wall clock

# ── Constants ──────────────────────────────────────────────────────────────────
INDEX_NAME = "NIFTY 50"
TICKER = "NIFTY"
PRICE_OFFSET = Decimal("0.5")

PREMIUM_TARGET_PCT = 0.012                 # target premium as fraction of spot
SL_PCT = 0.20                              # exit if LTP rises x% above entry premium
TP_PCT = 0.60                              # exit if LTP falls y% below entry premium
ROLLOVER_DAYS_BEFORE = 0                   # switch to NW expiry on expiry day itself
# BROKER_TOKEN_REFRESH_INTERVAL_SECS = 900  # Centralized — handled by TokenRefreshManager

RANGE_START = dt_time(9, 15, 2)           # first bar included in range
RANGE_END   = dt_time(11, 14, 59)          # last bar included in range
SIGNAL_START = dt_time(11, 15, 1)         # first bar eligible for entry
HARD_EXIT_T  = dt_time(15, 14, 59)         # close everything at or after this time

CHECK_INTERVAL_SEC = 5                   # polling interval (1 minute)

# ── CSV State Persistence ─────────────────────────────────────────────────────
_BASE_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
ORB_DUMP_DIR = os.path.join(_BASE_DIR, 'dump', 'orb')
CSV_COLUMNS = [
    'timestamp', 'event', 'leg', 'instrument_token', 'tradingsymbol',
    'expiry', 'strike', 'spot_open', 'target_premium',
    'range_high', 'range_low', 'entry_ltp', 'exit_ltp', 'exit_reason',
]


class OrbShort(BaseStrategy):

    def __init__(self, strategy_obj, datafeed_obj, ws_manager=None):
        super().__init__(strategy_obj, datafeed_obj, ws_manager)
        self.is_running = False

        # ── Range & Target State ───────────────────────────────────────────
        self.spot_open: Optional[float] = None
        self.target_premium: Optional[float] = None

        self.ce_instrument: Optional[Instrument] = None
        self.pe_instrument: Optional[Instrument] = None

        self.ce_range_high: Optional[float] = None
        self.ce_range_low: Optional[float] = None
        self.pe_range_high: Optional[float] = None
        self.pe_range_low: Optional[float] = None

        self.ce_traded: bool = False
        self.pe_traded: bool = False

        # ── Positions & Orders ─────────────────────────────────────────────
        self.open_positions: dict[str, StrategyPosition] = {}  # "CE" -> pos, "PE" -> pos
        self.entry_orders: dict[str, object] = {}
        self.exit_orders: dict[str, object] = {}
        # self._last_broker_token_refresh: float = 0.0  # Centralized — handled by TokenRefreshManager
        self._last_good_max_ts: Optional[datetime] = None        # For timestamp regression detection

    # =========================================================================
    # INSTRUMENT LOOKUPS
    # =========================================================================

    def _get_nearest_option_expiry(self) -> Optional[date]:
        """Get the nearest weekly option expiry date for NIFTY."""
        today = date.today()
        result = Instrument.objects.filter(
            name=TICKER,
            exchange="NFO",
            instrument_type__in=["CE", "PE"],
            is_active=True,
            expiry__gte=today,
        ).aggregate(min_expiry=Min("expiry"))
        return result.get("min_expiry")

    def _get_next_week_expiry(self) -> Optional[date]:
        """Get the next-week option expiry (second nearest)."""
        today = date.today()
        expiries = (
            Instrument.objects.filter(
                name=TICKER,
                exchange="NFO",
                instrument_type__in=["CE", "PE"],
                is_active=True,
                expiry__gte=today,
            )
            .values_list("expiry", flat=True)
            .distinct()
            .order_by("expiry")[:2]
        )
        expiry_list = list(expiries)
        if len(expiry_list) >= 2:
            return expiry_list[1]
        return expiry_list[0] if expiry_list else None

    def _resolve_expiry(self) -> Optional[date]:
        """Pick CW or NW expiry based on rollover rule (same as backtest)."""
        cw = self._get_nearest_option_expiry()
        if cw is None:
            self.log_error("No option expiry found.")
            return None

        days_to_cw = (cw - date.today()).days
        if days_to_cw <= ROLLOVER_DAYS_BEFORE:
            nw = self._get_next_week_expiry()
            if nw:
                self.log_info(f"Rollover: CW={cw} ({days_to_cw}d away), using NW={nw}")
                return nw

        self.log_info(f"Using CW expiry: {cw} ({days_to_cw}d away)")
        return cw

    def _get_available_strikes(self, expiry: date, option_type: str) -> list[Decimal]:
        """Get all available strikes for a given expiry and type."""
        strikes = Instrument.objects.filter(
            name=TICKER,
            exchange="NFO",
            instrument_type=option_type,
            expiry=expiry,
            is_active=True,
        ).values_list("strike", flat=True).distinct()
        return sorted([s for s in strikes if s is not None])

    def _get_option_instrument(
        self, expiry: date, strike: Decimal, option_type: str
    ) -> Optional[Instrument]:
        """Get a single option instrument."""
        return Instrument.objects.filter(
            name=TICKER,
            exchange="NFO",
            instrument_type=option_type,
            expiry=expiry,
            strike=strike,
            is_active=True,
        ).first()

    # =========================================================================
    # TBT SPOT PRICE
    # =========================================================================

    def _copy_tbt_file(self, file_date: Optional[date] = None) -> Optional[str]:
        """Copy today's TBT file from network share to local directory.
        Returns the local file path, or None on failure."""
        target_date = file_date or date.today()
        filename = target_date.strftime("%Y%m%d") + ".txt"
        source = os.path.join(TBT_DATA_PATH, filename)

        os.makedirs(LOCAL_TBT_DIR, exist_ok=True)
        dest = os.path.join(LOCAL_TBT_DIR, filename)

        try:
            shutil.copy2(source, dest)
            file_size = os.path.getsize(dest)
            self.log_info(f"Copied TBT file: {filename} ({file_size / 1024:.1f} KB)")
            return dest
        except FileNotFoundError:
            self.log_error(f"TBT file not found: {source}")
            return None
        except Exception as e:
            self.log_error(f"Failed to copy TBT file: {e}")
            return None

    def _parse_tbt_data(self, file_path: str) -> Optional[pd.DataFrame]:
        """Parse TBT file and filter for Nifty 50 ticks.

        TBT format:
            2026-02-01 09:32:35.339220 | Nifty 50 | 25301.0 | 1769918554

        Returns DataFrame with columns: [timestamp, price]"""
        try:
            df = pd.read_csv(
                file_path,
                sep=r"\s*\|\s*",
                header=None,
                names=["timestamp", "index_name", "price", "seq_id"],
                engine="python",
            )
        except Exception as e:
            self.log_error(f"Failed to parse TBT file: {e}")
            return None

        df = df[df["index_name"] == TBT_INDEX_NAME].copy()
        if df.empty:
            self.log_error(f"No '{TBT_INDEX_NAME}' ticks found in TBT file.")
            return None

        df["timestamp"] = pd.to_datetime(df["timestamp"], format="mixed")
        df["price"] = pd.to_numeric(df["price"], errors="coerce")
        df = df.dropna(subset=["price"])
        df = df.sort_values("timestamp").reset_index(drop=True)

        # ── Market hours filter: keep only 9:15–15:30 ────────────────────
        pre_filter_count = len(df)
        df = df[
            (df["timestamp"].dt.time >= TBT_MARKET_OPEN)
            & (df["timestamp"].dt.time <= TBT_MARKET_CLOSE)
        ].reset_index(drop=True)
        rejected = pre_filter_count - len(df)
        if rejected > 0:
            self.log_info(f"Market hours filter: rejected {rejected} ticks outside 09:15–15:30")

        if df.empty:
            self.log_error("No ticks remain after market hours filter.")
            return None

        self.log_info(f"Parsed {len(df)} Nifty 50 ticks from TBT file")
        return df[["timestamp", "price"]]

    def _validate_tbt_data(self, tbt_df: pd.DataFrame) -> bool:
        """Validate parsed TBT data for staleness and timestamp regression.
        Returns True if data is safe to use, False if it should be rejected."""

        max_ts: datetime = tbt_df["timestamp"].max().to_pydatetime()
        now = datetime.now()

        # ── Staleness: reject if latest tick is too far behind wall clock ─
        staleness_secs = (now - max_ts).total_seconds()
        if staleness_secs > TBT_MAX_STALENESS_SECS:
            self.log_error(
                f"TBT REJECTED (stale): latest tick {max_ts.strftime('%H:%M:%S')} "
                f"is {staleness_secs:.0f}s behind wall clock "
                f"(threshold: {TBT_MAX_STALENESS_SECS}s)"
            )
            return False

        # ── Timestamp regression: reject if max timestamp went backwards ──
        if self._last_good_max_ts is not None and max_ts < self._last_good_max_ts:
            regression_secs = (self._last_good_max_ts - max_ts).total_seconds()
            self.log_error(
                f"TBT REJECTED (regression): max tick {max_ts.strftime('%H:%M:%S')} "
                f"< previous good {self._last_good_max_ts.strftime('%H:%M:%S')} "
                f"(regressed {regression_secs:.0f}s)"
            )
            return False

        # ── All checks passed — update tracking state ────────────────────
        self._last_good_max_ts = max_ts
        return True

    def _fetch_spot_from_tbt(self) -> Optional[float]:
        """Fetch latest NIFTY 50 spot price from TBT file."""
        local_path = self._copy_tbt_file()
        if local_path is None:
            return None
        df = self._parse_tbt_data(local_path)
        if df is None or df.empty:
            return None
        if not self._validate_tbt_data(df):
            return None
        spot = float(df["price"].iloc[-1])
        self.log_info(f"TBT spot price: {spot:.2f} ({len(df)} ticks)")
        return spot

    # =========================================================================
    # DATA FEED
    # =========================================================================

    def _fetch_ltp(self, datafeed_handler, instrument: Instrument) -> Optional[float]:
        """Fetch LTP for a single instrument. On 400/401, refreshes token and retries indefinitely."""
        attempt = 0
        while self.is_running:
            attempt += 1
            try:
                self.datafeed_obj.refresh_from_db()
                from datafeed.rest.handler import DataFeedHandler
                datafeed_handler = DataFeedHandler(self.datafeed_obj)
                response = datafeed_handler.get_multiple_ltp([instrument])
                if response and "data" in response:
                    for item in response["data"].get("ltp_list", []):
                        if item.get("instrument_token") == instrument.instrument_token:
                            return item.get("ltp")
                return None
            except Exception as e:
                status = getattr(getattr(e, "response", None), "status_code", None)
                is_auth_error = status in (400, 401) or "Unauthorized" in str(e)
                # is_auth_error = status == 401 or "Unauthorized" in str(e)

                if is_auth_error:
                    self.log_warning(
                        f"LTP fetch failed for {instrument} (attempt {attempt}: {e}) "
                        f"— refreshing datafeed token..."
                    )
                    try:
                        from datafeed.rest.handler import DataFeedHandler
                        DataFeedHandler(self.datafeed_obj).update_token()
                        self.datafeed_obj.refresh_from_db()
                        datafeed_handler = DataFeedHandler(self.datafeed_obj)
                    except Exception as refresh_err:
                        self.log_error(f"Token refresh failed: {refresh_err}")
                    time.sleep(2)
                    continue
                self.log_error(f"Error fetching LTP for {instrument}: {e}")
                return None
        return None

    def _fetch_multiple_ltp(
        self, datafeed_handler, instruments: list[Instrument]
    ) -> dict[int, float]:
        """Fetch LTP for multiple instruments. Returns {token: ltp}. Retries on 400/401."""
        if not instruments:
            return {}
        attempt = 0
        while self.is_running:
            attempt += 1
            try:
                self.datafeed_obj.refresh_from_db()
                from datafeed.rest.handler import DataFeedHandler
                datafeed_handler = DataFeedHandler(self.datafeed_obj)
                response = datafeed_handler.get_multiple_ltp(instruments)
                result: dict[int, float] = {}
                if response and "data" in response:
                    for item in response["data"].get("ltp_list", []):
                        token = item.get("instrument_token")
                        ltp = item.get("ltp")
                        if token and ltp:
                            result[token] = ltp
                return result
            except Exception as e:
                status = getattr(getattr(e, "response", None), "status_code", None)
                is_auth_error = status in (400, 401) or "Unauthorized" in str(e)
                # is_auth_error = status == 401 or "Unauthorized" in str(e)

                if is_auth_error:
                    self.log_warning(
                        f"Multiple LTP fetch failed (attempt {attempt}: {e}) "
                        f"— refreshing datafeed token..."
                    )
                    try:
                        from datafeed.rest.handler import DataFeedHandler
                        DataFeedHandler(self.datafeed_obj).update_token()
                        self.datafeed_obj.refresh_from_db()
                        datafeed_handler = DataFeedHandler(self.datafeed_obj)
                    except Exception as refresh_err:
                        self.log_error(f"Token refresh failed: {refresh_err}")
                    time.sleep(2)
                    continue
                self.log_error(f"Error fetching multiple LTP: {e}")
                return {}
        return {}

    # # =========================================================================
    # # PROBE MODE (token-refresher diagnostic; set strategy_params.probe_mode=true)
    # # =========================================================================
    #
    # def _run_probe(self, params: dict) -> None:
    #     ticker = params.get("ticker", TICKER)
    #     exchange = params.get("exchange", "MCX")
    #     instrument_type = params.get("instrument_type", "FUT")
    #     poll_interval = int(params.get("poll_interval_secs", 30))
    #
    #     self.log_info("=" * 60)
    #     self.log_info(
    #         f"Starting OrbShort PROBE: {ticker} / {exchange} / "
    #         f"{instrument_type} @ {poll_interval}s"
    #     )
    #     self.log_info("=" * 60)
    #
    #     if not self.verify():
    #         self.log_error("Verification failed. Exiting probe.")
    #         return
    #
    #     self.is_running = True
    #
    #     instrument = (
    #         Instrument.objects.filter(
    #             name=ticker,
    #             exchange=exchange,
    #             instrument_type=instrument_type,
    #             is_active=True,
    #             expiry__gt=date.today(),
    #         )
    #         .order_by("expiry")
    #         .first()
    #     )
    #     if not instrument:
    #         self.log_error(
    #             f"No active {exchange} {instrument_type} found for {ticker}."
    #         )
    #         self.is_running = False
    #         return
    #
    #     self.log_info(
    #         f"Probe instrument: {instrument.tradingsymbol} "
    #         f"(expiry {instrument.expiry})"
    #     )
    #
    #     from datafeed.rest.handler import DataFeedHandler
    #     handler = DataFeedHandler(self.datafeed_obj)
    #
    #     # next_refresh_at = time.monotonic() + 10
    #
    #     while self.is_running:
    #         # if time.monotonic() >= next_refresh_at:
    #         #     handler.update_token()
    #         #     self.log_warning(
    #         #         f"[{datetime.now():%H:%M:%S}] forced token refresh"
    #         #     )
    #         #     next_refresh_at = time.monotonic() + 10
    #
    #         self.datafeed_obj.refresh_from_db()
    #         ts = datetime.now().strftime("%H:%M:%S")
    #         try:
    #             ltp = self._fetch_ltp(handler, instrument)
    #             if ltp is not None:
    #                 self.log_info(
    #                     f"[{ts}] PROBE LTP {instrument.tradingsymbol} = {ltp}"
    #                 )
    #             else:
    #                 self.log_warning(
    #                     f"[{ts}] PROBE LTP {instrument.tradingsymbol} returned None"
    #                 )
    #         except Exception as e:
    #             self.log_error(
    #                 f"[{ts}] PROBE LTP {instrument.tradingsymbol} FAIL: {e}"
    #             )
    #
    #         slept = 0
    #         while self.is_running and slept < poll_interval:
    #             time.sleep(1)
    #             slept += 1
    #
    #     self.log_info("Probe stopped.")

    # =========================================================================
    # STRIKE SELECTION
    # =========================================================================

    def _select_strike_by_premium(
        self,
        datafeed_handler,
        expiry: date,
        option_type: str,
        target_premium: float,
    ) -> tuple[Optional[Instrument], Optional[float]]:
        """
        From all available strikes, find the one whose LTP is closest to
        target_premium. Returns (instrument, ltp) or (None, None).
        """
        strikes = self._get_available_strikes(expiry, option_type)
        if not strikes:
            self.log_error(f"No {option_type} strikes found for expiry {expiry}")
            return None, None

        # Build instrument list for all strikes
        instruments = []
        strike_map: dict[int, tuple[Instrument, Decimal]] = {}
        for strike in strikes:
            inst = self._get_option_instrument(expiry, strike, option_type)
            if inst:
                instruments.append(inst)
                strike_map[inst.instrument_token] = (inst, strike)

        if not instruments:
            return None, None

        # Fetch LTPs in a single batch
        ltps = self._fetch_multiple_ltp(datafeed_handler, instruments)
        if not ltps:
            self.log_error(f"Could not fetch LTPs for {option_type} chain")
            return None, None

        # Find the strike whose LTP is closest to target_premium
        best_inst = None
        best_ltp = None
        best_diff = float("inf")

        for token, ltp in ltps.items():
            if token in strike_map:
                diff = abs(ltp - target_premium)
                if diff < best_diff:
                    best_diff = diff
                    best_inst = strike_map[token][0]
                    best_ltp = ltp

        if best_inst:
            self.log_info(
                f"Selected {option_type} strike={best_inst.strike} "
                f"ltp={best_ltp:.2f} target={target_premium:.2f} diff={best_diff:.2f}"
            )

        return best_inst, best_ltp

    # =========================================================================
    # ORDER PLACEMENT
    # =========================================================================

    def _limit_price(self, side: str, ltp: float) -> Decimal:
        """Passive limit: SELL → LTP + offset, BUY → LTP − offset."""
        base = Decimal(str(ltp))
        return base + PRICE_OFFSET if side == "SELL" else base - PRICE_OFFSET

    def _place_order(
        self,
        instrument: Instrument,
        side: str,
        quantity: int,
        price: Optional[Decimal],
        order_intent: str,
        tag: str = "",
        dry_run: bool = False,
    ) -> tuple[bool, object]:
        """Place an order via OrderManager. Supports dry-run mode."""
        order_type = "LIMIT" if price is not None else "MARKET"
        price_str = str(price) if price is not None else "MKT"

        if dry_run:
            self.log_info(
                f"  [DRY-RUN][{tag}] {order_intent} {side} {quantity} x"
                f" {instrument.tradingsymbol}"
                f" | {order_type} @ {price_str}"
                f" | NRML"
                f" | expiry={instrument.expiry}"
            )
            return True, None

        success, msg, parent_order, _ = order_manager.create_and_execute_order(
            strategy=self.strategy_obj,
            instrument=instrument,
            side=side,
            quantity=quantity,
            order_type=order_type,
            product_type="NRML",
            price=price,
            order_intent=order_intent,
            metadata={
                "strategy_code": self.strategy_obj.strategy_code,
                "instrument_type": instrument.instrument_type,
                "stock_name": instrument.name,
                "tag": tag,
            },
        )
        if success:
            self.log_info(
                f"  [{tag}] {side} {quantity} x {instrument.tradingsymbol}"
                f" @ {price_str}"
            )
        else:
            self.log_error(f"  [{tag}] FAILED {side} {instrument.tradingsymbol}: {msg}")
        return success, parent_order

    # =========================================================================
    # STATE RECOVERY
    # =========================================================================

    def _bootstrap_from_db(self) -> bool:
        """
        Restore state from DB if strategy was restarted mid-position.

        Returns:
            True  -> Found open position(s); state restored.
            False -> No open position; fresh run.
        """
        db_positions = StrategyPosition.objects.filter(
            strategy=self.strategy_obj,
            status="OPEN",
        ).select_related("instrument")

        if not db_positions.exists():
            self.log_info("No existing open positions found. Fresh run.")
            return False

        for pos in db_positions:
            meta = pos.strategy_metadata or {}
            opt_type = meta.get("option_type")  # "CE" or "PE"

            if opt_type == "CE":
                self.ce_instrument = pos.instrument
                self.ce_traded = True
                self.open_positions["CE"] = pos
            elif opt_type == "PE":
                self.pe_instrument = pos.instrument
                self.pe_traded = True
                self.open_positions["PE"] = pos
            else:
                self.log_warning(f"RECOVERY: Skipping position {pos.trade_id} with unknown option_type={opt_type}")

            self.log_warning(
                f"RECOVERY: Restored SHORT {opt_type} @ {pos.entry_price:.2f}"
                f" | instrument={pos.instrument.tradingsymbol}"
                f" | entered={pos.entry_time}"
            )
        return True

    # =========================================================================
    # CSV STATE PERSISTENCE
    # =========================================================================

    def _get_csv_path(self) -> str:
        """Return today's CSV state file path."""
        code = self.strategy_obj.strategy_code.lower()
        return os.path.join(ORB_DUMP_DIR, f"{code}_{date.today().strftime('%Y%m%d')}.csv")

    def _append_csv_event(self, event: str, leg: str, **kwargs) -> None:
        """Append a single event row to today's CSV state file."""
        csv_path = self._get_csv_path()
        os.makedirs(os.path.dirname(csv_path), exist_ok=True)

        file_exists = os.path.isfile(csv_path)

        row = {col: '' for col in CSV_COLUMNS}
        row['timestamp'] = datetime.now().isoformat()
        row['event'] = event
        row['leg'] = leg
        row.update({k: v for k, v in kwargs.items() if k in CSV_COLUMNS})

        try:
            with open(csv_path, 'a', newline='') as f:
                writer = csv.DictWriter(f, fieldnames=CSV_COLUMNS)
                if not file_exists:
                    writer.writeheader()
                writer.writerow(row)
        except Exception as e:
            self.log_error(f"Failed to write CSV event: {e}")

    def _write_setup_event(self, leg: str, instrument: Instrument) -> None:
        """Write SETUP event after strike selection."""
        self._append_csv_event(
            'SETUP', leg,
            instrument_token=instrument.instrument_token,
            tradingsymbol=instrument.tradingsymbol,
            expiry=str(instrument.expiry),
            strike=float(instrument.strike),
            spot_open=self.spot_open,
            target_premium=self.target_premium,
        )

    def _write_range_update_event(self, leg: str) -> None:
        """Write RANGE_UPDATE event with current range boundaries."""
        inst = self.ce_instrument if leg == 'CE' else self.pe_instrument
        if inst is None:
            return
        rh = self.ce_range_high if leg == 'CE' else self.pe_range_high
        rl = self.ce_range_low if leg == 'CE' else self.pe_range_low
        self._append_csv_event(
            'RANGE_UPDATE', leg,
            instrument_token=inst.instrument_token,
            tradingsymbol=inst.tradingsymbol,
            expiry=str(inst.expiry),
            strike=float(inst.strike),
            range_high=rh, range_low=rl,
        )

    def _write_range_locked_event(self, leg: str) -> None:
        """Write RANGE_LOCKED event when range building completes."""
        inst = self.ce_instrument if leg == 'CE' else self.pe_instrument
        if inst is None:
            return
        rh = self.ce_range_high if leg == 'CE' else self.pe_range_high
        rl = self.ce_range_low if leg == 'CE' else self.pe_range_low
        self._append_csv_event(
            'RANGE_LOCKED', leg,
            instrument_token=inst.instrument_token,
            tradingsymbol=inst.tradingsymbol,
            expiry=str(inst.expiry),
            strike=float(inst.strike),
            range_high=rh, range_low=rl,
        )

    def _write_entry_event(self, leg: str, entry_ltp: float) -> None:
        """Write ENTRY event after successful order placement."""
        inst = self.ce_instrument if leg == 'CE' else self.pe_instrument
        if inst is None:
            return
        self._append_csv_event(
            'ENTRY', leg,
            instrument_token=inst.instrument_token,
            tradingsymbol=inst.tradingsymbol,
            expiry=str(inst.expiry),
            strike=float(inst.strike),
            entry_ltp=entry_ltp,
        )

    def _write_exit_event(self, leg: str, exit_ltp: float, reason: str) -> None:
        """Write EXIT event after successful exit order."""
        inst = self.ce_instrument if leg == 'CE' else self.pe_instrument
        if inst is None:
            return
        self._append_csv_event(
            'EXIT', leg,
            instrument_token=inst.instrument_token,
            tradingsymbol=inst.tradingsymbol,
            expiry=str(inst.expiry),
            strike=float(inst.strike),
            exit_ltp=exit_ltp, exit_reason=reason,
        )

    def _load_state_from_csv(self) -> Optional[str]:
        """
        Load state from today's CSV event log.

        Returns the phase to resume:
            'RANGE_BUILDING' - strikes selected, partial/no range
            'MONITORING'     - range finalized or entries exist
            'DONE'           - all traded legs exited
            None             - no CSV found, fresh run needed
        """
        csv_path = self._get_csv_path()
        if not os.path.isfile(csv_path):
            return None

        try:
            df = pd.read_csv(csv_path, on_bad_lines='skip')
        except Exception as e:
            self.log_error(f"Failed to read CSV state: {e}")
            return None

        if df.empty:
            return None

        latest_phase = None
        ce_exited = False
        pe_exited = False

        for _, row in df.iterrows():
            event = row.get('event', '')
            leg = row.get('leg', '')

            if event == 'SETUP':
                token = row.get('instrument_token')
                if pd.isna(token):
                    continue
                try:
                    inst = Instrument.objects.get(instrument_token=int(token))
                except Instrument.DoesNotExist:
                    self.log_error(f"CSV RECOVERY: Instrument token {token} not found")
                    continue

                if leg == 'CE':
                    self.ce_instrument = inst
                elif leg == 'PE':
                    self.pe_instrument = inst

                spot = row.get('spot_open')
                if not pd.isna(spot):
                    self.spot_open = float(spot)
                tp = row.get('target_premium')
                if not pd.isna(tp):
                    self.target_premium = float(tp)

                latest_phase = 'SETUP'

            elif event in ('RANGE_UPDATE', 'RANGE_LOCKED'):
                rh = row.get('range_high')
                rl = row.get('range_low')
                if leg == 'CE':
                    if not pd.isna(rh):
                        self.ce_range_high = float(rh)
                    if not pd.isna(rl):
                        self.ce_range_low = float(rl)
                elif leg == 'PE':
                    if not pd.isna(rh):
                        self.pe_range_high = float(rh)
                    if not pd.isna(rl):
                        self.pe_range_low = float(rl)

                # Also restore instrument from these rows if not yet set
                token = row.get('instrument_token')
                if not pd.isna(token):
                    try:
                        inst = Instrument.objects.get(instrument_token=int(token))
                        if leg == 'CE' and self.ce_instrument is None:
                            self.ce_instrument = inst
                        elif leg == 'PE' and self.pe_instrument is None:
                            self.pe_instrument = inst
                    except Instrument.DoesNotExist:
                        pass

                latest_phase = 'RANGE_LOCKED' if event == 'RANGE_LOCKED' else 'RANGE_BUILDING'

            elif event == 'ENTRY':
                if leg == 'CE':
                    self.ce_traded = True
                elif leg == 'PE':
                    self.pe_traded = True
                latest_phase = 'MONITORING'

            elif event == 'EXIT':
                if leg == 'CE':
                    ce_exited = True
                elif leg == 'PE':
                    pe_exited = True

        # Determine phase to return
        both_done = (
            (self.ce_traded or self.ce_instrument is None) and
            (self.pe_traded or self.pe_instrument is None) and
            (not self.ce_traded or ce_exited) and
            (not self.pe_traded or pe_exited)
        )
        if both_done and (ce_exited or pe_exited):
            return 'DONE'

        if latest_phase in ('MONITORING', 'RANGE_LOCKED'):
            return 'MONITORING'
        if latest_phase in ('RANGE_BUILDING', 'SETUP'):
            return 'RANGE_BUILDING'

        return None

    def _cleanup_old_csv_files(self, keep_days: int = 7) -> None:
        """Remove CSV state files older than keep_days."""
        if not os.path.isdir(ORB_DUMP_DIR):
            return
        cutoff = date.today() - timedelta(days=keep_days)
        prefix = self.strategy_obj.strategy_code.lower() + "_"
        for fname in os.listdir(ORB_DUMP_DIR):
            if fname.startswith(prefix) and fname.endswith('.csv'):
                try:
                    date_str = fname[len(prefix):-4]
                    file_date = datetime.strptime(date_str, "%Y%m%d").date()
                    if file_date < cutoff:
                        os.remove(os.path.join(ORB_DUMP_DIR, fname))
                        self.log_info(f"Removed old state file: {fname}")
                except (ValueError, OSError):
                    pass

    # =========================================================================
    # SIGNAL EXECUTION
    # =========================================================================

    def _execute_entry(
        self, opt_type: str, instrument: Instrument, entry_ltp: float,
        datafeed_handler, dry_run: bool,
    ) -> None:
        """Short-sell one option leg and persist to DB."""
        lot_size = instrument.lot_size
        price = self._limit_price("SELL", entry_ltp)
        tag = f"ORB_{opt_type}_ENTRY"

        self.log_info(
            f"ENTRY SHORT {opt_type}: strike={instrument.strike} "
            f"ltp={entry_ltp:.2f} limit={price}"
        )

        success, parent_order = self._place_order(
            instrument, "SELL", lot_size, price,
            order_intent="ENTRY", tag=tag, dry_run=dry_run,
        )

        if success:
            sl_price = entry_ltp * (1 + SL_PCT)
            tp_price = entry_ltp * (1 - TP_PCT)
            self.log_info(
                f"  {opt_type} position opened: entry={entry_ltp:.2f} "
                f"SL={sl_price:.2f} (+{SL_PCT*100:.0f}%) TP={tp_price:.2f} (-{TP_PCT*100:.0f}%) "
                f"lot_size={lot_size}"
            )
            db_pos = StrategyPosition.objects.create(
                trade_id=f"ORB_{self.strategy_obj.id}_{uuid.uuid4().hex[:8]}",
                strategy=self.strategy_obj,
                instrument=instrument,
                position_type="SHORT",
                status="OPEN",
                quantity=lot_size,
                entry_price=Decimal(str(entry_ltp)),
                entry_time=timezone.now(),
                entry_parent_order=parent_order,
                last_price=Decimal(str(entry_ltp)),
                last_price_updated_at=timezone.now(),
                strategy_metadata={
                    "option_type": opt_type,
                    "sl_price": sl_price,
                    "tp_pct": TP_PCT,
                    "strike": float(instrument.strike),
                    "expiry": str(instrument.expiry),
                },
            )
            self.open_positions[opt_type] = db_pos
            self.entry_orders[opt_type] = parent_order
            self._write_entry_event(opt_type, entry_ltp)

    def _execute_exit(
        self, opt_type: str, exit_ltp: float, reason: str,
        datafeed_handler, dry_run: bool,
    ) -> None:
        """Buy-back one option leg and close in DB."""
        pos = self.open_positions.get(opt_type)
        if not pos:
            self.log_warning(f"EXIT called for {opt_type} but no open position found")
            return

        instrument = pos.instrument
        lot_size = pos.quantity
        price = self._limit_price("BUY", exit_ltp)
        tag = f"ORB_{opt_type}_EXIT_{reason}"

        self.log_info(
            f"EXIT SHORT {opt_type} ({reason}): ltp={exit_ltp:.2f} "
            f"entry={pos.entry_price:.2f} limit={price}"
        )

        success, parent_order = self._place_order(
            instrument, "BUY", lot_size, price,
            order_intent="EXIT", tag=tag, dry_run=dry_run,
        )

        if success:
            pnl = (float(pos.entry_price) - exit_ltp) * lot_size
            pos.status = "CLOSED"
            pos.exit_price = Decimal(str(exit_ltp))
            pos.exit_time = timezone.now()
            pos.exit_parent_order = parent_order
            pos.realized_pnl = Decimal(str(pnl))
            pos.unrealized_pnl = Decimal("0.00")
            pos.save()
            del self.open_positions[opt_type]
            self.exit_orders[opt_type] = parent_order
            self.log_info(f"  {opt_type} closed. PNL={pnl:+.2f}")
            self._write_exit_event(opt_type, exit_ltp, reason)

    # =========================================================================
    # MONITORING LOGIC 
    # =========================================================================

    def _check_exit(self, opt_type: str, ltp: float) -> Optional[str]:
        """
        Check TP / SL for an open position. Returns exit reason or None.
        Mirrors backtest:
            TP: ltp <= entry_prem * (1 - TP_PCT)
            SL: ltp >= entry_prem * (1 + SL_PCT)
        """
        pos = self.open_positions.get(opt_type)
        if not pos:
            return None

        entry_prem = float(pos.entry_price)
        tp_level = entry_prem * (1 - TP_PCT)
        sl_level = entry_prem * (1 + SL_PCT)

        if ltp <= tp_level:
            self.log_info(f"{opt_type} TP hit: ltp={ltp:.2f} <= tp_level={tp_level:.2f} (entry={entry_prem:.2f})")
            return "TP"
        if ltp >= sl_level:
            self.log_info(f"{opt_type} SL hit: ltp={ltp:.2f} >= sl_level={sl_level:.2f} (entry={entry_prem:.2f})")
            return "SL"

        self.log_debug(f"{opt_type} hold: ltp={ltp:.2f} | tp_level={tp_level:.2f} | sl_level={sl_level:.2f}")
        return None

    def _check_entry(self, opt_type: str, ltp: float) -> bool:
        """
        Check if LTP has broken below the range low (entry trigger).
        Mirrors backtest:  if ltp < range_low → short entry
        """
        if opt_type == "CE":
            triggered = (
                not self.ce_traded
                and self.ce_range_low is not None
                and ltp < self.ce_range_low
            )
            if not self.ce_traded and self.ce_range_low is not None:
                self.log_debug(f"CE entry check: ltp={ltp:.2f} vs range_low={self.ce_range_low:.2f} -> {'TRIGGER' if triggered else 'no'}")
            return triggered
        elif opt_type == "PE":
            triggered = (
                not self.pe_traded
                and self.pe_range_low is not None
                and ltp < self.pe_range_low
            )
            if not self.pe_traded and self.pe_range_low is not None:
                self.log_debug(f"PE entry check: ltp={ltp:.2f} vs range_low={self.pe_range_low:.2f} -> {'TRIGGER' if triggered else 'no'}")
            return triggered
        return False

    def _update_range(self, opt_type: str, ltp: float) -> None:
        """Update the opening range high/low with the latest 1-min close."""
        if opt_type == "CE":
            if self.ce_range_high is None or ltp > self.ce_range_high:
                self.log_debug(f"CE range high updated: {self.ce_range_high} -> {ltp}")
                self.ce_range_high = ltp
            if self.ce_range_low is None or ltp < self.ce_range_low:
                self.log_debug(f"CE range low updated: {self.ce_range_low} -> {ltp}")
                self.ce_range_low = ltp
        elif opt_type == "PE":
            if self.pe_range_high is None or ltp > self.pe_range_high:
                self.log_debug(f"PE range high updated: {self.pe_range_high} -> {ltp}")
                self.pe_range_high = ltp
            if self.pe_range_low is None or ltp < self.pe_range_low:
                self.log_debug(f"PE range low updated: {self.pe_range_low} -> {ltp}")
                self.pe_range_low = ltp

    # =========================================================================
    # TIME UTILITIES
    # =========================================================================

    def _get_today_datetime(self, time_obj) -> datetime:
        """Convert a time object to today's datetime in local timezone."""
        today = timezone.now().date()
        naive_dt = datetime.combine(today, time_obj)
        return timezone.make_aware(naive_dt)

    def _wait_until(self, target_time: datetime) -> bool:
        """Wait until target_time. Returns False if stop() was called."""
        while self.is_running:
            now = timezone.now()
            if now >= target_time:
                return True
            remaining = (target_time - now).total_seconds()
            if remaining > 60:
                self.log_info(
                    f"Waiting {int(remaining // 60)}m {int(remaining % 60)}s "
                    f"until {target_time.strftime('%H:%M:%S')}"
                )
                time.sleep(30)
            else:
                time.sleep(1)
        return False

    # =========================================================================
    # BASE STRATEGY INTERFACE
    # =========================================================================

    def verify(self) -> bool:
        """Verify strategy prerequisites before running."""
        if not self.datafeed_obj:
            self.log_error("No datafeed object provided.")
            return False

        if self.datafeed_obj.is_token_expired:
            self.log_warning("Datafeed token expired — attempting refresh...")
            from datafeed.rest.handler import DataFeedHandler
            handler = DataFeedHandler(self.datafeed_obj)
            if not handler.update_token():
                self.log_error("Failed to refresh datafeed token.")
                return False

        self.log_info("Verification passed.")
        return True

    def stop(self):
        """Stop the strategy gracefully."""
        self.log_info("Stopping OrbShort...")
        self.is_running = False

    # def _refresh_broker_tokens(self) -> None:  # Centralized — handled by TokenRefreshManager
    #     """Periodically refresh broker account tokens to prevent order failures."""
    #     from accounts.models import StrategyAccountMapping
    #     from accounts.brokers.handler import BrokerAccountHandler
    #
    #     mappings = StrategyAccountMapping.objects.filter(
    #         strategy=self.strategy_obj,
    #         is_active=True,
    #     ).select_related('broker_account', 'broker_account__broker')
    #
    #     for mapping in mappings:
    #         ba = mapping.broker_account
    #         ba.refresh_from_db()
    #         if ba.is_token_expired:
    #             self.log_warning(f"Broker token expired for {ba.account_name} — refreshing...")
    #             try:
    #                 BrokerAccountHandler(ba).update_token()
    #                 ba.refresh_from_db()
    #                 self.log_info(f"Broker token refreshed for {ba.account_name}")
    #             except Exception as e:
    #                 self.log_error(f"Broker token refresh failed for {ba.account_name}: {e}")
    #
    #     # Also refresh datafeed token if needed
    #     self.datafeed_obj.refresh_from_db()
    #     if self.datafeed_obj.is_token_expired:
    #         self.log_warning("Datafeed token expired — refreshing...")
    #         try:
    #             from datafeed.rest.handler import DataFeedHandler
    #             DataFeedHandler(self.datafeed_obj).update_token()
    #             self.datafeed_obj.refresh_from_db()
    #             self.log_info("Datafeed token refreshed")
    #         except Exception as e:
    #             self.log_error(f"Datafeed token refresh failed: {e}")

    # =========================================================================
    # MAIN RUN LOOP
    # =========================================================================

    def run(self):
        """
        Main orchestration loop:
          1. Verify
          2. Wait for range start (9:15:59)
          3. Resolve expiry, fetch spot, select CE/PE strikes
          4. Range building loop (9:16 – 11:15, poll every 60s)
          5. Signal + exit monitoring loop (11:16 – 15:15, poll every 60s)
          6. Hard exit at 15:15:59
        """
        params = self.strategy_obj.strategy_params or {}
        dry_run = bool(params.get("dry_run", False))

        # if params.get("probe_mode"):
        #     return self._run_probe(params)

        self.log_info("=" * 60)
        self.log_info(f"Starting OrbShort")
        self.log_info(f"Entry Time : {self.strategy_obj.entry_time}")
        self.log_info(f"Exit Time  : {self.strategy_obj.exit_time}")
        self.log_info(f"Mode       : {'DRY-RUN' if dry_run else 'LIVE'}")
        self.log_info("=" * 60)

        # Step 1: Verify
        if not self.verify():
            self.log_error("Verification failed. Exiting.")
            return

        self.is_running = True

        from datafeed.rest.handler import DataFeedHandler
        datafeed_handler = DataFeedHandler(self.datafeed_obj)

        # Step 2: Restore state from CSV + DB
        self._cleanup_old_csv_files()
        csv_phase = self._load_state_from_csv()
        self._bootstrap_from_db()

        if csv_phase == 'DONE':
            self.log_info("CSV state shows all legs completed for today. Nothing to do.")
            return

        if csv_phase is not None:
            self.log_warning(
                f"RECOVERY: Resuming from phase={csv_phase} | "
                f"CE inst={self.ce_instrument} | PE inst={self.pe_instrument} | "
                f"CE range=[{self.ce_range_low}, {self.ce_range_high}] | "
                f"PE range=[{self.pe_range_low}, {self.pe_range_high}] | "
                f"CE traded={self.ce_traded} | PE traded={self.pe_traded}"
            )

        # Step 3: Wait for range start time (unless already past it)
        range_start_dt = self._get_today_datetime(RANGE_START)
        if timezone.now() < range_start_dt:
            self.log_info(f"Waiting for range start: {range_start_dt.strftime('%H:%M:%S')}")
            if not self._wait_until(range_start_dt):
                self.log_info("Strategy stopped while waiting.")
                return
            if not self.is_running:
                return

        if csv_phase is None:
            # ─────────────────────────────────────────────────────────────
            # Step 4: FRESH SETUP — Resolve expiry and select CE/PE strikes
            # ─────────────────────────────────────────────────────────────
            expiry = self._resolve_expiry()
            if not expiry:
                self.log_error("Could not resolve option expiry. Exiting.")
                self.is_running = False
                return

            # Fetch spot price from TBT
            self.spot_open = self._fetch_spot_from_tbt()
            if self.spot_open is None:
                self.log_error("Could not fetch spot price from TBT before range end. Exiting.")
                self.is_running = False
                return

            self.target_premium = round(self.spot_open * PREMIUM_TARGET_PCT, 2)
            self.log_info(
                f"Spot={self.spot_open:.2f}  target_prem={self.target_premium:.2f}  "
                f"expiry={expiry}"
            )

            # Select CE strike
            self.ce_instrument, ce_snap = self._select_strike_by_premium(
                datafeed_handler, expiry, "CE", self.target_premium,
            )
            # Select PE strike
            self.pe_instrument, pe_snap = self._select_strike_by_premium(
                datafeed_handler, expiry, "PE", self.target_premium,
            )

            if not self.ce_instrument and not self.pe_instrument:
                self.log_error("Could not find CE or PE strikes. Exiting.")
                self.is_running = False
                return

            # Dump SETUP events to CSV
            if self.ce_instrument:
                self._write_setup_event("CE", self.ce_instrument)
            if self.pe_instrument:
                self._write_setup_event("PE", self.pe_instrument)

            self.log_info(
                f"CE: {self.ce_instrument.tradingsymbol if self.ce_instrument else 'NONE'} "
                f"(snap≈{ce_snap})  |  "
                f"PE: {self.pe_instrument.tradingsymbol if self.pe_instrument else 'NONE'} "
                f"(snap≈{pe_snap})"
            )

            # Seed range with snapshot LTPs
            if ce_snap is not None:
                self._update_range("CE", ce_snap)
            if pe_snap is not None:
                self._update_range("PE", pe_snap)

        # ─────────────────────────────────────────────────────────────────
        # Step 5: Range Building Loop (skip if resuming past this phase)
        # ─────────────────────────────────────────────────────────────────
        if csv_phase in (None, 'RANGE_BUILDING'):
            range_end_dt = self._get_today_datetime(RANGE_END)

            if timezone.now() < range_end_dt:
                self.log_info("Entering RANGE BUILDING phase...")

                # Track last written range to avoid excessive CSV writes
                last_written_ce = (self.ce_range_high, self.ce_range_low)
                last_written_pe = (self.pe_range_high, self.pe_range_low)

                while self.is_running:
                    now = timezone.now()
                    if now >= range_end_dt:
                        break

                    # Fetch latest LTPs for both legs
                    instruments = [i for i in [self.ce_instrument, self.pe_instrument] if i]
                    ltps = self._fetch_multiple_ltp(datafeed_handler, instruments)

                    if self.ce_instrument:
                        ce_ltp = ltps.get(self.ce_instrument.instrument_token)
                        if ce_ltp is not None:
                            self._update_range("CE", ce_ltp)

                    if self.pe_instrument:
                        pe_ltp = ltps.get(self.pe_instrument.instrument_token)
                        if pe_ltp is not None:
                            self._update_range("PE", pe_ltp)

                    # Dump RANGE_UPDATE only when boundaries actually change
                    current_ce = (self.ce_range_high, self.ce_range_low)
                    current_pe = (self.pe_range_high, self.pe_range_low)
                    if current_ce != last_written_ce:
                        self._write_range_update_event("CE")
                        last_written_ce = current_ce
                    if current_pe != last_written_pe:
                        self._write_range_update_event("PE")
                        last_written_pe = current_pe

                    time.sleep(CHECK_INTERVAL_SEC)

            if not self.is_running:
                self.log_info("Strategy stopped during range building — range NOT locked.")
                return

            self.log_info(
                f"Range locked — CE: lo={self.ce_range_low} hi={self.ce_range_high}  |  "
                f"PE: lo={self.pe_range_low} hi={self.pe_range_high}"
            )

            # Dump RANGE_LOCKED events
            if self.ce_instrument:
                self._write_range_locked_event("CE")
            if self.pe_instrument:
                self._write_range_locked_event("PE")

        # ─────────────────────────────────────────────────────────────────
        # Step 6: Signal + Exit Monitoring Loop (11:16 – 15:15)
        # ─────────────────────────────────────────────────────────────────
        self.log_info("Entering SIGNAL MONITORING phase...")
        signal_start_dt = self._get_today_datetime(SIGNAL_START)
        hard_exit_dt = self._get_today_datetime(HARD_EXIT_T)

        while self.is_running:
            now = timezone.now()

            # Hard exit
            if now >= hard_exit_dt:
                self.log_info(">>> HARD EXIT TIME REACHED <<<")
                for opt_type in list(self.open_positions.keys()):
                    inst = self.open_positions[opt_type].instrument
                    ltp = self._fetch_ltp(datafeed_handler, inst)
                    if ltp is not None:
                        self._execute_exit(opt_type, ltp, "HARD_EXIT", datafeed_handler, dry_run)
                break

            try:
                # Periodic broker + datafeed token refresh — centralized in TokenRefreshManager
                # if time.time() - self._last_broker_token_refresh >= BROKER_TOKEN_REFRESH_INTERVAL_SECS:
                #     try:
                #         self._refresh_broker_tokens()
                #     except Exception as e:
                #         self.log_error(f"Broker token refresh cycle failed: {e}")
                #     self._last_broker_token_refresh = time.time()

                # Collect instruments to poll
                instruments = []
                if self.ce_instrument:
                    instruments.append(self.ce_instrument)
                if self.pe_instrument:
                    instruments.append(self.pe_instrument)

                ltps = self._fetch_multiple_ltp(datafeed_handler, instruments)
                self.log_debug(f"Tick LTPs: {({i.tradingsymbol: ltps.get(i.instrument_token) for i in instruments})}")

                # ── Monitor existing positions (SL/TP) ────────────────
                for opt_type in list(self.open_positions.keys()):
                    inst = self.open_positions[opt_type].instrument
                    ltp = ltps.get(inst.instrument_token)
                    if ltp is None:
                        self.log_warning(f"No LTP for open {opt_type} position ({inst.tradingsymbol}), skipping tick")
                        continue

                    # Update last_price, sync fill price, recalculate unrealized PnL
                    pos = self.open_positions[opt_type]
                    self._sync_position_entry_fill(pos)
                    pos.last_price = Decimal(str(ltp))
                    pos.last_price_updated_at = timezone.now()
                    pos.unrealized_pnl = (pos.entry_price - pos.last_price) * pos.quantity
                    pos.save(update_fields=[
                        "entry_price", "strategy_metadata",
                        "last_price", "last_price_updated_at", "unrealized_pnl",
                    ])

                    # Check exit conditions
                    reason = self._check_exit(opt_type, ltp)
                    if reason:
                        self._execute_exit(opt_type, ltp, reason, datafeed_handler, dry_run)

                # ── Check entry conditions (only after SIGNAL_START) ──
                if now >= signal_start_dt:
                    if self.ce_instrument and not self.ce_traded:
                        ce_ltp = ltps.get(self.ce_instrument.instrument_token)
                        if ce_ltp is not None and self._check_entry("CE", ce_ltp):
                            self.log_info(
                                f"CE BREAKDOWN: ltp={ce_ltp:.2f} < range_low={self.ce_range_low:.2f}"
                            )
                            self._execute_entry("CE", self.ce_instrument, ce_ltp, datafeed_handler, dry_run)
                            self.ce_traded = True

                    if self.pe_instrument and not self.pe_traded:
                        pe_ltp = ltps.get(self.pe_instrument.instrument_token)
                        if pe_ltp is not None and self._check_entry("PE", pe_ltp):
                            self.log_info(
                                f"PE BREAKDOWN: ltp={pe_ltp:.2f} < range_low={self.pe_range_low:.2f}"
                            )
                            self._execute_entry("PE", self.pe_instrument, pe_ltp, datafeed_handler, dry_run)
                            self.pe_traded = True

            except Exception as e:
                self.log_exception(f"Error in monitoring loop: {e}")

            time.sleep(CHECK_INTERVAL_SEC)

        # ── End-of-day force-close (safety net) ───────────────────────
        # Only force-close if we're actually past hard exit time.
        # If the loop exited due to an external stop(), leave positions
        # intact in DB so they survive a restart.
        now_t = timezone.localtime(timezone.now()).time()
        if self.open_positions and now_t >= HARD_EXIT_T:
            for opt_type in list(self.open_positions.keys()):
                inst = self.open_positions[opt_type].instrument
                ltp = self._fetch_ltp(datafeed_handler, inst)
                if ltp is not None:
                    self._execute_exit(opt_type, ltp, "EOD_FORCE", datafeed_handler, dry_run)
                self.log_warning(f"Force-closed orphan {opt_type} position at EOD")
        elif self.open_positions:
            self.log_info(f"Loop exited but NOT EOD — keeping {len(self.open_positions)} position(s) open in DB for recovery")

        self.is_running = False
        self.log_info("OrbShort completed.")
