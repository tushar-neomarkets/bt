"""
Covered Call (Collar) Strategy - CCALL

Runs ONCE on expiry day at entry_time:

  Phase 1 — Close old positions
    Close CE/PE positions from the floor-authoritative positions file.
    Instruments resolved against today's expiry.

  Phase 2 — Rebalance equity
    Diff target shares (from portfolio.csv) against current holdings
    (from positions file). Buy/sell to close the gap.

  Phase 3 — Enter fresh positions (next expiry)
    For each stock: fetch spot LTP, SELL ATM CE, BUY ~5% OTM PE.
    Option lots = target_shares // lot_size (lot_size from DB).

Portfolio signal is loaded from a single CSV whose path is either
passed via strategy_params['portfolio_csv'] or falls back to
PORTFOLIO_CSV_PATH.

CSV expected columns (order-independent, header must match exactly):
  Ticker, Target Shares
"""

import re
import time
from datetime import date, datetime
from decimal import Decimal
from pathlib import Path
from typing import Optional

import pandas as pd
from django.db.models import Min, Sum
from django.utils import timezone

from instruments.models import Instrument
from orders.order_manager import order_manager
from strategy.strategy_class.base_strategy import BaseStrategy

POSITIONS_DIR = Path(r"C:\Users\Administrator\Desktop\Execution\AutomatedInfra\src\system\dump\cov_call")

PORTFOLIO_CSV_PATH = str(POSITIONS_DIR / "portfolio.csv")
PRICE_OFFSET = Decimal("0.05")
OTM_PE_PCT = Decimal("0.95")  # 5% OTM protective put
POSITIONS_FILE_GLOB = "Open Position Markets *.xls"
POSITIONS_FILENAME_DATE_RE = re.compile(r"Open Position Markets (\d{2}-\d{2}-\d{4})")
POSITIONS_FILE_MAX_AGE_DAYS = 7

POSITIONS_TRADER = "QuantAlgo"
POSITIONS_STRATEGY = "SS SY CC"
POSITIONS_INSTRUMENT_TYPE = "OPTSTK"
POSITIONS_INSTRUMENT_TYPE_EQ = "EQ"


class CoveredCall(BaseStrategy):
    """
    Covered-call collar strategy.
    Closes previous cycle's CE/PE, rebalances equity, then sells new ATM CE
    and buys a 5%-OTM PE for each portfolio stock on next expiry.
    """

    def __init__(self, strategy_obj, datafeed_obj, ws_manager=None):
        super().__init__(strategy_obj, datafeed_obj, ws_manager)
        self.is_running = False

    # =========================================================================
    # PORTFOLIO LOADING
    # =========================================================================

    def _load_portfolio(self) -> Optional[pd.DataFrame]:
        """Load portfolio CSV (Ticker, Target Shares). Returns None on failure."""
        csv_path = (
            self.strategy_obj.strategy_params.get("portfolio_csv", PORTFOLIO_CSV_PATH)
            if self.strategy_obj.strategy_params
            else PORTFOLIO_CSV_PATH
        )
        try:
            df = pd.read_csv(csv_path)
            df.columns = df.columns.str.strip()

            required = {"Ticker", "Target Shares"}
            missing = required - set(df.columns)
            if missing:
                self.log_error(f"Portfolio CSV missing columns: {sorted(missing)}")
                return None

            df["Ticker"] = df["Ticker"].astype(str).str.strip()
            df["Target Shares"] = pd.to_numeric(
                df["Target Shares"], errors="coerce"
            )

            if df["Ticker"].eq("").any() or df["Ticker"].isna().any():
                self.log_error("Portfolio CSV: blank Ticker found.")
                return None

            if df["Target Shares"].isna().any():
                bad = df.loc[df["Target Shares"].isna(), "Ticker"].tolist()
                self.log_error(
                    f"Portfolio CSV: unparseable Target Shares for: {bad}"
                )
                return None

            df["Target Shares"] = df["Target Shares"].astype(int)

            dupes = df["Ticker"][df["Ticker"].duplicated()].unique().tolist()
            if dupes:
                self.log_error(f"Portfolio CSV: duplicate ticker(s): {dupes}")
                return None

            self.log_info(f"Loaded portfolio: {len(df)} stocks from {csv_path}")
            return df
        except Exception as e:
            self.log_error(f"Failed to load portfolio CSV: {e}")
            return None

    # =========================================================================
    # INSTRUMENT LOOKUPS
    # =========================================================================

    def _get_equity_instrument(self, ticker: str) -> Optional[Instrument]:
        return Instrument.objects.filter(
            tradingsymbol=ticker, exchange="NSE", instrument_type="EQ", is_active=True
        ).first()

    def _get_current_expiry_option(
        self, ticker: str, strike: Decimal, option_type: str
    ) -> Optional[Instrument]:
        """Option expiring today (for closing old positions)."""
        today = date.today()
        return Instrument.objects.filter(
            name=ticker,
            exchange="NFO",
            instrument_type=option_type,
            strike=strike,
            expiry=today,
            is_active=True,
        ).first()

    def _get_next_expiry_future(self, ticker: str) -> Optional[Instrument]:
        """First future expiring after today."""
        today = date.today()
        return (
            Instrument.objects.filter(
                name=ticker,
                exchange="NFO",
                instrument_type="FUT",
                is_active=True,
                expiry__gt=today,
            )
            .order_by("expiry")
            .first()
        )

    def _get_next_option_expiry(self, ticker: str) -> Optional[date]:
        """Earliest option expiry after today."""
        today = date.today()
        result = Instrument.objects.filter(
            name=ticker,
            exchange="NFO",
            instrument_type__in=["CE", "PE"],
            is_active=True,
            expiry__gt=today,
        ).aggregate(min_expiry=Min("expiry"))
        return result.get("min_expiry")

    def _get_available_strikes(
        self, ticker: str, expiry: date, option_type: str
    ) -> list[Decimal]:
        strikes = Instrument.objects.filter(
            name=ticker,
            exchange="NFO",
            instrument_type=option_type,
            expiry=expiry,
            is_active=True,
        ).values_list("strike", flat=True).distinct()
        return sorted([s for s in strikes if s is not None])

    def _find_closest_strike(
        self, price: float, strikes: list[Decimal], tie_break: str = "lower"
    ) -> Optional[Decimal]:
        """
        Return the strike closest to `price`. On ties, `tie_break="higher"`
        returns the larger strike; default `"lower"` returns the smaller.
        """
        if not strikes:
            return None
        price_d = Decimal(str(price))
        min_dist = min(abs(s - price_d) for s in strikes)
        candidates = [s for s in strikes if abs(s - price_d) == min_dist]
        return max(candidates) if tie_break == "higher" else min(candidates)

    def _get_option_instrument(
        self, ticker: str, expiry: date, strike: Decimal, option_type: str
    ) -> Optional[Instrument]:
        return Instrument.objects.filter(
            name=ticker,
            exchange="NFO",
            instrument_type=option_type,
            expiry=expiry,
            strike=strike,
            is_active=True,
        ).first()

    # =========================================================================
    # ORDER PLACEMENT
    # =========================================================================

    def _place_order(
        self,
        instrument: Instrument,
        side: str,
        quantity: int,
        price: Optional[Decimal],
        product_type: str,
        order_intent: str,
        tag: str = "",
        dry_run: bool = False,
    ) -> tuple[bool, object]:
        order_type = "LIMIT" if price is not None else "MARKET"
        price_str = str(price) if price is not None else "MKT"

        if dry_run:
            self.log_info(
                f"  [DRY-RUN][{tag}] {order_intent} {side} {quantity}x"
                f" {instrument.tradingsymbol}"
                f" | {order_type} @ {price_str}"
                f" | {product_type}"
                f" | expiry={instrument.expiry}"
            )
            return True, None

        success, msg, parent_order, _ = order_manager.create_and_execute_order(
            strategy=self.strategy_obj,
            instrument=instrument,
            side=side,
            quantity=quantity,
            order_type=order_type,
            product_type=product_type,
            price=price,
            order_intent=order_intent,
            metadata={
                "strategy_code": self.strategy_obj.strategy_code,
                "instrument_type": instrument.instrument_type,
                "stock_name": instrument.name,
                "expiry": instrument.expiry.isoformat() if instrument.expiry else None,
                "strike": str(instrument.strike) if instrument.strike is not None else None,
                "tag": tag,
            },
        )
        if success:
            self.log_info(
                f"  [{tag}] {side} {quantity}x {instrument.tradingsymbol}"
                f" @ {price_str}"
            )
        else:
            self.log_error(f"  [{tag}] FAILED {side} {instrument.tradingsymbol}: {msg}")
        return success, parent_order

    def _fetch_ltp(
        self, datafeed_handler, instruments: list[Instrument]
    ) -> dict[int, float]:
        """Fetch LTP for a list of instruments in one call."""
        result: dict[int, float] = {}
        if not instruments:
            return result
        try:
            self.datafeed_obj.refresh_from_db()
            from datafeed.rest.handler import DataFeedHandler
            datafeed_handler = DataFeedHandler(self.datafeed_obj)
            response = datafeed_handler.get_multiple_ltp(instruments)
            if response and "data" in response:
                for item in response["data"].get("ltp_list", []):
                    token = item.get("instrument_token")
                    ltp = item.get("ltp")
                    if token and ltp:
                        result[token] = ltp
        except Exception as e:
            self.log_error(f"Error fetching LTP: {e}")
        return result

    def _limit_price(self, side: str, ltp: float) -> Decimal:
        """
        Passive limit price aligned with vol_trading convention:
          SELL → LTP + offset  (let buyers come up to us)
          BUY  → LTP - offset  (let sellers come down to us)
        Floored at 0.05 tick size.
        """
        base = Decimal(str(ltp))
        limit_px = base + PRICE_OFFSET if side == "SELL" else base - PRICE_OFFSET
        return limit_px if limit_px >= Decimal("0.05") else Decimal("0.05")


    # =========================================================================
    # POSITIONS FILE (source of truth for Phase 1)
    # =========================================================================

    def _find_positions_file(self) -> Optional[Path]:
        """Locate the latest positions file, or return None if missing/stale."""
        override = (
            (self.strategy_obj.strategy_params or {}).get("positions_file")
            if self.strategy_obj.strategy_params
            else None
        )
        if override:
            p = Path(override)
            if not p.is_file():
                self.log_error(f"positions_file override does not exist: {p}")
                return None
            self.log_info(f"Using override positions file: {p}")
            return p

        if not POSITIONS_DIR.is_dir():
            self.log_error(f"Positions directory does not exist: {POSITIONS_DIR}")
            return None

        candidates = []
        for path in POSITIONS_DIR.glob(POSITIONS_FILE_GLOB):
            m = POSITIONS_FILENAME_DATE_RE.search(path.name)
            if not m:
                continue
            try:
                file_date = datetime.strptime(m.group(1), "%d-%m-%Y").date()
            except ValueError:
                continue
            candidates.append((file_date, path))

        if not candidates:
            self.log_error(
                f"No positions file matching '{POSITIONS_FILE_GLOB}' "
                f"found in {POSITIONS_DIR}"
            )
            return None

        candidates.sort(key=lambda t: t[0], reverse=True)
        file_date, path = candidates[0]
        age_days = (date.today() - file_date).days
        if age_days > POSITIONS_FILE_MAX_AGE_DAYS:
            self.log_error(
                f"Latest positions file is stale: {path.name} dated "
                f"{file_date} ({age_days} days old; max allowed "
                f"{POSITIONS_FILE_MAX_AGE_DAYS})."
            )
            return None

        self.log_info(f"Positions file: {path.name} (dated {file_date})")
        return path

    def _parse_positions_file(self, path: Path) -> Optional[pd.DataFrame]:
        """Parse HTML-disguised-as-xls positions file. None on failure."""
        try:
            tables = pd.read_html(str(path))
        except Exception as e:
            self.log_error(f"Failed to read positions file {path.name}: {e}")
            return None

        if not tables:
            self.log_error(f"Positions file {path.name} contains no tables.")
            return None

        df = tables[0]
        if df.empty:
            self.log_error(f"Positions file {path.name} first table is empty.")
            return None

        df.columns = df.iloc[0].tolist()
        df = df.iloc[1:].reset_index(drop=True)

        for col in df.columns:
            if df[col].dtype == object:
                df[col] = df[col].astype(str).str.strip()

        required = {
            "Trader", "Strategy", "Instrument Type",
            "Symbol", "Expiry", "Strike", "OptionType", "Qty",
        }
        missing = required - set(df.columns)
        if missing:
            self.log_error(
                f"Positions file {path.name} missing columns: {sorted(missing)}"
            )
            return None

        return df

    def _filter_positions_by_type(
        self, df: pd.DataFrame, instrument_type: str
    ) -> pd.DataFrame:
        """Filter positions DataFrame to Trader/Strategy/Instrument-Type rows."""
        mask = (
            (df["Trader"] == POSITIONS_TRADER)
            & (df["Strategy"] == POSITIONS_STRATEGY)
            & (df["Instrument Type"] == instrument_type)
        )
        return df.loc[mask].copy()

    def _load_positions_to_close(self) -> Optional[list[dict]]:
        """
        Return list of {symbol, expiry, strike, option_type, signed_floor_qty}
        from the positions file. None on hard-abort; [] if nothing to close.
        """
        path = self._find_positions_file()
        if path is None:
            return None

        df = self._parse_positions_file(path)
        if df is None:
            return None

        total_rows = len(df)
        filtered = self._filter_positions_by_type(df, POSITIONS_INSTRUMENT_TYPE)

        if filtered.empty:
            self.log_error(
                f"Positions file {path.name}: filter returned 0 rows. "
                f"Total rows={total_rows}. "
                f"Trader='{POSITIONS_TRADER}' matches="
                f"{int((df['Trader'] == POSITIONS_TRADER).sum())}; "
                f"Strategy='{POSITIONS_STRATEGY}' matches="
                f"{int((df['Strategy'] == POSITIONS_STRATEGY).sum())}; "
                f"Instrument Type='{POSITIONS_INSTRUMENT_TYPE}' matches="
                f"{int((df['Instrument Type'] == POSITIONS_INSTRUMENT_TYPE).sum())}."
            )
            return None

        filtered["Qty"] = pd.to_numeric(filtered["Qty"], errors="coerce")
        filtered["Strike"] = pd.to_numeric(filtered["Strike"], errors="coerce")
        filtered["Expiry"] = pd.to_datetime(
            filtered["Expiry"], errors="coerce"
        ).dt.date

        bad_mask = filtered[
            ["Qty", "Strike", "Expiry", "Symbol", "OptionType"]
        ].isna().any(axis=1)
        if bad_mask.any():
            self.log_warning(
                f"Positions file: dropping {int(bad_mask.sum())} row(s) "
                f"with unparseable Qty/Strike/Expiry/Symbol/OptionType."
            )
            filtered = filtered.loc[~bad_mask]

        filtered = filtered[filtered["Qty"] != 0]

        grouped = (
            filtered.groupby(
                ["Symbol", "Expiry", "Strike", "OptionType"], as_index=False
            )["Qty"].sum()
        )
        grouped = grouped[grouped["Qty"] != 0]

        today = date.today()
        today_rows = grouped[grouped["Expiry"] == today]
        other = grouped[grouped["Expiry"] != today]
        for _, row in other.iterrows():
            self.log_warning(
                f"Positions file: skipping non-today expiry "
                f"{row['Symbol']} {row['Strike']} {row['OptionType']} "
                f"expiry={row['Expiry']} qty={row['Qty']}"
            )

        if today_rows.empty:
            self.log_warning(
                f"Positions file {path.name}: no rows with expiry == today "
                f"({today}) after filtering. Phase 1 will be a no-op."
            )
            return []

        positions = []
        for _, row in today_rows.iterrows():
            positions.append({
                "symbol": str(row["Symbol"]),
                "expiry": row["Expiry"],
                "strike": Decimal(str(row["Strike"])),
                "option_type": str(row["OptionType"]),
                "signed_floor_qty": int(row["Qty"]),
            })

        self.log_info(
            f"Positions file: {len(positions)} position(s) to close "
            f"(expiry {today})."
        )
        return positions

    def _build_target_shares(self, portfolio_df: pd.DataFrame) -> dict[str, int]:
        """Extract {ticker: target_shares} from the portfolio DataFrame."""
        return {
            str(row["Ticker"]): int(row["Target Shares"])
            for _, row in portfolio_df.iterrows()
        }

    def _load_eq_current_holdings(self) -> Optional[dict[str, int]]:
        """
        Load current EQ holdings from positions file (filtered to EQ rows).
        Returns {symbol: signed_floor_qty} (zero-qty entries dropped) or None
        on hard-abort. Empty dict is OK (book genuinely flat in equity).
        """
        path = self._find_positions_file()
        if path is None:
            return None

        df = self._parse_positions_file(path)
        if df is None:
            return None

        filtered = self._filter_positions_by_type(df, POSITIONS_INSTRUMENT_TYPE_EQ)
        if filtered.empty:
            self.log_info(
                f"Positions file {path.name}: no EQ rows after filter — "
                f"current holdings = empty."
            )
            return {}

        filtered["Qty"] = pd.to_numeric(filtered["Qty"], errors="coerce")
        bad_mask = filtered[["Qty", "Symbol"]].isna().any(axis=1) | (
            filtered["Symbol"].astype(str).str.strip() == ""
        )
        if bad_mask.any():
            self.log_warning(
                f"EQ holdings: dropping {int(bad_mask.sum())} row(s) "
                f"with unparseable Qty/Symbol."
            )
            filtered = filtered.loc[~bad_mask]

        if filtered.empty:
            return {}

        filtered["Symbol"] = filtered["Symbol"].astype(str).str.strip()
        grouped = filtered.groupby("Symbol", as_index=False)["Qty"].sum()
        grouped = grouped[grouped["Qty"] != 0]

        holdings = {
            str(row["Symbol"]): int(row["Qty"])
            for _, row in grouped.iterrows()
        }
        self.log_info(
            f"EQ current holdings: {len(holdings)} ticker(s) from {path.name}"
        )
        return holdings

    def _get_total_account_multiplier(self) -> int:
        """
        Sum of multipliers across active, auto-executing account mappings
        for this strategy. Mirrors OrderManager fan-out behaviour so that
        base_qty * total_mult == floor-level qty visible in positions file.
        """
        from accounts.models import StrategyAccountMapping
        total = StrategyAccountMapping.objects.filter(
            strategy=self.strategy_obj,
            is_active=True,
            auto_execute=True,
            broker_account__is_active=True,
        ).aggregate(s=Sum("multiplier"))["s"] or 0
        return int(total)

    # =========================================================================
    # PHASE 1 — CLOSE OLD POSITIONS
    # =========================================================================

    def _phase1_close_old_positions(
        self, datafeed_handler, dry_run: bool = False
    ) -> bool:
        """
        Close old CE/PE positions driven by the floor-authoritative positions
        file (not the portfolio CSV). Returns True on success (including the
        clean no-op case); False on any hard-abort condition so run() can
        skip Phases 2 and 3 and avoid double exposure.
        """
        self.log_info("=" * 60)
        self.log_info("PHASE 1: Closing old CE / PE positions (from positions file)")
        self.log_info("=" * 60)

        positions = self._load_positions_to_close()
        if positions is None:
            self.log_error("Phase 1 aborted: could not load positions from file.")
            return False

        if not positions:
            self.log_info(
                "Phase 1: no positions to close (book already flat for today's expiry)."
            )
            return True

        total_mult = self._get_total_account_multiplier()
        if total_mult <= 0:
            self.log_error(
                "Phase 1 aborted: no active account mappings (total multiplier = 0)."
            )
            return False
        self.log_info(f"Total account multiplier across active mappings: {total_mult}")

        close_tasks = []
        instruments_for_ltp = []

        for pos in positions:
            symbol = pos["symbol"]
            strike = pos["strike"]
            option_type = pos["option_type"]
            floor_qty = pos["signed_floor_qty"]
            tag = f"{symbol}_{option_type}_CLOSE"

            inst = self._get_current_expiry_option(symbol, strike, option_type)
            if inst is None:
                self.log_error(
                    f"Phase 1 aborted: instrument not found for "
                    f"{symbol} {strike} {option_type} expiring today "
                    f"(floor_qty={floor_qty})."
                )
                return False

            abs_floor = abs(floor_qty)
            if abs_floor % total_mult != 0:
                self.log_error(
                    f"Phase 1 aborted: floor qty {floor_qty} for {symbol} "
                    f"{strike} {option_type} is not divisible by total "
                    f"multiplier {total_mult}. Discretionary split across "
                    f"accounts suspected — resolve manually."
                )
                return False

            base_qty = abs_floor // total_mult
            base_lots = base_qty // inst.lot_size
            order_qty = base_lots * inst.lot_size

            if base_qty % inst.lot_size != 0:
                self.log_warning(
                    f"{tag}: base_qty {base_qty} is not a clean multiple of "
                    f"lot_size {inst.lot_size} — rounding down to {order_qty}."
                )

            if order_qty <= 0:
                self.log_warning(
                    f"{tag}: order_qty rounds to 0 (base_qty={base_qty}, "
                    f"lot_size={inst.lot_size}) — skipping."
                )
                continue

            side = "SELL" if floor_qty > 0 else "BUY"
            self.log_info(
                f"{tag}: side={side} floor_qty={floor_qty} "
                f"base_qty={base_qty} order_qty={order_qty} "
                f"lot_size={inst.lot_size}"
            )

            instruments_for_ltp.append(inst)
            close_tasks.append(
                dict(inst=inst, side=side, qty=order_qty, tag=tag)
            )

        if not close_tasks:
            self.log_warning(
                "Phase 1: all positions skipped after lot rounding — nothing to close."
            )
            return True

        ltps = self._fetch_ltp(datafeed_handler, instruments_for_ltp)

        for task in close_tasks:
            inst = task["inst"]
            ltp = ltps.get(inst.instrument_token)
            price = self._limit_price(task["side"], ltp) if ltp else None
            if ltp is None:
                self.log_warning(f"{task['tag']}: LTP unavailable — placing MARKET order")
            self._place_order(
                instrument=inst,
                side=task["side"],
                quantity=task["qty"],
                price=price,
                product_type="NRML",
                order_intent="EXIT",
                tag=task["tag"],
                dry_run=dry_run,
            )

        return True

    # =========================================================================
    # PHASE 2 — REBALANCE EQUITY
    # =========================================================================

    def _phase2_rebalance_equity(
        self, portfolio_df: pd.DataFrame, datafeed_handler, dry_run: bool = False
    ) -> bool:
        """
        Rebalance equity holdings against portfolio targets.
        Returns True on success (including clean no-op); False on any
        hard-abort condition so run() can skip Phase 3.
        """
        self.log_info("=" * 60)
        self.log_info("PHASE 2: Rebalancing equity holdings (CNC)")
        self.log_info("=" * 60)

        targets = self._build_target_shares(portfolio_df)

        current = self._load_eq_current_holdings()
        if current is None:
            self.log_error("Phase 2 aborted: could not load EQ current holdings.")
            return False

        total_mult = self._get_total_account_multiplier()
        if total_mult <= 0:
            self.log_error(
                "Phase 2 aborted: no active account mappings (total multiplier = 0)."
            )
            return False
        self.log_info(f"Total account multiplier across active mappings: {total_mult}")

        eq_tasks = []
        eq_instruments = []

        for ticker in sorted(set(targets.keys()) | set(current.keys())):
            target_floor = targets.get(ticker, 0)
            current_floor = current.get(ticker, 0)

            if ticker not in targets:
                self.log_warning(
                    f"{ticker}: held floor_qty={current_floor} but absent from "
                    f"EQ targets file — skipping (write target=0 to exit)."
                )
                continue

            floor_diff = target_floor - current_floor
            if floor_diff == 0:
                continue

            inst = self._get_equity_instrument(ticker)
            if inst is None:
                self.log_error(
                    f"Phase 2 aborted: EQ instrument not found on NSE for {ticker} "
                    f"(target={target_floor}, current={current_floor})."
                )
                return False

            base_qty = abs(floor_diff) // total_mult
            if base_qty == 0:
                self.log_warning(
                    f"{ticker}: floor_diff={floor_diff} smaller than "
                    f"total_mult={total_mult} — base_qty rounds to 0, "
                    f"skipping (residual {abs(floor_diff)} share(s) remain)."
                )
                continue

            if abs(floor_diff) % total_mult != 0:
                placed = base_qty * total_mult
                residual = abs(floor_diff) - placed
                self.log_warning(
                    f"{ticker}: floor_diff={floor_diff} not divisible by "
                    f"total_mult={total_mult} — placing base_qty={base_qty} "
                    f"({placed} share(s) total across accounts); "
                    f"{residual} share(s) of residual will remain."
                )

            side = "BUY" if floor_diff > 0 else "SELL"
            tag = f"{ticker}_EQ_{side}"

            self.log_info(
                f"{tag}: target={target_floor} current={current_floor} "
                f"diff={floor_diff} side={side} base_qty={base_qty}"
            )

            eq_instruments.append(inst)
            eq_tasks.append(dict(inst=inst, side=side, qty=base_qty, tag=tag))

        if not eq_tasks:
            self.log_info("No equity rebalancing needed.")
            return True

        ltps = self._fetch_ltp(datafeed_handler, eq_instruments)

        for task in eq_tasks:
            inst = task["inst"]
            ltp = ltps.get(inst.instrument_token)
            price = self._limit_price(task["side"], ltp) if ltp else None
            if ltp is None:
                self.log_warning(f"{task['tag']}: LTP unavailable — placing MARKET order")
            self._place_order(
                instrument=inst,
                side=task["side"],
                quantity=task["qty"],
                price=price,
                product_type="CNC",
                order_intent="ENTRY" if task["side"] == "BUY" else "EXIT",
                tag=task["tag"],
                dry_run=dry_run,
            )

        return True

    # =========================================================================
    # PHASE 3 — ENTER FRESH POSITIONS
    # =========================================================================

    def _phase3_enter_fresh_positions(
        self, portfolio_df: pd.DataFrame, datafeed_handler, dry_run: bool = False
    ) -> None:
        self.log_info("=" * 60)
        self.log_info("PHASE 3: Entering fresh CE short + PE long (next expiry)")
        self.log_info("=" * 60)

        total_mult = self._get_total_account_multiplier()
        if total_mult <= 0:
            self.log_error(
                "Phase 3 aborted: no active account mappings (total multiplier = 0)."
            )
            return

        # Step A: resolve instruments and gather equities for bulk LTP fetch
        stock_meta = {}
        equities_for_ltp = []

        for _, row in portfolio_df.iterrows():
            ticker = str(row["Ticker"])
            target_shares = int(row["Target Shares"])

            if target_shares <= 0:
                self.log_warning(
                    f"{ticker}: target_shares={target_shares} <= 0 — skipping"
                )
                continue

            equity = self._get_equity_instrument(ticker)
            if not equity:
                self.log_warning(f"{ticker}: No NSE EQ instrument found — skipping")
                continue

            option_expiry = self._get_next_option_expiry(ticker)
            if not option_expiry:
                self.log_warning(f"{ticker}: No next option expiry found — skipping")
                continue

            stock_meta[ticker] = {
                "equity": equity,
                "option_expiry": option_expiry,
                "target_shares": target_shares,
            }
            equities_for_ltp.append(equity)

        if not stock_meta:
            self.log_error("No stocks available for fresh entry.")
            return

        # Step B: bulk fetch spot (equity) LTPs
        spot_ltps = self._fetch_ltp(datafeed_handler, equities_for_ltp)

        # Step C: resolve option strikes, derive lots from DB, build tasks
        option_tasks = []
        option_instruments_for_ltp = []

        for ticker, meta in stock_meta.items():
            spot = spot_ltps.get(meta["equity"].instrument_token)
            if not spot:
                self.log_warning(f"{ticker}: Spot LTP unavailable — skipping")
                continue

            expiry = meta["option_expiry"]
            target_shares = meta["target_shares"]

            # ATM CE: nearest strike to spot; on ties, pick the higher strike
            ce_strikes = self._get_available_strikes(ticker, expiry, "CE")
            atm_strike = self._find_closest_strike(spot, ce_strikes, tie_break="higher")
            if not atm_strike:
                self.log_warning(f"{ticker}: No CE strikes for {expiry} — skipping")
                continue

            # 5% OTM PE: nearest strike to 95% of spot; on ties, pick the lower strike.
            pe_target = Decimal(str(spot)) * OTM_PE_PCT
            pe_strikes = self._get_available_strikes(ticker, expiry, "PE")
            pe_strike = self._find_closest_strike(pe_target, pe_strikes, tie_break="lower")
            if not pe_strike:
                self.log_warning(f"{ticker}: No PE strikes for {expiry} — skipping")
                continue

            ce_inst = self._get_option_instrument(ticker, expiry, atm_strike, "CE")
            pe_inst = self._get_option_instrument(ticker, expiry, pe_strike, "PE")

            if not ce_inst:
                self.log_warning(f"{ticker}: CE instrument missing at strike {atm_strike} — skipping")
                continue
            if not pe_inst:
                self.log_warning(f"{ticker}: PE instrument missing at strike {pe_strike} — skipping")
                continue

            # Derive lots from DB lot_size — single source of truth
            lot_size = ce_inst.lot_size

            # Validate CE/PE lot_size consistency
            if ce_inst.lot_size != pe_inst.lot_size:
                self.log_error(
                    f"{ticker}: CE lot_size={ce_inst.lot_size} != "
                    f"PE lot_size={pe_inst.lot_size} — asymmetric legs, "
                    f"skipping (investigate instrument data)."
                )
                continue

            # Check multiplier divisibility
            base_shares = target_shares // total_mult
            if target_shares % total_mult != 0:
                mult_residual = target_shares - (base_shares * total_mult)
                self.log_warning(
                    f"{ticker}: target_shares={target_shares} not divisible "
                    f"by total_mult={total_mult} — base_shares={base_shares}, "
                    f"{mult_residual} share(s) will have no option coverage."
                )

            # Check lot divisibility
            base_lots = base_shares // lot_size
            if base_shares % lot_size != 0:
                covered = base_lots * lot_size
                lot_residual = base_shares - covered
                self.log_warning(
                    f"{ticker}: base_shares={base_shares} not divisible by "
                    f"lot_size={lot_size} — writing {base_lots} lot(s) "
                    f"({covered} shares covered), {lot_residual} share(s) "
                    f"uncovered per account."
                )

            if base_lots <= 0:
                self.log_warning(
                    f"{ticker}: target_shares={target_shares} → "
                    f"base_shares={base_shares} → 0 lots "
                    f"(lot_size={lot_size}) — skipping"
                )
                continue

            ce_qty = base_lots * lot_size
            pe_qty = base_lots * lot_size

            self.log_info(
                f"{ticker}: SPOT={spot:.2f}  |  "
                f"CE {atm_strike} (ATM)  |  PE {pe_strike} (~5% OTM)  |  "
                f"Expiry={expiry}  |  Lots={base_lots}  |  "
                f"lot_size={lot_size} (from DB)"
            )

            option_instruments_for_ltp.extend([ce_inst, pe_inst])
            option_tasks.append(
                dict(
                    ticker=ticker,
                    ce_inst=ce_inst,
                    pe_inst=pe_inst,
                    ce_qty=ce_qty,
                    pe_qty=pe_qty,
                )
            )

        if not option_tasks:
            self.log_error("No option orders to place.")
            return

        # Step D: bulk fetch option LTPs
        option_ltps = self._fetch_ltp(datafeed_handler, option_instruments_for_ltp)

        # Step E: place orders
        for task in option_tasks:
            ticker = task["ticker"]
            ce_inst = task["ce_inst"]
            pe_inst = task["pe_inst"]

            ce_ltp = option_ltps.get(ce_inst.instrument_token)
            pe_ltp = option_ltps.get(pe_inst.instrument_token)

            # SELL CE (covered call leg)
            ce_price = self._limit_price("SELL", ce_ltp) if ce_ltp else None
            if ce_ltp is None:
                self.log_warning(f"{ticker}: CE LTP unavailable — placing MARKET order")
            self._place_order(
                instrument=ce_inst,
                side="SELL",
                quantity=task["ce_qty"],
                price=ce_price,
                product_type="NRML",
                order_intent="ENTRY",
                tag=f"{ticker}_NEW_CE_SELL",
                dry_run=dry_run,
            )

            # BUY PE (protective put leg)
            pe_price = self._limit_price("BUY", pe_ltp) if pe_ltp else None
            if pe_ltp is None:
                self.log_warning(f"{ticker}: PE LTP unavailable — placing MARKET order")
            self._place_order(
                instrument=pe_inst,
                side="BUY",
                quantity=task["pe_qty"],
                price=pe_price,
                product_type="NRML",
                order_intent="ENTRY",
                tag=f"{ticker}_NEW_PE_BUY",
                dry_run=dry_run,
            )

    # =========================================================================
    # TIME UTILITIES
    # =========================================================================

    def _get_today_datetime(self, time_obj) -> datetime:
        today = timezone.now().date()
        naive_dt = datetime.combine(today, time_obj)
        return timezone.make_aware(naive_dt)

    def _wait_until(self, target_time: datetime) -> bool:
        """Wait until target_time. Returns False if stop() was called."""
        while self.is_running:
            now = timezone.now()
            if now >= target_time:
                return True
            remaining = (target_time - now).total_seconds()
            if remaining > 60:
                self.log_info(
                    f"Waiting {int(remaining // 60)}m {int(remaining % 60)}s "
                    f"until {target_time.strftime('%H:%M:%S')}"
                )
                time.sleep(30)
            else:
                time.sleep(1)
        return False

    # =========================================================================
    # BASE STRATEGY INTERFACE
    # =========================================================================

    def verify(self) -> bool:
        if not self.datafeed_obj:
            self.log_error("No datafeed object provided.")
            return False

        if self.datafeed_obj.is_token_expired:
            self.log_warning("Datafeed token expired — attempting refresh...")
            from datafeed.rest.handler import DataFeedHandler
            handler = DataFeedHandler(self.datafeed_obj)
            if not handler.update_token():
                self.log_error("Failed to refresh datafeed token.")
                return False

        df = self._load_portfolio()
        if df is None or df.empty:
            self.log_error("Portfolio data is empty or could not be loaded.")
            return False

        # Sanity guard: today must be an expiry day for at least one portfolio ticker.
        today = date.today()
        portfolio_tickers = df["Ticker"].astype(str).str.strip().tolist()
        has_today_expiry = Instrument.objects.filter(
            name__in=portfolio_tickers,
            exchange="NFO",
            instrument_type__in=["CE", "PE"],
            is_active=True,
            expiry=today,
        ).exists()
        if not has_today_expiry:
            self.log_error(
                f"Verification failed: today ({today}) is not an expiry day "
                f"for any portfolio ticker. CCALL only runs on expiry days."
            )
            return False

        positions_file = self._find_positions_file()
        if positions_file is None:
            self.log_error(
                f"No fresh positions file found. Expected glob "
                f"'{POSITIONS_FILE_GLOB}' in '{POSITIONS_DIR}' "
                f"dated within last {POSITIONS_FILE_MAX_AGE_DAYS} days."
            )
            return False

        total_mult = self._get_total_account_multiplier()
        self.log_info(str(total_mult) + " = total multiplier")
        if total_mult <= 0:
            self.log_error(
                "No active StrategyAccountMapping with positive multiplier "
                "found for this strategy."
            )
            return False

        self.log_info(
            f"Verification passed. {len(df)} stocks in portfolio; "
            f"positions file: {positions_file.name}; "
            f"total account multiplier: {total_mult}."
        )
        return True

    def _ran_marker_path(self) -> Path:
        return POSITIONS_DIR / f".ran-{date.today().isoformat()}"

    def run(self):
        """
        Single-shot execution on expiry day:
          Wait for entry_time → Phase 1 → Phase 2 → Phase 3 → stop
        """
        dry_run: bool = bool(
            (self.strategy_obj.strategy_params or {}).get("dry_run", False)
        )

        # ── Idempotency guard ─────────────────────────────────────────────
        marker = self._ran_marker_path()
        if marker.exists() and not dry_run:
            self.log_error(
                f"CCALL already ran today — marker file exists: {marker}. "
                f"Delete it manually to force a re-run."
            )
            return

        self.log_info("=" * 60)
        self.log_info(f"Starting {self.strategy_obj.strategy_name}")
        self.log_info(f"Entry Time : {self.strategy_obj.entry_time}")
        self.log_info(f"Mode       : {'DRY-RUN (no orders placed)' if dry_run else 'LIVE'}")
        self.log_info("=" * 60)

        if not self.verify():
            self.log_error("Verification failed. Exiting.")
            return

        self.is_running = True

        from datafeed.rest.handler import DataFeedHandler
        datafeed_handler = DataFeedHandler(self.datafeed_obj)

        portfolio_df = self._load_portfolio()
        if portfolio_df is None:
            self.log_error("Could not load portfolio. Exiting.")
            self.is_running = False
            return

        # Wait for entry time
        entry_dt = self._get_today_datetime(self.strategy_obj.entry_time)
        self.log_info(f"Waiting for entry time: {entry_dt.strftime('%H:%M:%S')}")
        if not self._wait_until(entry_dt):
            self.log_info("Strategy stopped while waiting for entry time.")
            return

        if not self.is_running:
            return

        try:
            phase1_ok = self._phase1_close_old_positions(datafeed_handler, dry_run=dry_run)
            if not phase1_ok:
                self.log_error(
                    "Phase 1 aborted. Skipping Phase 2 (equity rebalance) and "
                    "Phase 3 (fresh entry) to avoid double exposure. "
                    "Manual intervention required."
                )
            else:
                phase2_ok = self._phase2_rebalance_equity(portfolio_df, datafeed_handler, dry_run=dry_run)
                if not phase2_ok:
                    self.log_error(
                        "Phase 2 aborted. Skipping Phase 3 (fresh entry) to avoid "
                        "mis-sized hedges against unknown equity. "
                        "Manual intervention required."
                    )
                else:
                    self._phase3_enter_fresh_positions(portfolio_df, datafeed_handler, dry_run=dry_run)
                    # ── Write marker on full success (skip in dry-run) ─────
                    if not dry_run:
                        marker.write_text(f"completed {datetime.now().isoformat()}")
                        self.log_info(f"Idempotency marker written: {marker}")
        except Exception as e:
            self.log_exception(f"Unexpected error during execution: {e}")

        self.is_running = False
        self.log_info(f"{self.strategy_obj.strategy_name} completed.")

    def stop(self):
        self.log_info(f"Stopping {self.strategy_obj.strategy_name}...")
        self.is_running = False