"""
Strategy class implementations.
Each strategy extends BaseStrategy and implements run/verify/stop methods.
"""
from strategy.strategy_class.base_strategy import BaseStrategy
from strategy.strategy_class.covered_call import CoveredCall
from strategy.strategy_class.vol_trading import VolLongShort
from strategy.strategy_class.nifty_straddle import NiftyDeltaHedgedStraddle
from strategy.strategy_class.long_stock import LongStock
from strategy.strategy_class.short_future import ShortFuture
from strategy.strategy_class.index_long_short import IndexLongShort


__all__ = [
    'BaseStrategy',
    'CoveredCall',
    'VolLongShort',
    'NiftyDeltaHedgedStraddle',
    'LongStock',
    'ShortFuture',
    'IndexLongShort',
]
