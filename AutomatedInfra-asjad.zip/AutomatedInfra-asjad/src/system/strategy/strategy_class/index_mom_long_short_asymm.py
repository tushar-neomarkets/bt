""" Index Momentum Long Short

15-min EMA + Bollinger Band breakout strategy on NIFTY 50.

Entry  : prior-bar high/low breakout of dynamic BB bands, gated by fast EMA(5)
         > slow EMA(20) for longs, < for shorts.
Exit   : 15-min close crosses back through the BB midline (20-SMA).
Reversal: same-bar flip if the opposite entry fires on the exit bar.
BB std : 1.5 + atr_percentile (range 1.5..2.5).
Execution (asymmetric):
    Long  = BUY ATM CE + SELL ATM PE (synthetic forward, CW expiry)
    Short = SELL ATM CE only        (naked short call,    CW expiry)
    Long  exit = box exit at current ATM, same expiry
    Short exit = buy back the same CE at the original strike
Expiry day: existing CW position rolls to NW at 09:44:59; new signals on
            expiry day enter NW directly.
"""

import csv
import math
import os
import shutil
import time
import uuid
from datetime import date, datetime, time as dt_time
from decimal import Decimal
from typing import Optional

import numpy as np
import pandas as pd
import scipy.optimize as spo
from scipy.special import ndtr
from django.db.models import Min
from django.utils import timezone
from marketdata import Index

from instruments.models import Instrument
from orders.order_manager import order_manager
from strategy.models import StrategyPosition
from strategy.strategy_class.base_strategy import BaseStrategy
from utils.ttm_helper import ttm as compute_ttm

TBT_DATA_PATH = r"\\10.211.8.76\GFD MBM Data\Momentum\logs"
LOCAL_TBT_DIR = os.path.join(
    os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))),
    "dump", "tbt_local",
)
TBT_COPY_INTERVAL_SECS = 20

# ── TBT Guard Constants ──────────────────────────────────────────────────────
TBT_MARKET_OPEN  = dt_time(9, 15, 0)
TBT_MARKET_CLOSE = dt_time(15, 30, 0)
TBT_MAX_STALENESS_SECS = 120                 # Reject if latest tick > 2 min behind wall clock

PRICE_OFFSET          = Decimal("0.5")
ROLLOVER_DAYS_BEFORE  = 0                    # Switch to NW expiry on expiry day itself
ROLLOVER_CHECK_TIME   = dt_time(9, 44, 59)   # NW roll on expiry day, per backtest
TICKER                = "NIFTY"

# ── Overnight hedge ──────────────────────────────────────────────────────────
HEDGE_OTM_PCT        = 0.03                    # 3% OTM
HEDGE_ENTRY_TIME     = dt_time(15, 14, 59)     # buy hedge at this bar close
HEDGE_EXIT_TIME      = dt_time(9, 29, 59)      # sell hedge at next-day open

# ── ATM-IV position sizing ───────────────────────────────────────────────────
DAILY_CAP            = 1   # ₹ daily notional cap (no compounding)
TRADING_DAYS_YEAR    = 252
RISK_FREE_RATE       = 0.0
MIN_SANE_ATM_IV      = 0.01

# ── CSV State Persistence ─────────────────────────────────────────────────────
_BASE_DIR       = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
IDXMA_DUMP_DIR = os.path.join(_BASE_DIR, 'dump', 'idxma')
CSV_COLUMNS = [
    'timestamp', 'event',
    # Indicator state
    'fast_ema', 'slow_ema',
    'bb_upper', 'bb_mean', 'bb_lower', 'bb_std',
    'atr', 'atr_percentile',
    # Bar OHLC
    'bar_idx', 'bar_open', 'bar_high', 'bar_low', 'bar_close',
    # Previous-bar anchor
    'prev_high', 'prev_low', 'prev_bb_upper', 'prev_bb_lower',
    # Signal state
    'signal',
    'entry_price',
    # Instruments
    'ce_token', 'ce_tradingsymbol',
    'pe_token', 'pe_tradingsymbol',
    'expiry', 'atm_strike', 'spot_price',
    # Flags / exit info
    'rollover_done',
    'exit_type', 'exit_atm_strike',
]

idx = Index()

# ── Index / bar params ────────────────────────────────────────────────────────
INDEX_SYMBOL    = "NIFTY 50"
TBT_INDEX_NAME  = "Nifty 50"
BAR_INTERVAL_MINS  = 15
NIFTY_STRIKE_STEP  = 50

# ── Indicator params (mirror backtest) ────────────────────────────────────────
PRICE_WINDOW            = 100
FAST_EMA_PERIOD         = 5
SLOW_EMA_PERIOD         = 20
BB_PERIOD               = 20
ATR_PERIOD              = 20
ATR_PERCENTILE_WINDOW   = 100
ATR_PERCENTILE_MIN_BARS = 100

# Calendar lookback for warm-up; needs at least
# ATR_PERCENTILE_MIN_BARS + ATR_PERIOD + 1 = 121 bars of 15-min data.
HISTORY_CALENDAR_DAYS = 30

# ── 15-min bar boundaries (NSE: 9:15→15:30, 25 bars/day) ─────────────────────
# Each candle: [start_inclusive, end_exclusive); close timestamp = end - 1s.
def _build_bar_boundaries() -> list[tuple[dt_time, dt_time]]:
    boundaries: list[tuple[dt_time, dt_time]] = []
    start_dt = datetime.combine(date(2000, 1, 1), TBT_MARKET_OPEN)
    end_dt   = datetime.combine(date(2000, 1, 1), TBT_MARKET_CLOSE)
    cur = start_dt
    while cur < end_dt:
        nxt = cur + pd.Timedelta(minutes=BAR_INTERVAL_MINS)
        if nxt > end_dt:
            nxt = end_dt
        boundaries.append((cur.time(), nxt.time()))
        cur = nxt
    return boundaries

BAR_BOUNDARIES = _build_bar_boundaries()
# Close-timestamp for each bar: 9:29:59, 9:44:59, ..., 15:29:59
VALID_BAR_CLOSE_TIMES = [
    (datetime.combine(date(2000, 1, 1), end) - pd.Timedelta(seconds=1)).time()
    for _, end in BAR_BOUNDARIES
]


# ═══════════════════════════════════════════════════════════════════════════════
# BLACK-SCHOLES IV SOLVERS  (live IV from LTP; ported from gex_regime_trader)
# ═══════════════════════════════════════════════════════════════════════════════
# T is fractional trading days; divided by 365 inside formulas.

def _d1(S, K, T, sigma, r):
    if sigma <= 1e-8:
        sigma = 1e-8
    return (math.log(S / K) + (r + sigma ** 2 / 2) * T / 365) / (sigma * math.sqrt(T / 365))


def _d2(d1_val, T, sigma):
    if sigma <= 1e-8:
        sigma = 1e-8
    return d1_val - sigma * math.sqrt(T / 365)


def _bs_call(S, K, r, T, sigma):
    d1 = _d1(S, K, T, sigma, r)
    d2 = _d2(d1, T, sigma)
    return S * ndtr(d1) - K * math.exp(-r * T / 365) * ndtr(d2)


def _bs_put(S, K, r, T, sigma):
    d1 = _d1(S, K, T, sigma, r)
    d2 = _d2(d1, T, sigma)
    return K * math.exp(-r * T / 365) * ndtr(-d2) - S * ndtr(-d1)


def _solve_call_iv(S, K, r, T, market_price, a=-2, b=5, xtol=1e-5):
    try:
        result = spo.brentq(lambda s: _bs_call(S, K, r, T, s) - market_price, a=a, b=b, xtol=xtol)
        return max(result, xtol)
    except ValueError:
        return float("nan")


def _solve_put_iv(S, K, r, T, market_price, a=-2, b=5, xtol=1e-5):
    try:
        result = spo.brentq(lambda s: _bs_put(S, K, r, T, s) - market_price, a=a, b=b, xtol=xtol)
        return max(result, xtol)
    except ValueError:
        return float("nan")


# ═══════════════════════════════════════════════════════════════════════════════
# PRICE WINDOW  (indicator engine — ported from backtest)
# ═══════════════════════════════════════════════════════════════════════════════

class PriceWindow:

    def __init__(self, n, fast_ema_period, slow_ema_period, bb_period, atr_period):
        self.n               = n
        self.window_open     = []
        self.window_high     = []
        self.window_low      = []
        self.window_close    = []

        self.fast_ema_period = fast_ema_period
        self.slow_ema_period = slow_ema_period
        self.fast_ema        = None
        self.slow_ema        = None

        self.bb_period       = bb_period
        self.atr_period      = atr_period
        self.atr             = None
        self._atr_wilder     = None
        self.atr_history     = []
        self.atr_percentile  = None

        self.fast_alpha = 2 / (fast_ema_period + 1)
        self.slow_alpha = 2 / (slow_ema_period + 1)

    def update_price(self, o, h, l, c):
        self.window_open.append(o)
        self.window_high.append(h)
        self.window_low.append(l)
        self.window_close.append(c)

        if len(self.window_close) > self.n:
            self.window_open.pop(0)
            self.window_high.pop(0)
            self.window_low.pop(0)
            self.window_close.pop(0)

        self._update_emas()
        self._update_atr()

    def _update_emas(self):
        prices = self.window_close
        if len(prices) >= self.fast_ema_period:
            if self.fast_ema is None:
                self.fast_ema = float(np.mean(prices[-self.fast_ema_period:]))
            else:
                self.fast_ema = self.fast_alpha * prices[-1] + (1 - self.fast_alpha) * self.fast_ema

        if len(prices) >= self.slow_ema_period:
            if self.slow_ema is None:
                self.slow_ema = float(np.mean(prices[-self.slow_ema_period:]))
            else:
                self.slow_ema = self.slow_alpha * prices[-1] + (1 - self.slow_alpha) * self.slow_ema

    def get_bollinger_bands(self, bb_std) -> tuple[Optional[float], Optional[float], Optional[float]]:
        prices = self.window_close
        if len(prices) < self.bb_period:
            return None, None, None
        recent = prices[-self.bb_period:]
        mid    = float(np.mean(recent))
        std    = float(np.std(recent, ddof=0))
        return mid + bb_std * std, mid, mid - bb_std * std

    def _update_atr(self):
        if len(self.window_close) < 2:
            return

        h  = self.window_high[-1]
        l  = self.window_low[-1]
        pc = self.window_close[-2]
        tr = max(h - l, abs(h - pc), abs(l - pc))

        alpha = 1.0 / self.atr_period
        if self._atr_wilder is None:
            if len(self.window_close) >= self.atr_period + 1:
                seed_trs = []
                for i in range(len(self.window_close) - self.atr_period, len(self.window_close)):
                    sh  = self.window_high[i]
                    sl  = self.window_low[i]
                    spc = self.window_close[i - 1]
                    seed_trs.append(max(sh - sl, abs(sh - spc), abs(sl - spc)))
                self._atr_wilder = float(np.mean(seed_trs))
            else:
                return
        else:
            self._atr_wilder = alpha * tr + (1 - alpha) * self._atr_wilder

        self.atr = self._atr_wilder
        current_close = self.window_close[-1]
        atr_pct = self.atr / current_close

        self.atr_history.append(atr_pct)
        if len(self.atr_history) > self.n:
            self.atr_history.pop(0)

        if len(self.atr_history) >= ATR_PERCENTILE_MIN_BARS:
            window  = self.atr_history[-ATR_PERCENTILE_WINDOW:]
            current = window[-1]
            past    = window[:-1]
            self.atr_percentile = float((np.array(past) < current).mean())
        else:
            self.atr_percentile = None

    def get_fast_ema(self):          return self.fast_ema
    def get_slow_ema(self):          return self.slow_ema
    def get_atr(self):               return self.atr
    def get_atr_percentile(self):    return self.atr_percentile


# ═══════════════════════════════════════════════════════════════════════════════
# STRATEGY
# ═══════════════════════════════════════════════════════════════════════════════

class IndexMomLongShort(BaseStrategy):

    def __init__(self, strategy_obj, datafeed_obj, ws_manager=None):
        super().__init__(strategy_obj, datafeed_obj, ws_manager)
        self.is_running = False

        # ── Indicator state ─────────────────────────────────────────────────
        self.price_window = PriceWindow(
            PRICE_WINDOW, FAST_EMA_PERIOD, SLOW_EMA_PERIOD, BB_PERIOD, ATR_PERIOD,
        )
        self.bb_std: float = 1.5
        # Previous-bar anchor: captured pre-update.
        self._prev_bar: Optional[dict] = None

        # ── Signal state ─────────────────────────────────────────────────────
        # "" = flat, "long", "short"
        self.signal: str = ""
        self.entry_time = None
        self.entry_price: Optional[float] = None

        # ── Synthetic forward / naked-call order state ────────────────────
        self.entry_ce: Optional[Instrument] = None
        self.entry_pe: Optional[Instrument] = None   # None for naked short
        self.open_positions: dict[str, StrategyPosition] = {}   # {"CE": pos[, "PE": pos]}
        self.last_processed_bar_idx: int = -1
        self._current_trading_date: Optional[date] = None
        self._rollover_done_today: bool = False
        self._last_good_max_ts: Optional[datetime] = None

    # =========================================================================
    # HISTORICAL DATA INGESTION & WARM-UP (Step 1)
    # =========================================================================

    def _fetch_historical_15min_data(self) -> Optional[pd.DataFrame]:
        """Fetch ~HISTORY_CALENDAR_DAYS of 15-min NIFTY 50 OHLC for PriceWindow warm-up."""
        today      = date.today()
        start_date = today - pd.Timedelta(days=HISTORY_CALENDAR_DAYS)
        start_str  = start_date.strftime("%Y-%m-%d")
        end_str    = today.strftime("%Y-%m-%d")
        self.log_info(
            f"Fetching 15-min data: {INDEX_SYMBOL} from {start_str} to {end_str}"
        )
        try:
            df = idx.get_prices(
                INDEX_SYMBOL, start_str, end_str, interval="15m", columns="ohlc",
            )
        except Exception as e:
            self.log_error(f"marketdata API call failed: {e}")
            return None
        if df is None or df.empty:
            self.log_error("API returned no data.")
            return None
        df.sort_values("timestamp", inplace=True)
        df.reset_index(drop=True, inplace=True)
        valid_set = set(VALID_BAR_CLOSE_TIMES)
        df = df[df["timestamp"].dt.time.isin(valid_set)].copy()
        df.reset_index(drop=True, inplace=True)
        if df.empty:
            self.log_error("No 15-min candles matched valid close times after filtering.")
            return None
        self.log_info(
            f"Fetched {len(df)} 15-min candles "
            f"({df['timestamp'].iloc[0]} → {df['timestamp'].iloc[-1]})"
        )
        return df

    def _warmup_price_window(self, df: pd.DataFrame) -> None:
        """Replay historical OHLC into PriceWindow so EMAs / BB / ATR are warm."""
        for row in df.itertuples(index=False):
            self.price_window.update_price(
                float(row.open), float(row.high), float(row.low), float(row.close),
            )
        atr_pct = self.price_window.get_atr_percentile()
        self.bb_std = 1.5 + atr_pct if atr_pct is not None else 1.5
        fe = self.price_window.get_fast_ema()
        se = self.price_window.get_slow_ema()
        fe_str = f"{fe:.2f}" if fe is not None else "N/A"
        se_str = f"{se:.2f}" if se is not None else "N/A"
        self.log_info(
            f"Warm-up complete: bars={len(df)} | "
            f"fast_ema={fe_str} slow_ema={se_str} "
            f"| atr_pct={atr_pct} | bb_std={self.bb_std:.3f}"
        )

    def _replay_today_bars(self) -> None:
        """Replay today's already-processed bars into PriceWindow after a restart.

        On restart the warm-up only contains historical data (up to yesterday).
        If CSV recovery restored last_processed_bar_idx >= 0, bars 0..N were
        processed in the previous session but are missing from PriceWindow.
        This method reads the BAR events from today's CSV and pushes their OHLC
        through update_price (indicator-only — no signal evaluation) so EMAs,
        BB, and ATR are correctly caught up before the live loop resumes.
        """
        if self.last_processed_bar_idx < 0:
            return

        csv_path = self._get_csv_path()
        if not os.path.isfile(csv_path):
            self.log_warning(
                "REPLAY: CSV file not found — PriceWindow may be stale."
            )
            return

        try:
            df = pd.read_csv(csv_path, on_bad_lines='skip')
        except Exception as e:
            self.log_warning(f"REPLAY: Failed to read CSV: {e}")
            return

        bar_rows = df[df['event'] == 'BAR'].copy()
        if bar_rows.empty:
            self.log_warning(
                "REPLAY: No BAR events in CSV — PriceWindow may be stale."
            )
            return

        replayed = 0
        for _, row in bar_rows.iterrows():
            o = row.get('bar_open')
            h = row.get('bar_high')
            l = row.get('bar_low')
            c = row.get('bar_close')
            if any(pd.isna(v) or v == '' for v in (o, h, l, c)):
                continue
            self.price_window.update_price(
                float(o), float(h), float(l), float(c),
            )
            replayed += 1

        # Refresh bb_std from the now-current ATR percentile.
        atr_pct = self.price_window.get_atr_percentile()
        self.bb_std = 1.5 + atr_pct if atr_pct is not None else 1.5

        self.log_info(
            f"REPLAY: Pushed {replayed} bars from CSV into PriceWindow "
            f"| bb_std={self.bb_std:.3f}"
        )

    # =========================================================================
    # TBT FILE COPY & PARSING (Step 2)
    # =========================================================================

    def _copy_tbt_file(self, file_date: Optional[date] = None) -> Optional[str]:
        """Copy today's TBT file from network share to local directory.
        Returns the local file path, or None on failure."""
        target_date = file_date or date.today()
        filename    = target_date.strftime("%Y%m%d") + ".txt"
        source      = os.path.join(TBT_DATA_PATH, filename)
        os.makedirs(LOCAL_TBT_DIR, exist_ok=True)
        dest = os.path.join(LOCAL_TBT_DIR, filename)
        try:
            shutil.copy2(source, dest)
            file_size = os.path.getsize(dest)
            self.log_info(f"Copied TBT file: {filename} ({file_size / 1024:.1f} KB)")
            return dest
        except FileNotFoundError:
            self.log_error(f"TBT file not found: {source}")
            return None
        except Exception as e:
            self.log_error(f"Failed to copy TBT file: {e}")
            return None

    def _parse_tbt_data(self, file_path: str) -> Optional[pd.DataFrame]:
        """Parse TBT file and filter for Nifty 50 ticks.

        TBT format:
            2026-02-01 09:32:35.339220 | Nifty 50 | 25301.0 | 1769918554

        Returns DataFrame with columns: [timestamp, price]"""
        try:
            df = pd.read_csv(
                file_path,
                sep=r"\s*\|\s*",
                header=None,
                names=["timestamp", "index_name", "price", "seq_id"],
                engine="python",
            )
        except Exception as e:
            self.log_error(f"Failed to parse TBT file: {e}")
            return None

        df = df[df["index_name"] == TBT_INDEX_NAME].copy()
        if df.empty:
            self.log_error(f"No '{TBT_INDEX_NAME}' ticks found in TBT file.")
            return None

        df["timestamp"] = pd.to_datetime(df["timestamp"], format="mixed")
        df["price"]     = pd.to_numeric(df["price"], errors="coerce")
        df = df.dropna(subset=["price"])
        df = df.sort_values("timestamp").reset_index(drop=True)

        pre_filter_count = len(df)
        df = df[
            (df["timestamp"].dt.time >= TBT_MARKET_OPEN)
            & (df["timestamp"].dt.time <= TBT_MARKET_CLOSE)
        ].reset_index(drop=True)
        rejected = pre_filter_count - len(df)
        if rejected > 0:
            self.log_info(f"Market hours filter: rejected {rejected} ticks outside 09:15–15:30")

        if df.empty:
            self.log_error("No ticks remain after market hours filter.")
            return None

        self.log_info(f"Parsed {len(df)} Nifty 50 ticks from TBT file")
        return df[["timestamp", "price"]]

    def _validate_tbt_data(self, tbt_df: pd.DataFrame) -> bool:
        """Validate parsed TBT data for staleness and timestamp regression.
        Returns True if data is safe to use, False if it should be rejected."""
        max_ts: datetime = tbt_df["timestamp"].max().to_pydatetime()
        now = datetime.now()

        staleness_secs = (now - max_ts).total_seconds()
        if staleness_secs > TBT_MAX_STALENESS_SECS:
            self.log_error(
                f"TBT REJECTED (stale): latest tick {max_ts.strftime('%H:%M:%S')} "
                f"is {staleness_secs:.0f}s behind wall clock "
                f"(threshold: {TBT_MAX_STALENESS_SECS}s)"
            )
            return False

        if self._last_good_max_ts is not None and max_ts < self._last_good_max_ts:
            regression_secs = (self._last_good_max_ts - max_ts).total_seconds()
            self.log_error(
                f"TBT REJECTED (regression): max tick {max_ts.strftime('%H:%M:%S')} "
                f"< previous good {self._last_good_max_ts.strftime('%H:%M:%S')} "
                f"(regressed {regression_secs:.0f}s)"
            )
            return False

        self._last_good_max_ts = max_ts
        return True

    def _resample_tbt_to_15min(self, tbt_df: pd.DataFrame) -> pd.DataFrame:
        """Resample tick data to 15-min OHLC candles using NSE 15-min boundaries."""
        candles = []
        for i, (start, end) in enumerate(BAR_BOUNDARIES):
            mask = (
                (tbt_df["timestamp"].dt.time >= start) &
                (tbt_df["timestamp"].dt.time < end)
            )
            bucket = tbt_df[mask]
            if bucket.empty:
                continue
            candle_time = VALID_BAR_CLOSE_TIMES[i]
            candle_date = bucket["timestamp"].iloc[0].date()
            candles.append({
                "timestamp":  pd.Timestamp.combine(candle_date, candle_time),
                "open":       float(bucket["price"].iloc[0]),
                "high":       float(bucket["price"].max()),
                "low":        float(bucket["price"].min()),
                "close":      float(bucket["price"].iloc[-1]),
                "tick_count": len(bucket),
            })
        result = pd.DataFrame(candles)
        if not result.empty:
            self.log_info(
                f"Resampled {len(result)} 15-min candles from "
                f"{tbt_df['timestamp'].iloc[0].time()} → "
                f"{tbt_df['timestamp'].iloc[-1].time()}"
            )
        return result

    # =========================================================================
    # SIGNAL GENERATION (Step 3)
    # =========================================================================

    def _on_bar_close(self, bar: dict) -> Optional[dict]:
        """Process a completed 15-min bar through the indicator + signal stack.

        Captures previous-bar anchor BEFORE updating PriceWindow (matching backtest),
        then evaluates entry / exit / same-bar reversal logic.

        Returns a signal dict describing the action to take, or None if no action.
        """
        o, h, l, c = bar["open"], bar["high"], bar["low"], bar["close"]

        # 1. Capture previous bar state BEFORE update (breakout anchor).
        prev_fast     = self.price_window.get_fast_ema()
        prev_slow     = self.price_window.get_slow_ema()
        prev_bb_upper, prev_bb_mean, prev_bb_lower = (
            self.price_window.get_bollinger_bands(self.bb_std)
        )
        prev_h = self.price_window.window_high[-1] if self.price_window.window_high else None
        prev_l = self.price_window.window_low[-1]  if self.price_window.window_low  else None

        # 2. Push current bar.
        self.price_window.update_price(o, h, l, c)

        # 3. Update dynamic BB std for NEXT bar's prev_bb_* readings.
        atr_pct = self.price_window.get_atr_percentile()
        self.bb_std = 1.5 + atr_pct if atr_pct is not None else 1.5

        # 4. Current-bar indicators.
        curr_fast = self.price_window.get_fast_ema()
        curr_slow = self.price_window.get_slow_ema()
        bb_upper, bb_mean, bb_lower = self.price_window.get_bollinger_bands(self.bb_std)

        # 5. Conditions (mirrors backtest exactly).
        indicators_ready = (
            prev_fast is not None and prev_slow is not None
            and prev_bb_upper is not None and prev_h is not None
        )
        long_breakout  = indicators_ready and h > prev_bb_upper and prev_h <= prev_bb_upper
        short_breakout = indicators_ready and l < prev_bb_lower and prev_l >= prev_bb_lower
        trend_long  = (curr_fast is not None and curr_slow is not None
                       and curr_fast > curr_slow)
        trend_short = (curr_fast is not None and curr_slow is not None
                       and curr_fast < curr_slow)

        new_action: Optional[str] = None

        # 6. Entry (only when flat).
        if self.signal not in ("long", "short"):
            if long_breakout and trend_long:
                self.signal = "long"
                new_action = "ENTER_LONG"
            elif short_breakout and trend_short:
                self.signal = "short"
                new_action = "ENTER_SHORT"

        # 7. Exit (with same-bar reversal).
        elif bb_mean is not None:
            if self.signal == "long" and c < bb_mean:
                if short_breakout and trend_short:
                    self.signal = "short"
                    new_action = "REVERSE_TO_SHORT"
                else:
                    self.signal = ""
                    new_action = "EXIT_LONG"
            elif self.signal == "short" and c > bb_mean:
                if long_breakout and trend_long:
                    self.signal = "long"
                    new_action = "REVERSE_TO_LONG"
                else:
                    self.signal = ""
                    new_action = "EXIT_SHORT"

        fe_str = f"{curr_fast:.2f}" if curr_fast is not None else "N/A"
        se_str = f"{curr_slow:.2f}" if curr_slow is not None else "N/A"
        bbl_str = f"{bb_lower:.2f}" if bb_lower is not None else "N/A"
        bbm_str = f"{bb_mean:.2f}" if bb_mean is not None else "N/A"
        bbu_str = f"{bb_upper:.2f}" if bb_upper is not None else "N/A"

        self.log_info(
            f"Bar {bar['timestamp']}: O={o:.2f} H={h:.2f} L={l:.2f} C={c:.2f} | "
            f"fast_ema={fe_str} slow_ema={se_str} | "
            f"bb=({bbl_str}, {bbm_str}, {bbu_str}) std={self.bb_std:.3f} | "
            f"signal={self.signal!r} action={new_action}"
        )

        if new_action is None:
            return None
        return {
            "action":     new_action,
            "timestamp":  bar["timestamp"],
            "spot_price": float(c),
            "bb_mean":    bb_mean,
            "bb_std":     self.bb_std,
        }

    # =========================================================================
    # INSTRUMENT LOOKUPS
    # =========================================================================

    def _get_nearest_option_expiry(self) -> Optional[date]:
        """Get the nearest weekly option expiry date for NIFTY."""
        today = date.today()
        result = Instrument.objects.filter(
            name=TICKER,
            exchange="NFO",
            instrument_type__in=["CE", "PE"],
            is_active=True,
            expiry__gte=today,
        ).aggregate(min_expiry=Min("expiry"))
        return result.get("min_expiry")

    def _get_next_week_expiry(self) -> Optional[date]:
        """Get the next-week option expiry (second nearest)."""
        today = date.today()
        expiries = (
            Instrument.objects.filter(
                name=TICKER,
                exchange="NFO",
                instrument_type__in=["CE", "PE"],
                is_active=True,
                expiry__gte=today,
            )
            .values_list("expiry", flat=True)
            .distinct()
            .order_by("expiry")[:2]
        )
        expiry_list = list(expiries)
        if len(expiry_list) >= 2:
            return expiry_list[1]
        return expiry_list[0] if expiry_list else None

    def _resolve_expiry(self) -> Optional[date]:
        """Pick CW or NW expiry based on rollover rule.
        On expiry day itself (ROLLOVER_DAYS_BEFORE=0), switch to next week."""
        cw = self._get_nearest_option_expiry()
        if cw is None:
            self.log_error("No option expiry found.")
            return None
        days_to_cw = (cw - date.today()).days
        if days_to_cw <= ROLLOVER_DAYS_BEFORE:
            nw = self._get_next_week_expiry()
            if nw:
                self.log_info(f"Rollover: CW={cw} ({days_to_cw}d away), using NW={nw}")
                return nw
        self.log_info(f"Using CW expiry: {cw} ({days_to_cw}d away)")
        return cw

    def _get_available_strikes(self, expiry: date, option_type: str) -> list[Decimal]:
        """Get all available strikes for a given expiry and type."""
        strikes = Instrument.objects.filter(
            name=TICKER,
            exchange="NFO",
            instrument_type=option_type,
            expiry=expiry,
            is_active=True,
        ).values_list("strike", flat=True).distinct()
        return sorted([s for s in strikes if s is not None])

    def _find_atm_strike(self, price: float, strikes: list[Decimal]) -> Optional[Decimal]:
        """Round spot to nearest NIFTY_STRIKE_STEP grid point, then validate against
        available strikes. Falls back to closest-available if the rounded strike is
        not listed."""
        if not strikes:
            return None
        grid_strike = Decimal(int(round(price / NIFTY_STRIKE_STEP) * NIFTY_STRIKE_STEP))
        if grid_strike in strikes:
            return grid_strike
        return min(strikes, key=lambda s: abs(s - grid_strike))

    def _get_option_instrument(
        self, expiry: date, strike: Decimal, option_type: str
    ) -> Optional[Instrument]:
        """Get a single option instrument."""
        return Instrument.objects.filter(
            name=TICKER,
            exchange="NFO",
            instrument_type=option_type,
            expiry=expiry,
            strike=strike,
            is_active=True,
        ).first()

    # =========================================================================
    # ORDER PLACEMENT
    # =========================================================================

    def _limit_price(self, side: str, ltp: float) -> Decimal:
        """Passive limit: SELL → LTP + offset, BUY → LTP − offset. Floored at 0.05 tick size."""
        base = Decimal(str(ltp))
        limit_px = base + PRICE_OFFSET if side == "SELL" else base - PRICE_OFFSET
        return limit_px if limit_px >= Decimal("0.05") else Decimal("0.05")

    def _fetch_ltp(self, datafeed_handler, instrument: Instrument) -> Optional[float]:
        """Fetch LTP for a single instrument. Retries indefinitely with token refresh on failure."""
        attempt = 0
        while self.is_running:
            attempt += 1
            try:
                self.datafeed_obj.refresh_from_db()
                from datafeed.rest.handler import DataFeedHandler
                datafeed_handler = DataFeedHandler(self.datafeed_obj)
                response = datafeed_handler.get_multiple_ltp([instrument])
                if response and "data" in response:
                    for item in response["data"].get("ltp_list", []):
                        if item.get("instrument_token") == instrument.instrument_token:
                            return item.get("ltp")
                return None
            except Exception as e:
                self.log_warning(
                    f"LTP fetch failed (attempt {attempt}) for "
                    f"{instrument.tradingsymbol}: {e}"
                )
                try:
                    from datafeed.rest.handler import DataFeedHandler
                    DataFeedHandler(self.datafeed_obj).update_token()
                    self.datafeed_obj.refresh_from_db()
                    self.log_info("Datafeed token refreshed after LTP failure")
                except Exception as refresh_err:
                    self.log_error(f"Token refresh failed: {refresh_err}")
                time.sleep(2)
        return None

    def _fetch_multiple_ltp(self, datafeed_handler, instruments: list[Instrument]) -> dict[int, float]:
        """Fetch LTP for multiple instruments. Retries indefinitely with token refresh on failure."""
        if not instruments:
            return {}
        attempt = 0
        while self.is_running:
            attempt += 1
            try:
                self.datafeed_obj.refresh_from_db()
                from datafeed.rest.handler import DataFeedHandler
                datafeed_handler = DataFeedHandler(self.datafeed_obj)
                result: dict[int, float] = {}
                response = datafeed_handler.get_multiple_ltp(instruments)
                if response and "data" in response:
                    for item in response["data"].get("ltp_list", []):
                        token = item.get("instrument_token")
                        ltp   = item.get("ltp")
                        if token and ltp:
                            result[token] = ltp
                return result
            except Exception as e:
                self.log_warning(
                    f"Multiple LTP fetch failed (attempt {attempt}) for "
                    f"{len(instruments)} instruments: {e}"
                )
                try:
                    from datafeed.rest.handler import DataFeedHandler
                    DataFeedHandler(self.datafeed_obj).update_token()
                    self.datafeed_obj.refresh_from_db()
                    self.log_info("Datafeed token refreshed after multi-LTP failure")
                except Exception as refresh_err:
                    self.log_error(f"Token refresh failed: {refresh_err}")
                time.sleep(2)
        return {}

    def _place_order(
        self,
        instrument: Instrument,
        side: str,
        quantity: int,
        price: Optional[Decimal],
        order_intent: str,
        tag: str = "",
        dry_run: bool = False,
    ) -> tuple[bool, object]:
        """Place an order via OrderManager. Supports dry-run mode."""
        order_type = "LIMIT" if price is not None else "MARKET"
        price_str  = str(price) if price is not None else "MKT"

        if dry_run:
            self.log_info(
                f"  [DRY-RUN][{tag}] {order_intent} {side} {quantity}x"
                f" {instrument.tradingsymbol}"
                f" | {order_type} @ {price_str}"
                f" | NRML"
                f" | expiry={instrument.expiry}"
            )
            return True, None

        success, msg, parent_order, _ = order_manager.create_and_execute_order(
            strategy=self.strategy_obj,
            instrument=instrument,
            side=side,
            quantity=quantity,
            order_type=order_type,
            product_type="NRML",
            price=price,
            order_intent=order_intent,
            metadata={
                "strategy_code":   self.strategy_obj.strategy_code,
                "instrument_type": instrument.instrument_type,
                "stock_name":      instrument.name,
                "tag":             tag,
            },
        )
        if success:
            self.log_info(
                f"  [{tag}] {side} {quantity}x {instrument.tradingsymbol} @ {price_str}"
            )
        else:
            self.log_error(f"  [{tag}] FAILED {side} {instrument.tradingsymbol}: {msg}")
        return success, parent_order

    # =========================================================================
    # STATE RECOVERY
    # =========================================================================

    def _bootstrap_from_db(self) -> bool:
        """Restore position/instrument state from DB if strategy was restarted mid-position.

        Returns True if open positions were found, False for a fresh run.
        """
        db_positions = StrategyPosition.objects.filter(
            strategy=self.strategy_obj,
            status="OPEN",
        ).select_related("instrument")

        if not db_positions.exists():
            self.log_info("No existing open positions found. Fresh run.")
            return False

        for pos in db_positions:
            meta     = pos.strategy_metadata or {}
            opt_type = meta.get("option_type")

            if opt_type == "CE":
                self.entry_ce = pos.instrument
                self.open_positions["CE"] = pos
            elif opt_type == "PE":
                self.entry_pe = pos.instrument
                self.open_positions["PE"] = pos
            elif opt_type == "HEDGE_CE":
                self.open_positions["HEDGE_CE"] = pos
                continue   # hedges don't drive signal state
            elif opt_type == "HEDGE_PE":
                self.open_positions["HEDGE_PE"] = pos
                continue   # hedges don't drive signal state
            else:
                self.log_warning(
                    f"RECOVERY: Skipping position {pos.trade_id} "
                    f"with unknown option_type={opt_type}"
                )
                continue

            # Only main legs (CE/PE) carry forward_direction → drive self.signal.
            if not self.signal:
                forward_dir  = meta.get("forward_direction", "LONG")
                self.signal  = "long" if forward_dir == "LONG" else "short"
                self.entry_price = float(meta.get("spot_signal", pos.entry_price))
                self.entry_time  = pos.entry_time

        self.log_warning(
            f"RECOVERY: signal={self.signal!r} | legs={list(self.open_positions.keys())}"
        )
        return True

    # =========================================================================
    # CSV STATE PERSISTENCE
    # =========================================================================

    def _get_csv_path(self) -> str:
        """Return today's CSV state file path."""
        code = self.strategy_obj.strategy_code.lower()
        return os.path.join(IDXMA_DUMP_DIR, f"{code}_{date.today().strftime('%Y%m%d')}.csv")

    def _append_csv_event(self, event: str, **kwargs) -> None:
        """Append a single event row to today's CSV state file."""
        csv_path = self._get_csv_path()
        os.makedirs(os.path.dirname(csv_path), exist_ok=True)
        file_exists = os.path.isfile(csv_path)
        row = {col: '' for col in CSV_COLUMNS}
        row['timestamp'] = datetime.now().isoformat()
        row['event']     = event
        row.update({k: v for k, v in kwargs.items() if k in CSV_COLUMNS})
        try:
            with open(csv_path, 'a', newline='') as f:
                writer = csv.DictWriter(f, fieldnames=CSV_COLUMNS)
                if not file_exists:
                    writer.writeheader()
                writer.writerow(row)
        except Exception as e:
            self.log_error(f"Failed to write CSV event: {e}")

    def _write_warmup_event(self) -> None:
        """Write WARMUP event after PriceWindow warm-up."""
        self._append_csv_event(
            'WARMUP',
            fast_ema=self.price_window.get_fast_ema(),
            slow_ema=self.price_window.get_slow_ema(),
            bb_std=self.bb_std,
            atr=self.price_window.get_atr(),
            atr_percentile=self.price_window.get_atr_percentile(),
        )

    def _write_bar_event(self, bar: dict, bar_idx: int) -> None:
        """Write BAR event after 15-min bar processing — captures full signal state snapshot."""
        bb_upper, bb_mean, bb_lower = self.price_window.get_bollinger_bands(self.bb_std)
        self._append_csv_event(
            'BAR',
            fast_ema=self.price_window.get_fast_ema(),
            slow_ema=self.price_window.get_slow_ema(),
            bb_upper=bb_upper,
            bb_mean=bb_mean,
            bb_lower=bb_lower,
            bb_std=self.bb_std,
            atr=self.price_window.get_atr(),
            atr_percentile=self.price_window.get_atr_percentile(),
            bar_idx=bar_idx,
            bar_open=bar.get('open'),
            bar_high=bar.get('high'),
            bar_low=bar.get('low'),
            bar_close=bar.get('close'),
            signal=self.signal,
            entry_price=self.entry_price if self.entry_price is not None else '',
        )

    def _write_entry_event(
        self, atm_strike: float, expiry: date, spot_price: float
    ) -> None:
        """Write ENTRY event after forward / naked-call entry placed."""
        self._append_csv_event(
            'ENTRY',
            signal=self.signal,
            entry_price=self.entry_price,
            ce_token=self.entry_ce.instrument_token if self.entry_ce else '',
            ce_tradingsymbol=self.entry_ce.tradingsymbol if self.entry_ce else '',
            pe_token=self.entry_pe.instrument_token if self.entry_pe else '',
            pe_tradingsymbol=self.entry_pe.tradingsymbol if self.entry_pe else '',
            expiry=str(expiry),
            atm_strike=atm_strike,
            spot_price=spot_price,
        )

    def _write_box_exit_event(
        self, exit_spot: float, exit_atm: float, exit_type: str = "BOX_SPREAD"
    ) -> None:
        """Write BOX_EXIT event after box spread exit."""
        self._append_csv_event(
            'BOX_EXIT',
            exit_type=exit_type,
            spot_price=exit_spot,
            exit_atm_strike=exit_atm,
        )

    def _write_naked_exit_event(self, atm_strike: float, exit_spot: float) -> None:
        """Write NAKED_EXIT event after naked-short buyback."""
        self._append_csv_event(
            'NAKED_EXIT',
            exit_type='NAKED_BUYBACK',
            exit_atm_strike=atm_strike,
            spot_price=exit_spot,
        )

    def _write_rollover_event(self, nw_expiry: date, atm_strike: float) -> None:
        """Write ROLLOVER event after rollover complete."""
        self._append_csv_event(
            'ROLLOVER',
            ce_token=self.entry_ce.instrument_token if self.entry_ce else '',
            ce_tradingsymbol=self.entry_ce.tradingsymbol if self.entry_ce else '',
            pe_token=self.entry_pe.instrument_token if self.entry_pe else '',
            pe_tradingsymbol=self.entry_pe.tradingsymbol if self.entry_pe else '',
            expiry=str(nw_expiry),
            atm_strike=atm_strike,
            signal=self.signal,
            rollover_done=1,
        )

    def _write_day_reset_event(self) -> None:
        """Write DAY_RESET event on day boundary change."""
        self._append_csv_event('DAY_RESET')

    def _load_state_from_csv(self) -> Optional[str]:
        """Restore signal state from today's CSV event log.

        Restores: signal string, bb_std, bar index, rollover flag.
        Position/instrument state is handled by _bootstrap_from_db.

        Returns phase string or None if no CSV found.
        """
        csv_path = self._get_csv_path()
        if not os.path.isfile(csv_path):
            return None

        try:
            df = pd.read_csv(csv_path, on_bad_lines='skip')
        except Exception as e:
            self.log_error(f"Failed to read CSV state: {e}")
            return None

        if df.empty:
            return None

        latest_phase = None

        for _, row in df.iterrows():
            event = row.get('event', '')

            if event == 'WARMUP':
                bb_std_val = row.get('bb_std')
                if not pd.isna(bb_std_val) and bb_std_val != '':
                    self.bb_std = float(bb_std_val)
                latest_phase = 'WARMUP_DONE'

            elif event == 'BAR':
                bb_std_val = row.get('bb_std')
                if not pd.isna(bb_std_val) and bb_std_val != '':
                    self.bb_std = float(bb_std_val)
                bar_idx_val = row.get('bar_idx')
                if not pd.isna(bar_idx_val) and bar_idx_val != '':
                    self.last_processed_bar_idx = int(bar_idx_val)
                sig_val = row.get('signal')
                if not pd.isna(sig_val) and sig_val != '':
                    self.signal = str(sig_val)
                ep_val = row.get('entry_price')
                if not pd.isna(ep_val) and ep_val != '':
                    self.entry_price = float(ep_val)
                latest_phase = 'RUNNING'

            elif event == 'ENTRY':
                sig_val = row.get('signal')
                if not pd.isna(sig_val) and sig_val != '':
                    self.signal = str(sig_val)
                latest_phase = 'IN_POSITION'

            elif event in ('BOX_EXIT', 'NAKED_EXIT'):
                self.signal     = ""
                self.entry_price = None
                latest_phase = 'RUNNING'

            elif event == 'ROLLOVER':
                rollover = row.get('rollover_done')
                if not pd.isna(rollover):
                    self._rollover_done_today = bool(int(rollover))
                latest_phase = 'IN_POSITION'

            elif event == 'DAY_RESET':
                self.signal              = ""
                self.entry_price         = None
                self.last_processed_bar_idx = -1
                self._rollover_done_today   = False
                latest_phase = 'RUNNING'

        self.log_info(
            f"CSV RECOVERY: phase={latest_phase} | signal={self.signal!r} "
            f"| bb_std={self.bb_std:.3f} | bar_idx={self.last_processed_bar_idx} "
            f"| rollover_done={self._rollover_done_today}"
        )
        return latest_phase

    # =========================================================================
    # TIME UTILITIES
    # =========================================================================

    def _get_today_datetime(self, time_obj) -> datetime:
        """Convert a time object to today's datetime in local timezone."""
        today    = timezone.now().date()
        naive_dt = datetime.combine(today, time_obj)
        return timezone.make_aware(naive_dt)

    def _wait_until(self, target_time: datetime) -> bool:
        """Wait until target_time. Returns False if stop() was called."""
        while self.is_running:
            now = timezone.now()
            if now >= target_time:
                return True
            remaining = (target_time - now).total_seconds()
            if remaining > 60:
                self.log_info(
                    f"Waiting {int(remaining // 60)}m {int(remaining % 60)}s "
                    f"until {target_time.strftime('%H:%M:%S')}"
                )
                time.sleep(30)
            else:
                time.sleep(1)
        return False

    def _get_latest_tbt_price(self, tbt_df: pd.DataFrame) -> Optional[tuple[float, datetime]]:
        """Extract the last Nifty 50 tick from the already-parsed TBT DataFrame."""
        if tbt_df is None or tbt_df.empty:
            return None
        last_row = tbt_df.iloc[-1]
        return float(last_row["price"]), last_row["timestamp"].to_pydatetime()

    # =========================================================================
    # BASE STRATEGY INTERFACE
    # =========================================================================

    def verify(self) -> bool:
        """Verify strategy prerequisites before running."""
        if not self.datafeed_obj:
            self.log_error("No datafeed object provided.")
            return False
        if self.datafeed_obj.is_token_expired:
            self.log_warning("Datafeed token expired — attempting refresh...")
            from datafeed.rest.handler import DataFeedHandler
            handler = DataFeedHandler(self.datafeed_obj)
            if not handler.update_token():
                self.log_error("Failed to refresh datafeed token.")
                return False
        self.log_info("Verification passed.")
        return True

    def stop(self):
        """Stop the strategy gracefully."""
        self.log_info("Stopping IndexMomLongShort...")
        self.is_running = False

    def run(self):
        """
        Main orchestration loop:
          1. Verify → 2. Wait for entry time → 3. Warm up PriceWindow
          4. Restore state → 5. TBT poll loop
             (15-min bar processing + bar-close signal execution)
        """
        params  = self.strategy_obj.strategy_params or {}
        dry_run = bool(params.get("dry_run", False))

        self.log_info("=" * 60)
        self.log_info("Starting IndexMomLongShort")
        self.log_info(f"Entry Time : {self.strategy_obj.entry_time}")
        self.log_info(f"Exit Time  : {self.strategy_obj.exit_time}")
        self.log_info(f"Mode       : {'DRY-RUN' if dry_run else 'LIVE'}")
        self.log_info("=" * 60)

        # Step 1: Verify
        if not self.verify():
            self.log_error("Verification failed. Exiting.")
            return

        self.is_running = True

        from datafeed.rest.handler import DataFeedHandler
        datafeed_handler = DataFeedHandler(self.datafeed_obj)

        # Step 2: Wait for entry time
        entry_dt = self._get_today_datetime(self.strategy_obj.entry_time)
        self.log_info(f"Waiting for entry time: {entry_dt.strftime('%H:%M:%S')}")
        if not self._wait_until(entry_dt):
            self.log_info("Strategy stopped while waiting.")
            return
        if not self.is_running:
            return

        # Step 3: Fetch historical data and warm up PriceWindow
        df = self._fetch_historical_15min_data()
        if df is None:
            self.log_error("Failed to fetch historical data. Exiting.")
            self.is_running = False
            return
        self._warmup_price_window(df)

        # Step 4: Restore state from CSV (signal state) + DB (position state)
        self._bootstrap_from_db()
        csv_phase = self._load_state_from_csv()

        if csv_phase is not None:
            # Consistency: CSV says long but no forward legs in DB
            if self.signal == "long" and not (
                "CE" in self.open_positions and "PE" in self.open_positions
            ):
                self.log_warning(
                    "RECOVERY: CSV says 'long' but CE+PE legs not found in DB. "
                    "Resetting to flat."
                )
                self.signal = ""
                self.open_positions.clear()
                self.entry_ce = self.entry_pe = None
                self.entry_price = self.entry_time = None

            # Consistency: CSV says short but CE-only not in DB (or PE is present)
            elif self.signal == "short" and not (
                "CE" in self.open_positions and "PE" not in self.open_positions
            ):
                self.log_warning(
                    "RECOVERY: CSV says 'short' but expected CE-only leg not found. "
                    "Resetting to flat."
                )
                self.signal = ""
                self.open_positions.clear()
                self.entry_ce = self.entry_pe = None
                self.entry_price = self.entry_time = None
        else:
            self._write_warmup_event()  # Fresh run — start CSV log

        # Step 4b: Replay today's already-processed bars into PriceWindow
        # so indicators (SMA20, EMA, ATR) are caught up after a restart.
        if csv_phase is not None and self.last_processed_bar_idx >= 0:
            self._replay_today_bars()

        # Protect recovered state from being wiped by the day-boundary check
        self._current_trading_date = date.today()

        # Step 5: Main TBT polling loop
        self.log_info("Entering main TBT polling loop...")
        exit_dt = self._get_today_datetime(self.strategy_obj.exit_time)

        while self.is_running:
            # Check exit time
            if timezone.now() >= exit_dt:
                self.log_info("Exit time reached. Stopping loop.")
                break

            try:
                # Day-boundary reset
                today = date.today()
                if self._current_trading_date != today:
                    if self._current_trading_date is not None:
                        self.log_info(
                            f"New trading day: {today}. "
                            f"Resetting bar index and rollover flag."
                        )
                    self._current_trading_date = today
                    self.last_processed_bar_idx = -1
                    self._rollover_done_today   = False
                    self._last_good_max_ts      = None
                    self._write_day_reset_event()

                # 5a: Copy and parse TBT file
                local_path = self._copy_tbt_file()
                if local_path is None:
                    time.sleep(TBT_COPY_INTERVAL_SECS)
                    continue

                tbt_df = self._parse_tbt_data(local_path)
                if tbt_df is None or tbt_df.empty:
                    time.sleep(TBT_COPY_INTERVAL_SECS)
                    continue

                if not self._validate_tbt_data(tbt_df):
                    time.sleep(TBT_COPY_INTERVAL_SECS)
                    continue

                # 5b: Rollover check — expiry day, position open, time ≥ 09:44:59
                if (
                    self.signal
                    and not self._rollover_done_today
                    and datetime.now().time() >= ROLLOVER_CHECK_TIME
                    and self._get_nearest_option_expiry() == date.today()
                ):
                    tick_result = self._get_latest_tbt_price(tbt_df)
                    if tick_result:
                        self._execute_rollover(tick_result[0], datafeed_handler, dry_run)

                # 5c: NEW BAR processing loop — evaluate each completed 15-min bar
                now_time = datetime.now().time()
                bar_df   = None
                for i, (start, end) in enumerate(BAR_BOUNDARIES):
                    if i <= self.last_processed_bar_idx:
                        continue
                    if now_time < end:
                        break  # This bar hasn't closed yet

                    if bar_df is None:
                        bar_df = self._resample_tbt_to_15min(tbt_df)
                        if bar_df.empty:
                            break

                    target_close_time = VALID_BAR_CLOSE_TIMES[i]
                    match = bar_df[bar_df["timestamp"].dt.time == target_close_time]
                    if match.empty:
                        continue

                    bar = match.iloc[-1].to_dict()
                    sig = self._on_bar_close(bar)
                    self.last_processed_bar_idx = i
                    self._write_bar_event(bar, i)

                    if sig is not None:
                        self._execute_signal(sig, datafeed_handler, dry_run)

                    # Overnight hedge: enter at 15:14:59, exit at 09:29:59.
                    if target_close_time == HEDGE_ENTRY_TIME:
                        self._execute_overnight_hedge_entry(bar, datafeed_handler, dry_run)
                    elif target_close_time == HEDGE_EXIT_TIME:
                        self._execute_overnight_hedge_exit(bar, datafeed_handler, dry_run)

                # 5d: Mark-to-market open positions
                if self.open_positions:
                    open_insts = [p.instrument for p in self.open_positions.values()]
                    try:
                        pos_ltps = self._fetch_multiple_ltp(datafeed_handler, open_insts)
                    except Exception as e:
                        self.log_warning(f"Failed to fetch LTPs for position update: {e}")
                        pos_ltps = {}
                    for opt_type, pos in list(self.open_positions.items()):
                        ltp_val = pos_ltps.get(pos.instrument.instrument_token)
                        if ltp_val is None:
                            continue
                        try:
                            self._sync_position_entry_fill(pos)
                            pos.last_price            = Decimal(str(ltp_val))
                            pos.last_price_updated_at = timezone.now()
                            if pos.position_type == "LONG":
                                pos.unrealized_pnl = (pos.last_price - pos.entry_price) * pos.quantity
                            else:
                                pos.unrealized_pnl = (pos.entry_price - pos.last_price) * pos.quantity
                            pos.save(update_fields=[
                                "entry_price", "strategy_metadata",
                                "last_price", "last_price_updated_at", "unrealized_pnl",
                            ])
                        except Exception as e:
                            self.log_warning(f"Failed to update position {opt_type}: {e}")

            except Exception as e:
                self.log_exception(f"Error in main loop: {e}")

            time.sleep(TBT_COPY_INTERVAL_SECS)

        self.is_running = False
        self.log_info("IndexMomLongShort completed.")

    # =========================================================================
    # ATM-IV POSITION SIZING
    # =========================================================================

    def _compute_quantity(
        self,
        spot: float,
        ce_ltp: Optional[float],
        pe_ltp: Optional[float],
        atm_strike: Decimal,
        expiry: date,
        lot_size: int,
    ) -> int:
        """
        Size the position from ATM IV (avg of CE+PE) and spot:
          daily_iv      = atm_iv / sqrt(252)
          expected_move = daily_iv × spot     (spot used as forward proxy, r=0)
          lots          = floor( DAILY_CAP / expected_move / lot_size )  (min 1)

        Falls back to 1 lot on any failure to avoid blocking entries.
        """
        try:
            ttm_days = max(compute_ttm(datetime.now(), expiry), 1e-6)
            K = float(atm_strike)
            ivs: list[float] = []
            if ce_ltp and ce_ltp > 0:
                iv = _solve_call_iv(spot, K, RISK_FREE_RATE, ttm_days, ce_ltp)
                if iv and not math.isnan(iv) and iv > 0:
                    ivs.append(iv)
            if pe_ltp and pe_ltp > 0:
                iv = _solve_put_iv(spot, K, RISK_FREE_RATE, ttm_days, pe_ltp)
                if iv and not math.isnan(iv) and iv > 0:
                    ivs.append(iv)
            if not ivs:
                self.log_warning("Sizing: no valid IVs solved — falling back to 1 lot.")
                return lot_size

            atm_iv      = sum(ivs) / len(ivs)
            if atm_iv < MIN_SANE_ATM_IV:
                self.log_error(
                    f"Sizing: atm_iv={atm_iv:.6f} < {MIN_SANE_ATM_IV} "
                    f"(IV solver clamp suspected) — falling back to 1 lot."
                )
                return lot_size
            daily_iv    = atm_iv / math.sqrt(TRADING_DAYS_YEAR)
            expected_mv = daily_iv * float(spot)
            if expected_mv <= 0:
                return lot_size
            total_lots = max(1, math.floor((DAILY_CAP / expected_mv) / lot_size))
            qty = total_lots * lot_size
            self.log_info(
                f"  Sizing: ttm={ttm_days:.4f} atm_iv={atm_iv:.4f} "
                f"daily_iv={daily_iv:.4f} exp_move={expected_mv:.2f} "
                f"cap={DAILY_CAP} → lots={total_lots} qty={qty}"
            )
            return qty
        except Exception as e:
            self.log_error(f"Sizing failed: {e} — falling back to 1 lot.")
            return lot_size

    # =========================================================================
    # SIGNAL → ORDER EXECUTION
    # =========================================================================

    def _execute_signal(self, signal: dict, datafeed_handler, dry_run: bool) -> None:
        """Route a bar-close signal to the appropriate execution path."""
        action = signal["action"]
        if action == "ENTER_LONG":
            self._execute_forward_entry(signal, "LONG", datafeed_handler, dry_run)
        elif action == "ENTER_SHORT":
            self._execute_naked_short_entry(signal, datafeed_handler, dry_run)
        elif action == "EXIT_LONG":
            self._execute_forward_exit(signal, datafeed_handler, dry_run, clear_signal=True)
        elif action == "EXIT_SHORT":
            self._execute_naked_short_exit(signal, datafeed_handler, dry_run, clear_signal=True)
        elif action == "REVERSE_TO_LONG":
            # Was short → close naked short, then enter long forward.
            self._execute_naked_short_exit(signal, datafeed_handler, dry_run, clear_signal=False)
            self._execute_forward_entry(signal, "LONG", datafeed_handler, dry_run)
        elif action == "REVERSE_TO_SHORT":
            # Was long → close long forward, then enter naked short.
            self._execute_forward_exit(signal, datafeed_handler, dry_run, clear_signal=False)
            self._execute_naked_short_entry(signal, datafeed_handler, dry_run)

    def _execute_forward_entry(
        self, signal: dict, direction: str, datafeed_handler, dry_run: bool
    ) -> None:
        """Place a synthetic long-forward entry: BUY ATM CE + SELL ATM PE."""
        spot_price = signal["spot_price"]

        expiry = self._resolve_expiry()
        if not expiry:
            self.log_error("Cannot resolve option expiry. Refusing to trade.")
            return

        ce_strikes = self._get_available_strikes(expiry, "CE")
        atm_strike = self._find_atm_strike(spot_price, ce_strikes)
        if atm_strike is None:
            self.log_error(
                f"No ATM strike found for spot={spot_price:.2f} expiry={expiry}"
            )
            return

        ce_inst = self._get_option_instrument(expiry, atm_strike, "CE")
        pe_inst = self._get_option_instrument(expiry, atm_strike, "PE")
        if not ce_inst or not pe_inst:
            self.log_error(
                f"ATM instruments not found: strike={atm_strike} expiry={expiry} "
                f"CE={'found' if ce_inst else 'MISSING'} "
                f"PE={'found' if pe_inst else 'MISSING'}"
            )
            return

        lot_size = ce_inst.lot_size
        ltps     = self._fetch_multiple_ltp(datafeed_handler, [ce_inst, pe_inst])
        ce_ltp   = ltps.get(ce_inst.instrument_token)
        pe_ltp   = ltps.get(pe_inst.instrument_token)

        quantity = self._compute_quantity(
            spot_price, ce_ltp, pe_ltp, atm_strike, expiry, lot_size,
        )

        self.log_info(
            f"ENTER_LONG (synthetic forward): spot={spot_price:.2f} "
            f"ATM={atm_strike} expiry={expiry} "
            f"CE_LTP={ce_ltp} PE_LTP={pe_ltp} qty={quantity}"
        )

        ce_side, pe_side       = "BUY", "SELL"
        ce_tag, pe_tag         = "IDXMA_LONG_CE_BUY", "IDXMA_LONG_PE_SELL"
        ce_pos_type, pe_pos_type = "LONG", "SHORT"

        ce_price = self._limit_price(ce_side, ce_ltp) if ce_ltp else None
        if ce_ltp is None:
            self.log_warning("CE LTP unavailable — placing MARKET order")
        success_ce, po_ce = self._place_order(
            ce_inst, ce_side, quantity, ce_price,
            order_intent="ENTRY", tag=ce_tag, dry_run=dry_run,
        )

        pe_price = self._limit_price(pe_side, pe_ltp) if pe_ltp else None
        if pe_ltp is None:
            self.log_warning("PE LTP unavailable — placing MARKET order")
        success_pe, po_pe = self._place_order(
            pe_inst, pe_side, quantity, pe_price,
            order_intent="ENTRY", tag=pe_tag, dry_run=dry_run,
        )

        common_meta = {
            "forward_direction": "LONG",
            "trade_kind":        "synthetic_forward",
            "atm_strike":        float(atm_strike),
            "expiry":            str(expiry),
            "spot_signal":       spot_price,
            "bb_mean":           signal.get("bb_mean"),
        }

        if success_ce:
            self.entry_ce = ce_inst
            self.open_positions["CE"] = StrategyPosition.objects.create(
                trade_id=f"IDXMA_{self.strategy_obj.id}_{uuid.uuid4().hex[:8]}",
                strategy=self.strategy_obj,
                instrument=ce_inst,
                position_type=ce_pos_type,
                status="OPEN",
                quantity=quantity,
                entry_price=Decimal(str(ce_ltp)) if ce_ltp else (ce_price or Decimal("0")),
                entry_time=timezone.now(),
                entry_parent_order=po_ce,
                last_price=Decimal(str(ce_ltp)) if ce_ltp else Decimal("0"),
                last_price_updated_at=timezone.now(),
                strategy_metadata={
                    "option_type":       "CE",
                    "ce_tradingsymbol":  ce_inst.tradingsymbol,
                    "pe_tradingsymbol":  pe_inst.tradingsymbol,
                    **common_meta,
                },
            )

        if success_pe:
            self.entry_pe = pe_inst
            self.open_positions["PE"] = StrategyPosition.objects.create(
                trade_id=f"IDXMA_{self.strategy_obj.id}_{uuid.uuid4().hex[:8]}",
                strategy=self.strategy_obj,
                instrument=pe_inst,
                position_type=pe_pos_type,
                status="OPEN",
                quantity=quantity,
                entry_price=Decimal(str(pe_ltp)) if pe_ltp else (pe_price or Decimal("0")),
                entry_time=timezone.now(),
                entry_parent_order=po_pe,
                last_price=Decimal(str(pe_ltp)) if pe_ltp else Decimal("0"),
                last_price_updated_at=timezone.now(),
                strategy_metadata={
                    "option_type":       "PE",
                    "ce_tradingsymbol":  ce_inst.tradingsymbol,
                    "pe_tradingsymbol":  pe_inst.tradingsymbol,
                    **common_meta,
                },
            )

        self.entry_price = spot_price
        self.entry_time  = timezone.now()

        if success_ce and success_pe:
            self.log_info(
                f"  LONG synthetic forward opened: ATM={atm_strike} "
                f"expiry={expiry} CE={ce_inst.tradingsymbol} "
                f"PE={pe_inst.tradingsymbol} lot={lot_size}"
            )
            self._write_entry_event(float(atm_strike), expiry, spot_price)
        else:
            self.log_error("=" * 20)
            self.log_error("  CRITICAL ALERT: PARTIAL ENTRY DETECTED!")
            self.log_error(
                f"  CE={'FILLED' if success_ce else 'FAILED'} | "
                f"PE={'FILLED' if success_pe else 'FAILED'}"
            )
            self.log_error("  YOU NOW HAVE NAKED DIRECTIONAL EXPOSURE. INTERVENE IMMEDIATELY!")
            self.log_error("=" * 20)

    def _execute_forward_exit(
        self,
        signal: dict,
        datafeed_handler,
        dry_run: bool,
        clear_signal: bool = True,
    ) -> None:
        """Exit a long synthetic forward by creating an opposing (short) forward at
        current ATM, SAME expiry as entry — forming a box spread that locks P&L until expiry.
        """
        exit_spot = signal["spot_price"]

        if not self.open_positions:
            self.log_error("No open positions to exit. Resetting state.")
            self._clear_position_state(clear_signal=clear_signal)
            return

        first_pos        = next(iter(self.open_positions.values()))
        entry_meta       = first_pos.strategy_metadata or {}
        entry_expiry_str = entry_meta.get("expiry")
        if not entry_expiry_str:
            self.log_error("No expiry in position metadata. Cannot create box spread.")
            return
        entry_expiry = date.fromisoformat(entry_expiry_str)
        entry_atm    = entry_meta.get("atm_strike")

        self.log_info(
            f"EXIT via box spread: entry_ATM={entry_atm} | "
            f"exit_spot={exit_spot:.2f} | expiry={entry_expiry}"
        )

        ce_strikes = self._get_available_strikes(entry_expiry, "CE")
        atm_strike = self._find_atm_strike(exit_spot, ce_strikes)
        if atm_strike is None:
            self.log_error(
                f"No ATM strike for exit: spot={exit_spot:.2f} expiry={entry_expiry}"
            )
            return

        ce_inst = self._get_option_instrument(entry_expiry, atm_strike, "CE")
        pe_inst = self._get_option_instrument(entry_expiry, atm_strike, "PE")
        if not ce_inst or not pe_inst:
            self.log_error(
                f"Exit instruments not found: strike={atm_strike} expiry={entry_expiry} "
                f"CE={'found' if ce_inst else 'MISSING'} "
                f"PE={'found' if pe_inst else 'MISSING'}"
            )
            return

        # Exit qty matches entry qty (read back per leg from DB).
        ce_qty = int(self.open_positions["CE"].quantity)
        pe_qty = int(self.open_positions["PE"].quantity)

        all_instruments = [ce_inst, pe_inst]
        for pos in self.open_positions.values():
            all_instruments.append(pos.instrument)
        ltps = self._fetch_multiple_ltp(datafeed_handler, all_instruments)

        ce_ltp = ltps.get(ce_inst.instrument_token)
        pe_ltp = ltps.get(pe_inst.instrument_token)

        # Long-forward exit is always a short-forward: SELL CE + BUY PE
        ce_side, pe_side = "SELL", "BUY"
        ce_tag,  pe_tag  = "IDXMA_BOX_CE_SELL", "IDXMA_BOX_PE_BUY"

        self.log_info(
            f"  Box SHORT forward: ATM={atm_strike} "
            f"CE_SELL PE_BUY | CE_LTP={ce_ltp} PE_LTP={pe_ltp} "
            f"qty=CE:{ce_qty}/PE:{pe_qty}"
        )

        ce_price = self._limit_price(ce_side, ce_ltp) if ce_ltp else None
        if ce_ltp is None:
            self.log_warning("Exit CE LTP unavailable — placing MARKET order")
        success_ce, po_ce = self._place_order(
            ce_inst, ce_side, ce_qty, ce_price,
            order_intent="BOX_EXIT", tag=ce_tag, dry_run=dry_run,
        )

        pe_price = self._limit_price(pe_side, pe_ltp) if pe_ltp else None
        if pe_ltp is None:
            self.log_warning("Exit PE LTP unavailable — placing MARKET order")
        success_pe, po_pe = self._place_order(
            pe_inst, pe_side, pe_qty, pe_price,
            order_intent="BOX_EXIT", tag=pe_tag, dry_run=dry_run,
        )

        if not success_ce and not success_pe:
            self.log_error(
                "  Both exit legs FAILED — position remains open!"
            )
            return

        if success_ce and success_pe:
            # Only main legs are exited here. HEDGE_xx (if present) is owned by
            # the overnight-hedge lifecycle and stays OPEN until 09:29:59.
            for opt_type in ("CE", "PE"):
                pos = self.open_positions.get(opt_type)
                if pos is None:
                    continue
                entry_inst = pos.instrument
                entry_ltp  = ltps.get(entry_inst.instrument_token) if entry_inst else None

                pos.status     = "CLOSED"
                pos.exit_price = Decimal(str(entry_ltp)) if entry_ltp else pos.entry_price
                pos.exit_time  = timezone.now()
                if opt_type == "CE" and po_ce:
                    pos.exit_parent_order = po_ce
                elif opt_type == "PE" and po_pe:
                    pos.exit_parent_order = po_pe

                meta = pos.strategy_metadata or {}
                meta["exit_type"]               = "BOX_SPREAD"
                meta["exit_atm_strike"]         = float(atm_strike)
                meta["exit_spot"]               = exit_spot
                meta["exit_ce_tradingsymbol"]   = ce_inst.tradingsymbol
                meta["exit_pe_tradingsymbol"]   = pe_inst.tradingsymbol
                pos.strategy_metadata = meta
                pos.save()

            self.log_info(
                f"  Box spread locked: entry_ATM={entry_atm} → exit_ATM={atm_strike} "
                f"| expiry={entry_expiry} | exit_spot={exit_spot:.2f}"
            )
        else:
            self.log_error("=" * 20)
            self.log_error("  CRITICAL ALERT: PARTIAL BOX EXIT DETECTED!")
            self.log_error(
                f"  CE={'EXITED' if success_ce else 'FAILED'} | "
                f"PE={'EXITED' if success_pe else 'FAILED'}"
            )
            self.log_error("  STRATEGY STATE IS BEING WIPED. THE ORPHANED LEG IS UNMANAGED!")
            self.log_error("  YOU MUST MANUALLY CLOSE THE REMAINING LEG IMMEDIATELY!")
            self.log_error("=" * 20)

        if success_ce or success_pe:
            self._write_box_exit_event(exit_spot, float(atm_strike))
        self._clear_position_state(clear_signal=clear_signal)

    def _execute_naked_short_entry(
        self, signal: dict, datafeed_handler, dry_run: bool
    ) -> None:
        """Place a single-leg naked short call entry: SELL ATM CE."""
        spot_price = signal["spot_price"]

        expiry = self._resolve_expiry()
        if not expiry:
            self.log_error("Cannot resolve option expiry. Refusing to trade.")
            return

        ce_strikes = self._get_available_strikes(expiry, "CE")
        atm_strike = self._find_atm_strike(spot_price, ce_strikes)
        if atm_strike is None:
            self.log_error(f"No ATM strike for spot={spot_price:.2f} expiry={expiry}")
            return

        ce_inst = self._get_option_instrument(expiry, atm_strike, "CE")
        if not ce_inst:
            self.log_error(f"ATM CE missing: strike={atm_strike} expiry={expiry}")
            return

        # Fetch matching ATM PE for IV-sizing only (not traded).
        pe_inst_for_iv = self._get_option_instrument(expiry, atm_strike, "PE")
        fetch_list = [ce_inst] + ([pe_inst_for_iv] if pe_inst_for_iv else [])

        lot_size = ce_inst.lot_size
        ltps     = self._fetch_multiple_ltp(datafeed_handler, fetch_list)
        ce_ltp   = ltps.get(ce_inst.instrument_token)
        pe_ltp_for_iv = (
            ltps.get(pe_inst_for_iv.instrument_token) if pe_inst_for_iv else None
        )

        quantity = self._compute_quantity(
            spot_price, ce_ltp, pe_ltp_for_iv, atm_strike, expiry, lot_size,
        )

        self.log_info(
            f"ENTER_SHORT (naked CE): spot={spot_price:.2f} ATM={atm_strike} "
            f"expiry={expiry} CE_LTP={ce_ltp} qty={quantity}"
        )

        ce_price = self._limit_price("SELL", ce_ltp) if ce_ltp else None
        if ce_ltp is None:
            self.log_warning("CE LTP unavailable — placing MARKET order")
        success_ce, po_ce = self._place_order(
            ce_inst, "SELL", quantity, ce_price,
            order_intent="ENTRY", tag="IDXMA_SHORT_CE_SELL", dry_run=dry_run,
        )

        if not success_ce:
            self.log_error("Naked short entry FAILED — no position opened.")
            return

        common_meta = {
            "forward_direction": "SHORT",
            "trade_kind":        "naked_short_call",
            "atm_strike":        float(atm_strike),
            "expiry":            str(expiry),
            "spot_signal":       spot_price,
            "bb_mean":           signal.get("bb_mean"),
        }

        self.entry_ce = ce_inst
        self.entry_pe = None
        self.open_positions["CE"] = StrategyPosition.objects.create(
            trade_id=f"IDXMA_{self.strategy_obj.id}_{uuid.uuid4().hex[:8]}",
            strategy=self.strategy_obj,
            instrument=ce_inst,
            position_type="SHORT",
            status="OPEN",
            quantity=quantity,
            entry_price=Decimal(str(ce_ltp)) if ce_ltp else (ce_price or Decimal("0")),
            entry_time=timezone.now(),
            entry_parent_order=po_ce,
            last_price=Decimal(str(ce_ltp)) if ce_ltp else Decimal("0"),
            last_price_updated_at=timezone.now(),
            strategy_metadata={
                "option_type":      "CE",
                "ce_tradingsymbol": ce_inst.tradingsymbol,
                **common_meta,
            },
        )

        self.entry_price = spot_price
        self.entry_time  = timezone.now()

        self._write_entry_event(float(atm_strike), expiry, spot_price)
        self.log_info(
            f"  SHORT naked call opened: ATM={atm_strike} expiry={expiry} "
            f"CE={ce_inst.tradingsymbol} lot={lot_size}"
        )

    def _execute_naked_short_exit(
        self,
        signal: dict,
        datafeed_handler,
        dry_run: bool,
        clear_signal: bool = True,
    ) -> None:
        """Buy back the original CE at the original strike to close a naked short call."""
        if "CE" not in self.open_positions:
            self.log_error("No naked-short CE position to exit.")
            if clear_signal:
                self.signal = ""
            return

        ce_pos  = self.open_positions["CE"]
        ce_inst = ce_pos.instrument
        ce_qty  = int(ce_pos.quantity)

        all_instruments = []
        for pos in self.open_positions.values():
            all_instruments.append(pos.instrument)

        ltps   = self._fetch_multiple_ltp(datafeed_handler, all_instruments)
        ce_ltp = ltps.get(ce_inst.instrument_token)

        ce_price = self._limit_price("BUY", ce_ltp) if ce_ltp else None
        if ce_ltp is None:
            self.log_warning("Exit CE LTP unavailable — placing MARKET order")

        success, po = self._place_order(
            ce_inst, "BUY", ce_qty, ce_price,
            order_intent="EXIT", tag="IDXMA_SHORT_CE_BUYBACK", dry_run=dry_run,
        )

        if not success:
            self.log_error("Naked short exit FAILED — position remains open.")
            return

        # HEDGE_CE (if present) is owned by the overnight-hedge lifecycle —
        # leave it open; it gets sold at HEDGE_EXIT_TIME on the next morning.

        ce_pos.status     = "CLOSED"
        ce_pos.exit_price = Decimal(str(ce_ltp)) if ce_ltp else ce_pos.entry_price
        ce_pos.exit_time  = timezone.now()
        ce_pos.exit_parent_order = po

        meta = ce_pos.strategy_metadata or {}
        meta["exit_type"] = "NAKED_BUYBACK"
        meta["exit_spot"] = signal.get("spot_price")
        ce_pos.strategy_metadata = meta
        ce_pos.save()

        self._write_naked_exit_event(
            float(meta.get("atm_strike", 0)),
            float(signal.get("spot_price", 0)),
        )
        self.log_info(
            f"  Naked short closed: strike={ce_inst.strike} "
            f"buyback_LTP={ce_ltp}"
        )
        self._clear_position_state(clear_signal=clear_signal)

    def _execute_rollover(
        self, spot_price: float, datafeed_handler, dry_run: bool
    ) -> None:
        """Roll position from CW to NW on expiry day.

        Phase 1: close current CW position (preserves self.signal).
        Phase 2: re-enter same direction at NW with current ATM.
        """
        if not self.open_positions or not self.signal:
            return

        direction = self.signal   # "long" or "short"

        first_pos = next(iter(self.open_positions.values()))
        entry_meta = first_pos.strategy_metadata or {}
        entry_expiry_str = entry_meta.get("expiry")
        if entry_expiry_str:
            entry_expiry = date.fromisoformat(entry_expiry_str)
            if entry_expiry != date.today():
                self.log_info(f"ROLLOVER SKIPPED: Position expiry {entry_expiry} > today. Already in NW.")
                self._rollover_done_today = True
                return

        self.log_info("=" * 60)
        self.log_info(f"ROLLOVER: {direction} | spot={spot_price:.2f}")
        self.log_info("=" * 60)

        fake_signal = {"spot_price": spot_price, "bb_mean": None}

        # Phase 1: close CW position WITHOUT clearing self.signal
        if direction == "long":
            self._execute_forward_exit(fake_signal, datafeed_handler, dry_run, clear_signal=False)
        else:
            self._execute_naked_short_exit(fake_signal, datafeed_handler, dry_run, clear_signal=False)

        # Phase 2: re-enter at NW with current ATM
        nw_signal = {"spot_price": spot_price, "bb_mean": None}
        if direction == "long":
            self._execute_forward_entry(nw_signal, "LONG", datafeed_handler, dry_run)
        else:
            self._execute_naked_short_entry(nw_signal, datafeed_handler, dry_run)

        self._rollover_done_today = True

        nw_expiry = self._resolve_expiry()
        if nw_expiry:
            nw_strikes = self._get_available_strikes(nw_expiry, "CE")
            nw_atm     = self._find_atm_strike(spot_price, nw_strikes)
            self._write_rollover_event(nw_expiry, float(nw_atm) if nw_atm else 0.0)
        self.log_info(f"ROLLOVER COMPLETE: {direction} → NW | spot={spot_price:.2f}")

    # =========================================================================
    # OVERNIGHT HEDGE
    # =========================================================================

    def _execute_overnight_hedge_entry(
        self, bar: dict, datafeed_handler, dry_run: bool
    ) -> None:
        """At HEDGE_ENTRY_TIME, buy a {HEDGE_OTM_PCT}% OTM hedge if a main
        position is open. Long → BUY OTM PE. Short → BUY OTM CE.
        Skips if a hedge is already open (idempotent against double-fire)."""
        if not self.signal or "CE" not in self.open_positions:
            return
        if "HEDGE_PE" in self.open_positions or "HEDGE_CE" in self.open_positions:
            self.log_info("Overnight hedge already open — skipping entry.")
            return

        spot      = float(bar["close"])
        direction = self.signal
        if direction == "long":
            h_type   = "PE"
            h_target = spot * (1 - HEDGE_OTM_PCT)
            h_key    = "HEDGE_PE"
            tag      = "IDXMA_LONG_HEDGE_BUY"
        else:
            h_type   = "CE"
            h_target = spot * (1 + HEDGE_OTM_PCT)
            h_key    = "HEDGE_CE"
            tag      = "IDXMA_SHORT_HEDGE_BUY"

        expiry = self._resolve_expiry()
        if not expiry:
            self.log_error("Overnight hedge: cannot resolve expiry — skipping.")
            return

        strikes  = self._get_available_strikes(expiry, h_type)
        h_strike = self._find_atm_strike(h_target, strikes)
        if h_strike is None:
            self.log_error(
                f"Overnight hedge: no strike near {h_target:.2f} "
                f"({h_type} {expiry}) — skipping."
            )
            return

        h_inst = self._get_option_instrument(expiry, h_strike, h_type)
        if not h_inst:
            self.log_error(
                f"Overnight hedge: instrument missing strike={h_strike} "
                f"{h_type} {expiry} — skipping."
            )
            return

        main_qty = int(self.open_positions["CE"].quantity)
        h_ltps   = self._fetch_multiple_ltp(datafeed_handler, [h_inst])
        h_ltp    = h_ltps.get(h_inst.instrument_token)
        h_price  = self._limit_price("BUY", h_ltp) if h_ltp else None
        if h_ltp is None:
            self.log_warning("Overnight hedge LTP unavailable — placing MARKET order")

        self.log_info(
            f"OVERNIGHT HEDGE ENTRY ({direction}): BUY {h_type} "
            f"strike={h_strike} expiry={expiry} qty={main_qty} ltp={h_ltp}"
        )

        success, po = self._place_order(
            h_inst, "BUY", main_qty, h_price,
            order_intent="ENTRY", tag=tag, dry_run=dry_run,
        )
        if not success:
            self.log_error(f"Overnight hedge entry FAILED ({tag}).")
            return

        self.open_positions[h_key] = StrategyPosition.objects.create(
            trade_id=f"IDXMA_{self.strategy_obj.id}_{uuid.uuid4().hex[:8]}",
            strategy=self.strategy_obj,
            instrument=h_inst,
            position_type="LONG",
            status="OPEN",
            quantity=main_qty,
            entry_price=Decimal(str(h_ltp)) if h_ltp else (h_price or Decimal("0")),
            entry_time=timezone.now(),
            entry_parent_order=po,
            last_price=Decimal(str(h_ltp)) if h_ltp else Decimal("0"),
            last_price_updated_at=timezone.now(),
            strategy_metadata={
                "option_type":     h_key,
                "trade_kind":      "overnight_hedge",
                "main_direction":  direction,
                "atm_strike":      float(h_strike),
                "expiry":          str(expiry),
                "spot_at_hedge":   spot,
            },
        )

    def _execute_overnight_hedge_exit(
        self, bar: dict, datafeed_handler, dry_run: bool
    ) -> None:
        """At HEDGE_EXIT_TIME, sell any open overnight hedge (HEDGE_PE / HEDGE_CE)."""
        h_keys = [k for k in ("HEDGE_PE", "HEDGE_CE") if k in self.open_positions]
        if not h_keys:
            return

        h_insts = [self.open_positions[k].instrument for k in h_keys]
        ltps    = self._fetch_multiple_ltp(datafeed_handler, h_insts)

        for h_key in h_keys:
            h_pos   = self.open_positions[h_key]
            h_inst  = h_pos.instrument
            h_qty   = int(h_pos.quantity)
            h_ltp   = ltps.get(h_inst.instrument_token)
            h_price = self._limit_price("SELL", h_ltp) if h_ltp else None
            if h_ltp is None:
                self.log_warning(f"Hedge exit LTP unavailable for {h_key} — MARKET order")

            tag = f"IDXMA_OVERNIGHT_HEDGE_{h_key.split('_')[1]}_SELL"
            self.log_info(
                f"OVERNIGHT HEDGE EXIT: SELL {h_key} {h_inst.tradingsymbol} "
                f"qty={h_qty} ltp={h_ltp}"
            )
            success, po = self._place_order(
                h_inst, "SELL", h_qty, h_price,
                order_intent="EXIT", tag=tag, dry_run=dry_run,
            )
            if not success:
                self.log_error(f"Overnight hedge exit FAILED for {h_key}.")
                continue

            h_pos.status            = "CLOSED"
            h_pos.exit_price        = Decimal(str(h_ltp)) if h_ltp else h_pos.entry_price
            h_pos.exit_time         = timezone.now()
            h_pos.exit_parent_order = po
            meta = h_pos.strategy_metadata or {}
            meta["exit_type"] = "OVERNIGHT_HEDGE_CLOSE"
            h_pos.strategy_metadata = meta
            h_pos.save()
            del self.open_positions[h_key]

    # =========================================================================
    # INTERNAL HELPERS
    # =========================================================================

    def _clear_position_state(self, clear_signal: bool = True) -> None:
        """Reset MAIN position tracking after a main-leg exit.

        Overnight hedges (HEDGE_PE / HEDGE_CE) live on a separate lifecycle
        (15:14:59 → next 09:29:59) and MUST survive intraday main exits, so
        we only pop the main keys here.
        """
        self.entry_ce    = None
        self.entry_pe    = None
        for k in ("CE", "PE"):
            self.open_positions.pop(k, None)
        self.entry_price = None
        self.entry_time  = None
        if clear_signal:
            self.signal = ""
