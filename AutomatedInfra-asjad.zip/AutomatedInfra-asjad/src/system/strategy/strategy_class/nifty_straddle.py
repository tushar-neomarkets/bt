"""
NIFTY Delta Hedged Short Straddle Strategy

This strategy:
1. Shorts ATM straddle on NIFTY at entry time
2. Monitors delta continuously
3. Delta hedges using forwards when threshold is breached:
   - Buy Forward (long bias): BUY ATM Call + SELL ATM Put
   - Sell Forward (short bias): BUY ATM Put + SELL ATM Call
4. Squares off all positions (straddle + forwards) at exit time

IMPORTANT: Matches backtest logic exactly by:
- Calculating forward prices from put-call parity
- Using forward (not futures) to determine ATM strike
- Computing greeks via Black-Scholes
"""
import time
import uuid
import math
from datetime import date, datetime, timedelta
from decimal import Decimal
from typing import Optional, Literal

from django.db.models import Min
from django.utils import timezone
from scipy.stats import norm

from strategy.strategy_class.base_strategy import BaseStrategy
from instruments.models import Instrument
from strategy.models import StrategyPosition
from orders.models import ParentOrder
from orders.order_manager import order_manager


class NiftyDeltaHedgedStraddle(BaseStrategy):
    """
    NIFTY short straddle with delta hedging via forwards.
    """

    # Delta threshold configuration
    DELTA_THRESHOLD = 0.4  # Trigger forward when |net_delta| > 0.4 (CUSTOM - adjust as needed)
    DELTA_CHECK_INTERVAL = 5  # Check delta every 5 seconds

    # Order configuration
    USE_MARKET_ORDERS = False  # Use MARKET orders for speed
    LIMIT_ORDER_OFFSET = Decimal("0.5")  # Offset for limit orders (not used if USE_MARKET_ORDERS=True)

    def __init__(self, strategy_obj, datafeed_obj, ws_manager=None):
        super().__init__(strategy_obj, datafeed_obj, ws_manager)
        self.strategy_obj = strategy_obj
        self.is_running = False

        # NIFTY instruments
        self.nifty_spot_instrument = None  # For reference (optional)
        self.nifty_future = None
        self.option_expiry = None
        self.atm_strike = None

        # Current ATM options
        self.atm_ce = None
        self.atm_pe = None

        # Position tracking
        self.straddle_ce_position: Optional[StrategyPosition] = None
        self.straddle_pe_position: Optional[StrategyPosition] = None


        self.forward_positions: list[dict] = []  # Each dict has {ce_pos, pe_pos, direction, created_at}

        # Order tracking
        self.straddle_entry_orders: list[ParentOrder] = []
        self.forward_entry_orders: list[ParentOrder] = []
        self.exit_orders: list[ParentOrder] = []

        # Greeks tracking
        self.current_net_delta = 0.0
        self.last_delta_check = None

        print(f"Initializing {self.strategy_obj.strategy_code} - {self.strategy_obj.strategy_name}")

    # =========================================================================
    # INSTRUMENT LOOKUP METHODS
    # =========================================================================

    def _get_nifty_future(self) -> Optional[Instrument]:
        """Get the nearest month NIFTY future."""
        today = date.today()

        future = Instrument.objects.filter(
            name='NIFTY',
            exchange='NFO',
            instrument_type='FUT',
            is_active=True,
            expiry__gte=today
        ).order_by('expiry').first()

        return future

    def _get_nifty_spot(self) -> Optional[Instrument]:
        """Get NIFTY spot index instrument (for reference)."""
        spot = Instrument.objects.filter(
            name='NIFTY',
            exchange='NSE',
            instrument_type='INDEX',
            is_active=True
        ).first()

        return spot

    def _get_nearest_option_expiry(self) -> Optional[date]:
        """Get the nearest NIFTY option expiry date."""
        today = date.today()

        result = Instrument.objects.filter(
            name='NIFTY',
            exchange='NFO',
            instrument_type__in=['CE', 'PE'],
            is_active=True,
            expiry__gte=today
        ).aggregate(min_expiry=Min('expiry'))

        return result.get('min_expiry')

    def _get_available_strikes(self, expiry: date) -> list[Decimal]:
        """Get all available strike prices for NIFTY on a given expiry."""
        strikes = Instrument.objects.filter(
            name='NIFTY',
            exchange='NFO',
            instrument_type__in=['CE', 'PE'],
            expiry=expiry,
            is_active=True
        ).values_list('strike', flat=True).distinct()

        return sorted([s for s in strikes if s is not None])

    def _find_closest_strike(self, price: float, available_strikes: list[Decimal]) -> Optional[Decimal]:
        """Find the strike price closest to the given price."""
        if not available_strikes:
            return None

        price_decimal = Decimal(str(price))
        return min(available_strikes, key=lambda s: abs(s - price_decimal))

    def _get_option_pair(
        self, expiry: date, strike: Decimal
    ) -> tuple[Optional[Instrument], Optional[Instrument]]:
        """Get CE and PE instruments for NIFTY at given expiry and strike."""
        ce = Instrument.objects.filter(
            name='NIFTY',
            exchange='NFO',
            instrument_type='CE',
            expiry=expiry,
            strike=strike,
            is_active=True
        ).first()

        pe = Instrument.objects.filter(
            name='NIFTY',
            exchange='NFO',
            instrument_type='PE',
            expiry=expiry,
            strike=strike,
            is_active=True
        ).first()

        return ce, pe

    # =========================================================================
    # TIME UTILITIES
    # =========================================================================

    def _get_today_datetime(self, time_obj) -> datetime:
        """Convert a time object to today's datetime in local timezone."""
        today = timezone.now().date()
        naive_dt = datetime.combine(today, time_obj)
        return timezone.make_aware(naive_dt)

    def _wait_until(self, target_time: datetime) -> bool:
        """
        Wait until target time, checking every second.
        Returns False if strategy was stopped during wait.
        """
        while self.is_running:
            now = timezone.now()
            if now >= target_time:
                return True

            remaining = (target_time - now).total_seconds()
            if remaining > 60:
                print(f"  Waiting... {int(remaining // 60)} minutes remaining until {target_time.strftime('%H:%M:%S')}")
                time.sleep(30)
            else:
                time.sleep(1)

        return False

    def _is_past_exit_time(self) -> bool:
        """Check if current time is past exit time."""
        exit_datetime = self._get_today_datetime(self.strategy_obj.exit_time)
        return timezone.now() >= exit_datetime

    # =========================================================================
    # BLACK-SCHOLES GREEKS CALCULATION
    # =========================================================================

    def _black_scholes_greeks(
        self,
        spot: float,
        strike: float,
        time_to_expiry: float,  # in years
        risk_free_rate: float,
        volatility: float,
        option_type: str  # 'CE' or 'PE'
    ) -> dict:
        """
        Calculate option greeks using Black-Scholes model.

        Returns:
            dict: {delta, gamma, theta, vega, price}
        """
        if time_to_expiry <= 0 or volatility <= 0:
            return {'delta': 0.0, 'gamma': 0.0, 'theta': 0.0, 'vega': 0.0, 'price': 0.0}

        try:
            # Black-Scholes parameters
            d1 = (math.log(spot / strike) + (risk_free_rate + 0.5 * volatility ** 2) * time_to_expiry) / \
                 (volatility * math.sqrt(time_to_expiry))
            d2 = d1 - volatility * math.sqrt(time_to_expiry)

            # Standard normal CDF and PDF
            nd1 = norm.cdf(d1)
            nd2 = norm.cdf(d2)
            nprime_d1 = norm.pdf(d1)

            # Calculate greeks
            if option_type == 'CE':
                # Call option
                delta = nd1
                price = spot * nd1 - strike * math.exp(-risk_free_rate * time_to_expiry) * nd2
            else:  # PE
                # Put option
                delta = nd1 - 1
                price = strike * math.exp(-risk_free_rate * time_to_expiry) * (1 - nd2) - spot * (1 - nd1)

            # Gamma (same for call and put)
            gamma = nprime_d1 / (spot * volatility * math.sqrt(time_to_expiry))

            # Vega (same for call and put) - in percentage points
            vega = spot * nprime_d1 * math.sqrt(time_to_expiry) / 100

            # Theta (per day)
            if option_type == 'CE':
                theta = (-spot * nprime_d1 * volatility / (2 * math.sqrt(time_to_expiry)) -
                        risk_free_rate * strike * math.exp(-risk_free_rate * time_to_expiry) * nd2) / 365
            else:
                theta = (-spot * nprime_d1 * volatility / (2 * math.sqrt(time_to_expiry)) +
                        risk_free_rate * strike * math.exp(-risk_free_rate * time_to_expiry) * (1 - nd2)) / 365

            return {
                'delta': delta,
                'gamma': gamma,
                'theta': theta,
                'vega': vega,
                'price': price
            }

        except Exception as e:
            print(f"Error calculating Black-Scholes greeks: {e}")
            return {'delta': 0.0, 'gamma': 0.0, 'theta': 0.0, 'vega': 0.0, 'price': 0.0}

    def _calculate_implied_volatility(
        self,
        market_price: float,
        spot: float,
        strike: float,
        time_to_expiry: float,
        risk_free_rate: float,
        option_type: str,
        initial_guess: float = 0.3
    ) -> float:
        """
        Calculate implied volatility using Newton-Raphson method.
        """
        if time_to_expiry <= 0 or market_price <= 0:
            return 0.0

        volatility = initial_guess
        max_iterations = 100
        tolerance = 1e-5

        for i in range(max_iterations):
            greeks = self._black_scholes_greeks(
                spot, strike, time_to_expiry, risk_free_rate, volatility, option_type
            )

            price_diff = greeks['price'] - market_price
            vega = greeks['vega'] * 100  # Convert back to full vega

            if abs(price_diff) < tolerance:
                return volatility

            if vega == 0:
                break

            # Newton-Raphson update
            volatility = volatility - price_diff / vega

            # Keep volatility positive and reasonable
            volatility = max(0.01, min(volatility, 3.0))

        return volatility

    # =========================================================================
    # FORWARD PRICE CALCULATION (PUT-CALL PARITY)
    # =========================================================================

    def _calculate_forward_from_options(
        self,
        datafeed_handler,
        expiry_date: date,
        strike: Decimal
    ) -> Optional[float]:
        """
        Calculate forward price using put-call parity:
        Forward = Strike + (Call_Price - Put_Price) / discount_factor

        For short-term options: Forward ≈ Strike + (Call_Price - Put_Price)

        Args:
            datafeed_handler: DataFeed handler
            expiry_date: Option expiry date
            strike: Strike price to use for calculation

        Returns:
            Forward price or None if calculation fails
        """
        # Get CE and PE at this strike
        ce, pe = self._get_option_pair(expiry_date, strike)

        if not ce or not pe:
            return None

        # Fetch LTPs
        ltps = self._fetch_multiple_ltp(datafeed_handler, [ce, pe])
        ce_price = ltps.get(ce.instrument_token)
        pe_price = ltps.get(pe.instrument_token)

        if not ce_price or not pe_price:
            return None

        # Calculate time to expiry
        now = timezone.now()
        tte_days = (datetime.combine(expiry_date, datetime.min.time()) - now).total_seconds() / 86400

        # Risk-free rate (approximate using 7% annual rate)
        risk_free_rate = 0.07
        discount_factor = math.exp(-risk_free_rate * (tte_days / 365))

        # Put-Call Parity: Forward = Strike + (Call - Put) / discount
        forward = float(strike) + (ce_price - pe_price) / discount_factor

        return forward

    def _calculate_forward_for_all_strikes(
        self,
        datafeed_handler,
        expiry_date: date,
        strikes: list[Decimal]
    ) -> Optional[float]:
        """
        Calculate forward using multiple strikes and take weighted average.
        More robust than single strike calculation.
        """
        forwards = []

        # Use middle 5 strikes for calculation (avoid deep ITM/OTM)
        mid_idx = len(strikes) // 2
        start_idx = max(0, mid_idx - 2)
        end_idx = min(len(strikes), mid_idx + 3)
        sample_strikes = strikes[start_idx:end_idx]

        for strike in sample_strikes:
            forward = self._calculate_forward_from_options(datafeed_handler, expiry_date, strike)
            if forward:
                forwards.append(forward)

        if not forwards:
            return None

        # Return median to avoid outliers
        forwards.sort()
        return forwards[len(forwards) // 2]

    # =========================================================================
    # ATM STRIKE CALCULATION (MATCHES BACKTEST EXACTLY)
    # =========================================================================

    def _calculate_atm_strike_from_forward(
        self,
        datafeed_handler,
        expiry_date: date,
        available_strikes: list[Decimal]
    ) -> Optional[Decimal]:
        """
        Calculate ATM strike using forward price, matching backtest logic:

        1. Calculate forward from put-call parity
        2. Find strike with minimum |strike - forward|

        This exactly matches the backtest ATM calculation.
        """
        # Calculate forward price
        forward = self._calculate_forward_for_all_strikes(
            datafeed_handler, expiry_date, available_strikes
        )

        if not forward:
            print("WARNING: Could not calculate forward, falling back to futures LTP")
            # Fallback to futures LTP
            future_ltps = self._fetch_multiple_ltp(datafeed_handler, [self.nifty_future])
            forward = future_ltps.get(self.nifty_future.instrument_token)

            if not forward:
                return None

        # Find strike with minimum absolute difference (matches backtest)
        atm_strike = min(
            available_strikes,
            key=lambda strike: abs(float(strike) - forward)
        )

        print(f"Forward: {forward:.2f}, ATM Strike: {atm_strike}")
        return atm_strike

    # =========================================================================
    # GREEKS CALCULATION FOR LIVE POSITIONS
    # =========================================================================

    def _calculate_position_greeks(
        self,
        datafeed_handler,
        positions: list[StrategyPosition]
    ) -> dict[int, dict]:
        """
        Calculate greeks for all positions using Black-Scholes.

        Returns:
            dict: {instrument_token: {delta, gamma, theta, vega, iv}}
        """
        result = {}

        if not positions:
            return result

        # Get current prices
        instruments = [pos.instrument for pos in positions]
        ltps = self._fetch_multiple_ltp(datafeed_handler, instruments)

        # Calculate forward (spot) for BS model
        forward = self._calculate_forward_for_all_strikes(
            datafeed_handler,
            self.option_expiry,
            self._get_available_strikes(self.option_expiry)
        )

        if not forward:
            print("WARNING: Cannot calculate greeks without forward price")
            return result

        # Risk-free rate
        risk_free_rate = 0.07

        for pos in positions:
            inst = pos.instrument
            market_price = ltps.get(inst.instrument_token)

            if not market_price or inst.instrument_type not in ['CE', 'PE']:
                continue

            # Calculate time to expiry in years
            now = timezone.now()
            expiry_dt = datetime.combine(inst.expiry, datetime.min.time())
            tte_seconds = (expiry_dt - now).total_seconds()
            tte_years = max(tte_seconds / (365 * 24 * 3600), 1/365)  # Minimum 1 day

            # Calculate IV from market price
            iv = self._calculate_implied_volatility(
                market_price=market_price,
                spot=forward,
                strike=float(inst.strike),
                time_to_expiry=tte_years,
                risk_free_rate=risk_free_rate,
                option_type=inst.instrument_type,
                initial_guess=0.15  # Start with 15% IV
            )

            # Calculate greeks using IV
            greeks = self._black_scholes_greeks(
                spot=forward,
                strike=float(inst.strike),
                time_to_expiry=tte_years,
                risk_free_rate=risk_free_rate,
                volatility=iv,
                option_type=inst.instrument_type
            )

            result[inst.instrument_token] = {
                'delta': greeks['delta'],
                'gamma': greeks['gamma'],
                'theta': greeks['theta'],
                'vega': greeks['vega'],
                'iv': iv
            }

        return result

    # =========================================================================
    # DATA FEED METHODS
    # =========================================================================

    def _fetch_multiple_ltp(
        self, datafeed_handler, instruments: list[Instrument]
    ) -> dict[int, float]:
        """Fetch LTP for multiple instruments."""
        result = {}
        if not instruments:
            return result

        try:
            response = datafeed_handler.get_multiple_ltp(instruments)
            if response and 'data' in response:
                ltp_list = response['data'].get('ltp_list', [])
                for ltp_data in ltp_list:
                    token = ltp_data.get('instrument_token')
                    ltp = ltp_data.get('ltp')
                    if token and ltp:
                        result[token] = ltp
        except Exception as e:
            print(f"Error fetching multiple LTP: {e}")
        return result

    def _update_atm_strike(self, datafeed_handler) -> bool:
        """Update ATM strike based on current forward price (matches backtest)."""
        available_strikes = self._get_available_strikes(self.option_expiry)
        if not available_strikes:
            print("ERROR: No strikes available")
            return False

        # Use forward-based ATM calculation (matches backtest exactly)
        new_atm_strike = self._calculate_atm_strike_from_forward(
            datafeed_handler, self.option_expiry, available_strikes
        )

        if not new_atm_strike:
            print("ERROR: Could not calculate ATM strike")
            return False

        # Update instruments if strike changed
        if new_atm_strike != self.atm_strike:
            self.atm_strike = new_atm_strike
            ce, pe = self._get_option_pair(self.option_expiry, self.atm_strike)

            if not ce or not pe:
                print(f"ERROR: Could not find option pair for strike {self.atm_strike}")
                return False

            self.atm_ce = ce
            self.atm_pe = pe
            print(f"Updated ATM strike to {self.atm_strike}")

        return True

    # =========================================================================
    # ORDER MANAGEMENT
    # =========================================================================

    def _place_order(
        self,
        instrument: Instrument,
        side: str,
        quantity: int,
        order_intent: str,
        price: Optional[Decimal] = None,
        metadata: Optional[dict] = None
    ) -> tuple[bool, Optional[ParentOrder]]:
        """
        Place an order via OrderManager.

        Args:
            instrument: Instrument to trade
            side: 'BUY' or 'SELL'
            quantity: Order quantity
            order_intent: 'ENTRY' or 'EXIT'
            price: Limit price (optional, uses MARKET if not provided or if USE_MARKET_ORDERS=True)
            metadata: Additional metadata

        Returns:
            tuple: (success, ParentOrder or None)
        """
        # Force MARKET order if USE_MARKET_ORDERS is True
        if self.USE_MARKET_ORDERS:
            order_type = 'MARKET'
            price = None
        else:
            order_type = 'LIMIT' if price else 'MARKET'

        base_metadata = {
            'strategy_code': self.strategy_obj.strategy_code,
            'instrument_type': instrument.instrument_type,
            'underlying': 'NIFTY'
        }
        if metadata:
            base_metadata.update(metadata)

        success, msg, parent_order, broker_orders = order_manager.create_and_execute_order(
            strategy=self.strategy_obj,
            instrument=instrument,
            side=side,
            quantity=quantity,
            order_type=order_type,
            product_type='NRML',
            price=price,
            order_intent=order_intent,
            metadata=base_metadata
        )

        if success:
            print(f"    ✓ {order_intent} order: {side} {quantity}x {instrument.tradingsymbol} @ {price or 'MARKET'}")
            return True, parent_order
        else:
            print(f"    ✗ {order_intent} order FAILED: {side} {instrument.tradingsymbol} - {msg}")
            return False, None

    # =========================================================================
    # POSITION MANAGEMENT - STRADDLE
    # =========================================================================

    def _generate_trade_id(self, prefix: str) -> str:
        """Generate unique trade ID."""
        timestamp = timezone.now().strftime('%Y%m%d%H%M%S')
        short_uuid = str(uuid.uuid4())[:8]
        return f"{self.strategy_obj.strategy_code}_{prefix}_{timestamp}_{short_uuid}"

    def _create_short_straddle(
        self,
        datafeed_handler,
        place_orders: bool = True
    ) -> bool:
        """
        Create short straddle position at ATM strike.

        Returns:
            bool: True if successful
        """
        print("\n" + "=" * 60)
        print("CREATING SHORT STRADDLE")
        print("=" * 60)

        if not self.atm_ce or not self.atm_pe:
            print("ERROR: ATM options not available")
            return False

        # Fetch current LTPs
        ltps = self._fetch_multiple_ltp(datafeed_handler, [self.atm_ce, self.atm_pe])
        ce_ltp = ltps.get(self.atm_ce.instrument_token)
        pe_ltp = ltps.get(self.atm_pe.instrument_token)

        if not ce_ltp or not pe_ltp:
            print("ERROR: Could not fetch option LTPs")
            return False

        print(f"ATM Strike: {self.atm_strike}")
        print(f"CE: {self.atm_ce.tradingsymbol} @ {ce_ltp:.2f}")
        print(f"PE: {self.atm_pe.tradingsymbol} @ {pe_ltp:.2f}")
        print(f"Total Premium: {ce_ltp + pe_ltp:.2f}")

        now = timezone.now()
        ce_parent_order = None
        pe_parent_order = None

        # Place orders if enabled
        if place_orders:
            print("\nPlacing SHORT straddle orders...")

            # SELL CE - MARKET order
            ce_success, ce_parent_order = self._place_order(
                instrument=self.atm_ce,
                side='SELL',
                quantity=self.atm_ce.lot_size,
                order_intent='ENTRY',
                price=None,  # MARKET order
                metadata={'leg': 'straddle_ce'}
            )

            # SELL PE - MARKET order
            pe_success, pe_parent_order = self._place_order(
                instrument=self.atm_pe,
                side='SELL',
                quantity=self.atm_pe.lot_size,
                order_intent='ENTRY',
                price=None,  # MARKET order
                metadata={'leg': 'straddle_pe'}
            )

            if not ce_success or not pe_success:
                print("WARNING: Some straddle orders failed")
                return False

        # Create CE position
        self.straddle_ce_position = StrategyPosition.objects.create(
            trade_id=self._generate_trade_id('STRADDLE_CE'),
            strategy=self.strategy_obj,
            instrument=self.atm_ce,
            position_type='SHORT',
            status='OPEN',
            quantity=self.atm_ce.lot_size,
            entry_price=Decimal(str(ce_ltp)),
            entry_time=now,
            entry_parent_order=ce_parent_order,
            last_price=Decimal(str(ce_ltp)),
            last_price_updated_at=now,
            strategy_metadata={
                'leg_type': 'straddle_ce',
                'strike': float(self.atm_strike),
                'expiry': str(self.option_expiry)
            }
        )

        # Create PE position
        self.straddle_pe_position = StrategyPosition.objects.create(
            trade_id=self._generate_trade_id('STRADDLE_PE'),
            strategy=self.strategy_obj,
            instrument=self.atm_pe,
            position_type='SHORT',
            status='OPEN',
            quantity=self.atm_pe.lot_size,
            entry_price=Decimal(str(pe_ltp)),
            entry_time=now,
            entry_parent_order=pe_parent_order,
            last_price=Decimal(str(pe_ltp)),
            last_price_updated_at=now,
            strategy_metadata={
                'leg_type': 'straddle_pe',
                'strike': float(self.atm_strike),
                'expiry': str(self.option_expiry)
            }
        )

        # Track entry orders
        if ce_parent_order:
            self.straddle_entry_orders.append(ce_parent_order)
        if pe_parent_order:
            self.straddle_entry_orders.append(pe_parent_order)

        print(f"\n✓ Short straddle created successfully")
        return True

    # =========================================================================
    # POSITION MANAGEMENT - FORWARD (DELTA HEDGE)
    # =========================================================================

    def _create_forward(
        self,
        direction: Literal['BUY', 'SELL'],
        datafeed_handler,
        place_orders: bool = True
    ) -> bool:
        """
        Create forward position to hedge delta.

        BUY Forward (bullish hedge): BUY CE + SELL PE
        SELL Forward (bearish hedge): BUY PE + SELL CE

        Args:
            direction: 'BUY' or 'SELL' forward
            datafeed_handler: DataFeed handler
            place_orders: Whether to place actual orders

        Returns:
            bool: Success status
        """
        print(f"\n{'='*60}")
        print(f"CREATING {direction} FORWARD (Delta Hedge)")
        print(f"{'='*60}")

        # Fetch current LTPs
        ltps = self._fetch_multiple_ltp(datafeed_handler, [self.atm_ce, self.atm_pe])
        ce_ltp = ltps.get(self.atm_ce.instrument_token)
        pe_ltp = ltps.get(self.atm_pe.instrument_token)

        if not ce_ltp or not pe_ltp:
            print("ERROR: Could not fetch option LTPs")
            return False

        now = timezone.now()
        ce_parent_order = None
        pe_parent_order = None

        if direction == 'BUY':
            # BUY Forward: BUY CE + SELL PE
            print(f"Strategy: BUY CE @ {ce_ltp:.2f}, SELL PE @ {pe_ltp:.2f}")
            print(f"Net Debit: {ce_ltp - pe_ltp:.2f}")

            if place_orders:
                # BUY CE - MARKET order
                ce_success, ce_parent_order = self._place_order(
                    instrument=self.atm_ce,
                    side='BUY',
                    quantity=self.atm_ce.lot_size,
                    order_intent='ENTRY',
                    price=None,  # MARKET order
                    metadata={'leg': 'forward_ce', 'forward_direction': 'BUY'}
                )

                # SELL PE - MARKET order
                pe_success, pe_parent_order = self._place_order(
                    instrument=self.atm_pe,
                    side='SELL',
                    quantity=self.atm_pe.lot_size,
                    order_intent='ENTRY',
                    price=None,  # MARKET order
                    metadata={'leg': 'forward_pe', 'forward_direction': 'BUY'}
                )

                if not ce_success or not pe_success:
                    print("WARNING: Some forward orders failed")
                    return False

            # Create positions
            ce_position = StrategyPosition.objects.create(
                trade_id=self._generate_trade_id('FORWARD_CE'),
                strategy=self.strategy_obj,
                instrument=self.atm_ce,
                position_type='LONG',
                status='OPEN',
                quantity=self.atm_ce.lot_size,
                entry_price=Decimal(str(ce_ltp)),
                entry_time=now,
                entry_parent_order=ce_parent_order,
                last_price=Decimal(str(ce_ltp)),
                last_price_updated_at=now,
                strategy_metadata={
                    'leg_type': 'forward_ce',
                    'forward_direction': 'BUY',
                    'strike': float(self.atm_strike),
                    'expiry': str(self.option_expiry)
                }
            )

            pe_position = StrategyPosition.objects.create(
                trade_id=self._generate_trade_id('FORWARD_PE'),
                strategy=self.strategy_obj,
                instrument=self.atm_pe,
                position_type='SHORT',
                status='OPEN',
                quantity=self.atm_pe.lot_size,
                entry_price=Decimal(str(pe_ltp)),
                entry_time=now,
                entry_parent_order=pe_parent_order,
                last_price=Decimal(str(pe_ltp)),
                last_price_updated_at=now,
                strategy_metadata={
                    'leg_type': 'forward_pe',
                    'forward_direction': 'BUY',
                    'strike': float(self.atm_strike),
                    'expiry': str(self.option_expiry)
                }
            )

        else:  # SELL forward
            # SELL Forward: BUY PE + SELL CE
            print(f"Strategy: BUY PE @ {pe_ltp:.2f}, SELL CE @ {ce_ltp:.2f}")
            print(f"Net Debit: {pe_ltp - ce_ltp:.2f}")

            if place_orders:
                # BUY PE - MARKET order
                pe_success, pe_parent_order = self._place_order(
                    instrument=self.atm_pe,
                    side='BUY',
                    quantity=self.atm_pe.lot_size,
                    order_intent='ENTRY',
                    price=None,  # MARKET order
                    metadata={'leg': 'forward_pe', 'forward_direction': 'SELL'}
                )

                # SELL CE - MARKET order
                ce_success, ce_parent_order = self._place_order(
                    instrument=self.atm_ce,
                    side='SELL',
                    quantity=self.atm_ce.lot_size,
                    order_intent='ENTRY',
                    price=None,  # MARKET order
                    metadata={'leg': 'forward_ce', 'forward_direction': 'SELL'}
                )

                if not ce_success or not pe_success:
                    print("WARNING: Some forward orders failed")
                    return False

            # Create positions
            pe_position = StrategyPosition.objects.create(
                trade_id=self._generate_trade_id('FORWARD_PE'),
                strategy=self.strategy_obj,
                instrument=self.atm_pe,
                position_type='LONG',
                status='OPEN',
                quantity=self.atm_pe.lot_size,
                entry_price=Decimal(str(pe_ltp)),
                entry_time=now,
                entry_parent_order=pe_parent_order,
                last_price=Decimal(str(pe_ltp)),
                last_price_updated_at=now,
                strategy_metadata={
                    'leg_type': 'forward_pe',
                    'forward_direction': 'SELL',
                    'strike': float(self.atm_strike),
                    'expiry': str(self.option_expiry)
                }
            )

            ce_position = StrategyPosition.objects.create(
                trade_id=self._generate_trade_id('FORWARD_CE'),
                strategy=self.strategy_obj,
                instrument=self.atm_ce,
                position_type='SHORT',
                status='OPEN',
                quantity=self.atm_ce.lot_size,
                entry_price=Decimal(str(ce_ltp)),
                entry_time=now,
                entry_parent_order=ce_parent_order,
                last_price=Decimal(str(ce_ltp)),
                last_price_updated_at=now,
                strategy_metadata={
                    'leg_type': 'forward_ce',
                    'forward_direction': 'SELL',
                    'strike': float(self.atm_strike),
                    'expiry': str(self.option_expiry)
                }
            )

        # Track forward
        forward_dict = {
            'ce_pos': ce_position,
            'pe_pos': pe_position,
            'direction': direction,
            'created_at': now,
            'entry_orders': [o for o in [ce_parent_order, pe_parent_order] if o]
        }
        self.forward_positions.append(forward_dict)

        if ce_parent_order or pe_parent_order:
            self.forward_entry_orders.extend([o for o in [ce_parent_order, pe_parent_order] if o])

        print(f"✓ {direction} forward created successfully")
        return True

    # =========================================================================
    # DELTA CALCULATION & HEDGING
    # =========================================================================

    def _calculate_net_delta(self, datafeed_handler) -> float:
        """
        Calculate net portfolio delta from all open positions.
        Uses Black-Scholes calculated greeks (matches backtest methodology).

        Returns:
            float: Net delta value
        """
        # Collect all option positions
        all_positions = []

        if self.straddle_ce_position and self.straddle_ce_position.status == 'OPEN':
            all_positions.append(self.straddle_ce_position)
        if self.straddle_pe_position and self.straddle_pe_position.status == 'OPEN':
            all_positions.append(self.straddle_pe_position)

        for forward in self.forward_positions:
            if forward['ce_pos'].status == 'OPEN':
                all_positions.append(forward['ce_pos'])
            if forward['pe_pos'].status == 'OPEN':
                all_positions.append(forward['pe_pos'])

        if not all_positions:
            return 0.0

        # Calculate greeks using Black-Scholes
        greeks = self._calculate_position_greeks(datafeed_handler, all_positions)

        # Calculate weighted delta
        net_delta = 0.0

        for pos in all_positions:
            inst_greeks = greeks.get(pos.instrument.instrument_token, {})
            delta = inst_greeks.get('delta', 0.0)

            # Adjust delta sign based on position type
            if pos.position_type == 'SHORT':
                delta = -delta

            # Weight by quantity (lot size)
            position_delta = delta * pos.quantity
            net_delta += position_delta

            # Debug print
            side = "SHORT" if pos.position_type == 'SHORT' else "LONG"
            print(f"  {pos.instrument.tradingsymbol} ({side}): delta={delta:.3f}, qty={pos.quantity}, contrib={position_delta:.3f}")

        return net_delta

    def _check_and_hedge_delta(self, datafeed_handler, place_orders: bool = True) -> None:
        """
        Check net delta and create forward if threshold is breached.
        """
        net_delta = self._calculate_net_delta(datafeed_handler)
        self.current_net_delta = net_delta
        self.last_delta_check = timezone.now()

        print(f"\nDelta Check [{self.last_delta_check.strftime('%H:%M:%S')}]: Net Delta = {net_delta:.3f}")

        # Check if hedging needed
        if abs(net_delta) > self.DELTA_THRESHOLD:
            # Determine hedge direction
            if net_delta > self.DELTA_THRESHOLD:
                # Portfolio is too long (positive delta) -> need to SELL forward (bearish)
                hedge_direction = 'SELL'
                print(f"⚠️  Net delta {net_delta:.3f} exceeds +{self.DELTA_THRESHOLD} → Creating SELL forward")
            else:
                # Portfolio is too short (negative delta) -> need to BUY forward (bullish)
                hedge_direction = 'BUY'
                print(f"⚠️  Net delta {net_delta:.3f} below -{self.DELTA_THRESHOLD} → Creating BUY forward")

            # Create forward to hedge
            self._create_forward(hedge_direction, datafeed_handler, place_orders=place_orders)
        else:
            print(f"✓ Delta within threshold (±{self.DELTA_THRESHOLD})")

    # =========================================================================
    # PNL TRACKING
    # =========================================================================

    def _calculate_position_pnl(self, position: StrategyPosition, current_ltp: float) -> float:
        """Calculate unrealized PNL for a position."""
        if not position.entry_price:
            return 0.0

        entry = float(position.entry_price)
        qty = position.quantity

        if position.position_type == 'LONG':
            return (current_ltp - entry) * qty
        else:  # SHORT
            return (entry - current_ltp) * qty

    def _update_all_positions_pnl(self, datafeed_handler) -> dict:
        """
        Update LTP and PNL for all positions.

        Returns:
            dict: PNL breakdown
        """
        # Collect all positions
        all_positions = []

        if self.straddle_ce_position and self.straddle_ce_position.status == 'OPEN':
            all_positions.append(self.straddle_ce_position)
        if self.straddle_pe_position and self.straddle_pe_position.status == 'OPEN':
            all_positions.append(self.straddle_pe_position)

        for forward in self.forward_positions:
            if forward['ce_pos'].status == 'OPEN':
                all_positions.append(forward['ce_pos'])
            if forward['pe_pos'].status == 'OPEN':
                all_positions.append(forward['pe_pos'])

        if not all_positions:
            return {}

        # Fetch LTPs
        instruments = [pos.instrument for pos in all_positions]
        ltps = self._fetch_multiple_ltp(datafeed_handler, instruments)
        now = timezone.now()

        # Update positions
        straddle_pnl = 0.0
        forward_pnl = 0.0

        for pos in all_positions:
            ltp = ltps.get(pos.instrument.instrument_token)
            if ltp is None:
                continue

            # Update position
            pos.last_price = Decimal(str(ltp))
            pos.last_price_updated_at = now
            pnl = self._calculate_position_pnl(pos, ltp)
            pos.unrealized_pnl = Decimal(str(pnl))
            pos.save(update_fields=['last_price', 'last_price_updated_at', 'unrealized_pnl'])

            # Categorize PNL
            leg_type = pos.strategy_metadata.get('leg_type', '')
            if 'straddle' in leg_type:
                straddle_pnl += pnl
            else:
                forward_pnl += pnl

        return {
            'straddle_pnl': straddle_pnl,
            'forward_pnl': forward_pnl,
            'total_pnl': straddle_pnl + forward_pnl,
            'net_delta': self.current_net_delta
        }

    # =========================================================================
    # EXIT & CLEANUP
    # =========================================================================

    def _close_all_positions(self, datafeed_handler, place_orders: bool = True) -> None:
        """Close all open positions (straddle + forwards)."""
        print("\n" + "=" * 60)
        print("CLOSING ALL POSITIONS")
        print("=" * 60)

        # Collect all open positions
        all_positions = []

        if self.straddle_ce_position and self.straddle_ce_position.status == 'OPEN':
            all_positions.append(self.straddle_ce_position)
        if self.straddle_pe_position and self.straddle_pe_position.status == 'OPEN':
            all_positions.append(self.straddle_pe_position)

        for forward in self.forward_positions:
            if forward['ce_pos'].status == 'OPEN':
                all_positions.append(forward['ce_pos'])
            if forward['pe_pos'].status == 'OPEN':
                all_positions.append(forward['pe_pos'])

        if not all_positions:
            print("No open positions to close.")
            return

        # Fetch current LTPs
        instruments = [pos.instrument for pos in all_positions]
        ltps = self._fetch_multiple_ltp(datafeed_handler, instruments)
        now = timezone.now()

        total_realized_pnl = 0.0

        print("\nClosing positions:")
        for pos in all_positions:
            ltp = ltps.get(pos.instrument.instrument_token)
            if ltp is None:
                print(f"  WARNING: No LTP for {pos.instrument.tradingsymbol}")
                continue

            # Determine exit side (opposite of entry)
            exit_side = 'SELL' if pos.position_type == 'LONG' else 'BUY'

            # Use MARKET orders for exit
            exit_price = Decimal(str(ltp))

            # Place exit order - MARKET
            exit_parent_order = None
            if place_orders:
                exit_success, exit_parent_order = self._place_order(
                    instrument=pos.instrument,
                    side=exit_side,
                    quantity=pos.quantity,
                    order_intent='EXIT',
                    price=None,  # MARKET order
                    metadata={'leg': pos.strategy_metadata.get('leg_type', 'unknown')}
                )

                if exit_parent_order:
                    self.exit_orders.append(exit_parent_order)

            # Calculate PNL
            pnl = self._calculate_position_pnl(pos, ltp)
            total_realized_pnl += pnl

            # Update position
            pos.exit_price = exit_price
            pos.exit_time = now
            pos.exit_parent_order = exit_parent_order
            pos.realized_pnl = Decimal(str(pnl))
            pos.unrealized_pnl = Decimal('0.00')
            pos.status = 'CLOSED'
            pos.save(update_fields=[
                'exit_price', 'exit_time', 'exit_parent_order',
                'realized_pnl', 'unrealized_pnl', 'status', 'updated_at'
            ])

            leg_type = pos.strategy_metadata.get('leg_type', 'unknown')
            print(f"  {leg_type}: {exit_side} {pos.instrument.tradingsymbol} @ MARKET (LTP: {ltp}) | PNL: {pnl:+.2f}")

        print(f"\n{'='*60}")
        print(f"TOTAL REALIZED PNL: {total_realized_pnl:+.2f}")
        print(f"{'='*60}")

        self._print_order_summary()

    def _print_order_summary(self) -> None:
        """Print summary of all orders."""
        print("\n" + "=" * 60)
        print("ORDER SUMMARY")
        print("=" * 60)

        if self.straddle_entry_orders:
            print("\nStraddle Entry Orders:")
            for order in self.straddle_entry_orders:
                summary = order_manager.get_parent_order_summary(order)
                print(f"  PO#{order.order_id}: {order.side} {order.quantity}x {order.instrument.tradingsymbol}")
                print(f"    Status: {order.status} | Broker Orders: {summary['completed']}/{summary['total_broker_orders']}")

        if self.forward_entry_orders:
            print(f"\nForward Entry Orders ({len(self.forward_entry_orders)} total):")
            for order in self.forward_entry_orders:
                summary = order_manager.get_parent_order_summary(order)
                print(f"  PO#{order.order_id}: {order.side} {order.quantity}x {order.instrument.tradingsymbol}")
                print(f"    Status: {order.status} | Broker Orders: {summary['completed']}/{summary['total_broker_orders']}")

        if self.exit_orders:
            print(f"\nExit Orders ({len(self.exit_orders)} total):")
            for order in self.exit_orders:
                summary = order_manager.get_parent_order_summary(order)
                print(f"  PO#{order.order_id}: {order.side} {order.quantity}x {order.instrument.tradingsymbol}")
                print(f"    Status: {order.status} | Broker Orders: {summary['completed']}/{summary['total_broker_orders']}")

        print("=" * 60)

    # =========================================================================
    # VERIFICATION
    # =========================================================================

    def verify(self) -> bool:
        """Verify prerequisites."""
        print("\n" + "=" * 60)
        print("VERIFICATION: Checking NIFTY instruments")
        print("=" * 60)

        if not self.datafeed_obj:
            print("ERROR: No datafeed object")
            return False

        if self.datafeed_obj.is_token_expired:
            print("WARNING: Datafeed token expired, refreshing...")
            from datafeed.rest.handler import DataFeedHandler
            handler = DataFeedHandler(self.datafeed_obj)
            if not handler.update_token():
                print("ERROR: Failed to refresh token")
                return False
            print("SUCCESS: Token refreshed")

        # Get NIFTY future
        self.nifty_future = self._get_nifty_future()
        if not self.nifty_future:
            print("ERROR: NIFTY future not found")
            return False
        print(f"✓ NIFTY Future: {self.nifty_future.tradingsymbol}")

        # Get option expiry
        self.option_expiry = self._get_nearest_option_expiry()
        if not self.option_expiry:
            print("ERROR: NIFTY option expiry not found")
            return False
        print(f"✓ Option Expiry: {self.option_expiry}")

        # Update ATM strike
        from datafeed.rest.handler import DataFeedHandler
        handler = DataFeedHandler(self.datafeed_obj)

        if not self._update_atm_strike(handler):
            print("ERROR: Could not determine ATM strike")
            return False
        print(f"✓ ATM Strike: {self.atm_strike}")
        print(f"  CE: {self.atm_ce.tradingsymbol}")
        print(f"  PE: {self.atm_pe.tradingsymbol}")

        print("\nVerification passed!")
        return True

    # =========================================================================
    # BOOTSTRAP FROM DB
    # =========================================================================

    def _bootstrap_from_db(self) -> bool:
        """
        Load existing OPEN positions from DB if strategy was restarted.

        Returns:
            bool: True if found existing positions (recovery mode)
        """
        open_positions = StrategyPosition.objects.filter(
            strategy=self.strategy_obj,
            status='OPEN'
        ).select_related('instrument')

        if not open_positions.exists():
            self.log_info("No existing open positions. Fresh run.")
            return False

        self.log_warning(
            f"Found {open_positions.count()} OPEN positions. "
            f"Resuming in RECOVERY mode (no new entries)."
        )

        # Categorize positions
        for pos in open_positions:
            leg_type = pos.strategy_metadata.get('leg_type', '')

            if leg_type == 'straddle_ce':
                self.straddle_ce_position = pos
            elif leg_type == 'straddle_pe':
                self.straddle_pe_position = pos
            elif 'forward' in leg_type:
                # Find matching forward pair
                forward_dir = pos.strategy_metadata.get('forward_direction')

                # Try to find existing forward dict with matching direction
                found = False
                for fwd in self.forward_positions:
                    if fwd['direction'] == forward_dir:
                        if leg_type == 'forward_ce':
                            fwd['ce_pos'] = pos
                        else:
                            fwd['pe_pos'] = pos
                        found = True
                        break

                if not found:
                    # Create new forward dict
                    new_fwd = {
                        'direction': forward_dir,
                        'created_at': pos.entry_time,
                        'entry_orders': []
                    }
                    if leg_type == 'forward_ce':
                        new_fwd['ce_pos'] = pos
                        new_fwd['pe_pos'] = None
                    else:
                        new_fwd['ce_pos'] = None
                        new_fwd['pe_pos'] = pos

                    self.forward_positions.append(new_fwd)

        return True

    # =========================================================================
    # MAIN RUN LOOP
    # =========================================================================

    def run(self, place_orders: bool = True):
        """
        Main execution loop.

        Args:
            place_orders: If True, place actual orders
        """
        print(f"\n{'='*60}")
        print(f"Starting {self.strategy_obj.strategy_name}")
        print(f"Entry Time: {self.strategy_obj.entry_time}")
        print(f"Exit Time: {self.strategy_obj.exit_time}")
        print(f"Delta Threshold: ±{self.DELTA_THRESHOLD} (CUSTOM - adjust in code)")
        print(f"Delta Check Interval: {self.DELTA_CHECK_INTERVAL}s")
        print(f"Order Type: {'MARKET' if self.USE_MARKET_ORDERS else 'LIMIT'}")
        print(f"Order Execution: {'ENABLED' if place_orders else 'DISABLED'}")
        print(f"{'='*60}\n")

        # Verify
        if not self.verify():
            print("Verification failed. Exiting.")
            return

        self.is_running = True

        from datafeed.rest.handler import DataFeedHandler
        datafeed_handler = DataFeedHandler(self.datafeed_obj)

        # Check for existing positions (recovery mode)
        resume_only = self._bootstrap_from_db()

        entry_datetime = self._get_today_datetime(self.strategy_obj.entry_time)
        exit_datetime = self._get_today_datetime(self.strategy_obj.exit_time)

        # =====================================================================
        # PHASE 1: Wait for entry time
        # =====================================================================
        print(f"\nWaiting for entry time: {entry_datetime.strftime('%H:%M:%S')}")

        if not self._wait_until(entry_datetime):
            print("Stopped while waiting.")
            return

        if not self.is_running:
            return

        # =====================================================================
        # PHASE 2: Entry (if fresh run)
        # =====================================================================
        if not resume_only:
            # Update ATM strike at entry time
            self._update_atm_strike(datafeed_handler)

            # Create short straddle
            if not self._create_short_straddle(datafeed_handler, place_orders=place_orders):
                print("Failed to create straddle. Exiting.")
                self.is_running = False
                return

            print("\n✓ Straddle entry completed")
        else:
            self.log_warning("Skipping entry phase (recovery mode)")

        # =====================================================================
        # PHASE 3: Monitor delta & PNL
        # =====================================================================
        print("\n" + "=" * 60)
        print("MONITORING PHASE - Delta hedging + PNL tracking")
        print(f"Exit scheduled at: {exit_datetime.strftime('%H:%M:%S')}")
        print("=" * 60)

        last_pnl_print = timezone.now()
        pnl_print_interval = 60  # Print PNL every 60 seconds

        while self.is_running:
            # Check exit time
            if self._is_past_exit_time():
                print("\n>>> EXIT TIME REACHED <<<")
                break

            current_time = timezone.now()

            # Check delta (every DELTA_CHECK_INTERVAL seconds)
            if not self.last_delta_check or \
               (current_time - self.last_delta_check).total_seconds() >= self.DELTA_CHECK_INTERVAL:
                self._check_and_hedge_delta(datafeed_handler, place_orders=place_orders)

            # Print PNL (every pnl_print_interval seconds)
            if (current_time - last_pnl_print).total_seconds() >= pnl_print_interval:
                pnl_data = self._update_all_positions_pnl(datafeed_handler)

                timestamp = current_time.strftime('%H:%M:%S')
                print(f"\n[{timestamp}] Portfolio Status:")
                print("-" * 60)
                print(f"Straddle PNL:   {pnl_data.get('straddle_pnl', 0):+12.2f}")
                print(f"Forward PNL:    {pnl_data.get('forward_pnl', 0):+12.2f}")
                print(f"{'─'*60}")
                print(f"TOTAL PNL:      {pnl_data.get('total_pnl', 0):+12.2f}")
                print(f"Net Delta:      {pnl_data.get('net_delta', 0):+12.3f}")
                print("-" * 60)

                # Time to exit
                remaining = (exit_datetime - current_time).total_seconds()
                if remaining > 0:
                    print(f"Time to exit: {int(remaining // 60)} min {int(remaining % 60)} sec")

                last_pnl_print = current_time

            # Sleep briefly
            time.sleep(5)

        # =====================================================================
        # PHASE 4: Exit
        # =====================================================================
        if self.is_running:
            self._close_all_positions(datafeed_handler, place_orders=place_orders)

        self.is_running = False
        print(f"\n{self.strategy_obj.strategy_name} completed.")

    def stop(self):
        """Stop strategy gracefully."""
        print(f"\nStopping {self.strategy_obj.strategy_name}...")
        self.is_running = False

    # =========================================================================
    # EXTERNAL API
    # =========================================================================

    def get_current_status(self) -> dict:
        """Get current strategy status (for external monitoring)."""
        if not self.datafeed_obj:
            return {}

        from datafeed.rest.handler import DataFeedHandler
        handler = DataFeedHandler(self.datafeed_obj)

        pnl_data = self._update_all_positions_pnl(handler)

        return {
            'is_running': self.is_running,
            'has_straddle': bool(self.straddle_ce_position and self.straddle_pe_position),
            'num_forwards': len(self.forward_positions),
            'pnl': pnl_data,
            'atm_strike': float(self.atm_strike) if self.atm_strike else None,
            'last_delta_check': self.last_delta_check.isoformat() if self.last_delta_check else None
        }