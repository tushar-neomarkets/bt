"""
Vol Long Short Strategy

This strategy:
1. Waits for entry time
2. Calls business logic to get X long and Y short straddle trades
3. Creates positions in DB for each straddle (CE + PE)
4. Places orders via OrderManager
5. Tracks and prints PNL every minute
6. At exit time, squares off all positions and exits
"""
import csv
import os
import time
import uuid
from datetime import date, datetime, timedelta
from decimal import Decimal
from typing import Optional

from django.db.models import Min
from django.utils import timezone

from strategy.strategy_class.base_strategy import BaseStrategy
from instruments.models import Instrument
from strategy.models import StrategyPosition
from orders.models import ParentOrder
from orders.order_manager import order_manager
from strategy.strategy_class.vol_utils import (
    calculate_ttm,
    compute_straddle_iv,
    compute_z_score,
    load_welford_states,
    rank_stocks_by_zscore,
    welford_std,
)


_BASE_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
WELFORD_STATE_PATH = os.path.join(_BASE_DIR, 'dump', 'vol', 'initial_state.csv')

VOL_DUMP_DIR = os.path.join(_BASE_DIR, 'dump', 'vol')
VOL_EVENTS_DIR = os.path.join(VOL_DUMP_DIR, 'events')
VOL_ZSCORES_DIR = os.path.join(VOL_DUMP_DIR, 'zscores')

EVENT_CSV_COLUMNS = [
    'timestamp', 'event', 'stock', 'direction', 'leg',
    'instrument_token', 'tradingsymbol', 'expiry', 'strike',
    'entry_ltp', 'exit_ltp', 'exit_reason',
    'realized_pnl', 'trade_id', 'note',
]

ZSCORE_CSV_COLUMNS = [
    'timestamp', 'stock', 'expiry', 'future_ltp', 'strike',
    'ce_ltp', 'ce_bid', 'ce_ask', 'pe_ltp', 'pe_bid', 'pe_ask',
    'ttm', 'straddle_iv',
    'welford_n', 'welford_mean', 'welford_std',
    'zscore', 'rank', 'pick',
]

STOCKS_TO_CONSIDER = [
    "ADANIENT",
    "ADANIPORTS",
    "APOLLOHOSP",
    "ASIANPAINT",
    "AXISBANK",
    "BAJAJ-AUTO",
    "BAJFINANCE",
    "BAJAJFINSV",
    "BEL",
    "BHARTIARTL",
    "CIPLA",
    "COALINDIA",
    "DRREDDY",
    "EICHERMOT",
    "ETERNAL",
    "GRASIM",
    "HCLTECH",
    "HDFCBANK",
    "HDFCLIFE",
    "HINDALCO",
    "HINDUNILVR",
    "ICICIBANK",
    "ITC",
    "INFY",
    "INDIGO",
    "JSWSTEEL",
    "JIOFIN",
    "KOTAKBANK",
    "LT",
    "M&M",
    "MARUTI",
    "MAXHEALTH",
    "NTPC",
    "NESTLEIND",
    "ONGC",
    "POWERGRID",
    "RELIANCE",
    "SBILIFE",
    "SHRIRAMFIN",
    "SBIN",
    "SUNPHARMA",
    "TCS",
    "TATACONSUM",
    "TMPV",
    "TATASTEEL",
    "TECHM",
    "TITAN",
    "TRENT",
    "ULTRACEMCO",
    "WIPRO"
]


class VolLongShort(BaseStrategy):
    """
    Strategy that trades long/short straddles based on business logic signals.
    Integrates with OrderManager to place actual broker orders.
    """

    def __init__(self, strategy_obj, datafeed_obj, ws_manager=None):
        super().__init__(strategy_obj, datafeed_obj, ws_manager)
        self.strategy_obj = strategy_obj
        self.is_running = False

        # Stock -> Future instrument mapping
        self.futures: dict[str, Instrument] = {}
        # Stock -> (CE instrument, PE instrument) mapping
        self.options: dict[str, tuple[Instrument, Instrument]] = {}
        # Stock -> option expiry date
        self.option_expiries: dict[str, date] = {}
        # Stocks that passed verification
        self.active_stocks: list[str] = []

        # Position tracking
        # Stock -> list of StrategyPosition objects (CE and PE)
        self.open_positions: dict[str, list[StrategyPosition]] = {}
        # Track straddle direction per stock: 'LONG' or 'SHORT'
        self.straddle_directions: dict[str, str] = {}

        # Order tracking
        # Stock -> list of ParentOrder objects (entry orders)
        self.entry_orders: dict[str, list[ParentOrder]] = {}
        # Stock -> list of ParentOrder objects (exit orders)
        self.exit_orders: dict[str, list[ParentOrder]] = {}

        self.log_info(
            f"[BOOT] Initializing {self.strategy_obj.strategy_code} — {self.strategy_obj.strategy_name}"
        )

    # =========================================================================
    # BUSINESS LOGIC PLACEHOLDER
    # =========================================================================

    def _get_trading_signals(self, datafeed_handler) -> tuple[list[str], list[str]]:
        """
        Gather market data for active stocks and filter by liquidity.
        Returns lists of stocks for long and short straddles.

        Steps:
        1. Find nearest option expiry for each active stock
        2. Fetch futures LTP for all stocks in a single call
        3. Find closest ATM strike based on futures LTP
        4. Fetch ATM straddle quotes (bid/ask/LTP) in a single call
        5. Filter stocks where both CE and PE have volume > 0
        6. Print summary table of remaining stocks

        Args:
            datafeed_handler: DataFeedHandler instance for market data calls

        Returns:
            tuple: (long_stocks, short_stocks)
                - long_stocks: List of stock names to go LONG straddle
                - short_stocks: List of stock names to go SHORT straddle
        """
        # Step 1: Find nearest expiry (already populated by verify())
        # self.option_expiries[stock] has the nearest expiry for each stock in self.active_stocks

        # Step 2: Fetch futures LTP for all active stocks at once
        self.log_info(f"[SIGNALS] Fetching futures LTP for {len(self.active_stocks)} stocks...")
        future_instruments = [self.futures[stock] for stock in self.active_stocks]
        future_ltps = self._fetch_multiple_ltp(datafeed_handler, future_instruments)

        # Build a mapping: stock -> futures LTP
        stock_future_ltp: dict[str, float] = {}
        for stock in self.active_stocks:
            future = self.futures[stock]
            ltp = future_ltps.get(future.instrument_token)
            if ltp:
                stock_future_ltp[stock] = ltp

        missing_fut = [s for s in self.active_stocks if s not in stock_future_ltp]
        self.log_info(
            f"[SIGNALS] Futures LTP resolved: {len(stock_future_ltp)}/{len(self.active_stocks)}"
        )
        if missing_fut:
            self.log_warning(f"[SIGNALS] Missing futures LTP for: {', '.join(missing_fut)}")

        # Step 3: Find closest ATM strike and option pairs for each stock
        all_option_instruments: list[Instrument] = []
        # Track which stocks we successfully found option pairs for
        stock_option_map: dict[str, dict] = {}  # stock -> {expiry, strike, ce, pe}

        for stock, fut_ltp in stock_future_ltp.items():
            expiry = self.option_expiries[stock]
            available_strikes = self._get_available_strikes(stock, expiry)
            if not available_strikes:
                continue

            atm_strike = self._find_closest_strike(fut_ltp, available_strikes)
            if not atm_strike:
                continue

            ce, pe = self._get_option_pair(stock, expiry, atm_strike)
            if not ce or not pe:
                continue

            stock_option_map[stock] = {
                'expiry': expiry,
                'strike': atm_strike,
                'ce': ce,
                'pe': pe,
                'future_ltp': fut_ltp,
            }
            all_option_instruments.extend([ce, pe])

        self.log_info(
            f"[SIGNALS] ATM option pairs resolved: {len(stock_option_map)}/{len(stock_future_ltp)}"
        )

        if not all_option_instruments:
            self.log_warning("[SIGNALS] No option instruments to quote. Returning empty signals.")
            return [], []

        # Step 4: Fetch ATM straddle touchline (LTP/bid/ask/volume) in a single call
        self.log_info(f"[SIGNALS] Fetching touchline for {len(all_option_instruments)} options...")
        quote_by_token: dict[int, dict] = {}
        try:
            self.datafeed_obj.refresh_from_db()
            from datafeed.rest.handler import DataFeedHandler
            datafeed_handler = DataFeedHandler(self.datafeed_obj)
            response = datafeed_handler.get_multiple_touchline(all_option_instruments)
            if response and 'data' in response:
                quote_list = response['data'].get('quote_list', [])
                for quote in quote_list:
                    token = quote.get('instrument_token')
                    if token:
                        quote_by_token[token] = quote
        except Exception as e:
            self.log_error(f"[SIGNALS] Error fetching option quotes: {e}")
            return [], []

        self.log_info(
            f"[SIGNALS] Quotes received: {len(quote_by_token)}/{len(all_option_instruments)}"
        )
        self.log_debug(f"[SIGNALS] Raw quote dump: {quote_by_token}")

        # Step 5: Filter stocks where both CE and PE have volume > 0
        valid_stocks: list[str] = []
        rejected_no_quote = 0
        rejected_no_volume = 0

        for stock, info in stock_option_map.items():
            ce_quote = quote_by_token.get(info['ce'].instrument_token)
            pe_quote = quote_by_token.get(info['pe'].instrument_token)

            if not ce_quote or not pe_quote:
                rejected_no_quote += 1
                continue

            ce_volume = ce_quote.get('volume', 0)
            pe_volume = pe_quote.get('volume', 0)

            if ce_volume > 0 and pe_volume > 0:
                valid_stocks.append(stock)
                # Populate self.options for downstream use (entry phase)
                self.options[stock] = (info['ce'], info['pe'])
                # Enrich info with quote data for printing
                info['ce_ltp'] = ce_quote.get('ltp', 0)
                info['pe_ltp'] = pe_quote.get('ltp', 0)
                info['ce_bid'] = ce_quote.get('best_bid_price', 0)
                info['ce_ask'] = ce_quote.get('best_ask_price', 0)
                info['pe_bid'] = pe_quote.get('best_bid_price', 0)
                info['pe_ask'] = pe_quote.get('best_ask_price', 0)
                info['ce_volume'] = ce_volume
                info['pe_volume'] = pe_volume
            else:
                rejected_no_volume += 1

        self.log_info(
            f"[SIGNALS] Liquidity filter: {len(valid_stocks)} passed "
            f"(rejected: no_quote={rejected_no_quote}, zero_volume={rejected_no_volume})"
        )

        # Step 6: Detailed chain snapshot for valid stocks
        chain_table = [
            "-" * 130,
            f"{'Stock':<12} {'Fut LTP':<10} {'Strike':<10} {'Expiry':<12} "
            f"{'CE LTP':<9} {'CE Bid':<9} {'CE Ask':<9} {'CE Vol':<9} "
            f"{'PE LTP':<9} {'PE Bid':<9} {'PE Ask':<9} {'PE Vol':<9}",
            "-" * 130,
        ]
        for stock in valid_stocks:
            info = stock_option_map[stock]
            chain_table.append(
                f"{stock:<12} {info['future_ltp']:<10.2f} {float(info['strike']):<10.2f} "
                f"{str(info['expiry']):<12} "
                f"{info['ce_ltp']:<9.2f} {info['ce_bid']:<9.2f} {info['ce_ask']:<9.2f} "
                f"{info['ce_volume']:<9} "
                f"{info['pe_ltp']:<9.2f} {info['pe_bid']:<9.2f} {info['pe_ask']:<9.2f} "
                f"{info['pe_volume']:<9}"
            )
        chain_table.append("-" * 130)
        self.log_info("[SIGNALS] Valid chain snapshot:\n" + "\n".join(chain_table))

        # Step 7: Compute straddle IV and z-scores
        self.log_info("[SIGNALS] Computing straddle IV + z-scores (Welford snapshot)...")
        now = datetime.now()
        zscores: dict[str, float] = {}
        iv_values: dict[str, float] = {}

        # Load Welford state (read-only snapshot)
        try:
            welford_states = load_welford_states(WELFORD_STATE_PATH)
        except Exception as e:
            self.log_error(f"[SIGNALS] Failed to load Welford state from {WELFORD_STATE_PATH}: {e}")
            return [], []

        skipped_iv = 0
        skipped_no_welford = 0
        for stock in valid_stocks:
            info = stock_option_map[stock]
            expiry = info['expiry']
            ttm = calculate_ttm(expiry, now)
            future_ltp = info['future_ltp']
            strike = float(info['strike'])
            ce_ltp = info['ce_ltp']
            pe_ltp = info['pe_ltp']

            straddle_iv = compute_straddle_iv(future_ltp, strike, ttm, ce_ltp, pe_ltp)
            if straddle_iv <= 0:
                skipped_iv += 1
                continue

            iv_values[stock] = straddle_iv

            if stock not in welford_states:
                skipped_no_welford += 1
                continue

            z, _ = compute_z_score(straddle_iv, welford_states[stock])
            zscores[stock] = z

        self.log_info(
            f"[SIGNALS] Z-scores computed: {len(zscores)} "
            f"(skipped: iv_invalid={skipped_iv}, no_welford={skipped_no_welford})"
        )

        # Full z-score table (sorted cheap → rich)
        z_table = [
            "-" * 70,
            f"{'Stock':<12} {'Straddle IV':<14} {'Mean':<10} {'Std':<10} {'Z-Score':<10}",
            "-" * 70,
        ]
        for stock in sorted(zscores, key=lambda s: zscores[s]):
            ws = welford_states[stock]
            std = welford_std(ws)
            z_table.append(
                f"{stock:<12} {iv_values[stock]:<14.4f} {ws.mean:<10.4f} "
                f"{std:<10.4f} {zscores[stock]:<+10.4f}"
            )
        z_table.append("-" * 70)
        self.log_info("[SIGNALS] Full z-score table:\n" + "\n".join(z_table))
        self._dump_zscores_csv(valid_stocks, stock_option_map, iv_values, welford_states, zscores, [], [])

        if len(zscores) < 10:
            self.log_warning(
                f"[SIGNALS] Only {len(zscores)} stocks with valid z-scores (need >=10). "
                f"Aborting ranking — returning empty signals."
            )
            return [], []

        long_stocks, short_stocks = rank_stocks_by_zscore(zscores, 5, 5)
        self._write_picks_event(long_stocks, short_stocks, zscores)

        # Consolidated picks summary: bottom 5 (LONG) + top 5 (SHORT) with z-scores
        picks_lines = [
            "=" * 70,
            "[SIGNALS] === FINAL PICKS ===",
            f"{'LONG  (cheap IV — bottom 5)':<35} | {'SHORT (rich IV — top 5)':<35}",
            "-" * 70,
        ]
        for i in range(max(len(long_stocks), len(short_stocks))):
            long_part = ""
            short_part = ""
            if i < len(long_stocks):
                s = long_stocks[i]
                long_part = f"{s:<10} z={zscores[s]:+.4f} IV={iv_values[s]:.4f}"
            if i < len(short_stocks):
                s = short_stocks[i]
                short_part = f"{s:<10} z={zscores[s]:+.4f} IV={iv_values[s]:.4f}"
            picks_lines.append(f"{long_part:<35} | {short_part:<35}")
        picks_lines.append("=" * 70)
        self.log_info("\n" + "\n".join(picks_lines))

        return long_stocks, short_stocks

    # =========================================================================
    # INSTRUMENT LOOKUP METHODS
    # =========================================================================

    def _get_nearest_future(self, stock_name: str) -> Optional[Instrument]:
        """Get the nearest month future instrument for a stock."""
        today = date.today()

        future = Instrument.objects.filter(
            name=stock_name,
            exchange='NFO',
            instrument_type='FUT',
            is_active=True,
            expiry__gte=today
        ).order_by('expiry').first()

        return future

    def _get_nearest_option_expiry(self, stock_name: str) -> Optional[date]:
        """Get the nearest option expiry date for a stock."""
        today = date.today()

        result = Instrument.objects.filter(
            name=stock_name,
            exchange='NFO',
            instrument_type__in=['CE', 'PE'],
            is_active=True,
            expiry__gte=today
        ).aggregate(min_expiry=Min('expiry'))

        return result.get('min_expiry')

    def _get_available_strikes(self, stock_name: str, expiry: date) -> list[Decimal]:
        """Get all available strike prices for a stock on a given expiry."""
        strikes = Instrument.objects.filter(
            name=stock_name,
            exchange='NFO',
            instrument_type__in=['CE', 'PE'],
            expiry=expiry,
            is_active=True
        ).values_list('strike', flat=True).distinct()

        return sorted([s for s in strikes if s is not None])

    def _find_closest_strike(self, price: float, available_strikes: list[Decimal]) -> Optional[Decimal]:
        """Find the strike price closest to the given price."""
        if not available_strikes:
            return None

        price_decimal = Decimal(str(price))
        return min(available_strikes, key=lambda s: abs(s - price_decimal))

    def _get_option_pair(
        self, stock_name: str, expiry: date, strike: Decimal
    ) -> tuple[Optional[Instrument], Optional[Instrument]]:
        """Get CE and PE instruments for a given stock, expiry, and strike."""
        ce = Instrument.objects.filter(
            name=stock_name,
            exchange='NFO',
            instrument_type='CE',
            expiry=expiry,
            strike=strike,
            is_active=True
        ).first()

        pe = Instrument.objects.filter(
            name=stock_name,
            exchange='NFO',
            instrument_type='PE',
            expiry=expiry,
            strike=strike,
            is_active=True
        ).first()

        return ce, pe

    # =========================================================================
    # TIME UTILITIES
    # =========================================================================

    def _get_today_datetime(self, time_obj) -> datetime:
        """Convert a time object to today's datetime in local timezone."""
        today = timezone.now().date()
        naive_dt = datetime.combine(today, time_obj)
        return timezone.make_aware(naive_dt)

    def _wait_until(self, target_time: datetime) -> bool:
        """
        Wait until target time, checking every second.
        Returns False if strategy was stopped during wait.
        """
        while self.is_running:
            now = timezone.now()
            if now >= target_time:
                return True

            remaining = (target_time - now).total_seconds()
            if remaining > 60:
                self.log_info(
                    f"[WAIT] {int(remaining // 60)}m {int(remaining % 60)}s "
                    f"until {target_time.strftime('%H:%M:%S')}"
                )
                time.sleep(30)
            else:
                time.sleep(1)

        return False

    def _is_past_exit_time(self) -> bool:
        """Check if current time is past exit time."""
        exit_datetime = self._get_today_datetime(self.strategy_obj.exit_time)
        return timezone.now() >= exit_datetime

    # =========================================================================
    # DATA FEED METHODS
    # =========================================================================

    def _fetch_multiple_ltp(
        self, datafeed_handler, instruments: list[Instrument]
    ) -> dict[int, float]:
        """Fetch LTP for multiple instruments."""
        result = {}
        if not instruments:
            return result

        try:
            self.datafeed_obj.refresh_from_db()
            from datafeed.rest.handler import DataFeedHandler
            datafeed_handler = DataFeedHandler(self.datafeed_obj)
            response = datafeed_handler.get_multiple_ltp(instruments)
            if response and 'data' in response:
                ltp_list = response['data'].get('ltp_list', [])
                for ltp_data in ltp_list:
                    token = ltp_data.get('instrument_token')
                    ltp = ltp_data.get('ltp')
                    if token and ltp:
                        result[token] = ltp
        except Exception as e:
            self.log_error(f"Error fetching multiple LTP for {len(instruments)} instruments: {e}")
        return result

    def _update_atm_options(self, datafeed_handler) -> None:
        """Update ATM options for all active stocks based on current future prices."""
        future_instruments = [self.futures[stock] for stock in self.active_stocks]
        future_ltps = self._fetch_multiple_ltp(datafeed_handler, future_instruments)

        for stock in self.active_stocks:
            future = self.futures[stock]
            future_ltp = future_ltps.get(future.instrument_token)

            if not future_ltp:
                continue

            expiry = self.option_expiries[stock]
            available_strikes = self._get_available_strikes(stock, expiry)

            if not available_strikes:
                continue

            atm_strike = self._find_closest_strike(future_ltp, available_strikes)
            if not atm_strike:
                continue

            ce, pe = self._get_option_pair(stock, expiry, atm_strike)

            if ce and pe:
                self.options[stock] = (ce, pe)

    # =========================================================================
    # ORDER MANAGEMENT
    # =========================================================================

    def _place_entry_order(
        self,
        instrument: Instrument,
        side: str,
        quantity: int,
        price: Optional[Decimal] = None
    ) -> tuple[bool, Optional[ParentOrder]]:
        """
        Place an entry order via OrderManager.

        Args:
            instrument: Instrument to trade
            side: 'BUY' or 'SELL'
            quantity: Order quantity
            price: Limit price (optional, uses MARKET if not provided)

        Returns:
            tuple: (success, ParentOrder or None)
        """
        order_type = 'LIMIT' if price else 'MARKET'

        success, msg, parent_order, broker_orders = order_manager.create_and_execute_order(
            strategy=self.strategy_obj,
            instrument=instrument,
            side=side,
            quantity=quantity,
            order_type=order_type,
            product_type='NRML',
            price=price,
            order_intent='ENTRY',
            metadata={
                'strategy_code': self.strategy_obj.strategy_code,
                'instrument_type': instrument.instrument_type,
                'stock_name': instrument.name
            }
        )

        if success:
            price_str = f"{price}" if price else "MKT"
            self.log_info(
                f"[ENTRY] Order placed: {side} {quantity}x "
                f"{instrument.tradingsymbol} @ {price_str}"
            )
            return True, parent_order
        else:
            self.log_error(
                f"[ENTRY] Order FAILED: {side} {instrument.tradingsymbol} — {msg}"
            )
            return False, None

    def _place_exit_order(
        self,
        instrument: Instrument,
        side: str,
        quantity: int,
        price: Optional[Decimal] = None
    ) -> tuple[bool, Optional[ParentOrder]]:
        """
        Place an exit order via OrderManager.

        Args:
            instrument: Instrument to trade
            side: 'BUY' or 'SELL' (opposite of entry)
            quantity: Order quantity
            price: Limit price (optional, uses MARKET if not provided)

        Returns:
            tuple: (success, ParentOrder or None)
        """
        order_type = 'LIMIT' if price else 'MARKET'

        success, msg, parent_order, broker_orders = order_manager.create_and_execute_order(
            strategy=self.strategy_obj,
            instrument=instrument,
            side=side,
            quantity=quantity,
            order_type=order_type,
            product_type='NRML',
            price=price,
            order_intent='EXIT',
            metadata={
                'strategy_code': self.strategy_obj.strategy_code,
                'instrument_type': instrument.instrument_type,
                'stock_name': instrument.name
            }
        )

        if success:
            price_str = f"{price}" if price else "MKT"
            self.log_info(
                f"[EXIT] Order placed: {side} {quantity}x "
                f"{instrument.tradingsymbol} @ {price_str}"
            )
            return True, parent_order
        else:
            self.log_error(
                f"[EXIT] Order FAILED: {side} {instrument.tradingsymbol} — {msg}"
            )
            return False, None

    # =========================================================================
    # CSV STATE PERSISTENCE
    # =========================================================================

    def _get_event_csv_path(self) -> str:
        """Return today's event log CSV path."""
        code = self.strategy_obj.strategy_code.lower()
        return os.path.join(VOL_EVENTS_DIR, f"{code}_{date.today().strftime('%Y%m%d')}.csv")

    def _get_zscore_csv_path(self) -> str:
        """Return today's z-score dump CSV path."""
        code = self.strategy_obj.strategy_code.lower()
        return os.path.join(VOL_ZSCORES_DIR, f"{code}_{date.today().strftime('%Y%m%d')}.csv")

    def _append_csv_event(self, event: str, **kwargs) -> None:
        """Append a single event row to today's event CSV. Best-effort, never raises."""
        try:
            csv_path = self._get_event_csv_path()
            os.makedirs(os.path.dirname(csv_path), exist_ok=True)
            file_exists = os.path.isfile(csv_path)

            row = {col: '' for col in EVENT_CSV_COLUMNS}
            row['timestamp'] = datetime.now().isoformat()
            row['event'] = event
            row.update({k: v for k, v in kwargs.items() if k in EVENT_CSV_COLUMNS})

            with open(csv_path, 'a', newline='') as f:
                writer = csv.DictWriter(f, fieldnames=EVENT_CSV_COLUMNS)
                if not file_exists:
                    writer.writeheader()
                writer.writerow(row)
        except Exception as e:
            self.log_warning(f"[CSV] Failed to write event '{event}': {e}")

    def _write_boot_event(self, mode: str) -> None:
        """Write BOOT event on strategy start. mode in {'FRESH', 'RESUME'}."""
        self._append_csv_event('BOOT', note=f'mode={mode}')

    def _write_picks_event(self, long_stocks: list[str], short_stocks: list[str], zscores: dict) -> None:
        """Write one PICKS row per selected stock with direction and z-score."""
        for stock in long_stocks:
            self._append_csv_event(
                'PICKS', stock=stock, direction='LONG',
                note=f'zscore={zscores.get(stock, 0):.4f}',
            )
        for stock in short_stocks:
            self._append_csv_event(
                'PICKS', stock=stock, direction='SHORT',
                note=f'zscore={zscores.get(stock, 0):.4f}',
            )

    def _write_entry_event(self, stock: str, direction: str, pos: StrategyPosition, entry_ltp: float) -> None:
        """Write ENTRY event for a single option leg after position creation."""
        self._append_csv_event(
            'ENTRY',
            stock=stock,
            direction=direction,
            leg=pos.instrument.instrument_type,
            instrument_token=pos.instrument.instrument_token,
            tradingsymbol=pos.instrument.tradingsymbol,
            expiry=str(pos.instrument.expiry),
            strike=float(pos.instrument.strike),
            entry_ltp=entry_ltp,
            trade_id=pos.trade_id,
        )

    def _write_exit_event(self, stock: str, pos: StrategyPosition, exit_ltp: float, reason: str, realized_pnl: float) -> None:
        """Write EXIT event for a single option leg after position close."""
        self._append_csv_event(
            'EXIT',
            stock=stock,
            leg=pos.instrument.instrument_type,
            instrument_token=pos.instrument.instrument_token,
            tradingsymbol=pos.instrument.tradingsymbol,
            expiry=str(pos.instrument.expiry),
            strike=float(pos.instrument.strike),
            exit_ltp=exit_ltp,
            exit_reason=reason,
            realized_pnl=realized_pnl,
            trade_id=pos.trade_id,
        )

    def _write_done_event(self, total_realized_pnl: float) -> None:
        """Write DONE event with total realized PNL."""
        self._append_csv_event('DONE', realized_pnl=total_realized_pnl)

    def _dump_zscores_csv(self, valid_stocks, stock_option_map, iv_values, welford_states, zscores, long_stocks, short_stocks) -> None:
        """Write the full z-score table to a CSV file. Best-effort, never raises."""
        try:
            csv_path = self._get_zscore_csv_path()
            os.makedirs(os.path.dirname(csv_path), exist_ok=True)
            now = datetime.now()

            with open(csv_path, 'w', newline='') as f:
                writer = csv.DictWriter(f, fieldnames=ZSCORE_CSV_COLUMNS)
                writer.writeheader()

                sorted_stocks = sorted(zscores, key=lambda s: zscores[s])
                for rank_idx, stock in enumerate(sorted_stocks, 1):
                    info = stock_option_map.get(stock, {})
                    ws = welford_states.get(stock)
                    std = welford_std(ws) if ws else 0.0
                    expiry = info.get('expiry')
                    ttm = calculate_ttm(expiry, now) if expiry else ''

                    pick = ''
                    if stock in long_stocks:
                        pick = 'LONG'
                    elif stock in short_stocks:
                        pick = 'SHORT'

                    writer.writerow({
                        'timestamp': now.isoformat(),
                        'stock': stock,
                        'expiry': str(expiry) if expiry else '',
                        'future_ltp': info.get('future_ltp', ''),
                        'strike': float(info.get('strike', 0)) if info.get('strike') else '',
                        'ce_ltp': info.get('ce_ltp', ''),
                        'ce_bid': info.get('ce_bid', ''),
                        'ce_ask': info.get('ce_ask', ''),
                        'pe_ltp': info.get('pe_ltp', ''),
                        'pe_bid': info.get('pe_bid', ''),
                        'pe_ask': info.get('pe_ask', ''),
                        'ttm': ttm,
                        'straddle_iv': iv_values.get(stock, ''),
                        'welford_n': ws.n if ws else '',
                        'welford_mean': ws.mean if ws else '',
                        'welford_std': std,
                        'zscore': zscores[stock],
                        'rank': rank_idx,
                        'pick': pick,
                    })
        except Exception as e:
            self.log_warning(f"[CSV] Failed to write z-score dump: {e}")

    def _cleanup_old_csv_files(self, keep_days: int = 7) -> None:
        """Remove CSV files older than keep_days from events and zscores dirs."""
        cutoff = date.today() - timedelta(days=keep_days)
        prefix = self.strategy_obj.strategy_code.lower() + "_"
        for target_dir in (VOL_EVENTS_DIR, VOL_ZSCORES_DIR):
            if not os.path.isdir(target_dir):
                continue
            for fname in os.listdir(target_dir):
                if fname.startswith(prefix) and fname.endswith('.csv'):
                    try:
                        date_str = fname[len(prefix):-4]
                        file_date = datetime.strptime(date_str, "%Y%m%d").date()
                        if file_date < cutoff:
                            os.remove(os.path.join(target_dir, fname))
                            self.log_info(f"[CSV] Removed old file: {fname}")
                    except (ValueError, OSError):
                        pass

    # =========================================================================
    # POSITION MANAGEMENT
    # =========================================================================
    def _bootstrap_from_db(self) -> bool:
        """
        Load OPEN positions from DB if strategy was restarted.

        Returns:
            True  -> Found open positions, resume in EXIT-ONLY mode
            False -> No open positions, normal execution
        """
        open_positions = StrategyPosition.objects.filter(
            strategy=self.strategy_obj,
            status='OPEN'
        ).select_related('instrument')

        if not open_positions.exists():
            self.log_info("No existing open positions found. Fresh run.")
            return False
        self.log_warning(
            f"Found {open_positions.count()} OPEN positions. "
            f"Resuming in RECOVERY mode (no new entries)."
        )

        self.open_positions.clear()
        self.straddle_directions.clear()

        for pos in open_positions:
            stock = pos.strategy_metadata.get('straddle_stock')

            if not stock:
                continue

            self.open_positions.setdefault(stock, []).append(pos)
            self.straddle_directions[stock] = pos.position_type

        return True

    def _generate_trade_id(self, stock: str, option_type: str) -> str:
        """Generate unique trade ID."""
        timestamp = timezone.now().strftime('%Y%m%d%H%M%S')
        short_uuid = str(uuid.uuid4())[:8]
        return f"{self.strategy_obj.strategy_code}_{stock}_{option_type}_{timestamp}_{short_uuid}"

    def _create_straddle_positions(
        self,
        stock: str,
        direction: str,
        ce_ltp: float,
        pe_ltp: float,
        datafeed_handler,
        place_orders: bool = True
    ) -> bool:
        """
        Create straddle positions (CE + PE) in the database and place orders.

        Args:
            stock: Stock name
            direction: 'LONG' or 'SHORT'
            ce_ltp: Current CE LTP (entry price)
            pe_ltp: Current PE LTP (entry price)
            datafeed_handler: DataFeedHandler instance
            place_orders: If True, place orders via OMS

        Returns:
            bool: True if positions created successfully
        """
        if stock not in self.options:
            self.log_error(f"[ENTRY] {stock}: No options resolved — cannot create positions")
            return False

        ce, pe = self.options[stock]
        now = timezone.now()

        # Determine order side based on straddle direction
        # LONG straddle = BUY CE + BUY PE
        # SHORT straddle = SELL CE + SELL PE
        entry_side = 'BUY' if direction == 'LONG' else 'SELL'

        try:
            # Place entry orders if enabled
            ce_parent_order = None
            pe_parent_order = None

            if place_orders:
                ce_limit = (
                    Decimal(str(ce_ltp)) - Decimal("0.0") if direction == 'LONG'
                    else Decimal(str(ce_ltp)) + Decimal("0.0")
                )
                pe_limit = (
                    Decimal(str(pe_ltp)) - Decimal("0.0") if direction == 'LONG'
                    else Decimal(str(pe_ltp)) + Decimal("0.0")
                )
                self.log_info(
                    f"[ENTRY] {stock} {direction} straddle @ K={ce.strike} | "
                    f"CE {entry_side} LTP={ce_ltp:.2f} limit={ce_limit} | "
                    f"PE {entry_side} LTP={pe_ltp:.2f} limit={pe_limit}"
                )

                # Place CE order
                ce_success, ce_parent_order = self._place_entry_order(
                    instrument=ce,
                    side=entry_side,
                    quantity=ce.lot_size,
                    price=ce_limit,
                )
                # Place PE order
                pe_success, pe_parent_order = self._place_entry_order(
                    instrument=pe,
                    side=entry_side,
                    quantity=pe.lot_size,
                    price=pe_limit,
                )
                if not ce_success or not pe_success:
                    self.log_warning(
                        f"[ENTRY] {stock}: partial order failure "
                        f"(CE={'OK' if ce_success else 'FAIL'}, "
                        f"PE={'OK' if pe_success else 'FAIL'})"
                    )

            # Create CE position
            ce_position = StrategyPosition.objects.create(
                trade_id=self._generate_trade_id(stock, 'CE'),
                strategy=self.strategy_obj,
                instrument=ce,
                position_type=direction,
                status='OPEN',
                quantity=ce.lot_size,
                entry_price=Decimal(str(ce_ltp)),
                entry_time=now,
                entry_parent_order=ce_parent_order,
                last_price=Decimal(str(ce_ltp)),
                last_price_updated_at=now,
                strategy_metadata={
                    'straddle_stock': stock,
                    'option_type': 'CE',
                    'strike': float(ce.strike),
                    'expiry': str(self.option_expiries[stock]),
                    'entry_side': entry_side
                }
            )

            # Create PE position
            pe_position = StrategyPosition.objects.create(
                trade_id=self._generate_trade_id(stock, 'PE'),
                strategy=self.strategy_obj,
                instrument=pe,
                position_type=direction,
                status='OPEN',
                quantity=pe.lot_size,
                entry_price=Decimal(str(pe_ltp)),
                entry_time=now,
                entry_parent_order=pe_parent_order,
                last_price=Decimal(str(pe_ltp)),
                last_price_updated_at=now,
                strategy_metadata={
                    'straddle_stock': stock,
                    'option_type': 'PE',
                    'strike': float(pe.strike),
                    'expiry': str(self.option_expiries[stock]),
                    'entry_side': entry_side
                }
            )

            self.open_positions[stock] = [ce_position, pe_position]
            self.straddle_directions[stock] = direction
            self._write_entry_event(stock, direction, ce_position, ce_ltp)
            self._write_entry_event(stock, direction, pe_position, pe_ltp)

            # Track entry orders
            if ce_parent_order or pe_parent_order:
                self.entry_orders[stock] = [
                    o for o in [ce_parent_order, pe_parent_order] if o
                ]

            self.log_info(
                f"[ENTRY] {stock} {direction} straddle created @ K={ce.strike} | "
                f"CE entry={ce_ltp:.2f} PE entry={pe_ltp:.2f} "
                f"Premium={ce_ltp + pe_ltp:.2f} | "
                f"trade_ids=[{ce_position.trade_id}, {pe_position.trade_id}]"
            )

            return True

        except Exception as e:
            self.log_exception(f"[ENTRY] Failed to create positions for {stock}: {e}")
            return False

    def _calculate_position_pnl(self, position: StrategyPosition, current_ltp: float) -> float:
        """
        Calculate unrealized PNL for a position.

        For LONG: PNL = (current - entry) * quantity
        For SHORT: PNL = (entry - current) * quantity
        """
        if not position.entry_price:
            return 0.0

        entry = float(position.entry_price)
        qty = position.quantity

        if position.position_type == 'LONG':
            return (current_ltp - entry) * qty
        else:  # SHORT
            return (entry - current_ltp) * qty

    def _update_positions_ltp(self, datafeed_handler) -> dict[str, dict]:
        """
        Update LTP for all open positions and calculate PNL.

        Returns:
            dict: Stock -> {ce_ltp, pe_ltp, ce_pnl, pe_pnl, total_pnl, direction}
        """
        if not self.open_positions:
            return {}

        # Collect all instruments from open positions
        all_instruments = []
        for stock, positions in self.open_positions.items():
            for pos in positions:
                all_instruments.append(pos.instrument)

        # Fetch all LTPs
        all_ltps = self._fetch_multiple_ltp(datafeed_handler, all_instruments)
        now = timezone.now()

        result = {}

        for stock, positions in self.open_positions.items():
            ce_pos = None
            pe_pos = None

            for pos in positions:
                if pos.instrument.instrument_type == 'CE':
                    ce_pos = pos
                else:
                    pe_pos = pos

            if not ce_pos or not pe_pos:
                continue

            ce_ltp = all_ltps.get(ce_pos.instrument.instrument_token)
            pe_ltp = all_ltps.get(pe_pos.instrument.instrument_token)

            if ce_ltp is None or pe_ltp is None:
                continue

            # Update positions in DB
            ce_pos.last_price = Decimal(str(ce_ltp))
            ce_pos.last_price_updated_at = now
            ce_pos.unrealized_pnl = Decimal(str(self._calculate_position_pnl(ce_pos, ce_ltp)))
            ce_pos.save(update_fields=['last_price', 'last_price_updated_at', 'unrealized_pnl'])

            pe_pos.last_price = Decimal(str(pe_ltp))
            pe_pos.last_price_updated_at = now
            pe_pos.unrealized_pnl = Decimal(str(self._calculate_position_pnl(pe_pos, pe_ltp)))
            pe_pos.save(update_fields=['last_price', 'last_price_updated_at', 'unrealized_pnl'])

            ce_pnl = float(ce_pos.unrealized_pnl)
            pe_pnl = float(pe_pos.unrealized_pnl)

            result[stock] = {
                'ce_ltp': ce_ltp,
                'pe_ltp': pe_ltp,
                'ce_entry': float(ce_pos.entry_price),
                'pe_entry': float(pe_pos.entry_price),
                'ce_pnl': ce_pnl,
                'pe_pnl': pe_pnl,
                'total_pnl': ce_pnl + pe_pnl,
                'direction': self.straddle_directions.get(stock, 'UNKNOWN'),
                'strike': float(ce_pos.instrument.strike)
            }

        return result

    def _close_all_positions(self, datafeed_handler, place_orders: bool = True) -> None:
        """
        Close all open positions at current LTP using LIMIT orders.
        """
        if not self.open_positions:
            self.log_info("[EXIT] No open positions to close.")
            return

        self.log_info(
            f"[EXIT] ===== CLOSING {len(self.open_positions)} STRADDLES (LIMIT ORDERS) ====="
        )

        # Collect all instruments to fetch LTP
        all_instruments = []
        for stock, positions in self.open_positions.items():
            for pos in positions:
                all_instruments.append(pos.instrument)

        # Fetch current LTPs for exit pricing
        all_ltps = self._fetch_multiple_ltp(datafeed_handler, all_instruments)
        now = timezone.now()
        total_realized_pnl = 0.0

        for stock, positions in self.open_positions.items():
            stock_pnl = 0.0
            direction = self.straddle_directions.get(stock, 'LONG')
            exit_side = 'SELL' if direction == 'LONG' else 'BUY'
            stock_exit_orders = []

            for pos in positions:
                ltp = all_ltps.get(pos.instrument.instrument_token)

                if ltp is None:
                    self.log_warning(
                        f"[EXIT] {stock}: Could not get LTP for "
                        f"{pos.instrument.tradingsymbol}. Skipping."
                    )
                    continue

                # --- LIMIT PRICE CALCULATION ---
                # For SELL: We place limit slightly BELOW LTP to hit the bid (aggressive)
                # For BUY: We place limit slightly ABOVE LTP to hit the ask (aggressive)
                # Using 0.5 as an example offset (adjust based on tick size)
                offset = Decimal("0.0")
                exit_price = Decimal(str(ltp))

                if exit_side == 'SELL':
                    limit_price = exit_price + offset
                else:
                    limit_price = exit_price - offset
                # Place exit order
                exit_parent_order = None
                if place_orders:
                    exit_success, exit_parent_order = self._place_exit_order(
                        instrument=pos.instrument,
                        side=exit_side,
                        quantity=pos.quantity,
                        price=limit_price  # <--- Passing the calculated price makes it a LIMIT order
                    )
                    if exit_parent_order:
                        stock_exit_orders.append(exit_parent_order)

                # Calculate final PNL based on the LTP at time of exit trigger
                pnl = self._calculate_position_pnl(pos, ltp)
                stock_pnl += pnl

                # Update position as closed in DB
                pos.exit_price = exit_price
                pos.exit_time = now
                pos.exit_parent_order = exit_parent_order
                pos.realized_pnl = Decimal(str(pnl))
                pos.unrealized_pnl = Decimal('0.00')
                pos.status = 'CLOSED'
                pos.save(update_fields=[
                    'exit_price', 'exit_time', 'exit_parent_order',
                    'realized_pnl', 'unrealized_pnl', 'status', 'updated_at'
                ])
                self._write_exit_event(stock, pos, ltp, reason='EXIT_TIME', realized_pnl=pnl)

                self.log_info(
                    f"[EXIT] {stock} {pos.instrument.instrument_type}: "
                    f"{exit_side} limit={limit_price} (LTP={ltp:.2f}) "
                    f"entry={float(pos.entry_price):.2f} PNL={pnl:+.2f}"
                )

            if stock_exit_orders:
                self.exit_orders[stock] = stock_exit_orders

            self.log_info(f"[EXIT] {stock} {direction} straddle PNL: {stock_pnl:+.2f}")
            total_realized_pnl += stock_pnl

        self.log_info(f"[EXIT] ===== TOTAL REALIZED PNL: {total_realized_pnl:+.2f} =====")
        self._print_order_summary()
        self._write_done_event(total_realized_pnl)
        self.open_positions.clear()
        self.straddle_directions.clear()

    def _print_order_summary(self) -> None:
        """Print summary of all orders placed."""
        lines = ["=" * 60, "ORDER SUMMARY", "=" * 60]

        total_entry = 0
        total_exit = 0

        for stock in sorted(set(list(self.entry_orders.keys()) + list(self.exit_orders.keys()))):
            entry_orders = self.entry_orders.get(stock, [])
            exit_orders = self.exit_orders.get(stock, [])

            lines.append(f"\n{stock}:")

            if entry_orders:
                lines.append("  Entry Orders:")
                for order in entry_orders:
                    summary = order_manager.get_parent_order_summary(order)
                    lines.append(
                        f"    PO#{order.order_id}: {order.side} {order.quantity}x "
                        f"{order.instrument.tradingsymbol} — {order.status} "
                        f"(broker orders: {summary['total_broker_orders']} total, "
                        f"{summary['completed']} completed, {summary['rejected']} rejected)"
                    )
                total_entry += len(entry_orders)

            if exit_orders:
                lines.append("  Exit Orders:")
                for order in exit_orders:
                    summary = order_manager.get_parent_order_summary(order)
                    lines.append(
                        f"    PO#{order.order_id}: {order.side} {order.quantity}x "
                        f"{order.instrument.tradingsymbol} — {order.status} "
                        f"(broker orders: {summary['total_broker_orders']} total, "
                        f"{summary['completed']} completed, {summary['rejected']} rejected)"
                    )
                total_exit += len(exit_orders)

        lines.append("-" * 60)
        lines.append(f"Total Entry Orders: {total_entry} | Total Exit Orders: {total_exit}")
        lines.append("=" * 60)
        self.log_info("[SUMMARY]\n" + "\n".join(lines))

    # =========================================================================
    # VERIFICATION
    # =========================================================================

    def verify(self) -> bool:
        """Verify strategy prerequisites before running."""
        self.log_info("[VERIFY] ===== Checking instruments and datafeed =====")

        if not self.datafeed_obj:
            self.log_error("[VERIFY] No datafeed object provided")
            return False

        if self.datafeed_obj.is_token_expired:
            self.log_warning("[VERIFY] Datafeed token expired, attempting refresh...")
            from datafeed.rest.handler import DataFeedHandler
            handler = DataFeedHandler(self.datafeed_obj)
            if not handler.update_token():
                self.log_error("[VERIFY] Failed to refresh datafeed token")
                return False
            self.log_info("[VERIFY] Datafeed token refreshed")

        self.log_info(f"[VERIFY] Resolving instruments for {len(STOCKS_TO_CONSIDER)} stocks...")

        missing_futures = []
        missing_options = []

        for stock in STOCKS_TO_CONSIDER:
            future = self._get_nearest_future(stock)
            if not future:
                missing_futures.append(stock)
                continue

            self.futures[stock] = future

            option_expiry = self._get_nearest_option_expiry(stock)
            if not option_expiry:
                missing_options.append(stock)
                continue

            self.option_expiries[stock] = option_expiry
            self.active_stocks.append(stock)

        self.log_info(
            f"[VERIFY] Active: {len(self.active_stocks)}/{len(STOCKS_TO_CONSIDER)} | "
            f"Missing futures: {len(missing_futures)} | Missing options: {len(missing_options)}"
        )

        if missing_futures:
            self.log_warning(
                f"[VERIFY] Missing futures ({len(missing_futures)}): "
                f"{', '.join(missing_futures)}"
            )
        if missing_options:
            self.log_warning(
                f"[VERIFY] Missing options ({len(missing_options)}): "
                f"{', '.join(missing_options)}"
            )

        if not self.active_stocks:
            self.log_error("[VERIFY] No stocks available for monitoring")
            return False

        self.log_info("[VERIFY] Passed.")
        return True

    # =========================================================================
    # MAIN RUN LOOP
    # =========================================================================

    def run(self, place_orders: bool = True):
        """
        Main strategy execution loop.

        Args:
            place_orders: If True, place actual orders via OMS. If False, only track positions.

        Flow:
        1. Verify prerequisites
        2. Wait for entry time
        3. Update ATM options
        4. Call business logic for signals
        5. Create positions and place entry orders
        6. Track PNL every minute
        7. At exit time, close positions and place exit orders
        """
        self.log_info("=" * 60)
        self.log_info(f"[BOOT] Starting {self.strategy_obj.strategy_name}")
        self.log_info(f"[BOOT] Entry={self.strategy_obj.entry_time}  Exit={self.strategy_obj.exit_time}")
        self.log_info(
            f"[BOOT] Order execution: "
            f"{'ENABLED' if place_orders else 'DISABLED (simulation)'}"
        )
        self.log_info("=" * 60)

        # Verify prerequisites
        if not self.verify():
            self.log_error("[BOOT] Verification failed. Exiting.")
            return

        self.is_running = True

        from datafeed.rest.handler import DataFeedHandler
        datafeed_handler = DataFeedHandler(self.datafeed_obj)
        resume_only = self._bootstrap_from_db()
        self._cleanup_old_csv_files()
        self._write_boot_event('RESUME' if resume_only else 'FRESH')

        # =====================================================================
        # PHASE 1: Wait for entry time
        # =====================================================================
        entry_datetime = self._get_today_datetime(self.strategy_obj.entry_time)
        exit_datetime = self._get_today_datetime(self.strategy_obj.exit_time)

        self.log_info(f"[WAIT] Waiting for entry time: {entry_datetime.strftime('%H:%M:%S')}")

        if not self._wait_until(entry_datetime):
            self.log_info("[BOOT] Stopped while waiting for entry time.")
            return

        if not self.is_running:
            return
        if resume_only:
            self.log_warning(
                "[RESUME] Skipping ENTRY phase. Monitoring existing positions only."
            )

            while self.is_running:
                if self._is_past_exit_time():
                    self.log_info("[RESUME] >>> EXIT TIME REACHED <<<")
                    break

                # Update positions and calculate PNL
                pnl_data = self._update_positions_ltp(datafeed_handler)

                # Build PNL table
                timestamp = timezone.now().strftime('%H:%M:%S')
                rows = [
                    "-" * 90,
                    f"{'Stock':<12} {'Dir':<6} {'Strike':<10} {'CE Entry':<10} {'CE LTP':<10} "
                    f"{'PE Entry':<10} {'PE LTP':<10} {'PNL':<12}",
                    "-" * 90,
                ]

                total_pnl = 0.0
                for stock, data in pnl_data.items():
                    rows.append(
                        f"{stock:<12} {data['direction']:<6} {data['strike']:<10.2f} "
                        f"{data['ce_entry']:<10.2f} {data['ce_ltp']:<10.2f} "
                        f"{data['pe_entry']:<10.2f} {data['pe_ltp']:<10.2f} "
                        f"{data['total_pnl']:+12.2f}"
                    )
                    total_pnl += data['total_pnl']

                rows.append("-" * 90)
                rows.append(
                    f"{'TOTAL':<12} {'':<6} {'':<10} {'':<10} {'':<10} {'':<10} {'':<10} "
                    f"{total_pnl:+12.2f}"
                )
                rows.append("-" * 90)

                remaining = (exit_datetime - timezone.now()).total_seconds()
                remaining_str = (
                    f" | {int(remaining // 60)}m {int(remaining % 60)}s to exit"
                    if remaining > 0 else ""
                )

                self.log_info(
                    f"[RESUME {timestamp}] PNL snapshot ({len(pnl_data)} straddles) "
                    f"TOTAL={total_pnl:+.2f}{remaining_str}\n" + "\n".join(rows)
                )

                time.sleep(60)

            if self.open_positions:
                self._close_all_positions(datafeed_handler, place_orders=place_orders)

            self.is_running = False
            self.log_info("[RESUME] Recovery exit completed.")
            return
        # =====================================================================
        # PHASE 2: Entry - Get signals and create positions
        # =====================================================================
        self.log_info("[ENTRY] ===== ENTRY PHASE =====")

        # Update ATM options based on current prices
        self.log_info("[ENTRY] Updating ATM options from current futures LTPs...")
        self._update_atm_options(datafeed_handler)

        stocks_with_options = [s for s in self.active_stocks if s in self.options]
        self.log_info(
            f"[ENTRY] Stocks with valid option pairs: "
            f"{len(stocks_with_options)}/{len(self.active_stocks)}"
        )

        if not stocks_with_options:
            self.log_error("[ENTRY] No stocks with valid options. Exiting.")
            self.is_running = False
            return

        # Get trading signals from business logic
        self.log_info("[ENTRY] Calling signal generation...")
        long_stocks, short_stocks = self._get_trading_signals(datafeed_handler)

        self.log_info(
            f"[ENTRY] Signals returned: LONG={long_stocks} | SHORT={short_stocks}"
        )

        if not long_stocks and not short_stocks:
            self.log_warning("[ENTRY] No signals generated. Exiting.")
            self.is_running = False
            return

        # Fetch LTPs for all option pairs we need
        all_options = []
        for stock in long_stocks + short_stocks:
            if stock in self.options:
                ce, pe = self.options[stock]
                all_options.extend([ce, pe])

        option_ltps = self._fetch_multiple_ltp(datafeed_handler, all_options)

        # Create long straddle positions
        self.log_info(f"[ENTRY] Creating LONG straddle positions ({len(long_stocks)})...")
        for stock in long_stocks:
            if stock not in self.options:
                self.log_warning(f"[ENTRY] {stock}: SKIP — no options available")
                continue

            ce, pe = self.options[stock]
            ce_ltp = option_ltps.get(ce.instrument_token)
            pe_ltp = option_ltps.get(pe.instrument_token)

            if ce_ltp and pe_ltp:
                self._create_straddle_positions(
                    stock, 'LONG', ce_ltp, pe_ltp,
                    datafeed_handler, place_orders=place_orders
                )
            else:
                self.log_warning(
                    f"[ENTRY] {stock}: SKIP — LTP missing (CE={ce_ltp}, PE={pe_ltp})"
                )

        # Create short straddle positions
        self.log_info(f"[ENTRY] Creating SHORT straddle positions ({len(short_stocks)})...")
        for stock in short_stocks:
            if stock not in self.options:
                self.log_warning(f"[ENTRY] {stock}: SKIP — no options available")
                continue

            ce, pe = self.options[stock]
            ce_ltp = option_ltps.get(ce.instrument_token)
            pe_ltp = option_ltps.get(pe.instrument_token)

            if ce_ltp and pe_ltp:
                self._create_straddle_positions(
                    stock, 'SHORT', ce_ltp, pe_ltp,
                    datafeed_handler, place_orders=place_orders
                )
            else:
                self.log_warning(
                    f"[ENTRY] {stock}: SKIP — LTP missing (CE={ce_ltp}, PE={pe_ltp})"
                )

        if not self.open_positions:
            self.log_error("[ENTRY] No positions created. Exiting.")
            self.is_running = False
            return

        self.log_info(
            f"[ENTRY] Total straddles created: {len(self.open_positions)} "
            f"(target: {len(long_stocks)} LONG + {len(short_stocks)} SHORT)"
        )

        # =====================================================================
        # PHASE 3: Monitor and track PNL
        # =====================================================================
        self.log_info(
            f"[MONITOR] ===== PNL tracking (60s interval) | "
            f"Exit at {exit_datetime.strftime('%H:%M:%S')} ====="
        )

        while self.is_running:
            # Check if it's time to exit
            if self._is_past_exit_time():
                self.log_info("[MONITOR] >>> EXIT TIME REACHED <<<")
                break

            # Update positions and calculate PNL
            pnl_data = self._update_positions_ltp(datafeed_handler)

            # Build PNL table
            timestamp = timezone.now().strftime('%H:%M:%S')
            rows = [
                "-" * 90,
                f"{'Stock':<12} {'Dir':<6} {'Strike':<10} {'CE Entry':<10} {'CE LTP':<10} "
                f"{'PE Entry':<10} {'PE LTP':<10} {'PNL':<12}",
                "-" * 90,
            ]

            total_pnl = 0.0
            long_pnl = 0.0
            short_pnl = 0.0
            for stock, data in pnl_data.items():
                rows.append(
                    f"{stock:<12} {data['direction']:<6} {data['strike']:<10.2f} "
                    f"{data['ce_entry']:<10.2f} {data['ce_ltp']:<10.2f} "
                    f"{data['pe_entry']:<10.2f} {data['pe_ltp']:<10.2f} "
                    f"{data['total_pnl']:+12.2f}"
                )
                total_pnl += data['total_pnl']
                if data['direction'] == 'LONG':
                    long_pnl += data['total_pnl']
                else:
                    short_pnl += data['total_pnl']

            rows.append("-" * 90)
            rows.append(
                f"{'TOTAL':<12} {'':<6} {'':<10} {'':<10} {'':<10} {'':<10} {'':<10} "
                f"{total_pnl:+12.2f}"
            )
            rows.append("-" * 90)

            remaining = (exit_datetime - timezone.now()).total_seconds()
            remaining_str = (
                f" | {int(remaining // 60)}m {int(remaining % 60)}s to exit"
                if remaining > 0 else ""
            )

            self.log_info(
                f"[MONITOR {timestamp}] TOTAL={total_pnl:+.2f} "
                f"(LONG {long_pnl:+.2f}, SHORT {short_pnl:+.2f}){remaining_str}\n"
                + "\n".join(rows)
            )

            # Wait 1 minute before next update
            time.sleep(60)

        # =====================================================================
        # PHASE 4: Exit - Close all positions
        # =====================================================================
        if self.is_running and self.open_positions:
            self._close_all_positions(datafeed_handler, place_orders=place_orders)

        self.is_running = False
        self.log_info(f"[DONE] {self.strategy_obj.strategy_name} completed.")

    def stop(self):
        """Stop the strategy gracefully."""
        self.log_info(f"[STOP] Stopping {self.strategy_obj.strategy_name}...")
        self.is_running = False

    # =========================================================================
    # EXTERNAL API
    # =========================================================================

    def get_open_positions(self) -> dict[str, dict]:
        """
        Get current open positions with PNL (can be called externally).

        Returns:
            dict: Stock -> position details with PNL
        """
        if not self.open_positions or not self.datafeed_obj:
            return {}

        from datafeed.rest.handler import DataFeedHandler
        handler = DataFeedHandler(self.datafeed_obj)

        return self._update_positions_ltp(handler)

    def get_order_status(self) -> dict:
        """
        Get status of all orders placed by this strategy.

        Returns:
            dict: Order status summary
        """
        result = {
            'entry_orders': {},
            'exit_orders': {},
            'summary': {
                'total_entry': 0,
                'total_exit': 0,
                'entry_completed': 0,
                'exit_completed': 0
            }
        }

        for stock, orders in self.entry_orders.items():
            result['entry_orders'][stock] = []
            for order in orders:
                summary = order_manager.get_parent_order_summary(order)
                result['entry_orders'][stock].append(summary)
                result['summary']['total_entry'] += 1
                if order.status == 'COMPLETED':
                    result['summary']['entry_completed'] += 1

        for stock, orders in self.exit_orders.items():
            result['exit_orders'][stock] = []
            for order in orders:
                summary = order_manager.get_parent_order_summary(order)
                result['exit_orders'][stock].append(summary)
                result['summary']['total_exit'] += 1
                if order.status == 'COMPLETED':
                    result['summary']['exit_completed'] += 1

        return result
