""" Hedged OTM Short Strangle — Weekly Expiry Day Only """

import json
import os
import shutil
import time
import uuid
from datetime import date, datetime, time as dt_time
from decimal import Decimal
from typing import Optional

import pandas as pd

from django.db.models import Min
from django.utils import timezone

from instruments.models import Instrument
from orders.order_manager import order_manager
from strategy.models import StrategyPosition
from strategy.strategy_class.base_strategy import BaseStrategy


# =============================================================================
# CONSTANTS
# =============================================================================

INDEX_NAME = "NIFTY 50"
TICKER = "NIFTY"

# ── TBT (Tick-By-Tick) ──────────────────────────────────────────────────────
TBT_DATA_PATH = r"\\10.211.8.76\GFD MBM Data\Momentum\logs"
TBT_INDEX_NAME = "Nifty 50"
LOCAL_TBT_DIR = os.path.join(
    os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))),
    "dump", "tbt_local",
)

TBT_MARKET_OPEN = dt_time(14, 00, 0)
TBT_MARKET_CLOSE = dt_time(15, 30, 0)
TBT_MAX_STALENESS_SECS = 120

# ── Strategy parameter defaults (overridable via strategy_params) ──────────
DEFAULT_OFFSET_MULT = 0.5     # short strangle offset, in straddles
DEFAULT_REBAL_MULT  = 0.5     # rebalance trigger, in initial straddles
DEFAULT_HEDGE_MULT  = 3.0     # hedge offset (added to short offset)
DEFAULT_ENTRY_TIME  = dt_time(14, 00, 00)
DEFAULT_POLL_INTERVAL_SECS = 5

EXIT_TIME = dt_time(15, 24, 59)        # mirror of EXIT_TIME in backtest
PRICE_OFFSET = Decimal("0.05")

_BASE_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
HOTMS_DUMP_DIR = os.path.join(_BASE_DIR, 'dump', 'hotms')

LEG_SHORT_CE = "SHORT_CE"
LEG_SHORT_PE = "SHORT_PE"
LEG_HEDGE_CE = "HEDGE_CE"
LEG_HEDGE_PE = "HEDGE_PE"
SHORT_LEGS = (LEG_SHORT_CE, LEG_SHORT_PE)
HEDGE_LEGS = (LEG_HEDGE_CE, LEG_HEDGE_PE)


class HedgedOtmStrangle(BaseStrategy):
    """
    Logic (per-day, expiry day only):
      * At entry_time, find ATM, compute initial straddle = ATM CE + ATM PE.
      * Open SHORT strangle at offset_mult × current straddle from current spot.
      * Open LONG hedge strangle at (offset_mult + hedge_mult) × INITIAL straddle
        from INITIAL spot — opens once, stays static, closes at EOD.
      * Rebalance the SHORT strangle when
            |spot - last_adjust_spot| / initial_straddle ≥ rebal_mult.
        Hedge does NOT move on rebalance. New short uses CURRENT spot and
        CURRENT ATM straddle.
      * Close everything at EXIT_TIME (15:24:59).
    """

    def __init__(self, strategy_obj, datafeed_obj, ws_manager=None):
        super().__init__(strategy_obj, datafeed_obj, ws_manager)
        self.is_running = False

        # ── Resolved params ──────────────────────────────────────────
        self.offset_mult: float = DEFAULT_OFFSET_MULT
        self.rebal_mult: float = DEFAULT_REBAL_MULT
        self.hedge_mult: float = DEFAULT_HEDGE_MULT
        self.entry_time: dt_time = DEFAULT_ENTRY_TIME
        self.poll_interval_secs: int = DEFAULT_POLL_INTERVAL_SECS

        # ── Day-level state ──────────────────────────────────────────
        self.initial_atm_straddle: Optional[float] = None
        self.initial_forward: Optional[float] = None
        self.last_adjust_forward: Optional[float] = None
        self.daily_rebalance_count: int = 0
        self.expiry: Optional[date] = None

        # ── Short state ──────────────────────────────────────────────
        self.short_call_strike: Optional[Decimal] = None
        self.short_put_strike: Optional[Decimal] = None
        self.short_open: bool = False

        # ── Hedge state (static after first entry) ───────────────────
        self.hedge_call_strike: Optional[Decimal] = None
        self.hedge_put_strike: Optional[Decimal] = None
        self.hedge_open: bool = False

        # ── DB position handles, keyed by leg name ───────────────────
        self.open_positions: dict[str, StrategyPosition] = {}
        self._last_good_max_ts: Optional[datetime] = None

        # ── Cached strike list for the day ───────────────────────────
        self._available_strikes: list[Decimal] = []

        self.log_info(
            f"Initializing {self.strategy_obj.strategy_code} — "
            f"{self.strategy_obj.strategy_name}"
        )

    # =========================================================================
    # INSTRUMENT LOOKUPS
    # =========================================================================

    def _get_nearest_option_expiry(self) -> Optional[date]:
        """Get the nearest weekly option expiry date for NIFTY."""
        today = date.today()
        result = Instrument.objects.filter(
            name=TICKER,
            exchange="NFO",
            instrument_type__in=["CE", "PE"],
            is_active=True,
            expiry__gte=today,
        ).aggregate(min_expiry=Min("expiry"))
        return result.get("min_expiry")

    def _load_available_strikes(self, expiry: date) -> None:
        """Cache all distinct strikes for the given expiry."""
        strikes = (
            Instrument.objects.filter(
                name=TICKER, exchange="NFO",
                instrument_type__in=["CE", "PE"],
                expiry=expiry, is_active=True,
            )
            .values_list("strike", flat=True)
            .distinct()
        )
        self._available_strikes = sorted([s for s in strikes if s is not None])

    def _nearest_strike(self, target: float) -> Optional[Decimal]:
        """Pick the available strike closest to target — mirrors np.argmin in backtest."""
        if not self._available_strikes:
            return None
        return min(self._available_strikes, key=lambda s: abs(float(s) - target))

    def _get_option_instrument(
        self, strike: Decimal, option_type: str
    ) -> Optional[Instrument]:
        """Get a single option instrument."""
        return Instrument.objects.filter(
            name=TICKER,
            exchange="NFO",
            instrument_type=option_type,
            expiry=self.expiry,
            strike=strike,
            is_active=True,
        ).first()

    # =========================================================================
    # TBT SPOT PRICE
    # =========================================================================

    def _copy_tbt_file(self, file_date: Optional[date] = None) -> Optional[str]:
        """Copy today's TBT file from network share to local directory."""
        target_date = file_date or date.today()
        filename = target_date.strftime("%Y%m%d") + ".txt"
        source = os.path.join(TBT_DATA_PATH, filename)

        os.makedirs(LOCAL_TBT_DIR, exist_ok=True)
        dest = os.path.join(LOCAL_TBT_DIR, filename)

        try:
            shutil.copy2(source, dest)
            return dest
        except FileNotFoundError:
            self.log_error(f"TBT file not found: {source}")
            return None
        except Exception as e:
            self.log_error(f"Failed to copy TBT file: {e}")
            return None

    def _parse_tbt_data(self, file_path: str) -> Optional[pd.DataFrame]:
        """Parse TBT file and filter for Nifty 50 ticks."""
        try:
            df = pd.read_csv(
                file_path,
                sep=r"\s*\|\s*",
                header=None,
                names=["timestamp", "index_name", "price", "seq_id"],
                engine="python",
            )
        except Exception as e:
            self.log_error(f"Failed to parse TBT file: {e}")
            return None

        df = df[df["index_name"] == TBT_INDEX_NAME].copy()
        if df.empty:
            self.log_error(f"No '{TBT_INDEX_NAME}' ticks in TBT file.")
            return None

        df["timestamp"] = pd.to_datetime(df["timestamp"], format="mixed")
        df["price"] = pd.to_numeric(df["price"], errors="coerce")
        df = df.dropna(subset=["price"])
        df = df.sort_values("timestamp").reset_index(drop=True)

        pre = len(df)
        df = df[
            (df["timestamp"].dt.time >= TBT_MARKET_OPEN)
            & (df["timestamp"].dt.time <= TBT_MARKET_CLOSE)
        ].reset_index(drop=True)
        rejected = pre - len(df)
        if rejected > 0:
            self.log_info(f"Market hours filter: rejected {rejected} ticks outside 09:15–15:30")

        if df.empty:
            self.log_error("No ticks remain after market hours filter.")
            return None
        return df[["timestamp", "price"]]

    def _validate_tbt_data(self, tbt_df: pd.DataFrame) -> bool:
        """Validate parsed TBT data for staleness and timestamp regression."""
        max_ts: datetime = tbt_df["timestamp"].max().to_pydatetime()
        now = datetime.now()

        staleness = (now - max_ts).total_seconds()
        if staleness > TBT_MAX_STALENESS_SECS:
            self.log_error(
                f"TBT REJECTED (stale): latest tick {max_ts.strftime('%H:%M:%S')} "
                f"is {staleness:.0f}s behind wall clock"
            )
            return False

        if self._last_good_max_ts is not None and max_ts < self._last_good_max_ts:
            regression = (self._last_good_max_ts - max_ts).total_seconds()
            self.log_error(
                f"TBT REJECTED (regression): max tick {max_ts.strftime('%H:%M:%S')} "
                f"< previous good {self._last_good_max_ts.strftime('%H:%M:%S')} "
                f"(regressed {regression:.0f}s)"
            )
            return False

        self._last_good_max_ts = max_ts
        return True

    def _fetch_spot_from_tbt(self) -> Optional[float]:
        """Fetch latest NIFTY 50 spot price from TBT file."""
        local_path = self._copy_tbt_file()
        if local_path is None:
            return None
        df = self._parse_tbt_data(local_path)
        if df is None or df.empty:
            return None
        if not self._validate_tbt_data(df):
            return None
        return float(df["price"].iloc[-1])

    # =========================================================================
    # DATA FEED
    # =========================================================================

    def _fetch_ltp(self, datafeed_handler, instrument: Instrument) -> Optional[float]:
        """Fetch LTP for a single instrument. Retries on auth errors."""
        attempt = 0
        while self.is_running:
            attempt += 1
            try:
                self.datafeed_obj.refresh_from_db()
                from datafeed.rest.handler import DataFeedHandler
                datafeed_handler = DataFeedHandler(self.datafeed_obj)
                response = datafeed_handler.get_multiple_ltp([instrument])
                if response and "data" in response:
                    for item in response["data"].get("ltp_list", []):
                        if item.get("instrument_token") == instrument.instrument_token:
                            return item.get("ltp")
                return None
            except Exception as e:
                status = getattr(getattr(e, "response", None), "status_code", None)
                is_auth_error = status in (400, 401) or "Unauthorized" in str(e)
                if is_auth_error:
                    self.log_warning(
                        f"LTP fetch failed (attempt {attempt}: {e}) — refreshing token..."
                    )
                    try:
                        from datafeed.rest.handler import DataFeedHandler
                        DataFeedHandler(self.datafeed_obj).update_token()
                        self.datafeed_obj.refresh_from_db()
                        datafeed_handler = DataFeedHandler(self.datafeed_obj)
                    except Exception as refresh_err:
                        self.log_error(f"Token refresh failed: {refresh_err}")
                    time.sleep(2)
                    continue
                self.log_error(f"Error fetching LTP for {instrument}: {e}")
                return None
        return None

    def _fetch_multiple_ltp(
        self, datafeed_handler, instruments: list[Instrument]
    ) -> dict[int, float]:
        """Fetch LTP for multiple instruments."""
        if not instruments:
            return {}
        attempt = 0
        while self.is_running:
            attempt += 1
            try:
                self.datafeed_obj.refresh_from_db()
                from datafeed.rest.handler import DataFeedHandler
                datafeed_handler = DataFeedHandler(self.datafeed_obj)
                response = datafeed_handler.get_multiple_ltp(instruments)
                result: dict[int, float] = {}
                if response and "data" in response:
                    for item in response["data"].get("ltp_list", []):
                        token = item.get("instrument_token")
                        ltp = item.get("ltp")
                        if token and ltp:
                            result[token] = ltp
                return result
            except Exception as e:
                status = getattr(getattr(e, "response", None), "status_code", None)
                is_auth_error = status in (400, 401) or "Unauthorized" in str(e)
                if is_auth_error:
                    self.log_warning(
                        f"Multi LTP fetch failed (attempt {attempt}: {e}) — refreshing token..."
                    )
                    try:
                        from datafeed.rest.handler import DataFeedHandler
                        DataFeedHandler(self.datafeed_obj).update_token()
                        self.datafeed_obj.refresh_from_db()
                        datafeed_handler = DataFeedHandler(self.datafeed_obj)
                    except Exception as refresh_err:
                        self.log_error(f"Token refresh failed: {refresh_err}")
                    time.sleep(2)
                    continue
                self.log_error(f"Error fetching multiple LTP: {e}")
                return {}
        return {}

    # =========================================================================
    # ATM STRADDLE FETCH
    # =========================================================================

    def _fetch_atm_straddle(
        self, datafeed_handler, spot: float
    ) -> Optional[tuple[Decimal, float, float, float]]:
        """
        Returns (atm_strike, ce_ltp, pe_ltp, atm_straddle_price) or None.
        Mirrors backtest: pick nearest strike to spot, take CE+PE close.
        """
        atm_strike = self._nearest_strike(spot)
        if atm_strike is None:
            self.log_error("ATM straddle: no available strikes")
            return None
        ce_inst = self._get_option_instrument(atm_strike, "CE")
        pe_inst = self._get_option_instrument(atm_strike, "PE")
        if not ce_inst or not pe_inst:
            self.log_error(f"ATM straddle: missing CE/PE for strike {atm_strike}")
            return None
        ltps = self._fetch_multiple_ltp(datafeed_handler, [ce_inst, pe_inst])
        ce_ltp = ltps.get(ce_inst.instrument_token)
        pe_ltp = ltps.get(pe_inst.instrument_token)
        if ce_ltp is None or pe_ltp is None or ce_ltp <= 0 or pe_ltp <= 0:
            self.log_error(
                f"ATM straddle: invalid LTPs ce={ce_ltp} pe={pe_ltp} (strike {atm_strike})"
            )
            return None
        return atm_strike, float(ce_ltp), float(pe_ltp), float(ce_ltp + pe_ltp)

    # =========================================================================
    # ORDER PLACEMENT
    # =========================================================================

    def _limit_price(self, side: str, ltp: float) -> Decimal:
        """Passive limit: SELL → LTP + offset, BUY → LTP − offset."""
        base = Decimal(str(ltp))
        return base + PRICE_OFFSET if side == "SELL" else base - PRICE_OFFSET

    def _place_order(
        self,
        instrument: Instrument,
        side: str,
        quantity: int,
        price: Optional[Decimal],
        order_intent: str,
        tag: str = "",
        dry_run: bool = False,
    ) -> tuple[bool, object]:
        """Place an order via OrderManager. Supports dry-run mode."""
        order_type = "LIMIT" if price is not None else "MARKET"
        price_str = str(price) if price is not None else "MKT"

        if dry_run:
            self.log_info(
                f"  [DRY-RUN][{tag}] {order_intent} {side} {quantity} x"
                f" {instrument.tradingsymbol} | {order_type} @ {price_str}"
                f" | NRML | expiry={instrument.expiry}"
            )
            return True, None

        success, msg, parent_order, _ = order_manager.create_and_execute_order(
            strategy=self.strategy_obj,
            instrument=instrument,
            side=side,
            quantity=quantity,
            order_type=order_type,
            product_type="NRML",
            price=price,
            order_intent=order_intent,
            metadata={
                "strategy_code": self.strategy_obj.strategy_code,
                "instrument_type": instrument.instrument_type,
                "stock_name": instrument.name,
                "tag": tag,
            },
        )
        if success:
            self.log_info(
                f"  [{tag}] {side} {quantity} x {instrument.tradingsymbol} @ {price_str}"
            )
        else:
            self.log_error(f"  [{tag}] FAILED {side} {instrument.tradingsymbol}: {msg}")
        return success, parent_order

    # =========================================================================
    # LEG OPEN / CLOSE
    # =========================================================================

    def _open_leg(
        self,
        leg_name: str,
        side: str,
        instrument: Instrument,
        entry_ltp: float,
        datafeed_handler,
        dry_run: bool,
    ) -> bool:
        """Open one leg and create a StrategyPosition row."""
        lot_size = instrument.lot_size
        price = self._limit_price(side, entry_ltp)
        tag = f"HOTMS_{leg_name}"

        success, parent_order = self._place_order(
            instrument, side, lot_size, price,
            order_intent="ENTRY", tag=tag, dry_run=dry_run,
        )
        if not success:
            return False

        pos_type = "SHORT" if side == "SELL" else "LONG"
        now = timezone.now()
        pos = StrategyPosition.objects.create(
            trade_id=f"HOTMS_{self.strategy_obj.id}_{uuid.uuid4().hex[:8]}",
            strategy=self.strategy_obj,
            instrument=instrument,
            position_type=pos_type,
            status="OPEN",
            quantity=lot_size,
            entry_price=Decimal(str(entry_ltp)),
            entry_time=now,
            entry_parent_order=parent_order,
            last_price=Decimal(str(entry_ltp)),
            last_price_updated_at=now,
            strategy_metadata={
                "leg_name": leg_name,
                "strike": float(instrument.strike),
                "expiry": str(instrument.expiry),
                "option_type": instrument.instrument_type,
                "rebalance_idx": self.daily_rebalance_count,
                "initial_atm_straddle": self.initial_atm_straddle,
                "initial_forward": self.initial_forward,
            },
        )
        self.open_positions[leg_name] = pos
        self.log_info(
            f"  [{leg_name}] OPENED {side} strike={instrument.strike} "
            f"entry={entry_ltp:.2f} lot_size={lot_size}"
        )
        return True

    def _close_leg(
        self,
        leg_name: str,
        reason: str,
        datafeed_handler,
        dry_run: bool,
    ) -> bool:
        """Close one leg and update its StrategyPosition."""
        pos = self.open_positions.get(leg_name)
        if pos is None:
            return False

        instrument = pos.instrument
        lot_size = pos.quantity
        # SHORT positions are closed via BUY-to-cover; LONG via SELL.
        side = "BUY" if pos.position_type == "SHORT" else "SELL"

        exit_ltp = self._fetch_ltp(datafeed_handler, instrument)
        price = self._limit_price(side, exit_ltp) if exit_ltp is not None else None
        tag = f"HOTMS_{leg_name}_{reason}"

        if exit_ltp is None:
            self.log_warning(
                f"  [{leg_name}] EXIT ({reason}): LTP unavailable — placing MARKET order"
            )

        success, parent_order = self._place_order(
            instrument, side, lot_size, price,
            order_intent="EXIT", tag=tag, dry_run=dry_run,
        )
        if not success:
            return False

        pos.status = "CLOSED"
        pos.exit_time = timezone.now()
        pos.exit_parent_order = parent_order
        pos.unrealized_pnl = Decimal("0.00")
        if exit_ltp is not None:
            pos.exit_price = Decimal(str(exit_ltp))
            if pos.position_type == "SHORT":
                pnl = (float(pos.entry_price) - exit_ltp) * lot_size
            else:
                pnl = (exit_ltp - float(pos.entry_price)) * lot_size
            pos.realized_pnl = Decimal(str(pnl))

        meta = pos.strategy_metadata or {}
        meta["exit_reason"] = reason
        meta["exit_ltp"] = exit_ltp
        pos.strategy_metadata = meta
        pos.save()

        del self.open_positions[leg_name]
        self.log_info(
            f"  [{leg_name}] CLOSED ({reason}) "
            f"strike={instrument.strike} "
            f"entry={pos.entry_price} exit={exit_ltp}"
        )
        return True

    # =========================================================================
    # SHORT / HEDGE LIFECYCLE
    # =========================================================================

    def _open_short_strangle(
        self, datafeed_handler, dry_run: bool, spot: float, atm_straddle: float,
    ) -> bool:
        """Open the SHORT strangle at offset_mult × current straddle from current spot."""
        short_offset = self.offset_mult * atm_straddle
        self.short_call_strike = self._nearest_strike(spot + short_offset)
        self.short_put_strike  = self._nearest_strike(spot - short_offset)

        if self.short_call_strike is None or self.short_put_strike is None:
            self.log_error("Short strangle: could not resolve strikes")
            return False

        ce_inst = self._get_option_instrument(self.short_call_strike, "CE")
        pe_inst = self._get_option_instrument(self.short_put_strike, "PE")
        if not ce_inst or not pe_inst:
            self.log_error(
                f"Short strangle: missing instruments "
                f"(CE@{self.short_call_strike}={ce_inst}, PE@{self.short_put_strike}={pe_inst})"
            )
            return False

        ltps = self._fetch_multiple_ltp(datafeed_handler, [ce_inst, pe_inst])
        ce_ltp = ltps.get(ce_inst.instrument_token)
        pe_ltp = ltps.get(pe_inst.instrument_token)
        if not ce_ltp or not pe_ltp or ce_ltp <= 0 or pe_ltp <= 0:
            self.log_error(f"Short strangle: invalid LTPs ce={ce_ltp} pe={pe_ltp}")
            return False

        self.log_info(
            f"Opening SHORT strangle: CE {self.short_call_strike}@{ce_ltp:.2f}, "
            f"PE {self.short_put_strike}@{pe_ltp:.2f} "
            f"(offset={short_offset:.2f} from spot={spot:.2f})"
        )

        ok_ce = self._open_leg(LEG_SHORT_CE, "SELL", ce_inst, ce_ltp, datafeed_handler, dry_run)
        ok_pe = self._open_leg(LEG_SHORT_PE, "SELL", pe_inst, pe_ltp, datafeed_handler, dry_run)
        if not (ok_ce and ok_pe):
            self.log_error("Short strangle: one or both legs failed to open")
            return False

        self.short_open = True
        self.last_adjust_forward = spot
        return True

    def _close_short_strangle(
        self, reason: str, datafeed_handler, dry_run: bool,
    ) -> None:
        """Close both short legs."""
        for leg in SHORT_LEGS:
            if leg in self.open_positions:
                self._close_leg(leg, reason, datafeed_handler, dry_run)
        self.short_open = False
        self.short_call_strike = None
        self.short_put_strike = None

    def _open_hedge_strangle(
        self, datafeed_handler, dry_run: bool, initial_spot: float, initial_straddle: float,
    ) -> bool:
        """Open the LONG hedge at (offset_mult + hedge_mult) × initial_straddle from initial_spot."""
        hedge_offset = (self.offset_mult + self.hedge_mult) * initial_straddle
        self.hedge_call_strike = self._nearest_strike(initial_spot + hedge_offset)
        self.hedge_put_strike  = self._nearest_strike(initial_spot - hedge_offset)

        if self.hedge_call_strike is None or self.hedge_put_strike is None:
            self.log_error("Hedge: could not resolve strikes")
            return False

        ce_inst = self._get_option_instrument(self.hedge_call_strike, "CE")
        pe_inst = self._get_option_instrument(self.hedge_put_strike, "PE")
        if not ce_inst or not pe_inst:
            self.log_error(
                f"Hedge: missing instruments "
                f"(CE@{self.hedge_call_strike}={ce_inst}, PE@{self.hedge_put_strike}={pe_inst})"
            )
            return False

        ltps = self._fetch_multiple_ltp(datafeed_handler, [ce_inst, pe_inst])
        ce_ltp = ltps.get(ce_inst.instrument_token)
        pe_ltp = ltps.get(pe_inst.instrument_token)
        if not ce_ltp or not pe_ltp or ce_ltp <= 0 or pe_ltp <= 0:
            self.log_error(f"Hedge: invalid LTPs ce={ce_ltp} pe={pe_ltp}")
            return False

        self.log_info(
            f"Opening LONG hedge: CE {self.hedge_call_strike}@{ce_ltp:.2f}, "
            f"PE {self.hedge_put_strike}@{pe_ltp:.2f} "
            f"(offset={hedge_offset:.2f} from initial_spot={initial_spot:.2f})"
        )

        ok_ce = self._open_leg(LEG_HEDGE_CE, "BUY", ce_inst, ce_ltp, datafeed_handler, dry_run)
        ok_pe = self._open_leg(LEG_HEDGE_PE, "BUY", pe_inst, pe_ltp, datafeed_handler, dry_run)
        if not (ok_ce and ok_pe):
            self.log_error("Hedge: one or both legs failed to open")
            return False

        self.hedge_open = True
        return True

    def _close_hedge_strangle(
        self, reason: str, datafeed_handler, dry_run: bool,
    ) -> None:
        """Close both hedge legs."""
        for leg in HEDGE_LEGS:
            if leg in self.open_positions:
                self._close_leg(leg, reason, datafeed_handler, dry_run)
        self.hedge_open = False

    def _close_all_legs(
        self, reason: str, datafeed_handler, dry_run: bool,
    ) -> None:
        """Close short + hedge in one go (used on EOD)."""
        self._close_short_strangle(reason, datafeed_handler, dry_run)
        self._close_hedge_strangle(reason, datafeed_handler, dry_run)

    # =========================================================================
    # INITIAL ENTRY + REBALANCE
    # =========================================================================

    def _initial_entry(self, datafeed_handler, dry_run: bool) -> bool:
        """First entry of the day — locks initial values, opens hedge then short."""
        spot = self._fetch_spot_from_tbt()
        if spot is None:
            self.log_error("Initial entry: could not fetch spot")
            return False

        atm = self._fetch_atm_straddle(datafeed_handler, spot)
        if atm is None:
            return False
        _atm_strike, _ce_ltp, _pe_ltp, atm_straddle = atm

        # Lock initial values BEFORE opening either leg, so position metadata reflects them.
        self.initial_atm_straddle = atm_straddle
        self.initial_forward = spot
        self.last_adjust_forward = spot
        self.daily_rebalance_count = 0

        self.log_info(
            f"INITIAL ENTRY: spot={spot:.2f}, atm_straddle={atm_straddle:.2f}, "
            f"offset_mult={self.offset_mult}, rebal_mult={self.rebal_mult}, "
            f"hedge_mult={self.hedge_mult}"
        )

        if not self._open_hedge_strangle(datafeed_handler, dry_run, spot, atm_straddle):
            self.log_error("Initial entry: hedge failed")
            return False

        if not self._open_short_strangle(datafeed_handler, dry_run, spot, atm_straddle):
            self.log_error("Initial entry: short failed AFTER hedge opened — hedge will close at EOD")
            return False

        self._save_state()
        return True

    def _rebalance_short(self, datafeed_handler, dry_run: bool, spot: float) -> bool:
        """
        Close current short, then reopen at NEW current spot using NEW current ATM straddle.
        Hedge stays untouched.
        """
        atm = self._fetch_atm_straddle(datafeed_handler, spot)
        if atm is None:
            self.log_warning("Rebalance: ATM straddle fetch failed — keeping current short open")
            return False
        _atm_strike, _ce_ltp, _pe_ltp, current_straddle = atm

        self._close_short_strangle("REBALANCE", datafeed_handler, dry_run)
        self.daily_rebalance_count += 1

        if not self._open_short_strangle(datafeed_handler, dry_run, spot, current_straddle):
            self.log_error("Rebalance: failed to reopen short — strategy is now hedge-only")
            return False

        self._save_state()
        return True

    # =========================================================================
    # POSITION LAST-PRICE SYNC
    # =========================================================================

    def _update_position_last_prices(self, datafeed_handler) -> None:
        """Refresh last_price + unrealized_pnl on all open positions."""
        if not self.open_positions:
            return
        instruments = [pos.instrument for pos in self.open_positions.values()]
        ltps = self._fetch_multiple_ltp(datafeed_handler, instruments)
        now = timezone.now()
        for pos in self.open_positions.values():
            ltp = ltps.get(pos.instrument.instrument_token)
            if ltp is None:
                continue
            pos.last_price = Decimal(str(ltp))
            pos.last_price_updated_at = now
            if pos.position_type == "SHORT":
                pos.unrealized_pnl = (pos.entry_price - pos.last_price) * pos.quantity
            else:
                pos.unrealized_pnl = (pos.last_price - pos.entry_price) * pos.quantity
            pos.save(update_fields=["last_price", "last_price_updated_at", "unrealized_pnl"])

    # =========================================================================
    # STATE PERSISTENCE
    # =========================================================================

    def _get_state_path(self) -> str:
        code = self.strategy_obj.strategy_code.lower()
        return os.path.join(HOTMS_DUMP_DIR, f"{code}_{date.today().strftime('%Y%m%d')}.json")

    def _save_state(self) -> None:
        """Persist day-level state so we can recover after a restart."""
        path = self._get_state_path()
        os.makedirs(os.path.dirname(path), exist_ok=True)
        state = {
            "date": str(date.today()),
            "expiry": str(self.expiry) if self.expiry else None,
            "offset_mult": self.offset_mult,
            "rebal_mult": self.rebal_mult,
            "hedge_mult": self.hedge_mult,
            "entry_time": self.entry_time.strftime("%H:%M:%S"),
            "initial_atm_straddle": self.initial_atm_straddle,
            "initial_forward": self.initial_forward,
            "last_adjust_forward": self.last_adjust_forward,
            "daily_rebalance_count": self.daily_rebalance_count,
            "short_call_strike": float(self.short_call_strike) if self.short_call_strike else None,
            "short_put_strike":  float(self.short_put_strike)  if self.short_put_strike  else None,
            "hedge_call_strike": float(self.hedge_call_strike) if self.hedge_call_strike else None,
            "hedge_put_strike":  float(self.hedge_put_strike)  if self.hedge_put_strike  else None,
            "short_open": self.short_open,
            "hedge_open": self.hedge_open,
        }
        try:
            with open(path, "w") as f:
                json.dump(state, f)
        except Exception as e:
            self.log_error(f"Failed to save state: {e}")

    def _load_state(self) -> bool:
        """Restore day-level state from JSON. Returns True if loaded."""
        path = self._get_state_path()
        if not os.path.isfile(path):
            return False
        try:
            with open(path, "r") as f:
                state = json.load(f)
        except Exception as e:
            self.log_error(f"Failed to load state: {e}")
            return False

        if state.get("date") != str(date.today()):
            self.log_info("State file stale (wrong date). Ignoring.")
            return False

        self.initial_atm_straddle = state.get("initial_atm_straddle")
        self.initial_forward = state.get("initial_forward")
        self.last_adjust_forward = state.get("last_adjust_forward")
        self.daily_rebalance_count = int(state.get("daily_rebalance_count", 0) or 0)
        scs = state.get("short_call_strike"); sps = state.get("short_put_strike")
        hcs = state.get("hedge_call_strike"); hps = state.get("hedge_put_strike")
        self.short_call_strike = Decimal(str(scs)) if scs is not None else None
        self.short_put_strike  = Decimal(str(sps)) if sps is not None else None
        self.hedge_call_strike = Decimal(str(hcs)) if hcs is not None else None
        self.hedge_put_strike  = Decimal(str(hps)) if hps is not None else None
        # short_open / hedge_open are authoritatively re-derived from DB in bootstrap.

        self.log_info(
            f"RECOVERY: state restored — initial_straddle={self.initial_atm_straddle}, "
            f"initial_fwd={self.initial_forward}, last_adj={self.last_adjust_forward}, "
            f"rebalances={self.daily_rebalance_count}"
        )
        return True

    def _bootstrap_from_db(self) -> None:
        """Restore open positions from DB and re-derive short_open / hedge_open."""
        db_positions = StrategyPosition.objects.filter(
            strategy=self.strategy_obj, status="OPEN",
        ).select_related("instrument")

        if not db_positions.exists():
            self.log_info("No existing open positions. Fresh run.")
            return

        for pos in db_positions:
            meta = pos.strategy_metadata or {}
            leg_name = meta.get("leg_name")
            if leg_name in (LEG_SHORT_CE, LEG_SHORT_PE, LEG_HEDGE_CE, LEG_HEDGE_PE):
                self.open_positions[leg_name] = pos
                self.log_warning(
                    f"RECOVERY: restored {leg_name} @ entry={pos.entry_price} "
                    f"({pos.instrument.tradingsymbol})"
                )
            else:
                self.log_warning(
                    f"RECOVERY: skipping position {pos.trade_id} — unknown leg_name={leg_name}"
                )

        self.short_open = (
            LEG_SHORT_CE in self.open_positions and LEG_SHORT_PE in self.open_positions
        )
        self.hedge_open = (
            LEG_HEDGE_CE in self.open_positions and LEG_HEDGE_PE in self.open_positions
        )

        if self.short_open:
            self.short_call_strike = self.open_positions[LEG_SHORT_CE].instrument.strike
            self.short_put_strike  = self.open_positions[LEG_SHORT_PE].instrument.strike
        if self.hedge_open:
            self.hedge_call_strike = self.open_positions[LEG_HEDGE_CE].instrument.strike
            self.hedge_put_strike  = self.open_positions[LEG_HEDGE_PE].instrument.strike

    # =========================================================================
    # TIME UTILITIES
    # =========================================================================

    def _get_today_datetime(self, time_obj) -> datetime:
        today = timezone.now().date()
        naive_dt = datetime.combine(today, time_obj)
        return timezone.make_aware(naive_dt)

    def _wait_until(self, target_time: datetime) -> bool:
        while self.is_running:
            now = timezone.now()
            if now >= target_time:
                return True
            remaining = (target_time - now).total_seconds()
            if remaining > 60:
                self.log_info(
                    f"Waiting {int(remaining // 60)}m {int(remaining % 60)}s "
                    f"until {target_time.strftime('%H:%M:%S')}"
                )
                time.sleep(30)
            else:
                time.sleep(1)
        return False

    # =========================================================================
    # BASE STRATEGY INTERFACE
    # =========================================================================

    def verify(self) -> bool:
        if not self.datafeed_obj:
            self.log_error("No datafeed object provided.")
            return False
        if self.datafeed_obj.is_token_expired:
            self.log_warning("Datafeed token expired — attempting refresh...")
            from datafeed.rest.handler import DataFeedHandler
            handler = DataFeedHandler(self.datafeed_obj)
            if not handler.update_token():
                self.log_error("Failed to refresh datafeed token.")
                return False
        self.log_info("Verification passed.")
        return True

    def stop(self):
        self.log_info("Stopping HedgedOtmStrangle...")
        self.is_running = False

    # =========================================================================
    # MAIN RUN LOOP
    # =========================================================================

    def _resolve_params(self) -> None:
        """Pull params from strategy_params with backtest-grid defaults."""
        params = self.strategy_obj.strategy_params or {}
        self.offset_mult = float(params.get("offset_mult", DEFAULT_OFFSET_MULT))
        self.rebal_mult  = float(params.get("rebal_mult",  DEFAULT_REBAL_MULT))
        self.hedge_mult  = float(params.get("hedge_mult",  DEFAULT_HEDGE_MULT))
        self.poll_interval_secs = int(params.get("poll_interval_secs", DEFAULT_POLL_INTERVAL_SECS))

        et_str = params.get("entry_time")
        if et_str:
            try:
                self.entry_time = datetime.strptime(et_str, "%H:%M:%S").time()
            except ValueError:
                self.log_error(f"Invalid entry_time '{et_str}', using default {DEFAULT_ENTRY_TIME}")
                self.entry_time = DEFAULT_ENTRY_TIME
        else:
            self.entry_time = DEFAULT_ENTRY_TIME

    def run(self):
        params = self.strategy_obj.strategy_params or {}
        dry_run = bool(params.get("dry_run", False))
        self._resolve_params()

        self.log_info("=" * 60)
        self.log_info("Starting HedgedOtmStrangle (Weekly Expiry Day Only)")
        self.log_info(
            f"offset_mult={self.offset_mult} rebal_mult={self.rebal_mult} "
            f"hedge_mult={self.hedge_mult}"
        )
        self.log_info(
            f"entry={self.entry_time} exit={EXIT_TIME} poll={self.poll_interval_secs}s"
        )
        self.log_info(f"Mode: {'DRY-RUN' if dry_run else 'LIVE'}")
        self.log_info("=" * 60)

        if not self.verify():
            self.log_error("Verification failed. Exiting.")
            return

        self.is_running = True

        from datafeed.rest.handler import DataFeedHandler
        datafeed_handler = DataFeedHandler(self.datafeed_obj)

        # ── Step 1: Resolve expiry — must equal today (weekly expiry day) ─
        cw_expiry = self._get_nearest_option_expiry()
        if cw_expiry is None:
            self.log_error("No NIFTY option expiry found. Exiting.")
            self.is_running = False
            return
        if cw_expiry != date.today():
            self.log_info(
                f"Today ({date.today()}) is NOT weekly expiry day "
                f"(next expiry: {cw_expiry}). Strategy will not run today."
            )
            self.is_running = False
            return

        self.expiry = cw_expiry
        self.log_info(f"Weekly expiry day confirmed: {self.expiry}")

        # ── Step 2: Cache available strikes for the expiry ────────────────
        self._load_available_strikes(self.expiry)
        if not self._available_strikes:
            self.log_error(f"No strikes found for expiry {self.expiry}. Exiting.")
            self.is_running = False
            return
        self.log_info(f"Loaded {len(self._available_strikes)} strikes for expiry {self.expiry}")

        # ── Step 3: Recover from prior crash (DB + JSON state) ────────────
        self._bootstrap_from_db()
        self._load_state()

        # ── Step 4: Wait for entry time (skip if we already have positions) ─
        if not (self.short_open or self.hedge_open):
            entry_dt = self._get_today_datetime(self.entry_time)
            if timezone.now() < entry_dt:
                self.log_info(f"Waiting for entry time: {entry_dt.strftime('%H:%M:%S')}")
                if not self._wait_until(entry_dt):
                    return
            if not self.is_running:
                return

            # ── Step 5: Initial entry (hedge + short) ─────────────────────
            if not self._initial_entry(datafeed_handler, dry_run):
                self.log_error("Initial entry failed. Exiting.")
                self.is_running = False
                return

        # ── Step 6: Monitor + rebalance loop ──────────────────────────────
        exit_dt = self._get_today_datetime(EXIT_TIME)
        self.log_info("Entering monitoring loop (rebalance + EOD exit)...")

        while self.is_running:
            now = timezone.now()
            now_t = timezone.localtime(now).time()

            # ── EOD: close everything (mirror of backtest's EXIT_TIME branch) ─
            if now >= exit_dt:
                self.log_info(">>> EXIT TIME REACHED <<<")
                self._close_all_legs("EOD", datafeed_handler, dry_run)
                break

            try:
                spot = self._fetch_spot_from_tbt()
                if spot is None:
                    self.log_warning("Spot fetch failed; skipping tick")
                    time.sleep(self.poll_interval_secs)
                    continue

                self._update_position_last_prices(datafeed_handler)

                # ── Rebalance trigger (faithful to backtest line 211-213) ──
                if (
                    self.short_open
                    and self.initial_atm_straddle
                    and self.initial_atm_straddle > 0.1
                    and self.last_adjust_forward is not None
                ):
                    move_in_straddles = (
                        abs(spot - self.last_adjust_forward) / self.initial_atm_straddle
                    )
                    self.log_debug(
                        f"Tick: spot={spot:.2f} last_adj={self.last_adjust_forward:.2f} "
                        f"move_in_straddles={move_in_straddles:.3f} threshold={self.rebal_mult}"
                    )
                    if move_in_straddles >= self.rebal_mult:
                        self.log_info(
                            f"REBALANCE TRIGGERED: move={move_in_straddles:.3f} straddles "
                            f">= {self.rebal_mult} (spot={spot:.2f}, "
                            f"last_adj={self.last_adjust_forward:.2f}, "
                            f"initial_straddle={self.initial_atm_straddle:.2f})"
                        )
                        self._rebalance_short(datafeed_handler, dry_run, spot)

            except Exception as e:
                self.log_exception(f"Main loop error: {e}")

            time.sleep(self.poll_interval_secs)

        # EOD safety net
        now_t = timezone.localtime(timezone.now()).time()
        if (self.short_open or self.hedge_open) and now_t >= EXIT_TIME:
            self.log_warning("EOD safety net: forcing close of any remaining legs")
            self._close_all_legs("EOD_FORCE", datafeed_handler, dry_run)
        elif self.short_open or self.hedge_open:
            self.log_info(
                f"Loop exited but NOT EOD — keeping "
                f"short_open={self.short_open} hedge_open={self.hedge_open} "
                f"in DB for recovery"
            )

        self.is_running = False
        self.log_info("HedgedOtmStrangle completed.")
