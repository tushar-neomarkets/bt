""" Put Bear Spread — NIFTY Weekly Expiry Day Only

Mirrors helpers/put-spread-helpers/put-spread-backtest.py. The backtest does a
parameter sweep; production runs ONE fixed combo (configurable via
strategy_params).

Per backtest:
1. Runs only on weekly expiry days (CW expiry == today).
2. PCR filter (full-chain or ATM OI/volume) — single check at OPEN bar
   ("open" timing) or rolling check until ENTRY_CUTOFF ("intraday").
3. On trigger:
       forward       = put-call parity (median over middle strikes)
       atm_strike    = nearest strike to forward
       straddle_px   = CE_atm + PE_atm
       short_strike  = round_to_50(forward - N_STRADDLES * straddle_px)
       long_strike   = atm_strike + LONG_OFFSET strikes (in LONG_DIRECTION)
       BUY long PE, SELL short PE.
4. Exit priority every poll cycle (mirror of backtest 3m bar loop):
       1. HARD_EXIT_T  (absolute)
       2. TIME_STOP    (regardless of P&L)
       3. SL  : spread <= net_debit * (1 - sl_pct)
       4. TP  : spread >= net_debit * (1 + tp_mult)
   spread = long_PE_LTP - short_PE_LTP
"""

import json
import math
import os
import time
import uuid
from datetime import date, datetime, time as dt_time
from decimal import Decimal
from typing import Optional

import requests as http_requests

from django.db.models import Min
from django.utils import timezone

from instruments.models import BrokerInstrument, Instrument
from orders.order_manager import order_manager
from strategy.models import StrategyPosition
from strategy.strategy_class.base_strategy import BaseStrategy


# =============================================================================
# CONSTANTS
# =============================================================================

TICKER = "NIFTY"
STRIKE_STEP = 50

# ── Time gates (match backtest) ──────────────────────────────────────────────
OPEN_BAR     = dt_time(9, 16, 59)    # used when PCR_TIMING = "open"
ENTRY_CUTOFF = dt_time(14, 59, 59)   # last bar eligible for entry (intraday)
HARD_EXIT_T  = dt_time(15, 15, 59)   # absolute last exit

# ── Strategy parameter defaults (one combo from sweep grid) ──────────────────
DEFAULT_PCR_MODE       = "oi"        # "oi" | "volume" | "both" | "either" | "none"
DEFAULT_PCR_THRESHOLD  = 1.0
DEFAULT_PCR_STRIKES    = "all"       # "all" | "atm"
DEFAULT_PCR_TIMING     = "open"      # "open" | "intraday"
DEFAULT_N_STRADDLES    = 2.0
DEFAULT_LONG_OFFSET    = 0
DEFAULT_LONG_DIRECTION = "otm"       # "otm" (lower strike) | "itm" (higher strike)
DEFAULT_SL_PCT         = 0.50        # set to None to disable
DEFAULT_TP_MULT        = 2.0         # set to None to disable
DEFAULT_TIME_STOP      = dt_time(15, 14, 59)

DEFAULT_POLL_INTERVAL_SECS = 20

PRICE_OFFSET = Decimal("0.05")
RISK_FREE_RATE = 0.07

_BASE_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
PUT_SPREAD_DUMP_DIR = os.path.join(_BASE_DIR, 'dump', 'put_spread')

LEG_LONG  = "PUT_LONG"     # BUY  PE
LEG_SHORT = "PUT_SHORT"    # SELL PE


def _round_to_strike(value: float, step: int = STRIKE_STEP) -> float:
    """Mirror of backtest round_to_strike (line 183-184)."""
    return float(round(value / step) * step)


class PutBearSpread(BaseStrategy):
    """Bear put spread on NIFTY weekly-expiry day, gated by PCR."""

    def __init__(self, strategy_obj, datafeed_obj, ws_manager=None):
        super().__init__(strategy_obj, datafeed_obj, ws_manager)
        self.is_running = False

        # ── Resolved params ──────────────────────────────────────────
        self.pcr_mode: str       = DEFAULT_PCR_MODE
        self.pcr_threshold: float = DEFAULT_PCR_THRESHOLD
        self.pcr_strikes: str    = DEFAULT_PCR_STRIKES
        self.pcr_timing: str     = DEFAULT_PCR_TIMING
        self.n_straddles: float  = DEFAULT_N_STRADDLES
        self.long_offset: int    = DEFAULT_LONG_OFFSET
        self.long_direction: str = DEFAULT_LONG_DIRECTION
        self.sl_pct: Optional[float]  = DEFAULT_SL_PCT
        self.tp_mult: Optional[float] = DEFAULT_TP_MULT
        self.time_stop: Optional[dt_time] = DEFAULT_TIME_STOP
        self.poll_interval_secs: int = DEFAULT_POLL_INTERVAL_SECS

        # ── Day-level state ──────────────────────────────────────────
        self.expiry: Optional[date] = None
        self.long_strike: Optional[Decimal] = None
        self.short_strike: Optional[Decimal] = None
        self.long_entry_prem: float = 0.0
        self.short_entry_prem: float = 0.0
        self.net_debit: float = 0.0
        self.forward_price: float = 0.0
        self.exited: bool = False

        # ── DB handles ───────────────────────────────────────────────
        self.open_positions: dict[str, StrategyPosition] = {}

        # ── Cached strike list ───────────────────────────────────────
        self._available_strikes: list[Decimal] = []

        self.log_info(
            f"Initializing {self.strategy_obj.strategy_code} — "
            f"{self.strategy_obj.strategy_name}"
        )

    # =========================================================================
    # INSTRUMENT LOOKUPS
    # =========================================================================

    def _get_nearest_option_expiry(self) -> Optional[date]:
        today = date.today()
        result = Instrument.objects.filter(
            name=TICKER, exchange="NFO",
            instrument_type__in=["CE", "PE"],
            is_active=True, expiry__gte=today,
        ).aggregate(min_expiry=Min("expiry"))
        return result.get("min_expiry")

    def _load_available_strikes(self, expiry: date) -> None:
        strikes = (
            Instrument.objects.filter(
                name=TICKER, exchange="NFO",
                instrument_type__in=["CE", "PE"],
                expiry=expiry, is_active=True,
            )
            .values_list("strike", flat=True)
            .distinct()
        )
        self._available_strikes = sorted([s for s in strikes if s is not None])

    def _nearest_strike(self, target: float) -> Optional[Decimal]:
        if not self._available_strikes:
            return None
        return min(self._available_strikes, key=lambda s: abs(float(s) - target))

    def _get_option_instrument(
        self, strike: Decimal, option_type: str
    ) -> Optional[Instrument]:
        return Instrument.objects.filter(
            name=TICKER, exchange="NFO",
            instrument_type=option_type, expiry=self.expiry,
            strike=strike, is_active=True,
        ).first()

    def _get_all_option_instruments(self, option_type: str) -> list[Instrument]:
        return list(
            Instrument.objects.filter(
                name=TICKER, exchange="NFO",
                instrument_type=option_type, expiry=self.expiry,
                is_active=True,
            ).order_by("strike")
        )

    # =========================================================================
    # DATA FEED — LTP
    # =========================================================================

    def _fetch_ltp(self, datafeed_handler, instrument: Instrument) -> Optional[float]:
        attempt = 0
        while self.is_running:
            attempt += 1
            try:
                self.datafeed_obj.refresh_from_db()
                from datafeed.rest.handler import DataFeedHandler
                datafeed_handler = DataFeedHandler(self.datafeed_obj)
                response = datafeed_handler.get_multiple_ltp([instrument])
                if response and "data" in response:
                    for item in response["data"].get("ltp_list", []):
                        if item.get("instrument_token") == instrument.instrument_token:
                            return item.get("ltp")
                return None
            except Exception as e:
                status = getattr(getattr(e, "response", None), "status_code", None)
                is_auth_error = status in (400, 401) or "Unauthorized" in str(e)
                if is_auth_error:
                    self.log_warning(f"LTP fetch failed (attempt {attempt}: {e}) — refreshing token...")
                    try:
                        from datafeed.rest.handler import DataFeedHandler
                        DataFeedHandler(self.datafeed_obj).update_token()
                        self.datafeed_obj.refresh_from_db()
                    except Exception as refresh_err:
                        self.log_error(f"Token refresh failed: {refresh_err}")
                    time.sleep(2)
                    continue
                self.log_error(f"Error fetching LTP for {instrument}: {e}")
                return None
        return None

    def _fetch_multiple_ltp(
        self, datafeed_handler, instruments: list[Instrument]
    ) -> dict[int, float]:
        if not instruments:
            return {}
        attempt = 0
        while self.is_running:
            attempt += 1
            try:
                self.datafeed_obj.refresh_from_db()
                from datafeed.rest.handler import DataFeedHandler
                datafeed_handler = DataFeedHandler(self.datafeed_obj)
                response = datafeed_handler.get_multiple_ltp(instruments)
                result: dict[int, float] = {}
                if response and "data" in response:
                    for item in response["data"].get("ltp_list", []):
                        token = item.get("instrument_token")
                        ltp = item.get("ltp")
                        if token and ltp:
                            result[token] = ltp
                return result
            except Exception as e:
                status = getattr(getattr(e, "response", None), "status_code", None)
                is_auth_error = status in (400, 401) or "Unauthorized" in str(e)
                if is_auth_error:
                    self.log_warning(f"Multi LTP fetch failed (attempt {attempt}: {e}) — refreshing token...")
                    try:
                        from datafeed.rest.handler import DataFeedHandler
                        DataFeedHandler(self.datafeed_obj).update_token()
                        self.datafeed_obj.refresh_from_db()
                    except Exception as refresh_err:
                        self.log_error(f"Token refresh failed: {refresh_err}")
                    time.sleep(2)
                    continue
                self.log_error(f"Error fetching multiple LTP: {e}")
                return {}
        return {}

    # =========================================================================
    # DATA FEED — XTS QUOTES (LTP + OI + VOLUME) for PCR
    # =========================================================================

    def _xts_request(self, instrument_payloads: list[dict], message_code: int) -> dict:
        """Direct XTS quotes call. Mirrors gex_regime_trader._xts_request."""
        account = self.datafeed_obj
        if account.extra_data and account.extra_data.get("hostlookup"):
            base_url = account.extra_data.get("connectionString", "")
        else:
            base_url = account.base_url

        url = f"{base_url}/apimarketdata/instruments/quotes"
        payload = {
            "instruments": instrument_payloads,
            "xtsMessageCode": message_code,
            "publishFormat": "JSON",
        }

        attempt = 0
        while self.is_running:
            attempt += 1
            headers = {"Content-Type": "application/json", "Authorization": account.access_token}
            resp = http_requests.post(url, headers=headers, data=json.dumps(payload))
            if resp.status_code == 400 and "e-session-0007" in resp.text:
                self.log_warning(f"Invalid Token (attempt {attempt}) — refreshing token...")
                try:
                    from datafeed.rest.handler import DataFeedHandler
                    DataFeedHandler(account).update_token()
                    account.refresh_from_db()
                except Exception as e:
                    self.log_error(f"Token refresh failed: {e}")
                time.sleep(2)
                continue
            resp.raise_for_status()
            try:
                return resp.json()
            except (json.JSONDecodeError, ValueError):
                self.log_warning(f"Non-JSON response (attempt {attempt}): {resp.text[:200]}")
                time.sleep(2)
                continue
        return {}

    def _fetch_chain_quotes(
        self, instruments: list[Instrument]
    ) -> dict[int, dict]:
        """
        Touchline (1501) for LTP + OI (1510) for OpenInterest, merged.
        Returns {instrument_token: {ltp, oi}}.
        """
        XTS_TOUCHLINE = 1501
        XTS_OI = 1510

        result: dict[int, dict] = {}
        if not instruments:
            return result

        broker_name = self.datafeed_obj.provider.provider_name.upper()
        token_list = [inst.instrument_token for inst in instruments]
        bi_map = BrokerInstrument.bulk_get_by_instruments_and_broker(token_list, broker_name)
        if not bi_map:
            self.log_error("No broker instrument mappings found for chain.")
            return result

        payloads = []
        xts_id_to_inst: dict[int, Instrument] = {}
        for inst in instruments:
            bi = bi_map.get(inst.instrument_token)
            if bi:
                extra = bi.extra_data or {}
                payloads.append({
                    "exchangeSegment": extra.get("exchange_segment_code", 2),
                    "exchangeInstrumentID": int(bi.broker_token),
                })
                xts_id_to_inst[int(bi.broker_token)] = inst
        if not payloads:
            return result

        # 1. Touchline → LTP
        try:
            data = self._xts_request(payloads, XTS_TOUCHLINE)
            if data.get("type") == "success" and "result" in data:
                for qs in data["result"].get("listQuotes", []):
                    qd = json.loads(qs)
                    xts_id = int(qd.get("ExchangeInstrumentID", 0))
                    inst = xts_id_to_inst.get(xts_id)
                    if inst:
                        result[inst.instrument_token] = {
                            "ltp": float(qd.get("LastTradedPrice", 0)),
                            "oi": 0,
                            "volume": float(qd.get("TotalTradedQuantity", 0) or 0),
                        }
        except Exception as e:
            self.log_error(f"Error fetching LTP (1501): {e}")
            return result

        # 2. OI
        try:
            data = self._xts_request(payloads, XTS_OI)
            if data.get("type") == "success" and "result" in data:
                for qs in data["result"].get("listQuotes", []):
                    qd = json.loads(qs)
                    xts_id = int(qd.get("ExchangeInstrumentID", 0))
                    inst = xts_id_to_inst.get(xts_id)
                    if inst and inst.instrument_token in result:
                        result[inst.instrument_token]["oi"] = int(qd.get("OpenInterest", 0))
        except Exception as e:
            self.log_error(f"Error fetching OI (1510): {e}")

        return result

    # =========================================================================
    # FORWARD (PUT-CALL PARITY) — adapted from nifty_straddle.py
    # =========================================================================

    def _forward_at_strike(
        self, strike: Decimal, ce_quotes: dict, pe_quotes: dict
    ) -> Optional[float]:
        ce = self._get_option_instrument(strike, "CE")
        pe = self._get_option_instrument(strike, "PE")
        if not ce or not pe:
            return None
        ce_q = ce_quotes.get(ce.instrument_token)
        pe_q = pe_quotes.get(pe.instrument_token)
        if not ce_q or not pe_q:
            return None
        ce_ltp = ce_q.get("ltp")
        pe_ltp = pe_q.get("ltp")
        if not ce_ltp or not pe_ltp:
            return None
        # F = K + (C - P) / discount.  Short-tenor: discount ≈ 1.
        tte_days = max(
            (datetime.combine(self.expiry, datetime.min.time()) - datetime.now()).total_seconds() / 86400,
            1e-6,
        )
        discount = math.exp(-RISK_FREE_RATE * tte_days / 365)
        return float(strike) + (ce_ltp - pe_ltp) / discount

    def _calculate_forward(
        self, ce_quotes: dict, pe_quotes: dict
    ) -> Optional[float]:
        """Median of forwards computed at the 5 middle strikes."""
        if not self._available_strikes:
            return None
        mid = len(self._available_strikes) // 2
        sample = self._available_strikes[max(0, mid - 2): min(len(self._available_strikes), mid + 3)]
        forwards = []
        for k in sample:
            f = self._forward_at_strike(k, ce_quotes, pe_quotes)
            if f:
                forwards.append(f)
        if not forwards:
            return None
        forwards.sort()
        return forwards[len(forwards) // 2]

    # =========================================================================
    # PCR — mirrors backtest compute_pcr_at + pcr_filter_passes
    # =========================================================================

    def _compute_pcr(
        self, ce_instruments: list[Instrument], pe_instruments: list[Instrument],
        ce_quotes: dict, pe_quotes: dict, atm_strike: Decimal,
    ) -> dict:
        if self.pcr_strikes == "atm":
            ce_pool = [i for i in ce_instruments if i.strike == atm_strike]
            pe_pool = [i for i in pe_instruments if i.strike == atm_strike]
        else:
            ce_pool = ce_instruments
            pe_pool = pe_instruments

        def _sum(pool: list[Instrument], quotes: dict, key: str) -> float:
            total = 0.0
            for inst in pool:
                q = quotes.get(inst.instrument_token)
                if q and q.get(key) is not None:
                    total += float(q[key])
            return total

        ce_oi  = _sum(ce_pool, ce_quotes, "oi")
        pe_oi  = _sum(pe_pool, pe_quotes, "oi")
        ce_vol = _sum(ce_pool, ce_quotes, "volume")
        pe_vol = _sum(pe_pool, pe_quotes, "volume")

        oi_pcr  = (pe_oi  / ce_oi)  if ce_oi  > 0 else None
        vol_pcr = (pe_vol / ce_vol) if ce_vol > 0 else None
        return {"oi_pcr": oi_pcr, "volume_pcr": vol_pcr}

    def _pcr_filter_passes(self, pcr: dict) -> bool:
        if self.pcr_mode == "none":
            return True
        oi_ok  = pcr["oi_pcr"]     is not None and pcr["oi_pcr"]     < self.pcr_threshold
        vol_ok = pcr["volume_pcr"] is not None and pcr["volume_pcr"] < self.pcr_threshold
        if self.pcr_mode == "oi":     return oi_ok
        if self.pcr_mode == "volume": return vol_ok
        if self.pcr_mode == "both":   return oi_ok and vol_ok
        if self.pcr_mode == "either": return oi_ok or  vol_ok
        raise ValueError(f"Unknown pcr_mode: {self.pcr_mode!r}")

    # =========================================================================
    # ORDER PLACEMENT
    # =========================================================================

    def _limit_price(self, side: str, ltp: float) -> Decimal:
        base = Decimal(str(ltp))
        return base + PRICE_OFFSET if side == "SELL" else base - PRICE_OFFSET

    def _place_order(
        self,
        instrument: Instrument,
        side: str,
        quantity: int,
        price: Optional[Decimal],
        order_intent: str,
        tag: str = "",
        dry_run: bool = False,
    ) -> tuple[bool, object]:
        order_type = "LIMIT" if price is not None else "MARKET"
        price_str = str(price) if price is not None else "MKT"

        if dry_run:
            self.log_info(
                f"  [DRY-RUN][{tag}] {order_intent} {side} {quantity} x"
                f" {instrument.tradingsymbol} | {order_type} @ {price_str}"
                f" | NRML | expiry={instrument.expiry}"
            )
            return True, None

        success, msg, parent_order, _ = order_manager.create_and_execute_order(
            strategy=self.strategy_obj,
            instrument=instrument,
            side=side,
            quantity=quantity,
            order_type=order_type,
            product_type="NRML",
            price=price,
            order_intent=order_intent,
            metadata={
                "strategy_code": self.strategy_obj.strategy_code,
                "instrument_type": instrument.instrument_type,
                "stock_name": instrument.name,
                "tag": tag,
            },
        )
        if success:
            self.log_info(f"  [{tag}] {side} {quantity} x {instrument.tradingsymbol} @ {price_str}")
        else:
            self.log_error(f"  [{tag}] FAILED {side} {instrument.tradingsymbol}: {msg}")
        return success, parent_order

    # =========================================================================
    # LEG OPEN / CLOSE
    # =========================================================================

    def _open_leg(
        self, leg_name: str, side: str, instrument: Instrument,
        entry_ltp: float, dry_run: bool, meta_extra: Optional[dict] = None,
    ) -> bool:
        lot_size = instrument.lot_size
        price = self._limit_price(side, entry_ltp)
        tag = f"PBSPRD_{leg_name}"

        success, parent_order = self._place_order(
            instrument, side, lot_size, price,
            order_intent="ENTRY", tag=tag, dry_run=dry_run,
        )
        if not success:
            return False

        pos_type = "SHORT" if side == "SELL" else "LONG"
        now = timezone.now()
        meta = {
            "leg_name": leg_name,
            "strike": float(instrument.strike),
            "expiry": str(instrument.expiry),
            "option_type": instrument.instrument_type,
        }
        if meta_extra:
            meta.update(meta_extra)

        pos = StrategyPosition.objects.create(
            trade_id=f"PBSPRD_{self.strategy_obj.id}_{uuid.uuid4().hex[:8]}",
            strategy=self.strategy_obj,
            instrument=instrument,
            position_type=pos_type,
            status="OPEN",
            quantity=lot_size,
            entry_price=Decimal(str(entry_ltp)),
            entry_time=now,
            entry_parent_order=parent_order,
            last_price=Decimal(str(entry_ltp)),
            last_price_updated_at=now,
            strategy_metadata=meta,
        )
        self.open_positions[leg_name] = pos
        self.log_info(
            f"  [{leg_name}] OPENED {side} strike={instrument.strike} "
            f"entry={entry_ltp:.2f} lot_size={lot_size}"
        )
        return True

    def _close_leg(
        self, leg_name: str, reason: str, datafeed_handler, dry_run: bool,
    ) -> bool:
        pos = self.open_positions.get(leg_name)
        if pos is None:
            return False

        instrument = pos.instrument
        lot_size = pos.quantity
        side = "BUY" if pos.position_type == "SHORT" else "SELL"

        exit_ltp = self._fetch_ltp(datafeed_handler, instrument)
        price = self._limit_price(side, exit_ltp) if exit_ltp is not None else None
        tag = f"PBSPRD_{leg_name}_{reason}"

        if exit_ltp is None:
            self.log_warning(
                f"  [{leg_name}] EXIT ({reason}): LTP unavailable — placing MARKET order"
            )

        success, parent_order = self._place_order(
            instrument, side, lot_size, price,
            order_intent="EXIT", tag=tag, dry_run=dry_run,
        )
        if not success:
            return False

        pos.status = "CLOSED"
        pos.exit_time = timezone.now()
        pos.exit_parent_order = parent_order
        pos.unrealized_pnl = Decimal("0.00")
        if exit_ltp is not None:
            pos.exit_price = Decimal(str(exit_ltp))
            if pos.position_type == "SHORT":
                pnl = (float(pos.entry_price) - exit_ltp) * lot_size
            else:
                pnl = (exit_ltp - float(pos.entry_price)) * lot_size
            pos.realized_pnl = Decimal(str(pnl))

        meta = pos.strategy_metadata or {}
        meta["exit_reason"] = reason
        meta["exit_ltp"] = exit_ltp
        pos.strategy_metadata = meta
        pos.save()

        del self.open_positions[leg_name]
        self.log_info(
            f"  [{leg_name}] CLOSED ({reason}) "
            f"strike={instrument.strike} entry={pos.entry_price} exit={exit_ltp}"
        )
        return True

    def _close_all_legs(self, reason: str, datafeed_handler, dry_run: bool) -> None:
        for leg in (LEG_LONG, LEG_SHORT):
            if leg in self.open_positions:
                self._close_leg(leg, reason, datafeed_handler, dry_run)
        self.exited = True
        self._save_state()

    # =========================================================================
    # ENTRY (PCR check + spread setup)
    # =========================================================================

    def _resolve_long_strike(
        self, atm_strike: Decimal
    ) -> Optional[Decimal]:
        """Mirror of backtest resolve_long_strike (lines 191-217)."""
        if self.long_offset == 0:
            return atm_strike
        if atm_strike not in self._available_strikes:
            return None
        idx = self._available_strikes.index(atm_strike)
        if self.long_direction == "otm":
            target_idx = idx - self.long_offset      # lower strike (more OTM put)
        else:
            target_idx = idx + self.long_offset      # higher strike (more ITM put)
        if target_idx < 0 or target_idx >= len(self._available_strikes):
            return None
        return self._available_strikes[target_idx]

    def _try_entry(self, datafeed_handler, dry_run: bool) -> bool:
        """
        Single PCR + entry attempt. Returns True if positions opened, False if
        PCR rejected (or data missing — caller decides whether to retry).
        Mirrors backtest process_day from line 681 onwards.
        """
        ce_instruments = self._get_all_option_instruments("CE")
        pe_instruments = self._get_all_option_instruments("PE")
        if not ce_instruments or not pe_instruments:
            self.log_error("Entry: empty CE or PE chain")
            return False

        ce_quotes = self._fetch_chain_quotes(ce_instruments)
        pe_quotes = self._fetch_chain_quotes(pe_instruments)
        if not ce_quotes or not pe_quotes:
            self.log_error("Entry: chain quotes empty")
            return False

        # Forward + ATM
        forward = self._calculate_forward(ce_quotes, pe_quotes)
        if forward is None:
            self.log_error("Entry: forward calc failed")
            return False
        atm_strike = self._nearest_strike(forward)
        if atm_strike is None:
            self.log_error("Entry: ATM strike not resolved")
            return False

        # Straddle price at ATM
        ce_atm = self._get_option_instrument(atm_strike, "CE")
        pe_atm = self._get_option_instrument(atm_strike, "PE")
        if not ce_atm or not pe_atm:
            self.log_error(f"Entry: ATM instruments missing at {atm_strike}")
            return False
        ce_atm_q = ce_quotes.get(ce_atm.instrument_token)
        pe_atm_q = pe_quotes.get(pe_atm.instrument_token)
        if not ce_atm_q or not pe_atm_q:
            self.log_error("Entry: ATM quotes missing")
            return False
        straddle_px = float(ce_atm_q["ltp"]) + float(pe_atm_q["ltp"])
        self.log_info(
            f"  forward={forward:.2f} atm={atm_strike} "
            f"ce={ce_atm_q['ltp']:.2f} pe={pe_atm_q['ltp']:.2f} straddle={straddle_px:.2f}"
        )

        # PCR
        pcr = self._compute_pcr(ce_instruments, pe_instruments, ce_quotes, pe_quotes, atm_strike)
        oi_str  = f"{pcr['oi_pcr']:.4f}"     if pcr["oi_pcr"]     is not None else "n/a"
        vol_str = f"{pcr['volume_pcr']:.4f}" if pcr["volume_pcr"] is not None else "n/a"
        self.log_info(
            f"  PCR check: oi={oi_str} vol={vol_str} (need <{self.pcr_threshold}, mode={self.pcr_mode})"
        )
        if not self._pcr_filter_passes(pcr):
            return False

        # Strikes
        long_strike = self._resolve_long_strike(atm_strike)
        if long_strike is None:
            self.log_error(f"Entry: long strike unresolved (offset={self.long_offset} {self.long_direction})")
            return False
        short_strike_val = _round_to_strike(forward - self.n_straddles * straddle_px)
        short_strike = self._nearest_strike(short_strike_val)
        if short_strike is None:
            self.log_error("Entry: short strike unresolved")
            return False
        if short_strike >= long_strike:
            self.log_warning(
                f"Entry: invalid spread (short={short_strike} >= long={long_strike}) — skipping"
            )
            return False

        # Premiums
        long_pe = self._get_option_instrument(long_strike, "PE")
        short_pe = self._get_option_instrument(short_strike, "PE")
        if not long_pe or not short_pe:
            self.log_error("Entry: PE instruments missing for chosen strikes")
            return False
        long_q = pe_quotes.get(long_pe.instrument_token)
        short_q = pe_quotes.get(short_pe.instrument_token)
        if not long_q or not short_q or not long_q.get("ltp") or not short_q.get("ltp"):
            self.log_error("Entry: PE quotes missing for chosen strikes")
            return False
        long_prem  = float(long_q["ltp"])
        short_prem = float(short_q["ltp"])
        net_debit  = long_prem - short_prem
        if net_debit <= 0:
            self.log_warning(f"Entry: non-positive net_debit={net_debit:.2f} — skipping")
            return False

        self.log_info(
            f"ENTRY: long PE {long_strike}@{long_prem:.2f}  short PE {short_strike}@{short_prem:.2f}  "
            f"net_debit={net_debit:.2f}"
        )
        if self.sl_pct is not None:
            self.log_info(f"  SL level = {net_debit*(1-self.sl_pct):.2f}")
        if self.tp_mult is not None:
            self.log_info(f"  TP level = {net_debit*(1+self.tp_mult):.2f}")

        meta = {
            "forward": forward,
            "atm_strike": float(atm_strike),
            "straddle_px": straddle_px,
            "net_debit": net_debit,
            "sl_pct": self.sl_pct,
            "tp_mult": self.tp_mult,
        }
        ok_long  = self._open_leg(LEG_LONG,  "BUY",  long_pe,  long_prem,  dry_run, meta_extra=meta)
        ok_short = self._open_leg(LEG_SHORT, "SELL", short_pe, short_prem, dry_run, meta_extra=meta)
        if not (ok_long and ok_short):
            self.log_error("Entry: one or both legs failed")
            return False

        self.long_strike       = long_strike
        self.short_strike      = short_strike
        self.long_entry_prem   = long_prem
        self.short_entry_prem  = short_prem
        self.net_debit         = net_debit
        self.forward_price     = forward
        self._save_state()
        return True

    # =========================================================================
    # EXIT MONITOR — mirrors backtest monitor_exit
    # =========================================================================

    def _check_exit(
        self, datafeed_handler, dry_run: bool
    ) -> bool:
        """
        Evaluate exit conditions in priority order:
          1. HARD_EXIT_T  (handled in run loop)
          2. TIME_STOP
          3. SL
          4. TP
        Updates last_price + unrealized_pnl on both legs as a side effect.
        Returns True if exit fired.
        """
        long_pos  = self.open_positions.get(LEG_LONG)
        short_pos = self.open_positions.get(LEG_SHORT)
        if not long_pos or not short_pos:
            return False

        # Time stop (regardless of P&L) — backtest line 558-561
        if self.time_stop is not None:
            now_t = timezone.localtime(timezone.now()).time()
            if now_t >= self.time_stop:
                self.log_info(f"TIME_STOP hit @ {now_t} — closing spread")
                self._close_all_legs("TIME_STOP", datafeed_handler, dry_run)
                return True

        ltps = self._fetch_multiple_ltp(
            datafeed_handler, [long_pos.instrument, short_pos.instrument]
        )
        long_ltp  = ltps.get(long_pos.instrument.instrument_token)
        short_ltp = ltps.get(short_pos.instrument.instrument_token)
        if long_ltp is None or short_ltp is None:
            return False

        # Update last_price + unrealized PnL for both legs
        now = timezone.now()
        for pos, ltp in ((long_pos, long_ltp), (short_pos, short_ltp)):
            pos.last_price = Decimal(str(ltp))
            pos.last_price_updated_at = now
            if pos.position_type == "LONG":
                pos.unrealized_pnl = (pos.last_price - pos.entry_price) * pos.quantity
            else:
                pos.unrealized_pnl = (pos.entry_price - pos.last_price) * pos.quantity
            pos.save(update_fields=["last_price", "last_price_updated_at", "unrealized_pnl"])

        spread_val = float(long_ltp) - float(short_ltp)
        sl_thr = self.net_debit * (1 - self.sl_pct)  if self.sl_pct  is not None else None
        tp_thr = self.net_debit * (1 + self.tp_mult) if self.tp_mult is not None else None

        self.log_debug(
            f"Exit chk: spread={spread_val:.2f} "
            f"sl={sl_thr if sl_thr is not None else 'off'} "
            f"tp={tp_thr if tp_thr is not None else 'off'} (debit={self.net_debit:.2f})"
        )

        # Backtest order: SL before TP (lines 577-590)
        if sl_thr is not None and spread_val <= sl_thr:
            self.log_info(f"SL hit: spread={spread_val:.2f} <= {sl_thr:.2f}")
            self._close_all_legs("SL", datafeed_handler, dry_run)
            return True
        if tp_thr is not None and spread_val >= tp_thr:
            self.log_info(f"TP hit: spread={spread_val:.2f} >= {tp_thr:.2f}")
            self._close_all_legs("TP", datafeed_handler, dry_run)
            return True

        return False

    # =========================================================================
    # STATE PERSISTENCE
    # =========================================================================

    def _get_state_path(self) -> str:
        code = self.strategy_obj.strategy_code.lower()
        return os.path.join(
            PUT_SPREAD_DUMP_DIR, f"{code}_{date.today().strftime('%Y%m%d')}.json"
        )

    def _save_state(self) -> None:
        path = self._get_state_path()
        os.makedirs(os.path.dirname(path), exist_ok=True)
        state = {
            "date": str(date.today()),
            "expiry": str(self.expiry) if self.expiry else None,
            "long_strike":  float(self.long_strike)  if self.long_strike  else None,
            "short_strike": float(self.short_strike) if self.short_strike else None,
            "long_entry_prem":  self.long_entry_prem,
            "short_entry_prem": self.short_entry_prem,
            "net_debit": self.net_debit,
            "forward_price": self.forward_price,
            "exited": self.exited,
        }
        try:
            with open(path, "w") as f:
                json.dump(state, f)
        except Exception as e:
            self.log_error(f"Failed to save state: {e}")

    def _load_state(self) -> bool:
        path = self._get_state_path()
        if not os.path.isfile(path):
            return False
        try:
            with open(path, "r") as f:
                state = json.load(f)
        except Exception as e:
            self.log_error(f"Failed to load state: {e}")
            return False

        if state.get("date") != str(date.today()):
            self.log_info("State file stale (wrong date). Ignoring.")
            return False

        ls = state.get("long_strike");  ss = state.get("short_strike")
        self.long_strike  = Decimal(str(ls)) if ls is not None else None
        self.short_strike = Decimal(str(ss)) if ss is not None else None
        self.long_entry_prem  = float(state.get("long_entry_prem", 0.0) or 0.0)
        self.short_entry_prem = float(state.get("short_entry_prem", 0.0) or 0.0)
        self.net_debit        = float(state.get("net_debit", 0.0) or 0.0)
        self.forward_price    = float(state.get("forward_price", 0.0) or 0.0)
        self.exited           = bool(state.get("exited", False))

        self.log_info(
            f"RECOVERY: state restored — long={self.long_strike} short={self.short_strike} "
            f"net_debit={self.net_debit} exited={self.exited}"
        )
        return True

    def _bootstrap_from_db(self) -> None:
        db_positions = StrategyPosition.objects.filter(
            strategy=self.strategy_obj, status="OPEN",
        ).select_related("instrument")

        if not db_positions.exists():
            self.log_info("No existing open positions. Fresh run.")
            return

        for pos in db_positions:
            meta = pos.strategy_metadata or {}
            leg_name = meta.get("leg_name")
            if leg_name in (LEG_LONG, LEG_SHORT):
                self.open_positions[leg_name] = pos
                self.log_warning(
                    f"RECOVERY: restored {leg_name} @ entry={pos.entry_price} "
                    f"({pos.instrument.tradingsymbol})"
                )

    # =========================================================================
    # TIME UTILITIES
    # =========================================================================

    def _get_today_datetime(self, time_obj) -> datetime:
        today = timezone.now().date()
        naive_dt = datetime.combine(today, time_obj)
        return timezone.make_aware(naive_dt)

    def _wait_until(self, target_time: datetime) -> bool:
        while self.is_running:
            now = timezone.now()
            if now >= target_time:
                return True
            remaining = (target_time - now).total_seconds()
            if remaining > 60:
                self.log_info(
                    f"Waiting {int(remaining // 60)}m {int(remaining % 60)}s "
                    f"until {target_time.strftime('%H:%M:%S')}"
                )
                time.sleep(30)
            else:
                time.sleep(1)
        return False

    # =========================================================================
    # BASE STRATEGY INTERFACE
    # =========================================================================

    def verify(self) -> bool:
        if not self.datafeed_obj:
            self.log_error("No datafeed object provided.")
            return False
        if self.datafeed_obj.is_token_expired:
            self.log_warning("Datafeed token expired — attempting refresh...")
            from datafeed.rest.handler import DataFeedHandler
            handler = DataFeedHandler(self.datafeed_obj)
            if not handler.update_token():
                self.log_error("Failed to refresh datafeed token.")
                return False
        self.log_info("Verification passed.")
        return True

    def stop(self):
        self.log_info("Stopping PutBearSpread...")
        self.is_running = False

    # =========================================================================
    # MAIN RUN LOOP
    # =========================================================================

    def _resolve_params(self) -> None:
        params = self.strategy_obj.strategy_params or {}
        self.pcr_mode       = params.get("pcr_mode",       DEFAULT_PCR_MODE)
        self.pcr_threshold  = float(params.get("pcr_threshold", DEFAULT_PCR_THRESHOLD))
        self.pcr_strikes    = params.get("pcr_strikes",    DEFAULT_PCR_STRIKES)
        self.pcr_timing     = params.get("pcr_timing",     DEFAULT_PCR_TIMING)
        self.n_straddles    = float(params.get("n_straddles", DEFAULT_N_STRADDLES))
        self.long_offset    = int(params.get("long_offset", DEFAULT_LONG_OFFSET))
        self.long_direction = params.get("long_direction", DEFAULT_LONG_DIRECTION)
        self.poll_interval_secs = int(params.get("poll_interval_secs", DEFAULT_POLL_INTERVAL_SECS))

        sl = params.get("sl_pct", DEFAULT_SL_PCT)
        self.sl_pct = float(sl) if sl is not None else None
        tp = params.get("tp_mult", DEFAULT_TP_MULT)
        self.tp_mult = float(tp) if tp is not None else None

        ts = params.get("time_stop")
        if ts is None:
            self.time_stop = DEFAULT_TIME_STOP
        elif ts == "":
            self.time_stop = None
        else:
            try:
                self.time_stop = datetime.strptime(ts, "%H:%M:%S").time()
            except ValueError:
                self.log_error(f"Invalid time_stop '{ts}', using default {DEFAULT_TIME_STOP}")
                self.time_stop = DEFAULT_TIME_STOP

    def run(self):
        params = self.strategy_obj.strategy_params or {}
        dry_run = bool(params.get("dry_run", False))
        self._resolve_params()

        self.log_info("=" * 60)
        self.log_info("Starting PutBearSpread (Weekly Expiry Day Only)")
        self.log_info(
            f"pcr={self.pcr_mode}/{self.pcr_strikes}/{self.pcr_timing} "
            f"thr={self.pcr_threshold} N={self.n_straddles} "
            f"long_off={self.long_offset}{self.long_direction} "
            f"SL={self.sl_pct} TP={self.tp_mult} TSTOP={self.time_stop}"
        )
        self.log_info(f"Mode: {'DRY-RUN' if dry_run else 'LIVE'}")
        self.log_info("=" * 60)

        if not self.verify():
            self.log_error("Verification failed. Exiting.")
            return

        self.is_running = True

        from datafeed.rest.handler import DataFeedHandler
        datafeed_handler = DataFeedHandler(self.datafeed_obj)

        # Step 1: weekly expiry day gate
        cw_expiry = self._get_nearest_option_expiry()
        if cw_expiry is None:
            self.log_error("No NIFTY option expiry found. Exiting.")
            self.is_running = False
            return
        if cw_expiry != date.today():
            self.log_info(
                f"Today ({date.today()}) is NOT weekly expiry day "
                f"(next expiry: {cw_expiry}). Strategy will not run today."
            )
            self.is_running = False
            return
        self.expiry = cw_expiry
        self.log_info(f"Weekly expiry day confirmed: {self.expiry}")

        # Step 2: cache strikes
        self._load_available_strikes(self.expiry)
        if not self._available_strikes:
            self.log_error(f"No strikes found for expiry {self.expiry}. Exiting.")
            self.is_running = False
            return
        self.log_info(f"Loaded {len(self._available_strikes)} strikes")

        # Step 3: recovery
        self._bootstrap_from_db()
        self._load_state()
        already_open = bool(self.open_positions)

        # Step 4: entry — open vs intraday timing (mirror of resolve_entry_bar)
        if not already_open and not self.exited:
            if self.pcr_timing == "open":
                target_dt = self._get_today_datetime(OPEN_BAR)
                if timezone.now() < target_dt:
                    self.log_info(f"Waiting for OPEN bar: {target_dt.strftime('%H:%M:%S')}")
                    if not self._wait_until(target_dt):
                        return
                if not self.is_running:
                    return
                self.log_info("OPEN bar — single PCR check")
                if not self._try_entry(datafeed_handler, dry_run):
                    self.log_info("PCR did not trigger at OPEN bar — no trade today.")
                    self.exited = True
                    self._save_state()
            else:  # intraday — poll until ENTRY_CUTOFF
                cutoff_dt = self._get_today_datetime(ENTRY_CUTOFF)
                self.log_info(f"Intraday PCR polling until {cutoff_dt.strftime('%H:%M:%S')}")
                while self.is_running and timezone.now() < cutoff_dt:
                    if self._try_entry(datafeed_handler, dry_run):
                        break
                    time.sleep(self.poll_interval_secs)
                if not self.open_positions:
                    self.log_info("PCR never triggered before ENTRY_CUTOFF — no trade today.")
                    self.exited = True
                    self._save_state()

        # Step 5: monitor + exit (mirror of monitor_exit)
        exit_dt = self._get_today_datetime(HARD_EXIT_T)
        self.log_info("Entering exit-monitor loop...")
        while self.is_running:
            if not self.open_positions:
                break
            if timezone.now() >= exit_dt:
                self.log_info(">>> HARD EXIT TIME REACHED <<<")
                self._close_all_legs("HARD_EXIT", datafeed_handler, dry_run)
                break
            try:
                if self._check_exit(datafeed_handler, dry_run):
                    break
            except Exception as e:
                self.log_exception(f"Main loop error: {e}")
            time.sleep(self.poll_interval_secs)

        # EOD safety net
        now_t = timezone.localtime(timezone.now()).time()
        if self.open_positions and now_t >= HARD_EXIT_T:
            self.log_warning("EOD safety net: forcing close")
            self._close_all_legs("HARD_EXIT_FORCE", datafeed_handler, dry_run)
        elif self.open_positions:
            self.log_info("Loop exited but NOT past HARD_EXIT — keeping legs open in DB for recovery")

        self.is_running = False
        self.log_info("PutBearSpread completed.")
