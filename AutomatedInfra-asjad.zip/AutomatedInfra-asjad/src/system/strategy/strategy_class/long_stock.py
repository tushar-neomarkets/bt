from decimal import Decimal
import time
from strategy.strategy_class.base_strategy import BaseStrategy
from instruments.models import Instrument
from orders.order_manager import order_manager

class LongStock(BaseStrategy):

    def __init__(self, strategy_obj, datafeed_obj, ws_manager=None):
        super().__init__(strategy_obj, datafeed_obj, ws_manager)
        self.is_running = False

    def verify(self) -> bool:
        if not self.datafeed_obj:
            self.log_error("No datafeed object provided.")
            return False

        if self.datafeed_obj.is_token_expired:
            self.log_warning("Datafeed token expired — attempting refresh...")
            from datafeed.rest.handler import DataFeedHandler
            handler = DataFeedHandler(self.datafeed_obj)
            if not handler.update_token():
                self.log_error("Failed to refresh datafeed token.")
                return False
        
        self.log_info("Verification passed: Ready to buy.")
        return True

    def run(self):
        """
        The main execution block. Find the instrument, place a market order, and stop.
        """
        self.log_info("Starting LongStock strategy...")
        
        if not self.verify():
            self.log_error("Verification failed. Exiting.")
            return

        self.is_running = True

        # 1. Lookup the instrument
        instrument = Instrument.objects.filter(
            tradingsymbol="PERSISTENT", 
            exchange="NSE", 
            instrument_type="EQ", 
            is_active=True
        ).first()

        if not instrument:
            self.log_error("Could not find active EQ instrument for PERSISTENT on NSE.")
            self.is_running = False
            return

        # 2. Fetch LTP
        self.log_info(f"Fetching LTP for {instrument.tradingsymbol}...")
        
        # We need the datafeed handler to fetch LTP
        from datafeed.rest.handler import DataFeedHandler
        datafeed_handler = DataFeedHandler(self.datafeed_obj)
        
        ltp = None
        try:
            # get_multiple_ltp expects a list of instruments
            response = datafeed_handler.get_multiple_ltp([instrument])
            if response and "data" in response:
                for item in response["data"].get("ltp_list", []):
                    if item.get("instrument_token") == instrument.instrument_token:
                        ltp = item.get("ltp")
                        break
        except Exception as e:
            self.log_error(f"Error fetching LTP: {e}")

        # 3. Calculate Limit Price (LTP + 0.5 for a BUY order)
        if ltp is None:
            self.log_error("Could not fetch LTP. Aborting to avoid MARKET order slippage.")
            self.is_running = False
            return
            
        PRICE_OFFSET = Decimal("0.5")
        limit_price = Decimal(str(ltp)) - PRICE_OFFSET
        
        self.log_info(f"LTP is {ltp}. Placing LIMIT BUY order at {limit_price}")
        # print(f"LTP is {ltp}. Placing LIMIT BUY order at {limit_price}")
        success, msg, parent_order, _ = order_manager.create_and_execute_order(
            strategy=self.strategy_obj,
            instrument=instrument,
            side="BUY",
            quantity=1,
            order_type="LIMIT",
            product_type="CNC", 
            price=limit_price,
            order_intent="ENTRY",
            metadata={
                "strategy_code": self.strategy_obj.strategy_code,
                "notes": "Simple automated test buy"
            },
        )

        if success:
            self.log_info(f"Successfully placed order! Parent Order ID: {parent_order.order_id}")
            self.log_info("Waiting 60 seconds to allow order fills to process before exiting...")
            
            wait_time = 60
            while self.is_running and wait_time > 0:
                time.sleep(1)
                wait_time -= 1
                
            self.log_info("Wait complete. Exiting strategy thread.")
        else:
            self.log_error(f"Failed to place order: {msg}")

        self.is_running = False

    def stop(self):
        """Stop the strategy."""
        self.log_info("Stopping LongStock...")
        self.is_running = False
