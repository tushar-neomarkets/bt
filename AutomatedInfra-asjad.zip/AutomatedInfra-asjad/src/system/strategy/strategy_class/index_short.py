""" Index Short """

import csv
import os
import time
import uuid
from datetime import date, datetime, time as dt_time
from decimal import Decimal
from typing import Optional
from marketdata import FnO

import pandas as pd
from django.db.models import Min
from django.utils import timezone

from instruments.models import Instrument, BrokerInstrument
from orders.order_manager import order_manager
from strategy.models import StrategyPosition
from strategy.strategy_class.base_strategy import BaseStrategy

PRICE_OFFSET = Decimal("0.5")
POLL_INTERVAL_SECS = 20
ROLLOVER_DAYS_BEFORE = 0              # Switch to NW expiry on expiry day itself
ROLLOVER_CHECK_TIME = dt_time(10, 30, 0)  # Roll open positions at this time on expiry day
# BROKER_TOKEN_REFRESH_INTERVAL_SECS = 900  # Centralized — handled by TokenRefreshManager
HEARTBEAT_INTERVAL_POLLS = 15             # Log heartbeat every ~5 min (15 × 20s)
TICKER = "NIFTY"

# ── CSV State Persistence ─────────────────────────────────────────────────────
_BASE_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
IDXS_DUMP_DIR = os.path.join(_BASE_DIR, 'dump', 'idxshort')
CSV_COLUMNS = [
    'timestamp', 'event',
    # Candle
    'candle_idx',
    'candle_open', 'candle_high', 'candle_low', 'candle_close', 'candle_volume',
    # EMAs
    'prev_entry_ema', 'prev_exit_ema',
    # RSI internals
    'prev_up_rma', 'prev_down_rma', 'prev_rsi',
    'prev_rsi_ema_entry', 'prev_rsi_ema_exit',
    # Signal state
    'position', 'sl_price', 'entry_price',
    # Instruments
    'ce_token', 'ce_tradingsymbol',
    'pe_token', 'pe_tradingsymbol',
    'expiry', 'atm_strike', 'spot_price',
    # Flags
    'rollover_done',
    # Exit info
    'exit_type', 'exit_atm_strike',
]

fno = FnO()

# ── Constants ──────────────────────────────────────────────────────────────────
FNO_SYMBOL = "NIFTY"
FNO_EXPIRY = "fm"

# Indicator Parameters
EMA_PERIOD_ENTRY = 20
EMA_PERIOD_EXIT = 50
RSI_PERIOD = 40
RSI_EMA_PERIOD_ENTRY = 100
RSI_EMA_PERIOD_EXIT = 50
VOLUME_MA_PERIOD = 20
ATR_PERIOD = 21

# Strategy Thresholds
VOLUME_RATIO_MIN = 1.0
RSI_OVERSOLD_EXIT = 30
ATR_STOP_LOSS_MULT = 2.0

# Warm-up requirement (100 EMA needs about 90+ days to converge exactly)
HISTORY_CALENDAR_DAYS = 120

# Valid Hourly Candle Boundaries for API
VALID_HOURLY_TIMES = [
    dt_time(10, 14, 59), dt_time(11, 14, 59), dt_time(12, 14, 59),
    dt_time(13, 14, 59), dt_time(14, 14, 59), dt_time(15, 14, 59),
]

# Time Filter (Hour of the datetime returned by the API closing timestamp)
VALID_ENTRY_HOURS = [9, 10, 15]

HOURLY_BOUNDARIES = [
    (dt_time(9, 15, 0),  dt_time(10, 15, 0)),
    (dt_time(10, 15, 0), dt_time(11, 15, 0)),
    (dt_time(11, 15, 0), dt_time(12, 15, 0)),
    (dt_time(12, 15, 0), dt_time(13, 15, 0)),
    (dt_time(13, 15, 0), dt_time(14, 15, 0)),
    (dt_time(14, 15, 0), dt_time(15, 15, 0)),
]

class IndexShort(BaseStrategy):

    def __init__(self, strategy_obj, datafeed_obj, ws_manager=None):
        super().__init__(strategy_obj, datafeed_obj, ws_manager)
        self.is_running = False

        # ── Indicator State ────────────────────────────────────────────────
        self.prev_entry_ema: float = 0.0          # Used for trend entry filter
        self.prev_exit_ema: float = 0.0           # Used for dynamic exit filter
        
        self.prev_up_rma: float = 0.0          
        self.prev_down_rma: float = 0.0        
        self.prev_rsi: float = 0.0
        self.prev_rsi_ema_entry: float = 0.0  # Smoothing applied to RSI for entry bearish crossover
        self.prev_rsi_ema_exit: float = 0.0   # Smoothing applied to RSI for exit bullish crossover
        
        # Queues for Simple Moving Averages
        self.close_history: list[float] = []   
        self.volume_history: list[float] = []  
        self.tr_history: list[float] = []      

        # ── Live Candle Builder State ─────────────────────────────────────
        self.hourly_candles: list[dict] = []
        self._candle_open: Optional[float] = None
        self._candle_high: float = 0.0
        self._candle_low: float = float("inf")
        self._candle_close: float = 0.0
        self._candle_volume_start: int = 0
        self._current_boundary_idx: int = -1

        # ── Signal & Order State ───────────────────────────────────────────
        self.position: int = 0                 
        self.trigger: int = 0                  
        self.sl_price: Optional[float] = None
        self.entry_time = None
        self.entry_price: Optional[float] = None

        # ── Synthetic Forward / Order State ───────────────────────────────
        self.entry_ce: Optional[Instrument] = None             # ATM CE leg of synthetic forward
        self.entry_pe: Optional[Instrument] = None             # ATM PE leg of synthetic forward
        self.open_positions: dict[str, StrategyPosition] = {}  # {"CE": pos, "PE": pos}
        self.nifty_future: Optional[Instrument] = None         # FM future for candle building only
        self.last_processed_candle_idx: int = -1
        self._current_trading_date: Optional[date] = None
        self._rollover_done_today: bool = False
        # self._last_broker_token_refresh: float = 0.0  # Centralized — handled by TokenRefreshManager
        self._poll_count: int = 0
        self._futures_poll_failures: int = 0

    # =========================================================================
    # HISTORICAL DATA INGESTION & WARM UP (Step 1)
    # =========================================================================

    def _fetch_historical_hourly_data(self) -> Optional[pd.DataFrame]:
        """ Fetch historical hourly NIFTY FM futures data to prime indicators. """
        today = date.today()
        start_date = today - pd.Timedelta(days=HISTORY_CALENDAR_DAYS)

        start_str = start_date.strftime("%Y-%m-%d")
        end_str = today.strftime("%Y-%m-%d")

        self.log_info(f"Fetching {FNO_SYMBOL} FM futures data: {start_str} to {end_str}")

        try:
            df = fno.get_prices(
                FNO_SYMBOL,
                start_str,
                end_str,
                interval="1h",
                columns="ohlcv",
                kind="futures",
                expiry=FNO_EXPIRY,
            )
        except Exception as e:
            self.log_error(f"FnO API call failed: {e}")
            return None

        if df is None or df.empty:
            self.log_error("FnO API returned no data.")
            return None

        # UTC → IST conversion
        df["timestamp"] = pd.to_datetime(df["timestamp"])
        if df["timestamp"].dt.tz is not None:
            df["timestamp"] = df["timestamp"].dt.tz_convert("Asia/Kolkata").dt.tz_localize(None)
        else:
            df["timestamp"] = df["timestamp"] + pd.Timedelta(hours=5, minutes=30)

        df.sort_values("timestamp", inplace=True)
        df.reset_index(drop=True, inplace=True)

        # Filter to valid hourly candle times (by hour, since FnO timestamps may differ)
        valid_hours = {t.hour for t in VALID_HOURLY_TIMES}
        df = df[df["timestamp"].dt.hour.isin(valid_hours)].copy()
        df.reset_index(drop=True, inplace=True)

        if df.empty:
            self.log_error("No candles matched valid hourly times after IST conversion.")
            return None

        self.log_info(f"Fetched {len(df)} hourly FM futures candles for warmup.")
        return df

    def _calculate_initial_indicators(self, df: pd.DataFrame) -> bool:
        """ Calculates full historical series to warmly initialize state variables. """
        df = df.copy()

        # EMAs
        df["ENTRY_EMA"] = df["close"].ewm(span=EMA_PERIOD_ENTRY, adjust=False).mean()
        df["EXIT_EMA"] = df["close"].ewm(span=EMA_PERIOD_EXIT, adjust=False).mean()

        # RMA for RSI
        change = df["close"].diff()
        up = change.clip(lower=0)
        down = -change.clip(upper=0)
        
        alpha_rsi = 1 / RSI_PERIOD
        df["up_rma"] = up.ewm(alpha=alpha_rsi, adjust=False).mean()
        df["down_rma"] = down.ewm(alpha=alpha_rsi, adjust=False).mean()
        
        rs = df["up_rma"] / df["down_rma"]
        df["RSI"] = 100 - (100 / (1 + rs))
        df["RSI"] = df["RSI"].fillna(50)

        # RSI EMAs
        df["RSI_EMA_ENTRY"] = df["RSI"].ewm(span=RSI_EMA_PERIOD_ENTRY, adjust=False).mean()
        df["RSI_EMA_EXIT"] = df["RSI"].ewm(span=RSI_EMA_PERIOD_EXIT, adjust=False).mean()

        # True Range
        tr1 = df["high"] - df["low"]
        tr2 = (df["high"] - df["close"].shift(1)).abs()
        tr3 = (df["low"] - df["close"].shift(1)).abs()
        df["TR"] = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)

        # Save to active state
        self.prev_entry_ema = float(df["ENTRY_EMA"].iloc[-1])
        self.prev_exit_ema = float(df["EXIT_EMA"].iloc[-1])
        
        self.prev_up_rma = float(df["up_rma"].iloc[-1])
        self.prev_down_rma = float(df["down_rma"].iloc[-1])
        self.prev_rsi = float(df["RSI"].iloc[-1])
        self.prev_rsi_ema_entry = float(df["RSI_EMA_ENTRY"].iloc[-1])
        self.prev_rsi_ema_exit = float(df["RSI_EMA_EXIT"].iloc[-1])

        self.close_history = df["close"].iloc[-2:].tolist() 
        
        # Guard against index volume being NaN
        vol_queue = df["volume"].iloc[-VOLUME_MA_PERIOD:].tolist() if "volume" in df.columns else [0.0] * VOLUME_MA_PERIOD
        self.volume_history = [float(v) if pd.notna(v) else 0.0 for v in vol_queue]
        
        tr_queue = df["TR"].iloc[-ATR_PERIOD:].tolist()
        self.tr_history = [float(t) for t in tr_queue if pd.notna(t)]

        self.log_info(
            f"Indicators warmed up: "
            f"Entry_EMA={self.prev_entry_ema:.2f}, Exit_EMA={self.prev_exit_ema:.2f}, "
            f"RSI={self.prev_rsi:.2f}, "
            f"RSI_EMA_Entry={self.prev_rsi_ema_entry:.2f}, RSI_EMA_Exit={self.prev_rsi_ema_exit:.2f}"
        )
        return True

    # =========================================================================
    # HOURLY CANDLE PROCESSING (Step 2 & 3)
    # =========================================================================

    def _on_candle_close(self, timestamp: pd.Timestamp, candle: dict) -> Optional[dict]:
        """ Incrementally update indicators and evaluate conditions on hourly close. """
        
        close = candle["close"]
        high = candle["high"]
        low = candle["low"]
        volume = candle.get("volume", 0)
        candle_hour = timestamp.hour

        # ── 1. Volume MA & Ratio ──
        self.volume_history.append(volume)
        if len(self.volume_history) > VOLUME_MA_PERIOD:
            self.volume_history.pop(0)
            
        vol_ma = sum(self.volume_history) / len(self.volume_history) if self.volume_history else 1.0
        volume_ratio = volume / vol_ma if vol_ma > 0 else 1.0

        # ── 2. True Range & ATR ──
        prev_close = self.close_history[-1] if self.close_history else close
        tr1 = high - low
        tr2 = abs(high - prev_close)
        tr3 = abs(low - prev_close)
        current_tr = max(tr1, tr2, tr3)
        
        self.tr_history.append(current_tr)
        if len(self.tr_history) > ATR_PERIOD:
            self.tr_history.pop(0)
            
        atr = sum(self.tr_history) / len(self.tr_history) if self.tr_history else current_tr

        # ── 3. EMAs ──
        k_entry = 2 / (EMA_PERIOD_ENTRY + 1)
        self.prev_entry_ema = (close * k_entry) + (self.prev_entry_ema * (1 - k_entry))
        
        k_exit = 2 / (EMA_PERIOD_EXIT + 1)
        self.prev_exit_ema = (close * k_exit) + (self.prev_exit_ema * (1 - k_exit))

        # ── 4. RSI (Wilder's Smoothing) ──
        change = close - prev_close
        up = max(change, 0)
        down = max(-change, 0)
        
        alpha_rsi = 1 / RSI_PERIOD
        self.prev_up_rma = (up * alpha_rsi) + (self.prev_up_rma * (1 - alpha_rsi))
        self.prev_down_rma = (down * alpha_rsi) + (self.prev_down_rma * (1 - alpha_rsi))
        
        rs = self.prev_up_rma / self.prev_down_rma if self.prev_down_rma else float('inf')
        current_rsi = 100 - (100 / (1 + rs)) if self.prev_down_rma else 50.0

        # ── 5. RSI EMAs ──
        old_rsi_ema_entry = self.prev_rsi_ema_entry
        k_rsi_entry = 2 / (RSI_EMA_PERIOD_ENTRY + 1)
        self.prev_rsi_ema_entry = (current_rsi * k_rsi_entry) + (self.prev_rsi_ema_entry * (1 - k_rsi_entry))

        old_rsi_ema_exit = self.prev_rsi_ema_exit
        k_rsi_exit = 2 / (RSI_EMA_PERIOD_EXIT + 1)
        self.prev_rsi_ema_exit = (current_rsi * k_rsi_exit) + (self.prev_rsi_ema_exit * (1 - k_rsi_exit))

        # ── 6. Housekeeping ──
        self.close_history.append(close)
        if len(self.close_history) > 2:
            self.close_history.pop(0)

        self.log_info(
            f"Candle Close {timestamp.time()}: close={close:.2f} | RSI={current_rsi:.2f} "
            f"| RSI_EMA_Entry={self.prev_rsi_ema_entry:.2f} | VolRatio={volume_ratio:.2f}"
        )

        signal = None

        # =====================================================================
        # SIGNAL EVALUATION
        # =====================================================================

        # Crossovers
        rsi_crossed_bearish = (current_rsi <= self.prev_rsi_ema_entry) and (self.prev_rsi >= old_rsi_ema_entry)
        rsi_crossed_bullish = (current_rsi >= self.prev_rsi_ema_exit) and (self.prev_rsi <= old_rsi_ema_exit)

        if self.position == 0:
            # ── ENTRY: Immediate at candle close ──
            if (
                rsi_crossed_bearish and
                (close < self.prev_entry_ema) and
                (volume_ratio >= VOLUME_RATIO_MIN) and
                (candle_hour in VALID_ENTRY_HOURS)
            ):
                self.position = -1
                self.entry_price = close
                self.entry_time = timestamp

                # Initial dynamic SL (recalculated each subsequent bar)
                self.sl_price = self.entry_price * (1.0 + ATR_STOP_LOSS_MULT * atr / close) if close > 0 else None

                signal = {
                    "action": "ENTER_SHORT", "timestamp": timestamp,
                    "price": close, "direction": -1,
                    "sl_price": self.sl_price,
                }
                self.log_info(
                    f"ENTRY SHORT @ {close:.2f} | "
                    f"RSI Bearish Cross | close < EMA={self.prev_entry_ema:.2f} | "
                    f"VolRatio={volume_ratio:.2f} | hour={candle_hour} | "
                    f"SL={self.sl_price:.2f}"
                )

        elif self.position == -1:
            # ── Recalculate dynamic SL every bar (backtest line 1324) ──
            dynamic_sl = self.entry_price * (1.0 + ATR_STOP_LOSS_MULT * atr / close) if close > 0 else self.sl_price
            self.sl_price = dynamic_sl

            # ── Exit conditions (priority matches backtest lines 1326-1333) ──
            exit_reason = None
            if close > dynamic_sl:
                exit_reason = "Stop Loss"
            elif rsi_crossed_bullish and current_rsi < RSI_OVERSOLD_EXIT:
                exit_reason = "RSI Bullish Cross"
            elif close > self.prev_exit_ema:
                exit_reason = "Closed above Exit EMA"
            elif current_rsi < RSI_OVERSOLD_EXIT:
                exit_reason = "RSI Oversold"

            if exit_reason:
                self.log_info(f"CANDLE EXIT: {exit_reason} (Close={close:.2f}, SL={dynamic_sl:.2f})")
                signal = {
                    "action": "EXIT_SHORT",
                    "timestamp": timestamp,
                    "price": close,
                    "exit_price": close,
                    "entry_price": self.entry_price,
                    "direction": -1,
                    "exit_reason": exit_reason,
                }

        # Remember RSI for next candle
        self.prev_rsi = current_rsi

        return signal

    # =========================================================================
    # LIVE CANDLE BUILDER (from XTS touchline polls)
    # =========================================================================

    def _get_current_boundary_idx(self) -> int:
        """Return the index of the hourly boundary the current time falls in, or -1."""
        now_t = datetime.now().time()
        for i, (start, end) in enumerate(HOURLY_BOUNDARIES):
            if start <= now_t < end:
                return i
        return -1

    def _poll_futures_quote(self, datafeed_handler) -> Optional[dict]:
        """Fetch LTP + cumulative volume for the FM future via XTS quote (market depth)."""
        if not self.nifty_future:
            return None
        try:
            response = datafeed_handler.get_single_quote(self.nifty_future)
            if response and "data" in response:
                quote = response["data"].get("quote", {})
                if quote.get("instrument_token") == self.nifty_future.instrument_token:
                    return {
                        "ltp": quote.get("ltp", 0.0),
                        "volume": quote.get("volume", 0),
                    }
        except Exception as e:
            self.log_error(f"Error polling futures quote: {e}")
            self._futures_poll_failures += 1
            # Rate-limited diagnostic dump: first failure, then every 20th
            # (~once per ~7 min at POLL_INTERVAL_SECS=20). Captures the XTS
            # response body (which carries the real rejection reason — token,
            # instrument id, segment, etc.) and the broker mapping actually
            # being sent on the wire.
            if self._futures_poll_failures == 1 or self._futures_poll_failures % 20 == 0:
                resp = getattr(e, "response", None)
                if resp is not None:
                    try:
                        body_preview = (resp.text or "")[:500]
                    except Exception:
                        body_preview = "<unreadable>"
                    self.log_error(
                        f"XTS 400 diag [fail#{self._futures_poll_failures}]: "
                        f"status={resp.status_code} body={body_preview!r}"
                    )
                else:
                    self.log_error(
                        f"XTS 400 diag [fail#{self._futures_poll_failures}]: "
                        f"exception has no .response — type={type(e).__name__}"
                    )
                try:
                    broker_name = self.datafeed_obj.provider.provider_name.upper()
                    bi = BrokerInstrument.get_by_instrument_and_broker(
                        self.nifty_future.instrument_token, broker_name
                    )
                    if bi is not None:
                        seg = (bi.extra_data or {}).get("exchange_segment_code")
                        self.log_error(
                            f"FUT mapping diag: symbol={self.nifty_future.tradingsymbol} "
                            f"instrument_token={self.nifty_future.instrument_token} "
                            f"broker_token={bi.broker_token} "
                            f"exchange_segment_code={seg} extra_data={bi.extra_data}"
                        )
                    else:
                        self.log_error(
                            f"FUT mapping diag: NO BrokerInstrument row for "
                            f"{self.nifty_future.tradingsymbol} "
                            f"(instrument_token={self.nifty_future.instrument_token}, "
                            f"broker={broker_name})"
                        )
                except Exception as diag_err:
                    self.log_error(f"FUT mapping diag lookup failed: {diag_err}")
            # TokenRefreshManager may have issued a new XTS token to DB — pick it up.
            try:
                self.datafeed_obj.refresh_from_db()
            except Exception:
                pass
        return None

    def _update_candle(self, ltp: float, cumulative_volume: int) -> Optional[dict]:
        """
        Feed a tick into the candle builder.
        Returns a completed candle dict when an hourly boundary closes, else None.
        """
        boundary_idx = self._get_current_boundary_idx()
        completed_candle = None

        # Boundary changed → emit previous candle (if any)
        if boundary_idx != self._current_boundary_idx:
            if self._candle_open is not None and self._current_boundary_idx >= 0:
                candle_time = VALID_HOURLY_TIMES[self._current_boundary_idx]
                candle_date = date.today()
                candle_volume = max(0, cumulative_volume - self._candle_volume_start)
                completed_candle = {
                    "timestamp": pd.Timestamp.combine(candle_date, candle_time),
                    "open": self._candle_open,
                    "high": self._candle_high,
                    "low": self._candle_low,
                    "close": self._candle_close,
                    "volume": candle_volume,
                }

            # Reset for new boundary
            self._current_boundary_idx = boundary_idx
            self._candle_open = ltp
            self._candle_high = ltp
            self._candle_low = ltp
            self._candle_close = ltp
            self._candle_volume_start = cumulative_volume
        else:
            # Same boundary — update running candle
            if self._candle_open is None:
                self._candle_open = ltp
                self._candle_volume_start = cumulative_volume
            self._candle_high = max(self._candle_high, ltp)
            self._candle_low = min(self._candle_low, ltp)
            self._candle_close = ltp

        return completed_candle

    # =========================================================================
    # TICK POLLING
    # =========================================================================

    def _check_poll_sl(self, price: float, timestamp: datetime) -> Optional[dict]:
        """Poll-level SL monitoring only. Entry happens at candle close.
        State reset is handled by _execute_forward_exit, not here."""
        signal = None

        if self.position == -1 and self.sl_price is not None:
            if price >= self.sl_price:
                signal = {
                    "action": "EXIT_SHORT",
                    "entry_time": self.entry_time,
                    "entry_price": self.entry_price,
                    "exit_time": timestamp, 
                    "exit_price": price,  # Must be the actual LTP for accurate ATM resolution
                    "direction": -1,
                    "exit_reason": "Stop Loss (Poll)",
                }
                self.log_info(
                    f"POLL SL SHORT: exit @ {self.sl_price:.2f} | ltp={price:.2f}")

        return signal

    # =========================================================================
    # INSTRUMENT LOOKUPS
    # =========================================================================

    def _get_far_month_future(self, ticker: str) -> Optional[Instrument]:
        """Get the far-month future for candle building (price polling only)."""
        today = date.today()
        futures = list(
            Instrument.objects.filter(
                name=ticker,
                exchange="NFO",
                instrument_type="FUT",
                is_active=True,
                expiry__gt=today,
            ).order_by("expiry")[:3]
        )

        if len(futures) >= 3:
            fm = futures[2]
            self.log_info(
                f"Far-month future: {fm.tradingsymbol} "
                f"(Expiry: {fm.expiry}, Lot Size: {fm.lot_size})"
            )
            return fm

        self.log_error(f"Expected 3 active futures for {ticker}, found {len(futures)}.")
        return None

    def _get_nearest_option_expiry(self) -> Optional[date]:
        """Get the nearest weekly option expiry date for NIFTY."""
        today = date.today()
        result = Instrument.objects.filter(
            name=TICKER,
            exchange="NFO",
            instrument_type__in=["CE", "PE"],
            is_active=True,
            expiry__gte=today,
        ).aggregate(min_expiry=Min("expiry"))
        return result.get("min_expiry")

    def _get_next_week_expiry(self) -> Optional[date]:
        """Get the next-week option expiry (second nearest)."""
        today = date.today()
        expiries = (
            Instrument.objects.filter(
                name=TICKER,
                exchange="NFO",
                instrument_type__in=["CE", "PE"],
                is_active=True,
                expiry__gte=today,
            )
            .values_list("expiry", flat=True)
            .distinct()
            .order_by("expiry")[:2]
        )
        expiry_list = list(expiries)
        if len(expiry_list) >= 2:
            return expiry_list[1]
        return expiry_list[0] if expiry_list else None

    def _resolve_expiry(self) -> Optional[date]:
        """Pick CW or NW expiry based on rollover rule.
        On expiry day itself (ROLLOVER_DAYS_BEFORE=0), switch to next week."""
        cw = self._get_nearest_option_expiry()
        if cw is None:
            self.log_error("No option expiry found.")
            return None

        days_to_cw = (cw - date.today()).days
        if days_to_cw <= ROLLOVER_DAYS_BEFORE:
            nw = self._get_next_week_expiry()
            if nw:
                self.log_info(f"Rollover: CW={cw} ({days_to_cw}d away), using NW={nw}")
                return nw

        self.log_info(f"Using CW expiry: {cw} ({days_to_cw}d away)")
        return cw

    def _get_available_strikes(self, expiry: date, option_type: str) -> list[Decimal]:
        """Get all available strikes for a given expiry and type."""
        strikes = Instrument.objects.filter(
            name=TICKER,
            exchange="NFO",
            instrument_type=option_type,
            expiry=expiry,
            is_active=True,
        ).values_list("strike", flat=True).distinct()
        return sorted([s for s in strikes if s is not None])

    def _find_atm_strike(self, price: float, strikes: list[Decimal]) -> Optional[Decimal]:
        """Find the strike closest to the given price."""
        if not strikes:
            return None
        price_d = Decimal(str(price))
        return min(strikes, key=lambda s: abs(s - price_d))

    def _get_option_instrument(
        self, expiry: date, strike: Decimal, option_type: str
    ) -> Optional[Instrument]:
        """Get a single option instrument."""
        return Instrument.objects.filter(
            name=TICKER,
            exchange="NFO",
            instrument_type=option_type,
            expiry=expiry,
            strike=strike,
            is_active=True,
        ).first()

    # =========================================================================
    # STATE RECOVERY
    # =========================================================================

    def _bootstrap_from_db(self) -> bool:
        """
        Restore state from DB if strategy was restarted mid-position.
        Follows IndexLongShort pattern: iterates open positions, restores CE/PE legs.

        Returns:
            True  -> Found open position(s); state restored.
            False -> No open position; fresh run.
        """
        db_positions = StrategyPosition.objects.filter(
            strategy=self.strategy_obj,
            status="OPEN",
        ).select_related("instrument")

        if not db_positions.exists():
            self.log_info("No existing open positions found. Fresh run.")
            return False

        for pos in db_positions:
            meta = pos.strategy_metadata or {}
            opt_type = meta.get("option_type")  # "CE" or "PE"

            if opt_type == "CE":
                self.entry_ce = pos.instrument
                self.open_positions["CE"] = pos
            elif opt_type == "PE":
                self.entry_pe = pos.instrument
                self.open_positions["PE"] = pos
            else:
                self.log_warning(
                    f"RECOVERY: Skipping position {pos.trade_id} "
                    f"with unknown option_type={opt_type}"
                )
                continue

            # Restore signal state from first leg encountered
            if self.position == 0:
                forward_dir = meta.get("forward_direction", "SHORT")
                self.position = 1 if forward_dir == "LONG" else -1
                self.entry_price = meta.get("spot_signal", float(pos.entry_price))
                self.entry_time = pos.entry_time

                saved_sl = meta.get("sl_price")
                if saved_sl is not None:
                    self.sl_price = float(saved_sl)
                else:
                    self.sl_price = None

            self.log_warning(
                f"RECOVERY: Restored {opt_type} leg | "
                f"instrument={pos.instrument.tradingsymbol} "
                f"@ {pos.entry_price:.2f} | entered={pos.entry_time}"
            )

        self.log_warning(
            f"RECOVERY: position={'LONG' if self.position == 1 else 'SHORT'} "
            f"| SL={self.sl_price} | legs={list(self.open_positions.keys())}"
        )
        return True

    # =========================================================================
    # CSV STATE PERSISTENCE
    # =========================================================================

    def _get_csv_path(self) -> str:
        """Return today's CSV state file path."""
        code = self.strategy_obj.strategy_code.lower()
        return os.path.join(IDXS_DUMP_DIR, f"{code}_{date.today().strftime('%Y%m%d')}.csv")

    def _append_csv_event(self, event: str, **kwargs) -> None:
        """Append a single event row to today's CSV state file."""
        csv_path = self._get_csv_path()
        os.makedirs(os.path.dirname(csv_path), exist_ok=True)

        file_exists = os.path.isfile(csv_path)

        row = {col: '' for col in CSV_COLUMNS}
        row['timestamp'] = datetime.now().isoformat()
        row['event'] = event
        row.update({k: v for k, v in kwargs.items() if k in CSV_COLUMNS})

        try:
            with open(csv_path, 'a', newline='') as f:
                writer = csv.DictWriter(f, fieldnames=CSV_COLUMNS)
                if not file_exists:
                    writer.writeheader()
                writer.writerow(row)
        except Exception as e:
            self.log_error(f"Failed to write CSV event: {e}")

    def _write_indicator_init_event(self) -> None:
        """Write INDICATOR_INIT event after historical indicator warmup."""
        self._append_csv_event(
            'INDICATOR_INIT',
            prev_entry_ema=self.prev_entry_ema,
            prev_exit_ema=self.prev_exit_ema,
            prev_up_rma=self.prev_up_rma,
            prev_down_rma=self.prev_down_rma,
            prev_rsi=self.prev_rsi,
            prev_rsi_ema_entry=self.prev_rsi_ema_entry,
            prev_rsi_ema_exit=self.prev_rsi_ema_exit,
        )

    def _write_candle_event(self, candle: dict, candle_idx: int) -> None:
        """Write CANDLE event after hourly candle processing.
        Captures full indicator state snapshot."""
        self._append_csv_event(
            'CANDLE',
            candle_idx=candle_idx,
            candle_open=candle['open'],
            candle_high=candle['high'],
            candle_low=candle['low'],
            candle_close=candle['close'],
            candle_volume=candle.get('volume', ''),
            prev_entry_ema=self.prev_entry_ema,
            prev_exit_ema=self.prev_exit_ema,
            prev_up_rma=self.prev_up_rma,
            prev_down_rma=self.prev_down_rma,
            prev_rsi=self.prev_rsi,
            prev_rsi_ema_entry=self.prev_rsi_ema_entry,
            prev_rsi_ema_exit=self.prev_rsi_ema_exit,
            position=self.position,
            sl_price=self.sl_price if self.sl_price is not None else '',
            entry_price=self.entry_price if self.entry_price is not None else '',
        )

    def _write_entry_event(
        self, atm_strike: float, expiry: date, spot_price: float
    ) -> None:
        """Write ENTRY event after forward entry placed."""
        self._append_csv_event(
            'ENTRY',
            position=self.position,
            entry_price=self.entry_price,
            sl_price=self.sl_price,
            ce_token=self.entry_ce.instrument_token if self.entry_ce else '',
            ce_tradingsymbol=self.entry_ce.tradingsymbol if self.entry_ce else '',
            pe_token=self.entry_pe.instrument_token if self.entry_pe else '',
            pe_tradingsymbol=self.entry_pe.tradingsymbol if self.entry_pe else '',
            expiry=str(expiry),
            atm_strike=atm_strike,
            spot_price=spot_price,
        )

    def _write_box_exit_event(
        self, exit_spot: float, exit_atm: float, exit_type: str = "BOX_SPREAD"
    ) -> None:
        """Write BOX_EXIT event after box spread exit."""
        self._append_csv_event(
            'BOX_EXIT',
            exit_type=exit_type,
            spot_price=exit_spot,
            exit_atm_strike=exit_atm,
        )

    def _write_rollover_event(self, nw_expiry: date, atm_strike: float) -> None:
        """Write ROLLOVER event after rollover complete."""
        self._append_csv_event(
            'ROLLOVER',
            ce_token=self.entry_ce.instrument_token if self.entry_ce else '',
            ce_tradingsymbol=self.entry_ce.tradingsymbol if self.entry_ce else '',
            pe_token=self.entry_pe.instrument_token if self.entry_pe else '',
            pe_tradingsymbol=self.entry_pe.tradingsymbol if self.entry_pe else '',
            expiry=str(nw_expiry),
            atm_strike=atm_strike,
            sl_price=self.sl_price,
            rollover_done=1,
        )

    def _write_day_reset_event(self) -> None:
        """Write DAY_RESET event on day boundary change."""
        self._append_csv_event('DAY_RESET')

    def _load_state_from_csv(self) -> Optional[str]:
        """
        Restore indicator + signal state from today's CSV event log.
        Restores: EMAs, RSI internals, candle tracking, rollover flag.
        Position/instrument state is handled by _bootstrap_from_db.

        Returns phase string or None if no CSV found.
        """
        csv_path = self._get_csv_path()
        if not os.path.isfile(csv_path):
            return None

        try:
            df = pd.read_csv(csv_path, on_bad_lines='skip')
        except Exception as e:
            self.log_error(f"Failed to read CSV state: {e}")
            return None

        if df.empty:
            return None

        latest_phase = None

        for _, row in df.iterrows():
            event = row.get('event', '')

            if event == 'INDICATOR_INIT':
                for field in ('prev_entry_ema', 'prev_exit_ema',
                              'prev_up_rma', 'prev_down_rma', 'prev_rsi',
                              'prev_rsi_ema_entry', 'prev_rsi_ema_exit'):
                    val = row.get(field)
                    if not pd.isna(val) and val != '':
                        setattr(self, field, float(val))
                latest_phase = 'INDICATOR_READY'

            elif event == 'CANDLE':
                # Restore indicator state
                for field in ('prev_entry_ema', 'prev_exit_ema',
                              'prev_up_rma', 'prev_down_rma', 'prev_rsi',
                              'prev_rsi_ema_entry', 'prev_rsi_ema_exit'):
                    val = row.get(field)
                    if not pd.isna(val) and val != '':
                        setattr(self, field, float(val))

                # Restore candle index
                idx = row.get('candle_idx')
                if not pd.isna(idx):
                    self.last_processed_candle_idx = int(idx)

                # Rebuild hourly_candles
                co = row.get('candle_open')
                ch = row.get('candle_high')
                cl = row.get('candle_low')
                cc = row.get('candle_close')
                if not any(pd.isna(v) for v in [co, ch, cl, cc]):
                    cidx = int(idx) if not pd.isna(idx) else len(self.hourly_candles)
                    if cidx < len(VALID_HOURLY_TIMES):
                        self.hourly_candles.append({
                            'timestamp': pd.Timestamp.combine(
                                date.today(), VALID_HOURLY_TIMES[cidx]
                            ),
                            'open': float(co), 'high': float(ch),
                            'low': float(cl), 'close': float(cc),
                        })

                # SL may have been trailed in candle processing
                sl = row.get('sl_price')
                if not pd.isna(sl) and sl != '':
                    self.sl_price = float(sl)

                latest_phase = 'RUNNING'

            elif event == 'ENTRY':
                latest_phase = 'IN_POSITION'

            elif event == 'BOX_EXIT':
                latest_phase = 'RUNNING'

            elif event == 'ROLLOVER':
                rollover = row.get('rollover_done')
                if not pd.isna(rollover):
                    self._rollover_done_today = bool(int(rollover))
                latest_phase = 'IN_POSITION'

            elif event == 'DAY_RESET':
                self.hourly_candles.clear()
                self.last_processed_candle_idx = -1
                self._rollover_done_today = False
                latest_phase = 'RUNNING'

        self.log_info(
            f"CSV RECOVERY: phase={latest_phase} | "
            f"entry_ema={self.prev_entry_ema:.2f} exit_ema={self.prev_exit_ema:.2f} | "
            f"RSI={self.prev_rsi:.2f} | candle_idx={self.last_processed_candle_idx} "
            f"| hourly_candles={len(self.hourly_candles)} "
            f"| rollover_done={self._rollover_done_today}"
        )
        return latest_phase

    # =========================================================================
    # ORDER PLACEMENT
    # =========================================================================

    def _limit_price(self, side: str, ltp: float) -> Decimal:
        """Passive limit: SELL → LTP + offset, BUY → LTP − offset."""
        base = Decimal(str(ltp))
        return base + PRICE_OFFSET if side == "SELL" else base - PRICE_OFFSET

    def _fetch_ltp(self, datafeed_handler, instrument: Instrument) -> Optional[float]:
        """Fetch LTP for a single instrument. Retries indefinitely with token refresh on failure."""
        attempt = 0
        while self.is_running:
            attempt += 1
            try:
                response = datafeed_handler.get_multiple_ltp([instrument])
                if response and "data" in response:
                    for item in response["data"].get("ltp_list", []):
                        if item.get("instrument_token") == instrument.instrument_token:
                            return item.get("ltp")
                return None  # Successful call, no matching data — don't retry
            except Exception as e:
                self.log_warning(
                    f"LTP fetch failed (attempt {attempt}) for "
                    f"{instrument.tradingsymbol}: {e}"
                )
                try:
                    from datafeed.rest.handler import DataFeedHandler
                    DataFeedHandler(self.datafeed_obj).update_token()
                    self.datafeed_obj.refresh_from_db()
                    self.log_info("Datafeed token refreshed after LTP failure")
                except Exception as refresh_err:
                    self.log_error(f"Token refresh failed: {refresh_err}")
                time.sleep(2)
        return None

    def _fetch_multiple_ltp(self, datafeed_handler, instruments: list[Instrument]) -> dict[int, float]:
        """Fetch LTP for multiple instruments. Retries indefinitely with token refresh on failure."""
        if not instruments:
            return {}
        attempt = 0
        while self.is_running:
            attempt += 1
            try:
                result: dict[int, float] = {}
                response = datafeed_handler.get_multiple_ltp(instruments)
                if response and "data" in response:
                    for item in response["data"].get("ltp_list", []):
                        token = item.get("instrument_token")
                        ltp = item.get("ltp")
                        if token and ltp:
                            result[token] = ltp
                return result  # Successful call — return even if empty
            except Exception as e:
                self.log_warning(
                    f"Multiple LTP fetch failed (attempt {attempt}) for "
                    f"{len(instruments)} instruments: {e}"
                )
                try:
                    from datafeed.rest.handler import DataFeedHandler
                    DataFeedHandler(self.datafeed_obj).update_token()
                    self.datafeed_obj.refresh_from_db()
                    self.log_info("Datafeed token refreshed after multi-LTP failure")
                except Exception as refresh_err:
                    self.log_error(f"Token refresh failed: {refresh_err}")
                time.sleep(2)
        return {}

    def _place_order(
        self,
        instrument: Instrument,
        side: str,
        quantity: int,
        price: Optional[Decimal],
        order_intent: str,
        tag: str = "",
        dry_run: bool = False,
    ) -> tuple[bool, object]:
        """Place an order via OrderManager. Supports dry-run mode."""
        order_type = "LIMIT" if price is not None else "MARKET"
        price_str = str(price) if price is not None else "MKT"

        if dry_run:
            self.log_info(
                f"  [DRY-RUN][{tag}] {order_intent} {side} {quantity}x"
                f" {instrument.tradingsymbol}"
                f" | {order_type} @ {price_str}"
                f" | NRML"
                f" | expiry={instrument.expiry}"
            )
            return True, None

        success, msg, parent_order, _ = order_manager.create_and_execute_order(
            strategy=self.strategy_obj,
            instrument=instrument,
            side=side,
            quantity=quantity,
            order_type=order_type,
            product_type="NRML",
            price=price,
            order_intent=order_intent,
            metadata={
                "strategy_code": self.strategy_obj.strategy_code,
                "instrument_type": instrument.instrument_type,
                "stock_name": instrument.name,
                "tag": tag,
            },
        )
        if success:
            self.log_info(
                f"  [{tag}] {side} {quantity}x {instrument.tradingsymbol}"
                f" @ {price_str}"
            )
        else:
            self.log_error(f"  [{tag}] FAILED {side} {instrument.tradingsymbol}: {msg}")
        return success, parent_order

    # =========================================================================
    # SIGNAL → ORDER EXECUTION (Synthetic Forward)
    # =========================================================================

    def _execute_signal(self, signal: dict, datafeed_handler, dry_run: bool) -> None:
        """Translate a signal from _on_candle_close/_check_poll_sl into synthetic forward orders.
        Entry: ATM CE + ATM PE at CW expiry (with rollover).
        Exit: Opposing forward at current ATM, same expiry → box spread."""
        action = signal["action"]

        if action == "ENTER_SHORT":
            self._execute_forward_entry(signal, "SHORT", datafeed_handler, dry_run)

        elif action == "EXIT_SHORT":
            self._execute_forward_exit(signal, datafeed_handler, dry_run)

    def _execute_forward_entry(
        self, signal: dict, direction: str, datafeed_handler, dry_run: bool
    ) -> None:
        """
        Place a synthetic forward entry (mirrors IndexLongShort):
          SHORT forward = BUY ATM PE + SELL ATM CE
        """
        spot_price = signal["price"]

        # 1. Resolve expiry (CW with rollover on expiry day)
        expiry = self._resolve_expiry()
        if not expiry:
            self.log_error("Cannot resolve option expiry. Refusing to trade.")
            return

        # 2. Find ATM strike from spot price
        ce_strikes = self._get_available_strikes(expiry, "CE")
        atm_strike = self._find_atm_strike(spot_price, ce_strikes)
        if atm_strike is None:
            self.log_error(
                f"No ATM strike found for spot={spot_price:.2f} expiry={expiry}"
            )
            return

        # 3. Get CE and PE instruments at ATM strike
        ce_inst = self._get_option_instrument(expiry, atm_strike, "CE")
        pe_inst = self._get_option_instrument(expiry, atm_strike, "PE")
        if not ce_inst or not pe_inst:
            self.log_error(
                f"ATM instruments not found: strike={atm_strike} expiry={expiry} "
                f"CE={'found' if ce_inst else 'MISSING'} "
                f"PE={'found' if pe_inst else 'MISSING'}"
            )
            return

        lot_size = ce_inst.lot_size

        # 4. Fetch LTPs for both legs in one call
        ltps = self._fetch_multiple_ltp(datafeed_handler, [ce_inst, pe_inst])
        ce_ltp = ltps.get(ce_inst.instrument_token)
        pe_ltp = ltps.get(pe_inst.instrument_token)

        self.log_info(
            f"ENTER_{direction} (synthetic forward): spot={spot_price:.2f} "
            f"ATM={atm_strike} expiry={expiry} "
            f"CE_LTP={ce_ltp} PE_LTP={pe_ltp}"
        )

        # 5. Determine sides based on direction
        if direction == "LONG":
            ce_side, pe_side = "BUY", "SELL"
            ce_tag, pe_tag = "IDXS_LONG_CE_BUY", "IDXS_LONG_PE_SELL"
            ce_pos_type, pe_pos_type = "LONG", "SHORT"
        else:
            ce_side, pe_side = "SELL", "BUY"
            ce_tag, pe_tag = "IDXS_SHORT_CE_SELL", "IDXS_SHORT_PE_BUY"
            ce_pos_type, pe_pos_type = "SHORT", "LONG"

        # 6. Place CE leg
        ce_price = self._limit_price(ce_side, ce_ltp) if ce_ltp else None
        if ce_ltp is None:
            self.log_warning("CE LTP unavailable — placing MARKET order")
        success_ce, po_ce = self._place_order(
            ce_inst, ce_side, lot_size, ce_price,
            order_intent="ENTRY", tag=ce_tag, dry_run=dry_run,
        )

        # 7. Place PE leg
        pe_price = self._limit_price(pe_side, pe_ltp) if pe_ltp else None
        if pe_ltp is None:
            self.log_warning("PE LTP unavailable — placing MARKET order")
        success_pe, po_pe = self._place_order(
            pe_inst, pe_side, lot_size, pe_price,
            order_intent="ENTRY", tag=pe_tag, dry_run=dry_run,
        )

        # 8. Create DB positions (one per leg)
        common_meta = {
            "forward_direction": direction,
            "atm_strike": float(atm_strike),
            "expiry": str(expiry),
            "spot_signal": spot_price,
            "sl_price": signal.get("sl_price"),
        }

        if success_ce:
            self.entry_ce = ce_inst
            self.open_positions["CE"] = StrategyPosition.objects.create(
                trade_id=f"IDXS_{self.strategy_obj.id}_{uuid.uuid4().hex[:8]}",
                strategy=self.strategy_obj,
                instrument=ce_inst,
                position_type=ce_pos_type,
                status="OPEN",
                quantity=lot_size,
                entry_price=Decimal(str(ce_ltp)) if ce_ltp else (ce_price or Decimal("0")),
                entry_time=timezone.now(),
                entry_parent_order=po_ce,
                last_price=Decimal(str(ce_ltp)) if ce_ltp else Decimal("0"),
                last_price_updated_at=timezone.now(),
                strategy_metadata={
                    "option_type": "CE",
                    "ce_tradingsymbol": ce_inst.tradingsymbol,
                    "pe_tradingsymbol": pe_inst.tradingsymbol,
                    **common_meta,
                },
            )

        if success_pe:
            self.entry_pe = pe_inst
            self.open_positions["PE"] = StrategyPosition.objects.create(
                trade_id=f"IDXS_{self.strategy_obj.id}_{uuid.uuid4().hex[:8]}",
                strategy=self.strategy_obj,
                instrument=pe_inst,
                position_type=pe_pos_type,
                status="OPEN",
                quantity=lot_size,
                entry_price=Decimal(str(pe_ltp)) if pe_ltp else (pe_price or Decimal("0")),
                entry_time=timezone.now(),
                entry_parent_order=po_pe,
                last_price=Decimal(str(pe_ltp)) if pe_ltp else Decimal("0"),
                last_price_updated_at=timezone.now(),
                strategy_metadata={
                    "option_type": "PE",
                    "ce_tradingsymbol": ce_inst.tradingsymbol,
                    "pe_tradingsymbol": pe_inst.tradingsymbol,
                    **common_meta,
                },
            )

        if success_ce and success_pe:
            self.log_info(
                f"  {direction} synthetic forward opened: ATM={atm_strike} "
                f"expiry={expiry} CE={ce_inst.tradingsymbol} "
                f"PE={pe_inst.tradingsymbol} SL={signal.get('sl_price')} "
                f"lot={lot_size}"
            )
            self._write_entry_event(float(atm_strike), expiry, spot_price)
        else:
            self.log_error("=" * 20)
            self.log_error(f"  CRITICAL ALERT: PARTIAL ENTRY DETECTED! ")
            self.log_error(f"  Strategy attempted {direction} entry but only one leg filled!")
            self.log_error(f"  CE={'FILLED' if success_ce else 'FAILED'} | PE={'FILLED' if success_pe else 'FAILED'}")
            self.log_error(f"  YOU NOW HAVE NAKED DIRECTIONAL EXPOSURE. INTERVENE IMMEDIATELY!")
            self.log_error("=" * 20)

    def _execute_forward_exit(
        self, signal: dict, datafeed_handler, dry_run: bool
    ) -> None:
        """
        Exit a synthetic forward by creating an opposing forward at current ATM,
        SAME expiry as entry — forming a box spread that locks P&L until expiry.

        Short position exit → LONG forward (BUY CE + SELL PE) at current ATM
        """
        exit_spot = signal["exit_price"]

        # ── 1. Retrieve entry expiry from existing position metadata ─────
        if not self.open_positions:
            self.log_error("No open positions to exit. Resetting state.")
            self.entry_ce = None
            self.entry_pe = None
            self.open_positions.clear()
            self.position = 0
            self.trigger = 0
            self.sl_price = None
            return

        first_pos = next(iter(self.open_positions.values()))
        entry_meta = first_pos.strategy_metadata or {}
        entry_expiry_str = entry_meta.get("expiry")
        if not entry_expiry_str:
            self.log_error("No expiry in position metadata. Cannot create box spread.")
            return
        entry_expiry = date.fromisoformat(entry_expiry_str)
        entry_atm = entry_meta.get("atm_strike")

        self.log_info(
            f"EXIT via box spread: entry_ATM={entry_atm} | "
            f"exit_spot={exit_spot:.2f} | expiry={entry_expiry}"
        )

        # ── 2. Find ATM strike at current spot ──────────────────────────
        ce_strikes = self._get_available_strikes(entry_expiry, "CE")
        atm_strike = self._find_atm_strike(exit_spot, ce_strikes)
        if atm_strike is None:
            self.log_error(
                f"No ATM strike for exit: spot={exit_spot:.2f} expiry={entry_expiry}"
            )
            return

        # ── 3. Get exit CE and PE instruments ────────────────────────────
        ce_inst = self._get_option_instrument(entry_expiry, atm_strike, "CE")
        pe_inst = self._get_option_instrument(entry_expiry, atm_strike, "PE")
        if not ce_inst or not pe_inst:
            self.log_error(
                f"Exit instruments not found: strike={atm_strike} expiry={entry_expiry} "
                f"CE={'found' if ce_inst else 'MISSING'} "
                f"PE={'found' if pe_inst else 'MISSING'}"
            )
            return

        lot_size = ce_inst.lot_size

        # ── 4. Fetch LTPs (exit legs + entry legs for exit_price) ────────
        all_instruments = [ce_inst, pe_inst]
        if self.entry_ce:
            all_instruments.append(self.entry_ce)
        if self.entry_pe:
            all_instruments.append(self.entry_pe)
        ltps = self._fetch_multiple_ltp(datafeed_handler, all_instruments)

        ce_ltp = ltps.get(ce_inst.instrument_token)
        pe_ltp = ltps.get(pe_inst.instrument_token)

        # ── 5. Determine sides (opposite of entry direction) ─────────────
        if signal["direction"] == 1:  # was LONG → exit with SHORT forward
            ce_side, pe_side = "SELL", "BUY"
            ce_tag, pe_tag = "IDXS_BOX_CE_SELL", "IDXS_BOX_PE_BUY"
            exit_fwd_dir = "SHORT"
        else:  # was SHORT → exit with LONG forward
            ce_side, pe_side = "BUY", "SELL"
            ce_tag, pe_tag = "IDXS_BOX_CE_BUY", "IDXS_BOX_PE_SELL"
            exit_fwd_dir = "LONG"

        self.log_info(
            f"  Box {exit_fwd_dir} forward: ATM={atm_strike} "
            f"CE_{ce_side} PE_{pe_side} | CE_LTP={ce_ltp} PE_LTP={pe_ltp}"
        )

        # ── 6. Place CE exit leg ─────────────────────────────────────────
        ce_price = self._limit_price(ce_side, ce_ltp) if ce_ltp else None
        if ce_ltp is None:
            self.log_warning("Exit CE LTP unavailable — placing MARKET order")
        success_ce, po_ce = self._place_order(
            ce_inst, ce_side, lot_size, ce_price,
            order_intent="BOX_EXIT", tag=ce_tag, dry_run=dry_run,
        )

        # ── 7. Place PE exit leg ─────────────────────────────────────────
        pe_price = self._limit_price(pe_side, pe_ltp) if pe_ltp else None
        if pe_ltp is None:
            self.log_warning("Exit PE LTP unavailable — placing MARKET order")
        success_pe, po_pe = self._place_order(
            pe_inst, pe_side, lot_size, pe_price,
            order_intent="BOX_EXIT", tag=pe_tag, dry_run=dry_run,
        )

        # ── 8. Handle results ────────────────────────────────────────────
        if not success_ce and not success_pe:
            self.log_error(
                "  Both exit legs FAILED — position remains open, SL still active!"
            )
            return  # Don't reset; keep monitoring for next SL tick

        if success_ce and success_pe:
            # Full success — close both entry positions in DB
            for opt_type, pos in self.open_positions.items():
                entry_inst = self.entry_ce if opt_type == "CE" else self.entry_pe
                entry_ltp = ltps.get(entry_inst.instrument_token) if entry_inst else None

                pos.status = "CLOSED"
                pos.exit_price = Decimal(str(entry_ltp)) if entry_ltp else pos.entry_price
                pos.exit_time = timezone.now()
                if opt_type == "CE" and po_ce:
                    pos.exit_parent_order = po_ce
                elif opt_type == "PE" and po_pe:
                    pos.exit_parent_order = po_pe

                meta = pos.strategy_metadata or {}
                meta["exit_type"] = "BOX_SPREAD"
                meta["exit_atm_strike"] = float(atm_strike)
                meta["exit_spot"] = exit_spot
                meta["exit_fwd_direction"] = exit_fwd_dir
                meta["exit_ce_tradingsymbol"] = ce_inst.tradingsymbol
                meta["exit_pe_tradingsymbol"] = pe_inst.tradingsymbol
                pos.strategy_metadata = meta
                pos.save()

            self.log_info(
                f"  Box spread locked: entry_ATM={entry_atm} → exit_ATM={atm_strike} "
                f"| expiry={entry_expiry} | entry_spot={signal.get('entry_price'):.2f} "
                f"exit_spot={exit_spot:.2f}"
            )
        else:
            self.log_error("=" * 20)
            self.log_error(f"  CRITICAL ALERT: PARTIAL BOX EXIT DETECTED! ")
            self.log_error(f"  CE={'EXITED' if success_ce else 'FAILED'} | PE={'EXITED' if success_pe else 'FAILED'}")
            self.log_error(f"  STRATEGY STATE IS BEING WIPED. THE ORPHANED LEG IS UNMANAGED!")
            self.log_error(f"  YOU MUST MANUALLY CLOSE THE REMAINING LEG IMMEDIATELY!")
            self.log_error("=" * 20)

        # ── 9. Persist to CSV, then reset signal state ─────────────────
        if success_ce or success_pe:
            self._write_box_exit_event(exit_spot, float(atm_strike))
        self.entry_ce = None
        self.entry_pe = None
        self.open_positions.clear()
        self.position = 0
        self.trigger = 0
        self.sl_price = None

    def _execute_rollover(
        self, spot_price: float, datafeed_handler, dry_run: bool
    ) -> None:
        """
        Roll position from CW to NW on expiry day:
          1. Box exit current CW position (opposing forward, same expiry)
          2. Re-enter same direction at NW (new expiry, current ATM)
          Signal state (position, trigger, sl_price) is preserved.
        """
        if not self.open_positions or self.position == 0:
            return

        direction = "LONG" if self.position == 1 else "SHORT"

        # ── Get CW expiry from existing positions ────────────────────────
        first_pos = next(iter(self.open_positions.values()))
        entry_meta = first_pos.strategy_metadata or {}
        cw_expiry_str = entry_meta.get("expiry")
        if not cw_expiry_str:
            self.log_error("ROLLOVER: No expiry in position metadata.")
            return
        cw_expiry = date.fromisoformat(cw_expiry_str)

        # ── Get NW expiry ────────────────────────────────────────────────
        nw_expiry = self._get_next_week_expiry()
        if not nw_expiry:
            self.log_error("ROLLOVER: Cannot find NW expiry.")
            return

        self.log_info("=" * 60)
        self.log_info(
            f"ROLLOVER: {direction} | CW={cw_expiry} -> NW={nw_expiry} "
            f"| spot={spot_price:.2f}"
        )
        self.log_info("=" * 60)

        # ── Find ATM strike at current spot ──────────────────────────────
        ce_strikes_cw = self._get_available_strikes(cw_expiry, "CE")
        atm_strike = self._find_atm_strike(spot_price, ce_strikes_cw)
        if atm_strike is None:
            self.log_error(f"ROLLOVER: No ATM strike for spot={spot_price:.2f}")
            return

        # ── Get all 4 instruments ────────────────────────────────────────
        cw_ce = self._get_option_instrument(cw_expiry, atm_strike, "CE")
        cw_pe = self._get_option_instrument(cw_expiry, atm_strike, "PE")
        nw_ce = self._get_option_instrument(nw_expiry, atm_strike, "CE")
        nw_pe = self._get_option_instrument(nw_expiry, atm_strike, "PE")

        if not all([cw_ce, cw_pe, nw_ce, nw_pe]):
            self.log_error(
                f"ROLLOVER: Missing instruments at ATM={atm_strike} | "
                f"CW_CE={'OK' if cw_ce else 'MISSING'} "
                f"CW_PE={'OK' if cw_pe else 'MISSING'} "
                f"NW_CE={'OK' if nw_ce else 'MISSING'} "
                f"NW_PE={'OK' if nw_pe else 'MISSING'}"
            )
            return

        lot_size = cw_ce.lot_size

        # ── Fetch LTPs for all instruments ───────────────────────────────
        all_insts = [cw_ce, cw_pe, nw_ce, nw_pe]
        if self.entry_ce:
            all_insts.append(self.entry_ce)
        if self.entry_pe:
            all_insts.append(self.entry_pe)
        ltps = self._fetch_multiple_ltp(datafeed_handler, all_insts)

        # ── Determine sides ──────────────────────────────────────────────
        if direction == "LONG":
            box_ce_side, box_pe_side = "SELL", "BUY"
            box_ce_tag = "IDXS_ROLL_BOX_CE_SELL"
            box_pe_tag = "IDXS_ROLL_BOX_PE_BUY"
            nw_ce_side, nw_pe_side = "BUY", "SELL"
            nw_ce_tag, nw_pe_tag = "IDXS_ROLL_NW_CE_BUY", "IDXS_ROLL_NW_PE_SELL"
            nw_ce_pos_type, nw_pe_pos_type = "LONG", "SHORT"
        else:
            box_ce_side, box_pe_side = "BUY", "SELL"
            box_ce_tag = "IDXS_ROLL_BOX_CE_BUY"
            box_pe_tag = "IDXS_ROLL_BOX_PE_SELL"
            nw_ce_side, nw_pe_side = "SELL", "BUY"
            nw_ce_tag, nw_pe_tag = "IDXS_ROLL_NW_CE_SELL", "IDXS_ROLL_NW_PE_BUY"
            nw_ce_pos_type, nw_pe_pos_type = "SHORT", "LONG"

        # ── Step 1: Box exit at CW (opposing forward) ────────────────────
        self.log_info(
            f"  ROLL Step 1: Box exit at CW={cw_expiry} ATM={atm_strike}"
        )

        cw_ce_ltp = ltps.get(cw_ce.instrument_token)
        cw_pe_ltp = ltps.get(cw_pe.instrument_token)

        box_ce_price = self._limit_price(box_ce_side, cw_ce_ltp) if cw_ce_ltp else None
        if cw_ce_ltp is None:
            self.log_warning("Roll box CE LTP unavailable — placing MARKET order")
        box_ce_ok, box_ce_po = self._place_order(
            cw_ce, box_ce_side, lot_size, box_ce_price,
            order_intent="BOX_EXIT", tag=box_ce_tag, dry_run=dry_run,
        )

        box_pe_price = self._limit_price(box_pe_side, cw_pe_ltp) if cw_pe_ltp else None
        if cw_pe_ltp is None:
            self.log_warning("Roll box PE LTP unavailable — placing MARKET order")
        box_pe_ok, box_pe_po = self._place_order(
            cw_pe, box_pe_side, lot_size, box_pe_price,
            order_intent="BOX_EXIT", tag=box_pe_tag, dry_run=dry_run,
        )

        if not box_ce_ok or not box_pe_ok:
            self.log_error("=" * 20)
            self.log_error(f"  CRITICAL ALERT: ROLLOVER BOX EXIT FAILED OR PARTIAL! ")
            self.log_error(f"  Box Exit CE={'OK' if box_ce_ok else 'FAILED'} | PE={'OK' if box_pe_ok else 'FAILED'}")
            self.log_error(f"  ROLLOVER ABORTED AND WILL NOT RETRY. OPEN POSITIONS IN IMMINENT DANGER OF EXPIRY!")
            self.log_error(f"  MANUAL INTERVENTION URGENTLY REQUIRED!")
            self.log_error("=" * 20)
            self._rollover_done_today = True  # Don't retry
            return

        # ── Close entry positions in DB ──────────────────────────────────
        for opt_type, pos in self.open_positions.items():
            entry_inst = self.entry_ce if opt_type == "CE" else self.entry_pe
            entry_ltp = ltps.get(entry_inst.instrument_token) if entry_inst else None

            pos.status = "CLOSED"
            pos.exit_price = Decimal(str(entry_ltp)) if entry_ltp else pos.entry_price
            pos.exit_time = timezone.now()
            if opt_type == "CE" and box_ce_po:
                pos.exit_parent_order = box_ce_po
            elif opt_type == "PE" and box_pe_po:
                pos.exit_parent_order = box_pe_po

            meta = pos.strategy_metadata or {}
            meta["exit_type"] = "ROLLOVER_BOX"
            meta["exit_atm_strike"] = float(atm_strike)
            meta["exit_spot"] = spot_price
            meta["rolled_to_expiry"] = str(nw_expiry)
            pos.strategy_metadata = meta
            pos.save()

        self._write_box_exit_event(spot_price, float(atm_strike), exit_type="ROLLOVER_BOX")

        # ── Step 2: Enter same direction at NW ───────────────────────────
        self.log_info(
            f"  ROLL Step 2: Enter {direction} at NW={nw_expiry} ATM={atm_strike}"
        )

        nw_ce_ltp = ltps.get(nw_ce.instrument_token)
        nw_pe_ltp = ltps.get(nw_pe.instrument_token)

        nw_ce_price = self._limit_price(nw_ce_side, nw_ce_ltp) if nw_ce_ltp else None
        if nw_ce_ltp is None:
            self.log_warning("Roll NW CE LTP unavailable — placing MARKET order")
        nw_ce_ok, nw_ce_po = self._place_order(
            nw_ce, nw_ce_side, lot_size, nw_ce_price,
            order_intent="ENTRY", tag=nw_ce_tag, dry_run=dry_run,
        )

        nw_pe_price = self._limit_price(nw_pe_side, nw_pe_ltp) if nw_pe_ltp else None
        if nw_pe_ltp is None:
            self.log_warning("Roll NW PE LTP unavailable — placing MARKET order")
        nw_pe_ok, nw_pe_po = self._place_order(
            nw_pe, nw_pe_side, lot_size, nw_pe_price,
            order_intent="ENTRY", tag=nw_pe_tag, dry_run=dry_run,
        )

        if not nw_ce_ok or not nw_pe_ok:
            self.log_error("=" * 20)
            self.log_error(f"  CRITICAL ALERT: ROLLOVER NW ENTRY FAILED OR PARTIAL! ")
            self.log_error(f"  NW Entry CE={'OK' if nw_ce_ok else 'FAILED'} | PE={'OK' if nw_pe_ok else 'FAILED'}")
            self.log_error(f"  YOU HAVE A NAKED POSITION IN THE NEW WEEK! SQUASH THE ORPHAN LEG IMMEDIATELY!")
            self.log_error("=" * 20)

        # ── Update state for NW positions ────────────────────────────────
        self.open_positions.clear()
        self.entry_ce = None
        self.entry_pe = None

        common_meta = {
            "forward_direction": direction,
            "atm_strike": float(atm_strike),
            "expiry": str(nw_expiry),
            "spot_signal": self.entry_price,
            "sl_price": self.sl_price,
            "rolled_from_expiry": str(cw_expiry),
            "rollover_spot": spot_price,
        }

        if nw_ce_ok:
            self.entry_ce = nw_ce
            self.open_positions["CE"] = StrategyPosition.objects.create(
                trade_id=f"IDXS_{self.strategy_obj.id}_{uuid.uuid4().hex[:8]}",
                strategy=self.strategy_obj,
                instrument=nw_ce,
                position_type=nw_ce_pos_type,
                status="OPEN",
                quantity=lot_size,
                entry_price=Decimal(str(nw_ce_ltp)) if nw_ce_ltp else (nw_ce_price or Decimal("0")),
                entry_time=timezone.now(),
                entry_parent_order=nw_ce_po,
                last_price=Decimal(str(nw_ce_ltp)) if nw_ce_ltp else Decimal("0"),
                last_price_updated_at=timezone.now(),
                strategy_metadata={
                    "option_type": "CE",
                    "ce_tradingsymbol": nw_ce.tradingsymbol,
                    "pe_tradingsymbol": nw_pe.tradingsymbol,
                    **common_meta,
                },
            )

        if nw_pe_ok:
            self.entry_pe = nw_pe
            self.open_positions["PE"] = StrategyPosition.objects.create(
                trade_id=f"IDXS_{self.strategy_obj.id}_{uuid.uuid4().hex[:8]}",
                strategy=self.strategy_obj,
                instrument=nw_pe,
                position_type=nw_pe_pos_type,
                status="OPEN",
                quantity=lot_size,
                entry_price=Decimal(str(nw_pe_ltp)) if nw_pe_ltp else (nw_pe_price or Decimal("0")),
                entry_time=timezone.now(),
                entry_parent_order=nw_pe_po,
                last_price=Decimal(str(nw_pe_ltp)) if nw_pe_ltp else Decimal("0"),
                last_price_updated_at=timezone.now(),
                strategy_metadata={
                    "option_type": "PE",
                    "ce_tradingsymbol": nw_ce.tradingsymbol,
                    "pe_tradingsymbol": nw_pe.tradingsymbol,
                    **common_meta,
                },
            )

        self._rollover_done_today = True

        self._write_rollover_event(nw_expiry, float(atm_strike))

        self.log_info(
            f"  ROLLOVER COMPLETE: {direction} CW({cw_expiry}) -> NW({nw_expiry}) "
            f"| ATM={atm_strike} | SL={self.sl_price} (preserved)"
        )

    # =========================================================================
    # TIME UTILITIES
    # =========================================================================

    def _get_today_datetime(self, time_obj) -> datetime:
        today = timezone.now().date()
        naive_dt = datetime.combine(today, time_obj)
        return timezone.make_aware(naive_dt)

    def _wait_until(self, target_time: datetime) -> bool:
        while self.is_running:
            now = timezone.now()
            if now >= target_time:
                return True
            remaining = (target_time - now).total_seconds()
            if remaining > 60:
                self.log_info(
                    f"Waiting {int(remaining // 60)}m {int(remaining % 60)}s "
                    f"until {target_time.strftime('%H:%M:%S')}"
                )
                time.sleep(30)
            else:
                time.sleep(1)
        return False

    # =========================================================================
    # BASE STRATEGY INTERFACE
    # =========================================================================

    # def _refresh_broker_tokens(self) -> None:  # Centralized — handled by TokenRefreshManager
    #     """Periodically refresh broker account tokens to prevent order failures."""
    #     from accounts.models import StrategyAccountMapping
    #     from accounts.brokers.handler import BrokerAccountHandler
    #
    #     mappings = StrategyAccountMapping.objects.filter(
    #         strategy=self.strategy_obj,
    #         is_active=True,
    #     ).select_related('broker_account', 'broker_account__broker')
    #
    #     for mapping in mappings:
    #         ba = mapping.broker_account
    #         ba.refresh_from_db()
    #         if ba.is_token_expired:
    #             self.log_warning(f"Broker token expired for {ba.account_name} — refreshing...")
    #             try:
    #                 BrokerAccountHandler(ba).update_token()
    #                 ba.refresh_from_db()
    #                 self.log_info(f"Broker token refreshed for {ba.account_name}")
    #             except Exception as e:
    #                 self.log_error(f"Broker token refresh failed for {ba.account_name}: {e}")
    #
    #     # Also refresh datafeed token if needed
    #     self.datafeed_obj.refresh_from_db()
    #     if self.datafeed_obj.is_token_expired:
    #         self.log_warning("Datafeed token expired — refreshing...")
    #         try:
    #             from datafeed.rest.handler import DataFeedHandler
    #             DataFeedHandler(self.datafeed_obj).update_token()
    #             self.datafeed_obj.refresh_from_db()
    #             self.log_info("Datafeed token refreshed")
    #         except Exception as e:
    #             self.log_error(f"Datafeed token refresh failed: {e}")

    def verify(self) -> bool:
        if not self.datafeed_obj:
            self.log_error("No datafeed object provided.")
            return False

        if self.datafeed_obj.is_token_expired:
            self.log_warning("Datafeed token expired — attempting refresh...")
            from datafeed.rest.handler import DataFeedHandler
            handler = DataFeedHandler(self.datafeed_obj)
            if not handler.update_token():
                self.log_error("Failed to refresh datafeed token.")
                return False

        self.log_info("Verification passed.")
        return True

    def stop(self):
        self.log_info("Stopping IndexShort...")
        self.is_running = False

    def run(self):
        params = self.strategy_obj.strategy_params or {}
        dry_run = bool(params.get("dry_run", False))

        self.log_info("=" * 60)
        self.log_info(f"Starting IndexShort")
        self.log_info(f"Entry Time : {self.strategy_obj.entry_time}")
        self.log_info(f"Exit Time  : {self.strategy_obj.exit_time}")
        self.log_info(f"Mode       : {'DRY-RUN' if dry_run else 'LIVE'}")
        self.log_info("=" * 60)

        if not self.verify():
            self.log_error("Verification failed. Exiting.")
            return

        self.is_running = True

        from datafeed.rest.handler import DataFeedHandler
        datafeed_handler = DataFeedHandler(self.datafeed_obj)

        entry_dt = self._get_today_datetime(self.strategy_obj.entry_time)
        self.log_info(f"Waiting for entry time: {entry_dt.strftime('%H:%M:%S')}")
        if not self._wait_until(entry_dt):
            self.log_info("Strategy stopped while waiting.")
            return
        if not self.is_running:
            return

        self.nifty_future = self._get_far_month_future("NIFTY")
        if not self.nifty_future:
            self.log_error("Could not find NIFTY future. Exiting.")
            self.is_running = False
            return

        self._bootstrap_from_db()           # Authoritative for position/instrument state
        csv_phase = self._load_state_from_csv()  # Fills in EMAs, RSI, candle tracking

        if csv_phase is not None:
            # Consistency check: CSV says in position but DB has no open positions
            if self.position != 0 and not self.open_positions:
                self.log_warning(
                    "RECOVERY: CSV shows position but no open DB positions. "
                    "Resetting to flat."
                )
                self.position = 0
                self.sl_price = None
            self.log_info("Restored from CSV — skipping historical warmup.")
        else:
            # Fresh start — fetch history and warm up indicators
            df = self._fetch_historical_hourly_data()
            if df is None:
                self.log_error("Failed to fetch historical warmup data. Exiting.")
                self.is_running = False
                return
            self._calculate_initial_indicators(df)
            self._write_indicator_init_event()

        # Protect recovered state from being wiped by the day-boundary check
        self._current_trading_date = date.today()

        self.log_info("Entering main futures polling loop...")
        exit_dt = self._get_today_datetime(self.strategy_obj.exit_time)

        while self.is_running:
            if timezone.now() >= exit_dt:
                self.log_info("Exit time reached. Stopping loop.")
                break

            # Periodic broker + datafeed token refresh — centralized in TokenRefreshManager
            # if time.time() - self._last_broker_token_refresh >= BROKER_TOKEN_REFRESH_INTERVAL_SECS:
            #     try:
            #         self._refresh_broker_tokens()
            #     except Exception as e:
            #         self.log_error(f"Broker token refresh cycle failed: {e}")
            #     self._last_broker_token_refresh = time.time()

            try:
                today = date.today()
                if self._current_trading_date != today:
                    if self._current_trading_date is not None:
                        self.log_info(f"New trading day: {today}. Resetting state.")
                    self._current_trading_date = today
                    self.last_processed_candle_idx = -1
                    self.hourly_candles.clear()
                    self._candle_open = None
                    self._current_boundary_idx = -1
                    self._rollover_done_today = False
                    self._write_day_reset_event()

                # Poll FM future quote (LTP + cumulative volume)
                quote = self._poll_futures_quote(datafeed_handler)
                if quote is None:
                    time.sleep(POLL_INTERVAL_SECS)
                    continue

                ltp = quote["ltp"]
                cum_vol = quote["volume"]

                # Heartbeat logging
                self._poll_count += 1
                if self._poll_count % HEARTBEAT_INTERVAL_POLLS == 0:
                    boundary_idx = self._current_boundary_idx
                    candle_range = (
                        f"O={self._candle_open:.2f} H={self._candle_high:.2f} "
                        f"L={self._candle_low:.2f} C={self._candle_close:.2f}"
                        if self._candle_open is not None else "no candle"
                    )
                    pos_label = {1: "LONG", -1: "SHORT"}.get(self.position, "FLAT")
                    self.log_info(
                        f"HEARTBEAT [poll#{self._poll_count}]: LTP={ltp:.2f} | "
                        f"pos={pos_label} SL={self.sl_price} | "
                        f"boundary={boundary_idx} {candle_range} | "
                        f"EMA_entry={self.prev_entry_ema:.2f} EMA_exit={self.prev_exit_ema:.2f} | "
                        f"RSI={self.prev_rsi:.2f}"
                    )

                # Rollover check — on expiry day, if position still open
                #     at ROLLOVER_CHECK_TIME, box exit CW and re-enter at NW.
                if (
                    self.position != 0
                    and not self._rollover_done_today
                    and datetime.now().time() >= ROLLOVER_CHECK_TIME
                    and self._get_nearest_option_expiry() == date.today()
                ):
                    self._execute_rollover(ltp, datafeed_handler, dry_run)

                # Feed tick into candle builder — emits candle when boundary closes
                completed_candle = self._update_candle(ltp, cum_vol)

                if completed_candle is not None:
                    boundary_i = self.last_processed_candle_idx + 1
                    candle_signal = self._on_candle_close(
                        completed_candle["timestamp"], completed_candle
                    )
                    if candle_signal:
                        self._execute_signal(candle_signal, datafeed_handler, dry_run)

                    self.hourly_candles.append(completed_candle)
                    self.last_processed_candle_idx = boundary_i

                    # Persist indicator state to CSV
                    self._write_candle_event(completed_candle, boundary_i)

                    self.log_info(
                        f"Candle emitted [{boundary_i}]: "
                        f"O={completed_candle['open']:.2f} H={completed_candle['high']:.2f} "
                        f"L={completed_candle['low']:.2f} C={completed_candle['close']:.2f} "
                        f"V={completed_candle['volume']}"
                    )

                # Tick-level SL monitoring (reuse the LTP we just polled)
                if self.position == -1 and self.sl_price is not None:
                    signal = self._check_poll_sl(ltp, datetime.now())
                    if signal:
                        self._execute_signal(signal, datafeed_handler, dry_run)

            except Exception as e:
                self.log_exception(f"Error in main loop: {e}")

            time.sleep(POLL_INTERVAL_SECS)

        self.is_running = False
        self.log_info("IndexShort completed.")


