""" Expiry-Day Short Straddle (Target-Delta Strike) — Weekly Expiry Day Only

1. Runs only on weekly expiry days (CW expiry == today).
2. At entry time, picks the strike whose CE delta is closest to TARGET_DELTA.
3. Shorts both CE and PE at that strike (straddle).
4. SL when (cur_ce + cur_pe) >= entry_combined * SL_MULTIPLIER.
5. Hard exit at HARD_EXIT_TIME.
"""

import json
import math
import os
import shutil
import time
import uuid
from datetime import date, datetime, time as dt_time
from decimal import Decimal
from typing import Optional

import pandas as pd
import scipy.optimize as spo
from scipy.special import ndtr

from django.db.models import Min
from django.utils import timezone

from instruments.models import Instrument
from orders.order_manager import order_manager
from strategy.models import StrategyPosition
from strategy.strategy_class.base_strategy import BaseStrategy
from utils.ttm_helper import ttm as compute_ttm


# =============================================================================
# CONSTANTS
# =============================================================================

TICKER = "NIFTY"

# ── TBT (Tick-By-Tick) ──────────────────────────────────────────────────────
TBT_DATA_PATH = r"\\10.211.8.76\GFD MBM Data\Momentum\logs"
TBT_INDEX_NAME = "Nifty 50"
LOCAL_TBT_DIR = os.path.join(
    os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))),
    "dump", "tbt_local",
)

TBT_MARKET_OPEN = dt_time(9, 15, 0)
TBT_MARKET_CLOSE = dt_time(15, 30, 0)
TBT_MAX_STALENESS_SECS = 120

# ── Strategy parameter defaults ──────────────────────────────────────────────
DEFAULT_TARGET_DELTA       = 0.7        # CE delta target for strike selection
DEFAULT_SL_MULTIPLIER      = 1.30       # exit when straddle price >= entry * mul
DEFAULT_ENTRY_TIME         = dt_time(9, 15, 59)
DEFAULT_HARD_EXIT_TIME     = dt_time(14, 59, 59)
DEFAULT_POLL_INTERVAL_SECS = 20

RISK_FREE_RATE = 0.00
PRICE_OFFSET = Decimal("0.5")

_BASE_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
DELTA_STRADDLE_DUMP_DIR = os.path.join(_BASE_DIR, 'dump', 'delta_straddle')

LEG_CE = "STRADDLE_CE"
LEG_PE = "STRADDLE_PE"


# =============================================================================
# BLACK-SCHOLES (CALL DELTA + IV)
# =============================================================================

def _d1(S: float, K: float, T: float, sigma: float, r: float) -> float:
    """Black-Scholes d1. T in calendar days."""
    if sigma <= 1e-8:
        sigma = 1e-8
    return (math.log(S / K) + (r + sigma ** 2 / 2) * T / 365) / (sigma * math.sqrt(T / 365))


def _bs_call(S: float, K: float, r: float, T: float, sigma: float) -> float:
    d1 = _d1(S, K, T, sigma, r)
    d2 = d1 - sigma * math.sqrt(T / 365)
    return S * ndtr(d1) - K * math.exp(-r * T / 365) * ndtr(d2)


def _solve_call_iv(S, K, r, T, market_price, a=-2, b=5, xtol=1e-5) -> float:
    try:
        result = spo.brentq(
            lambda sigma: _bs_call(S, K, r, T, sigma) - market_price,
            a=a, b=b, xtol=xtol,
        )
        return max(result, xtol)
    except ValueError:
        return float("nan")


def _bs_call_delta(S: float, K: float, T: float, sigma: float, r: float) -> float:
    return float(ndtr(_d1(S, K, T, sigma, r)))


class DeltaStraddle(BaseStrategy):
    """Short straddle on the strike whose CE delta is closest to target_delta."""

    def __init__(self, strategy_obj, datafeed_obj, ws_manager=None):
        super().__init__(strategy_obj, datafeed_obj, ws_manager)
        self.is_running = False

        # ── Resolved params ──────────────────────────────────────────
        self.target_delta: float = DEFAULT_TARGET_DELTA
        self.sl_multiplier: float = DEFAULT_SL_MULTIPLIER
        self.entry_time: dt_time = DEFAULT_ENTRY_TIME
        self.hard_exit_time: dt_time = DEFAULT_HARD_EXIT_TIME
        self.poll_interval_secs: int = DEFAULT_POLL_INTERVAL_SECS

        # ── Day-level state ──────────────────────────────────────────
        self.expiry: Optional[date] = None
        self.entry_strike: Optional[Decimal] = None
        self.entry_ce_price: float = 0.0
        self.entry_pe_price: float = 0.0
        self.entry_combined: float = 0.0
        self.sl_level: float = 0.0
        self.exited: bool = False

        # ── DB handles ───────────────────────────────────────────────
        self.open_positions: dict[str, StrategyPosition] = {}

        # ── Cached strike list + TBT tracking ────────────────────────
        self._available_strikes: list[Decimal] = []
        self._last_good_max_ts: Optional[datetime] = None

        self.log_info(
            f"Initializing {self.strategy_obj.strategy_code} — "
            f"{self.strategy_obj.strategy_name}"
        )

    # =========================================================================
    # INSTRUMENT LOOKUPS
    # =========================================================================

    def _get_nearest_option_expiry(self) -> Optional[date]:
        today = date.today()
        result = Instrument.objects.filter(
            name=TICKER,
            exchange="NFO",
            instrument_type__in=["CE", "PE"],
            is_active=True,
            expiry__gte=today,
        ).aggregate(min_expiry=Min("expiry"))
        return result.get("min_expiry")

    def _load_available_strikes(self, expiry: date) -> None:
        strikes = (
            Instrument.objects.filter(
                name=TICKER, exchange="NFO",
                instrument_type__in=["CE", "PE"],
                expiry=expiry, is_active=True,
            )
            .values_list("strike", flat=True)
            .distinct()
        )
        self._available_strikes = sorted([s for s in strikes if s is not None])

    def _nearest_strike(self, target: float) -> Optional[Decimal]:
        if not self._available_strikes:
            return None
        return min(self._available_strikes, key=lambda s: abs(float(s) - target))

    def _get_option_instrument(
        self, strike: Decimal, option_type: str
    ) -> Optional[Instrument]:
        return Instrument.objects.filter(
            name=TICKER,
            exchange="NFO",
            instrument_type=option_type,
            expiry=self.expiry,
            strike=strike,
            is_active=True,
        ).first()

    # =========================================================================
    # TBT SPOT PRICE
    # =========================================================================

    def _copy_tbt_file(self, file_date: Optional[date] = None) -> Optional[str]:
        target_date = file_date or date.today()
        filename = target_date.strftime("%Y%m%d") + ".txt"
        source = os.path.join(TBT_DATA_PATH, filename)

        os.makedirs(LOCAL_TBT_DIR, exist_ok=True)
        dest = os.path.join(LOCAL_TBT_DIR, filename)

        try:
            shutil.copy2(source, dest)
            return dest
        except FileNotFoundError:
            self.log_error(f"TBT file not found: {source}")
            return None
        except Exception as e:
            self.log_error(f"Failed to copy TBT file: {e}")
            return None

    def _parse_tbt_data(self, file_path: str) -> Optional[pd.DataFrame]:
        try:
            df = pd.read_csv(
                file_path,
                sep=r"\s*\|\s*",
                header=None,
                names=["timestamp", "index_name", "price", "seq_id"],
                engine="python",
            )
        except Exception as e:
            self.log_error(f"Failed to parse TBT file: {e}")
            return None

        df = df[df["index_name"] == TBT_INDEX_NAME].copy()
        if df.empty:
            self.log_error(f"No '{TBT_INDEX_NAME}' ticks in TBT file.")
            return None

        df["timestamp"] = pd.to_datetime(df["timestamp"], format="mixed")
        df["price"] = pd.to_numeric(df["price"], errors="coerce")
        df = df.dropna(subset=["price"])
        df = df.sort_values("timestamp").reset_index(drop=True)

        pre = len(df)
        df = df[
            (df["timestamp"].dt.time >= TBT_MARKET_OPEN)
            & (df["timestamp"].dt.time <= TBT_MARKET_CLOSE)
        ].reset_index(drop=True)
        rejected = pre - len(df)
        if rejected > 0:
            self.log_info(f"Market hours filter: rejected {rejected} ticks outside 09:15–15:30")

        if df.empty:
            self.log_error("No ticks remain after market hours filter.")
            return None
        return df[["timestamp", "price"]]

    def _validate_tbt_data(self, tbt_df: pd.DataFrame) -> bool:
        max_ts: datetime = tbt_df["timestamp"].max().to_pydatetime()
        now = datetime.now()

        staleness = (now - max_ts).total_seconds()
        if staleness > TBT_MAX_STALENESS_SECS:
            self.log_error(
                f"TBT REJECTED (stale): latest tick {max_ts.strftime('%H:%M:%S')} "
                f"is {staleness:.0f}s behind wall clock"
            )
            return False

        if self._last_good_max_ts is not None and max_ts < self._last_good_max_ts:
            regression = (self._last_good_max_ts - max_ts).total_seconds()
            self.log_error(
                f"TBT REJECTED (regression): max tick {max_ts.strftime('%H:%M:%S')} "
                f"< previous good {self._last_good_max_ts.strftime('%H:%M:%S')} "
                f"(regressed {regression:.0f}s)"
            )
            return False

        self._last_good_max_ts = max_ts
        return True

    def _fetch_spot_from_tbt(self) -> Optional[float]:
        local_path = self._copy_tbt_file()
        if local_path is None:
            return None
        df = self._parse_tbt_data(local_path)
        if df is None or df.empty:
            return None
        if not self._validate_tbt_data(df):
            return None
        return float(df["price"].iloc[-1])

    # =========================================================================
    # DATA FEED
    # =========================================================================

    def _fetch_ltp(self, datafeed_handler, instrument: Instrument) -> Optional[float]:
        attempt = 0
        while self.is_running:
            attempt += 1
            try:
                self.datafeed_obj.refresh_from_db()
                from datafeed.rest.handler import DataFeedHandler
                datafeed_handler = DataFeedHandler(self.datafeed_obj)
                response = datafeed_handler.get_multiple_ltp([instrument])
                if response and "data" in response:
                    for item in response["data"].get("ltp_list", []):
                        if item.get("instrument_token") == instrument.instrument_token:
                            return item.get("ltp")
                return None
            except Exception as e:
                status = getattr(getattr(e, "response", None), "status_code", None)
                is_auth_error = status in (400, 401) or "Unauthorized" in str(e)
                if is_auth_error:
                    self.log_warning(
                        f"LTP fetch failed (attempt {attempt}: {e}) — refreshing token..."
                    )
                    try:
                        from datafeed.rest.handler import DataFeedHandler
                        DataFeedHandler(self.datafeed_obj).update_token()
                        self.datafeed_obj.refresh_from_db()
                    except Exception as refresh_err:
                        self.log_error(f"Token refresh failed: {refresh_err}")
                    time.sleep(2)
                    continue
                self.log_error(f"Error fetching LTP for {instrument}: {e}")
                return None
        return None

    def _fetch_multiple_ltp(
        self, datafeed_handler, instruments: list[Instrument]
    ) -> dict[int, float]:
        if not instruments:
            return {}
        attempt = 0
        while self.is_running:
            attempt += 1
            try:
                self.datafeed_obj.refresh_from_db()
                from datafeed.rest.handler import DataFeedHandler
                datafeed_handler = DataFeedHandler(self.datafeed_obj)
                response = datafeed_handler.get_multiple_ltp(instruments)
                result: dict[int, float] = {}
                if response and "data" in response:
                    for item in response["data"].get("ltp_list", []):
                        token = item.get("instrument_token")
                        ltp = item.get("ltp")
                        if token and ltp:
                            result[token] = ltp
                return result
            except Exception as e:
                status = getattr(getattr(e, "response", None), "status_code", None)
                is_auth_error = status in (400, 401) or "Unauthorized" in str(e)
                if is_auth_error:
                    self.log_warning(
                        f"Multi LTP fetch failed (attempt {attempt}: {e}) — refreshing token..."
                    )
                    try:
                        from datafeed.rest.handler import DataFeedHandler
                        DataFeedHandler(self.datafeed_obj).update_token()
                        self.datafeed_obj.refresh_from_db()
                    except Exception as refresh_err:
                        self.log_error(f"Token refresh failed: {refresh_err}")
                    time.sleep(2)
                    continue
                self.log_error(f"Error fetching multiple LTP: {e}")
                return {}
        return {}

    # =========================================================================
    # DELTA-BASED STRIKE SELECTION
    # =========================================================================

    def _pick_target_delta_strike(
        self, datafeed_handler, spot: float
    ) -> Optional[tuple[Decimal, float, float]]:
        """
        For every CE strike in the chain, compute IV → delta and pick the
        strike whose CE delta is closest to target_delta. Mirrors backtest
        lines 144–152 (search across full CE chain).

        Returns (strike, ce_ltp, pe_ltp) or None.
        """
        ce_instruments: list[Instrument] = list(
            Instrument.objects.filter(
                name=TICKER, exchange="NFO",
                instrument_type="CE", expiry=self.expiry, is_active=True,
            ).order_by("strike")
        )
        if not ce_instruments:
            self.log_error("Strike selection: no CE instruments in chain")
            return None

        ce_ltps = self._fetch_multiple_ltp(datafeed_handler, ce_instruments)

        # Compute TTM (calendar days) — _bs_call uses days/365
        now = datetime.now()
        ttm_days = max(compute_ttm(now, self.expiry), 1e-6)

        best_strike: Optional[Decimal] = None
        best_diff = float("inf")
        best_iv: float = 0.0
        best_ce_ltp: Optional[float] = None

        for ce_inst in ce_instruments:
            ltp = ce_ltps.get(ce_inst.instrument_token)
            if not ltp or ltp <= 0:
                continue
            K = float(ce_inst.strike)
            iv = _solve_call_iv(spot, K, RISK_FREE_RATE, ttm_days, float(ltp))
            if iv is None or math.isnan(iv) or iv <= 0:
                continue
            delta = _bs_call_delta(spot, K, ttm_days, iv, RISK_FREE_RATE)
            diff = abs(delta - self.target_delta)
            self.log_debug(
                f"  candidate K={K} ce_ltp={ltp:.2f} iv={iv:.4f} delta={delta:.3f} diff={diff:.3f}"
            )
            if diff < best_diff:
                best_diff = diff
                best_strike = ce_inst.strike
                best_iv = iv
                best_ce_ltp = float(ltp)

        if best_strike is None or best_ce_ltp is None:
            self.log_error("Strike selection: could not solve delta for any candidate")
            return None

        # Need PE LTP at the same strike
        pe_inst = self._get_option_instrument(best_strike, "PE")
        if not pe_inst:
            self.log_error(f"Strike selection: PE missing at strike {best_strike}")
            return None
        pe_ltps = self._fetch_multiple_ltp(datafeed_handler, [pe_inst])
        pe_ltp = pe_ltps.get(pe_inst.instrument_token)
        if not pe_ltp or pe_ltp <= 0:
            self.log_error(f"Strike selection: invalid PE LTP at strike {best_strike}")
            return None

        # Recompute selected delta for logging
        K = float(best_strike)
        selected_delta = _bs_call_delta(spot, K, ttm_days, best_iv, RISK_FREE_RATE)
        self.log_info(
            f"Selected strike {best_strike}: CE delta={selected_delta:.3f} "
            f"(target={self.target_delta}, iv={best_iv:.4f})"
        )
        return best_strike, best_ce_ltp, float(pe_ltp)

    # =========================================================================
    # ORDER PLACEMENT
    # =========================================================================

    def _limit_price(self, side: str, ltp: float) -> Decimal:
        base = Decimal(str(ltp))
        return base + PRICE_OFFSET if side == "SELL" else base - PRICE_OFFSET

    def _place_order(
        self,
        instrument: Instrument,
        side: str,
        quantity: int,
        price: Optional[Decimal],
        order_intent: str,
        tag: str = "",
        dry_run: bool = False,
    ) -> tuple[bool, object]:
        order_type = "LIMIT" if price is not None else "MARKET"
        price_str = str(price) if price is not None else "MKT"

        if dry_run:
            self.log_info(
                f"  [DRY-RUN][{tag}] {order_intent} {side} {quantity} x"
                f" {instrument.tradingsymbol} | {order_type} @ {price_str}"
                f" | NRML | expiry={instrument.expiry}"
            )
            return True, None

        success, msg, parent_order, _ = order_manager.create_and_execute_order(
            strategy=self.strategy_obj,
            instrument=instrument,
            side=side,
            quantity=quantity,
            order_type=order_type,
            product_type="NRML",
            price=price,
            order_intent=order_intent,
            metadata={
                "strategy_code": self.strategy_obj.strategy_code,
                "instrument_type": instrument.instrument_type,
                "stock_name": instrument.name,
                "tag": tag,
            },
        )
        if success:
            self.log_info(
                f"  [{tag}] {side} {quantity} x {instrument.tradingsymbol} @ {price_str}"
            )
        else:
            self.log_error(f"  [{tag}] FAILED {side} {instrument.tradingsymbol}: {msg}")
        return success, parent_order

    # =========================================================================
    # LEG OPEN / CLOSE
    # =========================================================================

    def _open_leg(
        self,
        leg_name: str,
        instrument: Instrument,
        entry_ltp: float,
        dry_run: bool,
        meta_extra: Optional[dict] = None,
    ) -> bool:
        lot_size = instrument.lot_size
        price = self._limit_price("SELL", entry_ltp)
        tag = f"DLTSTR_{leg_name}"

        success, parent_order = self._place_order(
            instrument, "SELL", lot_size, price,
            order_intent="ENTRY", tag=tag, dry_run=dry_run,
        )
        if not success:
            return False

        now = timezone.now()
        meta = {
            "leg_name": leg_name,
            "strike": float(instrument.strike),
            "expiry": str(instrument.expiry),
            "option_type": instrument.instrument_type,
        }
        if meta_extra:
            meta.update(meta_extra)

        pos = StrategyPosition.objects.create(
            trade_id=f"DLTSTR_{self.strategy_obj.id}_{uuid.uuid4().hex[:8]}",
            strategy=self.strategy_obj,
            instrument=instrument,
            position_type="SHORT",
            status="OPEN",
            quantity=lot_size,
            entry_price=Decimal(str(entry_ltp)),
            entry_time=now,
            entry_parent_order=parent_order,
            last_price=Decimal(str(entry_ltp)),
            last_price_updated_at=now,
            strategy_metadata=meta,
        )
        self.open_positions[leg_name] = pos
        self.log_info(
            f"  [{leg_name}] OPENED SELL strike={instrument.strike} "
            f"entry={entry_ltp:.2f} lot_size={lot_size}"
        )
        return True

    def _close_leg(
        self,
        leg_name: str,
        reason: str,
        datafeed_handler,
        dry_run: bool,
    ) -> bool:
        pos = self.open_positions.get(leg_name)
        if pos is None:
            return False

        instrument = pos.instrument
        lot_size = pos.quantity
        side = "BUY" if pos.position_type == "SHORT" else "SELL"

        exit_ltp = self._fetch_ltp(datafeed_handler, instrument)
        price = self._limit_price(side, exit_ltp) if exit_ltp is not None else None
        tag = f"DLTSTR_{leg_name}_{reason}"

        if exit_ltp is None:
            self.log_warning(
                f"  [{leg_name}] EXIT ({reason}): LTP unavailable — placing MARKET order"
            )

        success, parent_order = self._place_order(
            instrument, side, lot_size, price,
            order_intent="EXIT", tag=tag, dry_run=dry_run,
        )
        if not success:
            return False

        pos.status = "CLOSED"
        pos.exit_time = timezone.now()
        pos.exit_parent_order = parent_order
        pos.unrealized_pnl = Decimal("0.00")
        if exit_ltp is not None:
            pos.exit_price = Decimal(str(exit_ltp))
            if pos.position_type == "SHORT":
                pnl = (float(pos.entry_price) - exit_ltp) * lot_size
            else:
                pnl = (exit_ltp - float(pos.entry_price)) * lot_size
            pos.realized_pnl = Decimal(str(pnl))

        meta = pos.strategy_metadata or {}
        meta["exit_reason"] = reason
        meta["exit_ltp"] = exit_ltp
        pos.strategy_metadata = meta
        pos.save()

        del self.open_positions[leg_name]
        self.log_info(
            f"  [{leg_name}] CLOSED ({reason}) "
            f"strike={instrument.strike} entry={pos.entry_price} exit={exit_ltp}"
        )
        return True

    def _close_all_legs(self, reason: str, datafeed_handler, dry_run: bool) -> None:
        for leg in (LEG_CE, LEG_PE):
            if leg in self.open_positions:
                self._close_leg(leg, reason, datafeed_handler, dry_run)
        self.exited = True
        self._save_state()

    # =========================================================================
    # ENTRY + SL CHECK
    # =========================================================================

    def _initial_entry(self, datafeed_handler, dry_run: bool) -> bool:
        """Pick target-delta strike, sell CE+PE. Mirrors backtest lines 100–167."""
        spot = self._fetch_spot_from_tbt()
        if spot is None:
            self.log_error("Initial entry: could not fetch spot")
            return False

        picked = self._pick_target_delta_strike(datafeed_handler, spot)
        if picked is None:
            return False
        strike, ce_ltp, pe_ltp = picked

        ce_inst = self._get_option_instrument(strike, "CE")
        pe_inst = self._get_option_instrument(strike, "PE")
        if not ce_inst or not pe_inst:
            self.log_error(f"Initial entry: missing instruments at strike {strike}")
            return False

        entry_combined = ce_ltp + pe_ltp
        sl_level = entry_combined * self.sl_multiplier

        self.log_info(
            f"INITIAL ENTRY: spot={spot:.2f} strike={strike} "
            f"ce={ce_ltp:.2f} pe={pe_ltp:.2f} combined={entry_combined:.2f} "
            f"SL@{sl_level:.2f} (mul={self.sl_multiplier})"
        )

        meta = {
            "spot_at_entry": spot,
            "entry_combined": entry_combined,
            "sl_level": sl_level,
            "sl_multiplier": self.sl_multiplier,
            "target_delta": self.target_delta,
        }
        ok_ce = self._open_leg(LEG_CE, ce_inst, ce_ltp, dry_run, meta_extra=meta)
        ok_pe = self._open_leg(LEG_PE, pe_inst, pe_ltp, dry_run, meta_extra=meta)
        if not (ok_ce and ok_pe):
            self.log_error("Initial entry: one or both legs failed to open")
            return False

        self.entry_strike   = strike
        self.entry_ce_price = ce_ltp
        self.entry_pe_price = pe_ltp
        self.entry_combined = entry_combined
        self.sl_level       = sl_level
        self._save_state()
        return True

    def _check_sl(
        self, datafeed_handler, dry_run: bool
    ) -> bool:
        """
        Update last_price + unrealized_pnl on both legs and fire SL when
        cur_ce + cur_pe >= entry_combined * sl_multiplier.
        Returns True if SL fired (caller should stop). Mirrors backtest 169–199.
        """
        ce_pos = self.open_positions.get(LEG_CE)
        pe_pos = self.open_positions.get(LEG_PE)
        if not ce_pos or not pe_pos:
            return False

        ltps = self._fetch_multiple_ltp(
            datafeed_handler, [ce_pos.instrument, pe_pos.instrument]
        )
        cur_ce = ltps.get(ce_pos.instrument.instrument_token)
        cur_pe = ltps.get(pe_pos.instrument.instrument_token)
        if cur_ce is None or cur_pe is None:
            return False

        now = timezone.now()
        for pos, ltp in ((ce_pos, cur_ce), (pe_pos, cur_pe)):
            pos.last_price = Decimal(str(ltp))
            pos.last_price_updated_at = now
            pos.unrealized_pnl = (pos.entry_price - pos.last_price) * pos.quantity
            pos.save(update_fields=["last_price", "last_price_updated_at", "unrealized_pnl"])

        cur_combined = float(cur_ce) + float(cur_pe)
        self.log_debug(
            f"SL chk: cur={cur_combined:.2f} thr={self.sl_level:.2f} "
            f"(entry_combined={self.entry_combined:.2f}, mul={self.sl_multiplier})"
        )
        if cur_combined >= self.sl_level:
            self.log_info(
                f"SL HIT: cur={cur_combined:.2f} >= {self.sl_level:.2f} — closing both legs"
            )
            self._close_all_legs("SL", datafeed_handler, dry_run)
            return True
        return False

    # =========================================================================
    # STATE PERSISTENCE
    # =========================================================================

    def _get_state_path(self) -> str:
        code = self.strategy_obj.strategy_code.lower()
        return os.path.join(
            DELTA_STRADDLE_DUMP_DIR, f"{code}_{date.today().strftime('%Y%m%d')}.json"
        )

    def _save_state(self) -> None:
        path = self._get_state_path()
        os.makedirs(os.path.dirname(path), exist_ok=True)
        state = {
            "date": str(date.today()),
            "expiry": str(self.expiry) if self.expiry else None,
            "target_delta": self.target_delta,
            "sl_multiplier": self.sl_multiplier,
            "entry_time": self.entry_time.strftime("%H:%M:%S"),
            "hard_exit_time": self.hard_exit_time.strftime("%H:%M:%S"),
            "entry_strike": float(self.entry_strike) if self.entry_strike else None,
            "entry_ce_price": self.entry_ce_price,
            "entry_pe_price": self.entry_pe_price,
            "entry_combined": self.entry_combined,
            "sl_level": self.sl_level,
            "exited": self.exited,
        }
        try:
            with open(path, "w") as f:
                json.dump(state, f)
        except Exception as e:
            self.log_error(f"Failed to save state: {e}")

    def _load_state(self) -> bool:
        path = self._get_state_path()
        if not os.path.isfile(path):
            return False
        try:
            with open(path, "r") as f:
                state = json.load(f)
        except Exception as e:
            self.log_error(f"Failed to load state: {e}")
            return False

        if state.get("date") != str(date.today()):
            self.log_info("State file stale (wrong date). Ignoring.")
            return False

        es = state.get("entry_strike")
        self.entry_strike   = Decimal(str(es)) if es is not None else None
        self.entry_ce_price = float(state.get("entry_ce_price", 0.0) or 0.0)
        self.entry_pe_price = float(state.get("entry_pe_price", 0.0) or 0.0)
        self.entry_combined = float(state.get("entry_combined", 0.0) or 0.0)
        self.sl_level       = float(state.get("sl_level", 0.0) or 0.0)
        self.exited         = bool(state.get("exited", False))

        self.log_info(
            f"RECOVERY: state restored — strike={self.entry_strike} "
            f"entry_combined={self.entry_combined} sl={self.sl_level} exited={self.exited}"
        )
        return True

    def _bootstrap_from_db(self) -> None:
        """Restore open positions from DB."""
        db_positions = StrategyPosition.objects.filter(
            strategy=self.strategy_obj, status="OPEN",
        ).select_related("instrument")

        if not db_positions.exists():
            self.log_info("No existing open positions. Fresh run.")
            return

        for pos in db_positions:
            meta = pos.strategy_metadata or {}
            leg_name = meta.get("leg_name")
            if leg_name in (LEG_CE, LEG_PE):
                self.open_positions[leg_name] = pos
                self.log_warning(
                    f"RECOVERY: restored {leg_name} @ entry={pos.entry_price} "
                    f"({pos.instrument.tradingsymbol})"
                )
            else:
                self.log_warning(
                    f"RECOVERY: skipping position {pos.trade_id} — unknown leg_name={leg_name}"
                )

        # Re-derive entry_strike from any restored leg.
        for leg in (LEG_CE, LEG_PE):
            pos = self.open_positions.get(leg)
            if pos:
                self.entry_strike = pos.instrument.strike
                break

    # =========================================================================
    # TIME UTILITIES
    # =========================================================================

    def _get_today_datetime(self, time_obj) -> datetime:
        today = timezone.now().date()
        naive_dt = datetime.combine(today, time_obj)
        return timezone.make_aware(naive_dt)

    def _wait_until(self, target_time: datetime) -> bool:
        while self.is_running:
            now = timezone.now()
            if now >= target_time:
                return True
            remaining = (target_time - now).total_seconds()
            if remaining > 60:
                self.log_info(
                    f"Waiting {int(remaining // 60)}m {int(remaining % 60)}s "
                    f"until {target_time.strftime('%H:%M:%S')}"
                )
                time.sleep(30)
            else:
                time.sleep(1)
        return False

    # =========================================================================
    # BASE STRATEGY INTERFACE
    # =========================================================================

    def verify(self) -> bool:
        if not self.datafeed_obj:
            self.log_error("No datafeed object provided.")
            return False
        if self.datafeed_obj.is_token_expired:
            self.log_warning("Datafeed token expired — attempting refresh...")
            from datafeed.rest.handler import DataFeedHandler
            handler = DataFeedHandler(self.datafeed_obj)
            if not handler.update_token():
                self.log_error("Failed to refresh datafeed token.")
                return False
        self.log_info("Verification passed.")
        return True

    def stop(self):
        self.log_info("Stopping DeltaStraddle...")
        self.is_running = False

    # =========================================================================
    # MAIN RUN LOOP
    # =========================================================================

    def _resolve_params(self) -> None:
        params = self.strategy_obj.strategy_params or {}
        self.target_delta       = float(params.get("target_delta",  DEFAULT_TARGET_DELTA))
        self.sl_multiplier      = float(params.get("sl_multiplier", DEFAULT_SL_MULTIPLIER))
        self.poll_interval_secs = int(params.get("poll_interval_secs", DEFAULT_POLL_INTERVAL_SECS))

        et_str = params.get("entry_time")
        if et_str:
            try:
                self.entry_time = datetime.strptime(et_str, "%H:%M:%S").time()
            except ValueError:
                self.log_error(f"Invalid entry_time '{et_str}', using default {DEFAULT_ENTRY_TIME}")
                self.entry_time = DEFAULT_ENTRY_TIME
        else:
            self.entry_time = DEFAULT_ENTRY_TIME

        xt_str = params.get("hard_exit_time")
        if xt_str:
            try:
                self.hard_exit_time = datetime.strptime(xt_str, "%H:%M:%S").time()
            except ValueError:
                self.log_error(
                    f"Invalid hard_exit_time '{xt_str}', using default {DEFAULT_HARD_EXIT_TIME}"
                )
                self.hard_exit_time = DEFAULT_HARD_EXIT_TIME
        else:
            self.hard_exit_time = DEFAULT_HARD_EXIT_TIME

    def run(self):
        params = self.strategy_obj.strategy_params or {}
        dry_run = bool(params.get("dry_run", False))
        self._resolve_params()

        self.log_info("=" * 60)
        self.log_info("Starting DeltaStraddle (Weekly Expiry Day Only)")
        self.log_info(
            f"target_delta={self.target_delta} sl_mul={self.sl_multiplier}"
        )
        self.log_info(
            f"entry={self.entry_time} hard_exit={self.hard_exit_time} "
            f"poll={self.poll_interval_secs}s"
        )
        self.log_info(f"Mode: {'DRY-RUN' if dry_run else 'LIVE'}")
        self.log_info("=" * 60)

        if not self.verify():
            self.log_error("Verification failed. Exiting.")
            return

        self.is_running = True

        from datafeed.rest.handler import DataFeedHandler
        datafeed_handler = DataFeedHandler(self.datafeed_obj)

        # ── Step 1: Resolve expiry — must equal today (weekly expiry day) ─
        cw_expiry = self._get_nearest_option_expiry()
        if cw_expiry is None:
            self.log_error("No NIFTY option expiry found. Exiting.")
            self.is_running = False
            return
        if cw_expiry != date.today():
            self.log_info(
                f"Today ({date.today()}) is NOT weekly expiry day "
                f"(next expiry: {cw_expiry}). Strategy will not run today."
            )
            self.is_running = False
            return

        self.expiry = cw_expiry
        self.log_info(f"Weekly expiry day confirmed: {self.expiry}")

        # ── Step 2: Cache available strikes ───────────────────────────────
        self._load_available_strikes(self.expiry)
        if not self._available_strikes:
            self.log_error(f"No strikes found for expiry {self.expiry}. Exiting.")
            self.is_running = False
            return
        self.log_info(f"Loaded {len(self._available_strikes)} strikes for expiry {self.expiry}")

        # ── Step 3: Recover from prior crash (DB + JSON state) ────────────
        self._bootstrap_from_db()
        self._load_state()

        already_open = bool(self.open_positions)

        # ── Step 4: Wait for entry time (skip if already in position) ─────
        if not already_open and not self.exited:
            entry_dt = self._get_today_datetime(self.entry_time)
            if timezone.now() < entry_dt:
                self.log_info(f"Waiting for entry time: {entry_dt.strftime('%H:%M:%S')}")
                if not self._wait_until(entry_dt):
                    return
            if not self.is_running:
                return

            # If we've already passed hard exit, skip entirely.
            local_now = timezone.localtime(timezone.now()).time()
            if local_now >= self.hard_exit_time:
                self.log_info(
                    f"Past hard_exit_time ({self.hard_exit_time}); skipping initial entry"
                )
                self.exited = True
            else:
                # ── Step 5: Initial entry ────────────────────────────
                if not self._initial_entry(datafeed_handler, dry_run):
                    self.log_error("Initial entry failed. Exiting.")
                    self.is_running = False
                    return

        # ── Step 6: Monitor loop (SL + hard exit) ─────────────────────────
        exit_dt = self._get_today_datetime(self.hard_exit_time)
        self.log_info("Entering monitoring loop (SL + hard exit)...")

        while self.is_running:
            now = timezone.now()

            if now >= exit_dt:
                self.log_info(">>> HARD EXIT TIME REACHED <<<")
                self._close_all_legs("HARD_EXIT", datafeed_handler, dry_run)
                break

            if not self.open_positions:
                # Either already exited (SL / restart after exit) or never entered.
                break

            try:
                if self._check_sl(datafeed_handler, dry_run):
                    break
            except Exception as e:
                self.log_exception(f"Main loop error: {e}")

            time.sleep(self.poll_interval_secs)

        # ── EOD safety net ────────────────────────────────────────────────
        now_t = timezone.localtime(timezone.now()).time()
        if self.open_positions and now_t >= self.hard_exit_time:
            self.log_warning("EOD safety net: forcing close of any remaining legs")
            self._close_all_legs("HARD_EXIT_FORCE", datafeed_handler, dry_run)
        elif self.open_positions:
            self.log_info(
                "Loop exited but NOT past hard_exit_time — keeping legs open in DB for recovery"
            )

        self.is_running = False
        self.log_info("DeltaStraddle completed.")
