"""
Vol Long Short Strategy

This strategy:
1. Waits for entry time
2. Calls business logic to get X long and Y short straddle trades
3. Creates positions in DB for each straddle (CE + PE)
4. Places orders via OrderManager
5. Tracks and prints PNL every minute
6. At exit time, squares off all positions and exits
"""
import time
import uuid
from datetime import date, datetime, timedelta
from decimal import Decimal
from typing import Optional

from django.db.models import Min
from django.utils import timezone

from strategy.strategy_class.base_strategy import BaseStrategy
from instruments.models import Instrument
from strategy.models import StrategyPosition
from orders.models import ParentOrder
from orders.order_manager import order_manager


STOCKS_TO_CONSIDER = [
    "ADANIENT",
    "ADANIPORTS",
    "APOLLOHOSP",
    "ASIANPAINT",
    "AXISBANK",
    "BAJAJ-AUTO",
    "BAJFINANCE",
    "BAJAJFINSV",
    "BEL",
    "BHARTIARTL",
    "CIPLA",
    "COALINDIA",
    "DRREDDY",
    "EICHERMOT",
    "ETERNAL",
    "GRASIM",
    "HCLTECH",
    "HDFCBANK",
    "HDFCLIFE",
    "HINDALCO",
    "HINDUNILVR",
    "ICICIBANK",
    "ITC",
    "INFY",
    "INDIGO",
    "JSWSTEEL",
    "JIOFIN",
    "KOTAKBANK",
    "LT",
    "M&M",
    "MARUTI",
    "MAXHEALTH",
    "NTPC",
    "NESTLEIND",
    "ONGC",
    "POWERGRID",
    "RELIANCE",
    "SBILIFE",
    "SHRIRAMFIN",
    "SBIN",
    "SUNPHARMA",
    "TCS",
    "TATACONSUM",
    "TMPV",
    "TATASTEEL",
    "TECHM",
    "TITAN",
    "TRENT",
    "ULTRACEMCO",
    "WIPRO"
]


class VolLongShort(BaseStrategy):
    """
    Strategy that trades long/short straddles based on business logic signals.
    Integrates with OrderManager to place actual broker orders.
    """

    def __init__(self, strategy_obj, datafeed_obj, ws_manager=None):
        super().__init__(strategy_obj, datafeed_obj, ws_manager)
        self.strategy_obj = strategy_obj
        self.is_running = False

        # Stock -> Future instrument mapping
        self.futures: dict[str, Instrument] = {}
        # Stock -> (CE instrument, PE instrument) mapping
        self.options: dict[str, tuple[Instrument, Instrument]] = {}
        # Stock -> option expiry date
        self.option_expiries: dict[str, date] = {}
        # Stocks that passed verification
        self.active_stocks: list[str] = []

        # Position tracking
        # Stock -> list of StrategyPosition objects (CE and PE)
        self.open_positions: dict[str, list[StrategyPosition]] = {}
        # Track straddle direction per stock: 'LONG' or 'SHORT'
        self.straddle_directions: dict[str, str] = {}

        # Order tracking
        # Stock -> list of ParentOrder objects (entry orders)
        self.entry_orders: dict[str, list[ParentOrder]] = {}
        # Stock -> list of ParentOrder objects (exit orders)
        self.exit_orders: dict[str, list[ParentOrder]] = {}

        print(f"Initializing {self.strategy_obj.strategy_code} - {self.strategy_obj.strategy_name}")

    # =========================================================================
    # BUSINESS LOGIC PLACEHOLDER
    # =========================================================================

    def _get_trading_signals(self) -> tuple[list[str], list[str]]:
        """
        Placeholder business logic function.
        Returns lists of stocks for long and short straddles.

        Returns:
            tuple: (long_stocks, short_stocks)
                - long_stocks: List of stock names to go LONG straddle
                - short_stocks: List of stock names to go SHORT straddle
        """
        # TODO: Replace with actual business logic
        # For now, return sample data for testing

        # Example: Go long on first 2 stocks, short on next 2
        long_stocks = []
        short_stocks = []

        available = [s for s in self.active_stocks if s in self.options]

        if len(available) >= 4:
            long_stocks = available[:1]
            short_stocks = available[1:2]
        elif len(available) >= 2:
            long_stocks = available[:1]
            short_stocks = available[1:2]
        long_stocks = ['ADANIPORTS', 'APOLLOHOSP', 'SUNPHARMA', 'HINDUNILVR', 'EICHERMOT']
        short_stocks = ['HCLTECH', 'RELIANCE', 'HDFCBANK', 'ITC', 'COALINDIA']
        return long_stocks, short_stocks

    # =========================================================================
    # INSTRUMENT LOOKUP METHODS
    # =========================================================================

    def _get_nearest_future(self, stock_name: str) -> Optional[Instrument]:
        """Get the nearest month future instrument for a stock."""
        today = date.today()

        future = Instrument.objects.filter(
            name=stock_name,
            exchange='NFO',
            instrument_type='FUT',
            is_active=True,
            expiry__gte=today
        ).order_by('expiry').first()

        return future

    def _get_nearest_option_expiry(self, stock_name: str) -> Optional[date]:
        """Get the nearest option expiry date for a stock."""
        today = date.today()

        result = Instrument.objects.filter(
            name=stock_name,
            exchange='NFO',
            instrument_type__in=['CE', 'PE'],
            is_active=True,
            expiry__gte=today
        ).aggregate(min_expiry=Min('expiry'))

        return result.get('min_expiry')

    def _get_available_strikes(self, stock_name: str, expiry: date) -> list[Decimal]:
        """Get all available strike prices for a stock on a given expiry."""
        strikes = Instrument.objects.filter(
            name=stock_name,
            exchange='NFO',
            instrument_type__in=['CE', 'PE'],
            expiry=expiry,
            is_active=True
        ).values_list('strike', flat=True).distinct()

        return sorted([s for s in strikes if s is not None])

    def _find_closest_strike(self, price: float, available_strikes: list[Decimal]) -> Optional[Decimal]:
        """Find the strike price closest to the given price."""
        if not available_strikes:
            return None

        price_decimal = Decimal(str(price))
        return min(available_strikes, key=lambda s: abs(s - price_decimal))

    def _get_option_pair(
        self, stock_name: str, expiry: date, strike: Decimal
    ) -> tuple[Optional[Instrument], Optional[Instrument]]:
        """Get CE and PE instruments for a given stock, expiry, and strike."""
        ce = Instrument.objects.filter(
            name=stock_name,
            exchange='NFO',
            instrument_type='CE',
            expiry=expiry,
            strike=strike,
            is_active=True
        ).first()

        pe = Instrument.objects.filter(
            name=stock_name,
            exchange='NFO',
            instrument_type='PE',
            expiry=expiry,
            strike=strike,
            is_active=True
        ).first()

        return ce, pe

    # =========================================================================
    # TIME UTILITIES
    # =========================================================================

    def _get_today_datetime(self, time_obj) -> datetime:
        """Convert a time object to today's datetime in local timezone."""
        today = timezone.now().date()
        naive_dt = datetime.combine(today, time_obj)
        return timezone.make_aware(naive_dt)

    def _wait_until(self, target_time: datetime) -> bool:
        """
        Wait until target time, checking every second.
        Returns False if strategy was stopped during wait.
        """
        while self.is_running:
            now = timezone.now()
            if now >= target_time:
                return True

            remaining = (target_time - now).total_seconds()
            if remaining > 60:
                print(f"  Waiting... {int(remaining // 60)} minutes remaining until {target_time.strftime('%H:%M:%S')}")
                time.sleep(30)
            else:
                time.sleep(1)

        return False

    def _is_past_exit_time(self) -> bool:
        """Check if current time is past exit time."""
        exit_datetime = self._get_today_datetime(self.strategy_obj.exit_time)
        return timezone.now() >= exit_datetime

    # =========================================================================
    # DATA FEED METHODS
    # =========================================================================

    def _fetch_multiple_ltp(
        self, datafeed_handler, instruments: list[Instrument]
    ) -> dict[int, float]:
        """Fetch LTP for multiple instruments."""
        result = {}
        if not instruments:
            return result

        try:
            response = datafeed_handler.get_multiple_ltp(instruments)
            if response and 'data' in response:
                ltp_list = response['data'].get('ltp_list', [])
                for ltp_data in ltp_list:
                    token = ltp_data.get('instrument_token')
                    ltp = ltp_data.get('ltp')
                    if token and ltp:
                        result[token] = ltp
        except Exception as e:
            print(f"Error fetching multiple LTP: {e}")
        return result

    def _update_atm_options(self, datafeed_handler) -> None:
        """Update ATM options for all active stocks based on current future prices."""
        future_instruments = [self.futures[stock] for stock in self.active_stocks]
        future_ltps = self._fetch_multiple_ltp(datafeed_handler, future_instruments)

        for stock in self.active_stocks:
            future = self.futures[stock]
            future_ltp = future_ltps.get(future.instrument_token)

            if not future_ltp:
                continue

            expiry = self.option_expiries[stock]
            available_strikes = self._get_available_strikes(stock, expiry)

            if not available_strikes:
                continue

            atm_strike = self._find_closest_strike(future_ltp, available_strikes)
            if not atm_strike:
                continue

            ce, pe = self._get_option_pair(stock, expiry, atm_strike)

            if ce and pe:
                self.options[stock] = (ce, pe)

    # =========================================================================
    # ORDER MANAGEMENT
    # =========================================================================

    def _place_entry_order(
        self,
        instrument: Instrument,
        side: str,
        quantity: int,
        price: Optional[Decimal] = None
    ) -> tuple[bool, Optional[ParentOrder]]:
        """
        Place an entry order via OrderManager.

        Args:
            instrument: Instrument to trade
            side: 'BUY' or 'SELL'
            quantity: Order quantity
            price: Limit price (optional, uses MARKET if not provided)

        Returns:
            tuple: (success, ParentOrder or None)
        """
        order_type = 'LIMIT' if price else 'MARKET'

        success, msg, parent_order, broker_orders = order_manager.create_and_execute_order(
            strategy=self.strategy_obj,
            instrument=instrument,
            side=side,
            quantity=quantity,
            order_type=order_type,
            product_type='NRML',
            price=price,
            order_intent='ENTRY',
            metadata={
                'strategy_code': self.strategy_obj.strategy_code,
                'instrument_type': instrument.instrument_type,
                'stock_name': instrument.name
            }
        )

        if success:
            print(f"    Order placed: {side} {quantity}x {instrument.tradingsymbol}")
            return True, parent_order
        else:
            print(f"    Order FAILED: {side} {instrument.tradingsymbol} - {msg}")
            return False, None

    def _place_exit_order(
        self,
        instrument: Instrument,
        side: str,
        quantity: int,
        price: Optional[Decimal] = None
    ) -> tuple[bool, Optional[ParentOrder]]:
        """
        Place an exit order via OrderManager.

        Args:
            instrument: Instrument to trade
            side: 'BUY' or 'SELL' (opposite of entry)
            quantity: Order quantity
            price: Limit price (optional, uses MARKET if not provided)

        Returns:
            tuple: (success, ParentOrder or None)
        """
        order_type = 'LIMIT' if price else 'MARKET'

        success, msg, parent_order, broker_orders = order_manager.create_and_execute_order(
            strategy=self.strategy_obj,
            instrument=instrument,
            side=side,
            quantity=quantity,
            order_type=order_type,
            product_type='NRML',
            price=price,
            order_intent='EXIT',
            metadata={
                'strategy_code': self.strategy_obj.strategy_code,
                'instrument_type': instrument.instrument_type,
                'stock_name': instrument.name
            }
        )

        if success:
            print(f"    Exit order placed: {side} {quantity}x {instrument.tradingsymbol}")
            return True, parent_order
        else:
            print(f"    Exit order FAILED: {side} {instrument.tradingsymbol} - {msg}")
            return False, None

    # =========================================================================
    # POSITION MANAGEMENT
    # =========================================================================
    def _bootstrap_from_db(self) -> bool:
        """
        Load OPEN positions from DB if strategy was restarted.

        Returns:
            True  -> Found open positions, resume in EXIT-ONLY mode
            False -> No open positions, normal execution
        """
        open_positions = StrategyPosition.objects.filter(
            strategy=self.strategy_obj,
            status='OPEN'
        ).select_related('instrument')

        if not open_positions.exists():
            self.log_info("No existing open positions found. Fresh run.")
            return False
        self.log_warning(
            f"Found {open_positions.count()} OPEN positions. "
            f"Resuming in RECOVERY mode (no new entries)."
        )

        self.open_positions.clear()
        self.straddle_directions.clear()

        for pos in open_positions:
            stock = pos.strategy_metadata.get('straddle_stock')

            if not stock:
                continue

            self.open_positions.setdefault(stock, []).append(pos)
            self.straddle_directions[stock] = pos.position_type

        return True

    def _generate_trade_id(self, stock: str, option_type: str) -> str:
        """Generate unique trade ID."""
        timestamp = timezone.now().strftime('%Y%m%d%H%M%S')
        short_uuid = str(uuid.uuid4())[:8]
        return f"{self.strategy_obj.strategy_code}_{stock}_{option_type}_{timestamp}_{short_uuid}"

    def _create_straddle_positions(
        self,
        stock: str,
        direction: str,
        ce_ltp: float,
        pe_ltp: float,
        datafeed_handler,
        place_orders: bool = True
    ) -> bool:
        """
        Create straddle positions (CE + PE) in the database and place orders.

        Args:
            stock: Stock name
            direction: 'LONG' or 'SHORT'
            ce_ltp: Current CE LTP (entry price)
            pe_ltp: Current PE LTP (entry price)
            datafeed_handler: DataFeedHandler instance
            place_orders: If True, place orders via OMS

        Returns:
            bool: True if positions created successfully
        """
        if stock not in self.options:
            print(f"  ERROR: No options found for {stock}")
            return False

        ce, pe = self.options[stock]
        now = timezone.now()

        # Determine order side based on straddle direction
        # LONG straddle = BUY CE + BUY PE
        # SHORT straddle = SELL CE + SELL PE
        entry_side = 'BUY' if direction == 'LONG' else 'SELL'

        try:
            # Place entry orders if enabled
            ce_parent_order = None
            pe_parent_order = None

            if place_orders:
                print(f"  Placing {direction} straddle orders for {stock}...")

                # Place CE order
                ce_success, ce_parent_order = self._place_entry_order(
                    instrument=ce,
                    side=entry_side,
                    quantity=ce.lot_size,
                    price=Decimal(str(ce_ltp))-Decimal(0.5) if direction == 'LONG' else Decimal(str(ce_ltp))+Decimal(0.5)
                )
                self.logger.info(f"Price for {ce} is {ce_ltp} Placed {direction} {Decimal(str(ce_ltp))-Decimal(0.5) if direction == 'LONG' else Decimal(str(ce_ltp))+Decimal(0.5)}")
                # Place PE order
                pe_success, pe_parent_order = self._place_entry_order(
                    instrument=pe,
                    side=entry_side,
                    quantity=pe.lot_size,
                    price=Decimal(str(pe_ltp))-Decimal(0.5) if direction == 'LONG' else Decimal(str(pe_ltp))+Decimal(0.5)
                )
                self.logger.info(f"Price for {pe} is {pe_ltp} Placed {direction} {Decimal(str(pe_ltp))-Decimal(0.5) if direction == 'LONG' else Decimal(str(pe_ltp))+Decimal(0.5)}")
                if not ce_success or not pe_success:
                    print(f"  WARNING: Some orders failed for {stock}")

            # Create CE position
            ce_position = StrategyPosition.objects.create(
                trade_id=self._generate_trade_id(stock, 'CE'),
                strategy=self.strategy_obj,
                instrument=ce,
                position_type=direction,
                status='OPEN',
                quantity=ce.lot_size,
                entry_price=Decimal(str(ce_ltp)),
                entry_time=now,
                entry_parent_order=ce_parent_order,
                last_price=Decimal(str(ce_ltp)),
                last_price_updated_at=now,
                strategy_metadata={
                    'straddle_stock': stock,
                    'option_type': 'CE',
                    'strike': float(ce.strike),
                    'expiry': str(self.option_expiries[stock]),
                    'entry_side': entry_side
                }
            )

            # Create PE position
            pe_position = StrategyPosition.objects.create(
                trade_id=self._generate_trade_id(stock, 'PE'),
                strategy=self.strategy_obj,
                instrument=pe,
                position_type=direction,
                status='OPEN',
                quantity=pe.lot_size,
                entry_price=Decimal(str(pe_ltp)),
                entry_time=now,
                entry_parent_order=pe_parent_order,
                last_price=Decimal(str(pe_ltp)),
                last_price_updated_at=now,
                strategy_metadata={
                    'straddle_stock': stock,
                    'option_type': 'PE',
                    'strike': float(pe.strike),
                    'expiry': str(self.option_expiries[stock]),
                    'entry_side': entry_side
                }
            )

            self.open_positions[stock] = [ce_position, pe_position]
            self.straddle_directions[stock] = direction

            # Track entry orders
            if ce_parent_order or pe_parent_order:
                self.entry_orders[stock] = [
                    o for o in [ce_parent_order, pe_parent_order] if o
                ]

            print(f"  {stock}: Created {direction} straddle at strike {ce.strike}")
            print(f"    CE: {entry_side} @ {ce_ltp:.2f}, PE: {entry_side} @ {pe_ltp:.2f}")
            print(f"    Total Premium: {ce_ltp + pe_ltp:.2f}")

            return True

        except Exception as e:
            print(f"  ERROR creating positions for {stock}: {e}")
            return False

    def _calculate_position_pnl(self, position: StrategyPosition, current_ltp: float) -> float:
        """
        Calculate unrealized PNL for a position.

        For LONG: PNL = (current - entry) * quantity
        For SHORT: PNL = (entry - current) * quantity
        """
        if not position.entry_price:
            return 0.0

        entry = float(position.entry_price)
        qty = position.quantity

        if position.position_type == 'LONG':
            return (current_ltp - entry) * qty
        else:  # SHORT
            return (entry - current_ltp) * qty

    def _update_positions_ltp(self, datafeed_handler) -> dict[str, dict]:
        """
        Update LTP for all open positions and calculate PNL.

        Returns:
            dict: Stock -> {ce_ltp, pe_ltp, ce_pnl, pe_pnl, total_pnl, direction}
        """
        if not self.open_positions:
            return {}

        # Collect all instruments from open positions
        all_instruments = []
        for stock, positions in self.open_positions.items():
            for pos in positions:
                all_instruments.append(pos.instrument)

        # Fetch all LTPs
        all_ltps = self._fetch_multiple_ltp(datafeed_handler, all_instruments)
        now = timezone.now()

        result = {}

        for stock, positions in self.open_positions.items():
            ce_pos = None
            pe_pos = None

            for pos in positions:
                if pos.instrument.instrument_type == 'CE':
                    ce_pos = pos
                else:
                    pe_pos = pos

            if not ce_pos or not pe_pos:
                continue

            ce_ltp = all_ltps.get(ce_pos.instrument.instrument_token)
            pe_ltp = all_ltps.get(pe_pos.instrument.instrument_token)

            if ce_ltp is None or pe_ltp is None:
                continue

            # Update positions in DB
            ce_pos.last_price = Decimal(str(ce_ltp))
            ce_pos.last_price_updated_at = now
            ce_pos.unrealized_pnl = Decimal(str(self._calculate_position_pnl(ce_pos, ce_ltp)))
            ce_pos.save(update_fields=['last_price', 'last_price_updated_at', 'unrealized_pnl'])

            pe_pos.last_price = Decimal(str(pe_ltp))
            pe_pos.last_price_updated_at = now
            pe_pos.unrealized_pnl = Decimal(str(self._calculate_position_pnl(pe_pos, pe_ltp)))
            pe_pos.save(update_fields=['last_price', 'last_price_updated_at', 'unrealized_pnl'])

            ce_pnl = float(ce_pos.unrealized_pnl)
            pe_pnl = float(pe_pos.unrealized_pnl)

            result[stock] = {
                'ce_ltp': ce_ltp,
                'pe_ltp': pe_ltp,
                'ce_entry': float(ce_pos.entry_price),
                'pe_entry': float(pe_pos.entry_price),
                'ce_pnl': ce_pnl,
                'pe_pnl': pe_pnl,
                'total_pnl': ce_pnl + pe_pnl,
                'direction': self.straddle_directions.get(stock, 'UNKNOWN'),
                'strike': float(ce_pos.instrument.strike)
            }

        return result

    def _close_all_positions(self, datafeed_handler, place_orders: bool = True) -> None:
        """
        Close all open positions at current LTP using LIMIT orders.
        """
        if not self.open_positions:
            print("No open positions to close.")
            return

        print("\n" + "=" * 60)
        print("CLOSING ALL POSITIONS (LIMIT ORDERS)")
        print("=" * 60)

        # Collect all instruments to fetch LTP
        all_instruments = []
        for stock, positions in self.open_positions.items():
            for pos in positions:
                all_instruments.append(pos.instrument)

        # Fetch current LTPs for exit pricing
        all_ltps = self._fetch_multiple_ltp(datafeed_handler, all_instruments)
        now = timezone.now()
        total_realized_pnl = 0.0

        for stock, positions in self.open_positions.items():
            print(f"\n{stock}:")
            stock_pnl = 0.0
            direction = self.straddle_directions.get(stock, 'LONG')
            exit_side = 'SELL' if direction == 'LONG' else 'BUY'
            stock_exit_orders = []

            for pos in positions:
                ltp = all_ltps.get(pos.instrument.instrument_token)

                if ltp is None:
                    print(f"  WARNING: Could not get LTP for {pos.instrument.tradingsymbol}. Skipping.")
                    continue

                # --- LIMIT PRICE CALCULATION ---
                # For SELL: We place limit slightly BELOW LTP to hit the bid (aggressive)
                # For BUY: We place limit slightly ABOVE LTP to hit the ask (aggressive)
                # Using 0.5 as an example offset (adjust based on tick size)
                offset = Decimal("0.5")
                exit_price = Decimal(str(ltp))

                if exit_side == 'SELL':
                    limit_price = exit_price + offset
                else:
                    limit_price = exit_price - offset
                # Place exit order
                exit_parent_order = None
                if place_orders:
                    exit_success, exit_parent_order = self._place_exit_order(
                        instrument=pos.instrument,
                        side=exit_side,
                        quantity=pos.quantity,
                        price=limit_price  # <--- Passing the calculated price makes it a LIMIT order
                    )
                    if exit_parent_order:
                        stock_exit_orders.append(exit_parent_order)

                # Calculate final PNL based on the LTP at time of exit trigger
                pnl = self._calculate_position_pnl(pos, ltp)
                stock_pnl += pnl

                # Update position as closed in DB
                pos.exit_price = exit_price
                pos.exit_time = now
                pos.exit_parent_order = exit_parent_order
                pos.realized_pnl = Decimal(str(pnl))
                pos.unrealized_pnl = Decimal('0.00')
                pos.status = 'CLOSED'
                pos.save(update_fields=[
                    'exit_price', 'exit_time', 'exit_parent_order',
                    'realized_pnl', 'unrealized_pnl', 'status', 'updated_at'
                ])

                print(f"  {pos.instrument.instrument_type}: Exit Limit @ {limit_price} (LTP: {ltp}), PNL: {pnl:+.2f}")

            if stock_exit_orders:
                self.exit_orders[stock] = stock_exit_orders

            total_realized_pnl += stock_pnl

        print(f"\nTOTAL REALIZED PNL: {total_realized_pnl:+.2f}")
        self._print_order_summary()
        self.open_positions.clear()
        self.straddle_directions.clear()

    def _print_order_summary(self) -> None:
        """Print summary of all orders placed."""
        print("\n" + "=" * 60)
        print("ORDER SUMMARY")
        print("=" * 60)

        total_entry = 0
        total_exit = 0

        for stock in set(list(self.entry_orders.keys()) + list(self.exit_orders.keys())):
            entry_orders = self.entry_orders.get(stock, [])
            exit_orders = self.exit_orders.get(stock, [])

            print(f"\n{stock}:")

            if entry_orders:
                print("  Entry Orders:")
                for order in entry_orders:
                    summary = order_manager.get_parent_order_summary(order)
                    print(f"    PO#{order.order_id}: {order.side} {order.quantity}x "
                          f"{order.instrument.tradingsymbol} - {order.status}")
                    print(f"      Broker Orders: {summary['total_broker_orders']} total, "
                          f"{summary['completed']} completed, {summary['rejected']} rejected")
                total_entry += len(entry_orders)

            if exit_orders:
                print("  Exit Orders:")
                for order in exit_orders:
                    summary = order_manager.get_parent_order_summary(order)
                    print(f"    PO#{order.order_id}: {order.side} {order.quantity}x "
                          f"{order.instrument.tradingsymbol} - {order.status}")
                    print(f"      Broker Orders: {summary['total_broker_orders']} total, "
                          f"{summary['completed']} completed, {summary['rejected']} rejected")
                total_exit += len(exit_orders)

        print("\n" + "-" * 60)
        print(f"Total Entry Orders: {total_entry}")
        print(f"Total Exit Orders: {total_exit}")
        print("=" * 60)

    # =========================================================================
    # VERIFICATION
    # =========================================================================

    def verify(self) -> bool:
        """Verify strategy prerequisites before running."""
        print("\n" + "=" * 60)
        print("VERIFICATION: Checking instruments and datafeed")
        print("=" * 60)

        if not self.datafeed_obj:
            print("ERROR: No datafeed object provided")
            return False

        if self.datafeed_obj.is_token_expired:
            print("WARNING: Datafeed token expired, attempting refresh...")
            from datafeed.rest.handler import DataFeedHandler
            handler = DataFeedHandler(self.datafeed_obj)
            if not handler.update_token():
                print("ERROR: Failed to refresh datafeed token")
                return False
            print("SUCCESS: Datafeed token refreshed")

        print(f"\nChecking {len(STOCKS_TO_CONSIDER)} stocks...")

        missing_futures = []
        missing_options = []

        for stock in STOCKS_TO_CONSIDER:
            future = self._get_nearest_future(stock)
            if not future:
                missing_futures.append(stock)
                continue

            self.futures[stock] = future

            option_expiry = self._get_nearest_option_expiry(stock)
            if not option_expiry:
                missing_options.append(stock)
                continue

            self.option_expiries[stock] = option_expiry
            self.active_stocks.append(stock)

        print(f"\nVerification Results:")
        print(f"  Active stocks: {len(self.active_stocks)}")

        if missing_futures:
            print(f"  Missing futures ({len(missing_futures)}): {', '.join(missing_futures[:5])}...")
        if missing_options:
            print(f"  Missing options ({len(missing_options)}): {', '.join(missing_options[:5])}...")

        if not self.active_stocks:
            print("\nERROR: No stocks available for monitoring")
            return False

        print("\nStrategy verification passed!")
        return True

    # =========================================================================
    # MAIN RUN LOOP
    # =========================================================================

    def run(self, place_orders: bool = True):
        """
        Main strategy execution loop.

        Args:
            place_orders: If True, place actual orders via OMS. If False, only track positions.

        Flow:
        1. Verify prerequisites
        2. Wait for entry time
        3. Update ATM options
        4. Call business logic for signals
        5. Create positions and place entry orders
        6. Track PNL every minute
        7. At exit time, close positions and place exit orders
        """
        print(f"\n{'='*60}")
        print(f"Starting {self.strategy_obj.strategy_name}")
        print(f"Entry Time: {self.strategy_obj.entry_time}")
        print(f"Exit Time: {self.strategy_obj.exit_time}")
        print(f"Order Execution: {'ENABLED' if place_orders else 'DISABLED (simulation)'}")
        print(f"{'='*60}\n")

        # Verify prerequisites
        if not self.verify():
            print("Strategy verification failed. Exiting.")
            return

        self.is_running = True

        from datafeed.rest.handler import DataFeedHandler
        datafeed_handler = DataFeedHandler(self.datafeed_obj)
        resume_only = self._bootstrap_from_db()

        # =====================================================================
        # PHASE 1: Wait for entry time
        # =====================================================================
        entry_datetime = self._get_today_datetime(self.strategy_obj.entry_time)
        exit_datetime = self._get_today_datetime(self.strategy_obj.exit_time)

        print(f"\nWaiting for entry time: {entry_datetime.strftime('%H:%M:%S')}")

        if not self._wait_until(entry_datetime):
            print("Strategy stopped while waiting for entry time.")
            return

        if not self.is_running:
            return
        if resume_only:
            self.log_warning("Skipping ENTRY phase. Monitoring existing positions.")

            while self.is_running:
                if self._is_past_exit_time():
                    print("\n>>> EXIT TIME REACHED <<<")
                    break

                # Update positions and calculate PNL
                pnl_data = self._update_positions_ltp(datafeed_handler)

                # Print PNL table
                timestamp = timezone.now().strftime('%H:%M:%S')
                print(f"\n[{timestamp}] Position PNL (Resume Mode):")
                print("-" * 90)
                print(f"{'Stock':<12} {'Dir':<6} {'Strike':<10} {'CE Entry':<10} {'CE LTP':<10} "
                      f"{'PE Entry':<10} {'PE LTP':<10} {'PNL':<12}")
                print("-" * 90)

                total_pnl = 0.0
                for stock, data in pnl_data.items():
                    print(f"{stock:<12} {data['direction']:<6} {data['strike']:<10.2f} "
                          f"{data['ce_entry']:<10.2f} {data['ce_ltp']:<10.2f} "
                          f"{data['pe_entry']:<10.2f} {data['pe_ltp']:<10.2f} "
                          f"{data['total_pnl']:+12.2f}")
                    total_pnl += data['total_pnl']

                print("-" * 90)
                print(f"{'TOTAL':<12} {'':<6} {'':<10} {'':<10} {'':<10} {'':<10} {'':<10} {total_pnl:+12.2f}")
                print("-" * 90)

                # Calculate time to exit
                remaining = (exit_datetime - timezone.now()).total_seconds()
                if remaining > 0:
                    print(f"Time to exit: {int(remaining // 60)} min {int(remaining % 60)} sec")

                time.sleep(60)

            if self.open_positions:
                self._close_all_positions(datafeed_handler, place_orders=place_orders)

            self.is_running = False
            self.log_info("Recovery exit completed.")
            return
        # =====================================================================
        # PHASE 2: Entry - Get signals and create positions
        # =====================================================================
        print("\n" + "=" * 60)
        print("ENTRY PHASE")
        print("=" * 60)

        # Update ATM options based on current prices
        print("\nUpdating ATM options...")
        self._update_atm_options(datafeed_handler)

        stocks_with_options = [s for s in self.active_stocks if s in self.options]
        print(f"Stocks with valid option pairs: {len(stocks_with_options)}")

        if not stocks_with_options:
            print("ERROR: No stocks with valid options. Exiting.")
            self.is_running = False
            return

        # Get trading signals from business logic
        print("\nCalling business logic for signals...")
        long_stocks, short_stocks = self._get_trading_signals()

        print(f"  Long straddles: {long_stocks}")
        print(f"  Short straddles: {short_stocks}")

        if not long_stocks and not short_stocks:
            print("No signals generated. Exiting.")
            self.is_running = False
            return

        # Fetch LTPs for all option pairs we need
        all_options = []
        for stock in long_stocks + short_stocks:
            if stock in self.options:
                ce, pe = self.options[stock]
                all_options.extend([ce, pe])

        option_ltps = self._fetch_multiple_ltp(datafeed_handler, all_options)

        # Create long straddle positions
        print("\nCreating LONG straddle positions:")
        for stock in long_stocks:
            if stock not in self.options:
                print(f"  {stock}: SKIP - No options available")
                continue

            ce, pe = self.options[stock]
            ce_ltp = option_ltps.get(ce.instrument_token)
            pe_ltp = option_ltps.get(pe.instrument_token)

            if ce_ltp and pe_ltp:
                self._create_straddle_positions(
                    stock, 'LONG', ce_ltp, pe_ltp,
                    datafeed_handler, place_orders=place_orders
                )
            else:
                print(f"  {stock}: SKIP - Could not fetch LTP")

        # Create short straddle positions
        print("\nCreating SHORT straddle positions:")
        for stock in short_stocks:
            if stock not in self.options:
                print(f"  {stock}: SKIP - No options available")
                continue

            ce, pe = self.options[stock]
            ce_ltp = option_ltps.get(ce.instrument_token)
            pe_ltp = option_ltps.get(pe.instrument_token)

            if ce_ltp and pe_ltp:
                self._create_straddle_positions(
                    stock, 'SHORT', ce_ltp, pe_ltp,
                    datafeed_handler, place_orders=place_orders
                )
            else:
                print(f"  {stock}: SKIP - Could not fetch LTP")

        if not self.open_positions:
            print("\nNo positions created. Exiting.")
            self.is_running = False
            return

        print(f"\nTotal straddles created: {len(self.open_positions)}")

        # =====================================================================
        # PHASE 3: Monitor and track PNL
        # =====================================================================
        print("\n" + "=" * 60)
        print("MONITORING PHASE - Tracking PNL every minute")
        print(f"Exit scheduled at: {exit_datetime.strftime('%H:%M:%S')}")
        print("=" * 60)

        while self.is_running:
            # Check if it's time to exit
            if self._is_past_exit_time():
                print("\n>>> EXIT TIME REACHED <<<")
                break

            # Update positions and calculate PNL
            pnl_data = self._update_positions_ltp(datafeed_handler)

            # Print PNL table
            timestamp = timezone.now().strftime('%H:%M:%S')
            print(f"\n[{timestamp}] Position PNL:")
            print("-" * 90)
            print(f"{'Stock':<12} {'Dir':<6} {'Strike':<10} {'CE Entry':<10} {'CE LTP':<10} "
                  f"{'PE Entry':<10} {'PE LTP':<10} {'PNL':<12}")
            print("-" * 90)

            total_pnl = 0.0
            for stock, data in pnl_data.items():
                print(f"{stock:<12} {data['direction']:<6} {data['strike']:<10.2f} "
                      f"{data['ce_entry']:<10.2f} {data['ce_ltp']:<10.2f} "
                      f"{data['pe_entry']:<10.2f} {data['pe_ltp']:<10.2f} "
                      f"{data['total_pnl']:+12.2f}")
                total_pnl += data['total_pnl']

            print("-" * 90)
            print(f"{'TOTAL':<12} {'':<6} {'':<10} {'':<10} {'':<10} {'':<10} {'':<10} {total_pnl:+12.2f}")
            print("-" * 90)

            # Calculate time to exit
            remaining = (exit_datetime - timezone.now()).total_seconds()
            if remaining > 0:
                print(f"Time to exit: {int(remaining // 60)} min {int(remaining % 60)} sec")

            # Wait 1 minute before next update
            time.sleep(60)

        # =====================================================================
        # PHASE 4: Exit - Close all positions
        # =====================================================================
        if self.is_running and self.open_positions:
            self._close_all_positions(datafeed_handler, place_orders=place_orders)

        self.is_running = False
        print(f"\n{self.strategy_obj.strategy_name} completed.")

    def stop(self):
        """Stop the strategy gracefully."""
        print(f"\nStopping {self.strategy_obj.strategy_name}...")
        self.is_running = False

    # =========================================================================
    # EXTERNAL API
    # =========================================================================

    def get_open_positions(self) -> dict[str, dict]:
        """
        Get current open positions with PNL (can be called externally).

        Returns:
            dict: Stock -> position details with PNL
        """
        if not self.open_positions or not self.datafeed_obj:
            return {}

        from datafeed.rest.handler import DataFeedHandler
        handler = DataFeedHandler(self.datafeed_obj)

        return self._update_positions_ltp(handler)

    def get_order_status(self) -> dict:
        """
        Get status of all orders placed by this strategy.

        Returns:
            dict: Order status summary
        """
        result = {
            'entry_orders': {},
            'exit_orders': {},
            'summary': {
                'total_entry': 0,
                'total_exit': 0,
                'entry_completed': 0,
                'exit_completed': 0
            }
        }

        for stock, orders in self.entry_orders.items():
            result['entry_orders'][stock] = []
            for order in orders:
                summary = order_manager.get_parent_order_summary(order)
                result['entry_orders'][stock].append(summary)
                result['summary']['total_entry'] += 1
                if order.status == 'COMPLETED':
                    result['summary']['entry_completed'] += 1

        for stock, orders in self.exit_orders.items():
            result['exit_orders'][stock] = []
            for order in orders:
                summary = order_manager.get_parent_order_summary(order)
                result['exit_orders'][stock].append(summary)
                result['summary']['total_exit'] += 1
                if order.status == 'COMPLETED':
                    result['summary']['exit_completed'] += 1

        return result
