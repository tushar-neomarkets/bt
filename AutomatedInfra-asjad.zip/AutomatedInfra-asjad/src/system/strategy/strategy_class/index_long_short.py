""" Index Long Short """

import csv
import os
import shutil
import time
import uuid
from datetime import date, datetime, time as dt_time
from decimal import Decimal
from typing import Optional
from marketdata import Index

import pandas as pd
from django.db.models import Min
from django.utils import timezone

from instruments.models import Instrument
from orders.order_manager import order_manager
from strategy.models import StrategyPosition
from strategy.strategy_class.base_strategy import BaseStrategy

TBT_DATA_PATH = r"\\10.211.8.76\GFD MBM Data\Momentum\logs"
LOCAL_TBT_DIR = os.path.join(
    os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))),
    "dump", "tbt_local",
)
TBT_COPY_INTERVAL_SECS = 20

# ── TBT Guard Constants ──────────────────────────────────────────────────────
TBT_MARKET_OPEN = dt_time(9, 15, 0)
TBT_MARKET_CLOSE = dt_time(15, 30, 0)
TBT_MAX_STALENESS_SECS = 120          # Reject if latest tick > 2 min behind wall clock

PRICE_OFFSET = Decimal("0.5")
ROLLOVER_DAYS_BEFORE = 0             # Switch to NW expiry on expiry day itself
ROLLOVER_CHECK_TIME = dt_time(10, 30, 0)  # Roll open positions at this time on expiry day

TICKER = "NIFTY"

# ── CSV State Persistence ─────────────────────────────────────────────────────
_BASE_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
IDXLS_DUMP_DIR = os.path.join(_BASE_DIR, 'dump', 'idxls')
CSV_COLUMNS = [
    'timestamp', 'event',
    # EMA & candle
    'prev_ema', 'candle_idx',
    'candle_open', 'candle_high', 'candle_low', 'candle_close',
    # Signal state
    'position', 'trigger',
    'entry_price', 'sl_price',
    'ema_trigger', 'high_trigger', 'low_trigger',
    'day_high', 'day_low',
    # Instruments
    'ce_token', 'ce_tradingsymbol',
    'pe_token', 'pe_tradingsymbol',
    'expiry', 'atm_strike', 'spot_price',
    # Flags
    'rollover_done',
    # Exit info
    'exit_type', 'exit_atm_strike',
]

# fno = FnO()
# cash = Cash()
idx = Index()

# ── Constants ──────────────────────────────────────────────────────────────────
INDEX_SYMBOL = "NIFTY 50"
TBT_INDEX_NAME = "Nifty 50"          # Name as it appears in TBT files
EMA_SPAN = 40
HISTORY_CALENDAR_DAYS = 90           # For EMA warm up, ideally 90 days  
EMA_K = 2 / (EMA_SPAN + 1)           # EMA_K = 0.04878 --> 1 - EMA_K = 0.95122 (for span = 40)

# For historical data from marketdata
VALID_HOURLY_TIMES = [
    dt_time(10, 14, 59), dt_time(11, 14, 59), dt_time(12, 14, 59),
    dt_time(13, 14, 59), dt_time(14, 14, 59), dt_time(15, 14, 59),
]

# For TBT data
# Hourly candle boundaries: (start_inclusive, end_exclusive)
# Each candle spans 1 hour; close = last tick before end boundary
HOURLY_BOUNDARIES = [
    (dt_time(9, 15, 0),  dt_time(10, 15, 0)),
    (dt_time(10, 15, 0), dt_time(11, 15, 0)),
    (dt_time(11, 15, 0), dt_time(12, 15, 0)),
    (dt_time(12, 15, 0), dt_time(13, 15, 0)),
    (dt_time(13, 15, 0), dt_time(14, 15, 0)),
    (dt_time(14, 15, 0), dt_time(15, 15, 0)),
]


class IndexLongShort(BaseStrategy):

    def __init__(self, strategy_obj, datafeed_obj, ws_manager=None):
        super().__init__(strategy_obj, datafeed_obj, ws_manager)
        self.is_running = False

        # ── EMA State ──────────────────────────────────────────────────────
        self.prev_ema: Optional[float] = None
        self.ema_series: Optional[pd.DataFrame] = None

        # ── TBT State ──────────────────────────────────────────────────────
        self.hourly_candles: list[dict] = []

        # ── Signal State ───────────────────────────────────────────────────
        self.position: int = 0              # 0=flat, 1=long, -1=short
        self.trigger: int = 0               # 0=none, 1=bullish, -1=bearish
        self.sl_price: Optional[float] = None
        self.entry_time = None
        self.entry_price: Optional[float] = None
        self.day_high: Optional[float] = None
        self.day_low: Optional[float] = None
        self.ema_trigger: Optional[float] = None   # EMA at time of trigger
        self.high_trigger: Optional[float] = None  # Breakout level for long
        self.low_trigger: Optional[float] = None   # Breakout level for short

        # ── Synthetic Forward / Order State ───────────────────────────────
        self.entry_ce: Optional[Instrument] = None             # ATM CE leg of synthetic forward
        self.entry_pe: Optional[Instrument] = None             # ATM PE leg of synthetic forward
        self.open_positions: dict[str, StrategyPosition] = {}  # {"CE": pos, "PE": pos}
        self.last_processed_candle_idx: int = -1               # Track which hourly boundary was last processed
        self._current_trading_date: Optional[date] = None      # For day-boundary detection
        self._rollover_done_today: bool = False                # Prevent double-rollover
        # self._last_broker_token_refresh: float = 0.0  # Centralized — handled by TokenRefreshManager
        self._last_good_max_ts: Optional[datetime] = None        # For timestamp regression detection

    # =========================================================================
    # HISTORICAL DATA INGESTION & EMA (Step 1)
    # =========================================================================

    def _fetch_historical_hourly_data(self) -> Optional[pd.DataFrame]:
        """ Fetch ~N trading days (1.33x calendar days) of hourly NIFTY 50 data
        from the marketdata API. """
        
        today = date.today()
        start_date = today - pd.Timedelta(days=HISTORY_CALENDAR_DAYS)

        start_str = start_date.strftime("%Y-%m-%d")
        end_str = today.strftime("%Y-%m-%d")

        self.log_info(
            f"Fetching hourly data: {INDEX_SYMBOL} "
            f"from {start_str} to {end_str}"
            )

        try:
            df = idx.get_prices(
                INDEX_SYMBOL,
                start_str,
                end_str,
                interval="1h",
                columns="ohlc",
            )
        except Exception as e:
            self.log_error(f"marketdata API call failed: {e}")
            return None

        if df is None or df.empty:
            self.log_error("API returned no data.")
            return None

        df.sort_values("timestamp", inplace=True)
        df.reset_index(drop=True, inplace=True)

        # Filter to valid hourly candle close times only
        valid_set = set(VALID_HOURLY_TIMES)
        df = df[df["timestamp"].dt.time.isin(valid_set)].copy()
        df.reset_index(drop=True, inplace=True)

        if df.empty:
            self.log_error("No candles matched valid hourly times after filtering.")
            return None

        self.log_info(
            f"Fetched {len(df)} hourly candles "
            f"({df['timestamp'].iloc[0]} → {df['timestamp'].iloc[-1]})"
        )

        return df

    def _calculate_initial_ema(self, df: pd.DataFrame) -> float:
        """ Compute EMA(n) on the historical hourly close prices. """
        
        df = df.copy()

        df["EMA"] = df["close"].ewm(span=EMA_SPAN, adjust=False).mean()

        self.prev_ema = float(df["EMA"].iloc[-1])
        self.ema_series = df[["timestamp", "close", "EMA"]].copy()

        self.log_info(
            f"EMA({EMA_SPAN}) initialized: {self.prev_ema:.2f} "
            f"(from {len(df)} candles, "
            f"last close: {df['close'].iloc[-1]:.2f})"
        )

        return self.prev_ema

    # =========================================================================
    # TBT FILE COPY & PARSING (Step 2)
    # =========================================================================

    def _copy_tbt_file(self, file_date: Optional[date] = None) -> Optional[str]:
        """ Copy today's TBT file from network share to local directory.
        Returns the local file path, or None on failure. """

        target_date = file_date or date.today()
        filename = target_date.strftime("%Y%m%d") + ".txt"
        source = os.path.join(TBT_DATA_PATH, filename)
        
        os.makedirs(LOCAL_TBT_DIR, exist_ok=True)
        dest = os.path.join(LOCAL_TBT_DIR, filename)

        try:
            shutil.copy2(source, dest)
            file_size = os.path.getsize(dest)
            self.log_info(f"Copied TBT file: {filename} ({file_size / 1024:.1f} KB)")
            return dest
        except FileNotFoundError:
            self.log_error(f"TBT file not found: {source}")
            return None
        except Exception as e:
            self.log_error(f"Failed to copy TBT file: {e}")
            return None

    def _parse_tbt_data(self, file_path: str) -> Optional[pd.DataFrame]:
        """ Parse TBT file and filter for Nifty 50 ticks.
        
        TBT format:
            2026-02-01 09:32:35.339220 | Nifty 50 | 25301.0 | 1769918554
        
        Returns DataFrame with columns: [timestamp, price] """

        try:
            df = pd.read_csv(
                file_path,
                sep=r"\s*\|\s*",
                header=None,
                names=["timestamp", "index_name", "price", "seq_id"],
                engine="python",
            )
        except Exception as e:
            self.log_error(f"Failed to parse TBT file: {e}")
            return None

        # Filter for Nifty 50 only
        df = df[df["index_name"] == TBT_INDEX_NAME].copy()

        if df.empty:
            self.log_error(f"No '{TBT_INDEX_NAME}' ticks found in TBT file.")
            return None

        df["timestamp"] = pd.to_datetime(df["timestamp"], format="mixed")
        df["price"] = pd.to_numeric(df["price"], errors="coerce")
        df = df.dropna(subset=["price"])
        df = df.sort_values("timestamp").reset_index(drop=True)

        # ── Market hours filter: keep only 9:15–15:30 ────────────────────
        pre_filter_count = len(df)
        df = df[
            (df["timestamp"].dt.time >= TBT_MARKET_OPEN)
            & (df["timestamp"].dt.time <= TBT_MARKET_CLOSE)
        ].reset_index(drop=True)
        rejected = pre_filter_count - len(df)
        if rejected > 0:
            self.log_info(f"Market hours filter: rejected {rejected} ticks outside 09:15–15:30")

        if df.empty:
            self.log_error("No ticks remain after market hours filter.")
            return None

        self.log_info(f"Parsed {len(df)} Nifty 50 ticks from TBT file")
        return df[["timestamp", "price"]]

    def _validate_tbt_data(self, tbt_df: pd.DataFrame) -> bool:
        """Validate parsed TBT data for staleness and timestamp regression.
        Returns True if data is safe to use, False if it should be rejected."""

        max_ts: datetime = tbt_df["timestamp"].max().to_pydatetime()
        now = datetime.now()

        # ── Staleness: reject if latest tick is too far behind wall clock ─
        staleness_secs = (now - max_ts).total_seconds()
        if staleness_secs > TBT_MAX_STALENESS_SECS:
            self.log_error(
                f"TBT REJECTED (stale): latest tick {max_ts.strftime('%H:%M:%S')} "
                f"is {staleness_secs:.0f}s behind wall clock "
                f"(threshold: {TBT_MAX_STALENESS_SECS}s)"
            )
            return False

        # ── Timestamp regression: reject if max timestamp went backwards ──
        if self._last_good_max_ts is not None and max_ts < self._last_good_max_ts:
            regression_secs = (self._last_good_max_ts - max_ts).total_seconds()
            self.log_error(
                f"TBT REJECTED (regression): max tick {max_ts.strftime('%H:%M:%S')} "
                f"< previous good {self._last_good_max_ts.strftime('%H:%M:%S')} "
                f"(regressed {regression_secs:.0f}s)"
            )
            return False

        # ── All checks passed — update tracking state ────────────────────
        self._last_good_max_ts = max_ts
        return True

    def _resample_tbt_to_hourly(self, tbt_df: pd.DataFrame) -> pd.DataFrame:
        """ Resample tick data to 1H OHLC candles using NSE hourly boundaries.
        
        Boundaries: [9:15→10:15), [10:15→11:15), ..., [14:15→15:15)
        Candle timestamp = last second of the bucket (10:14:59, 11:14:59, etc.)
        
        Returns DataFrame with columns: [timestamp, open, high, low, close] """

        candles = []
        
        for i, (start, end) in enumerate(HOURLY_BOUNDARIES):
            mask = (
                (tbt_df["timestamp"].dt.time >= start) &
                (tbt_df["timestamp"].dt.time < end)
            )
            bucket = tbt_df[mask]

            if bucket.empty:
                continue

            candle_time = VALID_HOURLY_TIMES[i]
            candle_date = bucket["timestamp"].iloc[0].date()

            candles.append({
                "timestamp": pd.Timestamp.combine(candle_date, candle_time),
                "open": float(bucket["price"].iloc[0]),
                "high": float(bucket["price"].max()),
                "low": float(bucket["price"].min()),
                "close": float(bucket["price"].iloc[-1]),
                "tick_count": len(bucket),
            })

        result = pd.DataFrame(candles)

        if not result.empty:
            self.log_info(
                f"Resampled {len(result)} hourly candles from "
                f"{tbt_df['timestamp'].iloc[0].time()} → "
                f"{tbt_df['timestamp'].iloc[-1].time()}"
            )
        return result

    def _update_ema(self, candle_close: float) -> float:
        """ Incremental EMA update from a single candle close. """

        if self.prev_ema is None:
            self.log_error("Cannot update EMA: prev_ema not initialized.")
            raise ValueError("prev_ema must be initialized before calling _update_ema")

        self.prev_ema = (candle_close * EMA_K) + (self.prev_ema * (1 - EMA_K))

        self.log_info(
            f"EMA updated: {self.prev_ema:.2f} "
            f"(candle close: {candle_close:.2f})"
        )
        return self.prev_ema

    # =========================================================================
    # SIGNAL GENERATION (Step 3)
    # =========================================================================

    def _get_day_high_low(self, current_candle: dict) -> tuple[float, float]:
        """Compute today's running high and low from completed hourly candles
        plus the current candle (inclusive)."""

        candle_date = current_candle["timestamp"].date()
        today_candles = [c for c in self.hourly_candles
                         if c["timestamp"].date() == candle_date]
        today_candles.append(current_candle)

        day_high = max(c["high"] for c in today_candles)
        day_low = min(c["low"] for c in today_candles)
        return day_high, day_low

    def _on_candle_close(self, candle: dict) -> None:
        """ Hourly candle processing — trigger logic, trailing SL, and EOD reset.
        Called once per hourly candle close. Entry/SL detection is handled by _check_tick()."""

        ema = self.prev_ema
        self.log_info(
            f"Candle close: {candle['timestamp']} | close={candle['close']:.2f} "
            f"EMA={ema:.2f} | pos={self.position} trigger={self.trigger}"
        )

        # ─── SECTION 1: TRAILING SL UPDATE (in position, new day) ────────

        if self.position == 1:
            if candle["timestamp"].date() != self.entry_time.date():
                old_sl = self.sl_price
                self.sl_price = ema - 1
                self.log_info(f"Trailing SL (long): {old_sl} → {self.sl_price:.2f}")
                for pos in self.open_positions.values():
                    meta = pos.strategy_metadata or {}
                    meta["sl_price"] = self.sl_price
                    pos.strategy_metadata = meta
                    pos.save(update_fields=["strategy_metadata"])
            else:
                self.log_info(f"Long position on entry day — SL unchanged at {self.sl_price}")

        elif self.position == -1:
            if candle["timestamp"].date() != self.entry_time.date():
                old_sl = self.sl_price
                self.sl_price = ema + 1
                self.log_info(f"Trailing SL (short): {old_sl} → {self.sl_price:.2f}")
                for pos in self.open_positions.values():
                    meta = pos.strategy_metadata or {}
                    meta["sl_price"] = self.sl_price
                    pos.strategy_metadata = meta
                    pos.save(update_fields=["strategy_metadata"])
            else:
                self.log_info(f"Short position on entry day — SL unchanged at {self.sl_price}")

        # ─── SECTION 2: TRIGGER SET/FLIP (only when flat) ────────────────

        if self.position == 0:
            if self.trigger == 0:
                if candle["close"] > ema:
                    self.trigger = 1
                    self.day_high, self.day_low = self._get_day_high_low(candle)
                    self.ema_trigger = ema
                    self.high_trigger = self.day_high + 1
                    self.log_info(
                        f"TRIGGER: Bullish | close={candle['close']:.2f} > "
                        f"EMA={ema:.2f} | breakout={self.high_trigger:.2f}")

                elif candle["close"] < ema:
                    self.trigger = -1
                    self.day_high, self.day_low = self._get_day_high_low(candle)
                    self.ema_trigger = ema
                    self.low_trigger = self.day_low - 1
                    self.log_info(
                        f"TRIGGER: Bearish | close={candle['close']:.2f} < "
                        f"EMA={ema:.2f} | breakout={self.low_trigger:.2f}")

            elif self.trigger == 1:
                if candle["close"] < ema:
                    self.trigger = -1
                    self.day_high, self.day_low = self._get_day_high_low(candle)
                    self.ema_trigger = ema
                    self.low_trigger = self.day_low - 1
                    self.log_info(
                        f"FLIP: Bull→Bear | breakout={self.low_trigger:.2f}")
                else:
                    self.log_info(
                        f"Bullish trigger holds: close={candle['close']:.2f} >= EMA={ema:.2f} "
                        f"| waiting for breakout={self.high_trigger:.2f}")

            elif self.trigger == -1:
                if candle["close"] > ema:
                    self.trigger = 1
                    self.day_high, self.day_low = self._get_day_high_low(candle)
                    self.ema_trigger = ema
                    self.high_trigger = self.day_high + 1
                    self.log_info(
                        f"FLIP: Bear→Bull | breakout={self.high_trigger:.2f}")
                else:
                    self.log_info(
                        f"Bearish trigger holds: close={candle['close']:.2f} <= EMA={ema:.2f} "
                        f"| waiting for breakout={self.low_trigger:.2f}")

            # EOD reset
            if self.position == 0 and candle["timestamp"].time() == dt_time(15, 14, 59):
                if self.trigger != 0:
                    self.log_info(f"EOD trigger reset (was {self.trigger})")
                self.trigger = 0

    # =========================================================================
    # 20-SECOND TBT POLLING (Step 4)
    # =========================================================================

    def _get_latest_tbt_price(self, tbt_df: pd.DataFrame) -> Optional[tuple[float, datetime]]:
        """Extract the last Nifty 50 tick from the already-parsed TBT DataFrame.

        Returns (price, timestamp) tuple, or None if empty."""

        if tbt_df is None or tbt_df.empty:
            return None

        last_row = tbt_df.iloc[-1]
        return float(last_row["price"]), last_row["timestamp"].to_pydatetime()

    def _check_tick(self, price: float, timestamp: datetime) -> Optional[dict]:
        """ Check latest tick price against entry triggers and SL levels.
        Called every 20 seconds between candle closes.

        Returns trade signal dict if entry/exit triggered, None otherwise. """

        signal = None

        # ── Entry check (flat with active trigger) ────────────────────────
        if self.position == 0 and self.trigger != 0:
            if self.trigger == 1 and price >= self.high_trigger:
                self.position = 1
                self.entry_time = timestamp
                self.entry_price = self.high_trigger
                self.sl_price = min(self.day_low - 1, self.ema_trigger)
                signal = {
                    "action": "ENTER_LONG", "timestamp": timestamp,
                    "price": self.entry_price, "direction": 1,
                    "sl_price": self.sl_price,
                }
                self.log_info(
                    f"TICK ENTRY LONG @ {self.entry_price:.2f} | "
                    f"SL={self.sl_price:.2f} | tick={price:.2f}")

            elif self.trigger == -1 and price <= self.low_trigger:
                self.position = -1
                self.entry_time = timestamp
                self.entry_price = self.low_trigger
                self.sl_price = max(self.day_high + 1, self.ema_trigger)
                signal = {
                    "action": "ENTER_SHORT", "timestamp": timestamp,
                    "price": self.entry_price, "direction": -1,
                    "sl_price": self.sl_price,
                }
                self.log_info(
                    f"TICK ENTRY SHORT @ {self.entry_price:.2f} | "
                    f"SL={self.sl_price:.2f} | tick={price:.2f}")

        # ── SL check (in position) ───────────────────────────────────────
        # State reset (position=0, trigger=0) is deferred to
        # _execute_signal and only applied on confirmed order success.
        elif self.position == 1 and self.sl_price is not None and price <= self.sl_price:
            signal = {
                "action": "EXIT_LONG", "entry_time": self.entry_time,
                "entry_price": self.entry_price,
                "exit_time": timestamp, "exit_price": price,
                "direction": 1, "sl_type": "Tick",
            }
            self.log_info(
                f"TICK SL LONG: exit @ {self.sl_price:.2f} | tick={price:.2f}")

        elif self.position == -1 and self.sl_price is not None and price >= self.sl_price:
            signal = {
                "action": "EXIT_SHORT", "entry_time": self.entry_time,
                "entry_price": self.entry_price,
                "exit_time": timestamp, "exit_price": price,
                "direction": -1, "sl_type": "Tick",
            }
            self.log_info(
                f"TICK SL SHORT: exit @ {self.sl_price:.2f} | tick={price:.2f}")

        return signal

    # =========================================================================
    # INSTRUMENT LOOKUPS
    # =========================================================================

    def _get_nearest_option_expiry(self) -> Optional[date]:
        """Get the nearest weekly option expiry date for NIFTY."""
        today = date.today()
        result = Instrument.objects.filter(
            name=TICKER,
            exchange="NFO",
            instrument_type__in=["CE", "PE"],
            is_active=True,
            expiry__gte=today,
        ).aggregate(min_expiry=Min("expiry"))
        return result.get("min_expiry")

    def _get_next_week_expiry(self) -> Optional[date]:
        """Get the next-week option expiry (second nearest)."""
        today = date.today()
        expiries = (
            Instrument.objects.filter(
                name=TICKER,
                exchange="NFO",
                instrument_type__in=["CE", "PE"],
                is_active=True,
                expiry__gte=today,
            )
            .values_list("expiry", flat=True)
            .distinct()
            .order_by("expiry")[:2]
        )
        expiry_list = list(expiries)
        if len(expiry_list) >= 2:
            return expiry_list[1]
        return expiry_list[0] if expiry_list else None

    def _resolve_expiry(self) -> Optional[date]:
        """Pick CW or NW expiry based on rollover rule.
        On expiry day itself (ROLLOVER_DAYS_BEFORE=0), switch to next week."""
        cw = self._get_nearest_option_expiry()
        if cw is None:
            self.log_error("No option expiry found.")
            return None

        days_to_cw = (cw - date.today()).days
        if days_to_cw <= ROLLOVER_DAYS_BEFORE:
            nw = self._get_next_week_expiry()
            if nw:
                self.log_info(f"Rollover: CW={cw} ({days_to_cw}d away), using NW={nw}")
                return nw

        self.log_info(f"Using CW expiry: {cw} ({days_to_cw}d away)")
        return cw

    def _get_available_strikes(self, expiry: date, option_type: str) -> list[Decimal]:
        """Get all available strikes for a given expiry and type."""
        strikes = Instrument.objects.filter(
            name=TICKER,
            exchange="NFO",
            instrument_type=option_type,
            expiry=expiry,
            is_active=True,
        ).values_list("strike", flat=True).distinct()
        return sorted([s for s in strikes if s is not None])

    def _find_atm_strike(self, price: float, strikes: list[Decimal]) -> Optional[Decimal]:
        """Find the strike closest to the given price."""
        if not strikes:
            return None
        price_d = Decimal(str(price))
        return min(strikes, key=lambda s: abs(s - price_d))

    def _get_option_instrument(
        self, expiry: date, strike: Decimal, option_type: str
    ) -> Optional[Instrument]:
        """Get a single option instrument."""
        return Instrument.objects.filter(
            name=TICKER,
            exchange="NFO",
            instrument_type=option_type,
            expiry=expiry,
            strike=strike,
            is_active=True,
        ).first()

    # =========================================================================
    # ORDER PLACEMENT
    # =========================================================================

    def _limit_price(self, side: str, ltp: float) -> Decimal:
        """Passive limit: SELL → LTP + offset, BUY → LTP − offset."""
        base = Decimal(str(ltp))
        return base + PRICE_OFFSET if side == "SELL" else base - PRICE_OFFSET

    def _fetch_ltp(self, datafeed_handler, instrument: Instrument) -> Optional[float]:
        """Fetch LTP for a single instrument. Retries indefinitely with token refresh on failure."""
        attempt = 0
        while self.is_running:
            attempt += 1
            try:
                response = datafeed_handler.get_multiple_ltp([instrument])
                if response and "data" in response:
                    for item in response["data"].get("ltp_list", []):
                        if item.get("instrument_token") == instrument.instrument_token:
                            return item.get("ltp")
                return None  # Successful call, no matching data — don't retry
            except Exception as e:
                self.log_warning(
                    f"LTP fetch failed (attempt {attempt}) for "
                    f"{instrument.tradingsymbol}: {e}"
                )
                try:
                    from datafeed.rest.handler import DataFeedHandler
                    DataFeedHandler(self.datafeed_obj).update_token()
                    self.datafeed_obj.refresh_from_db()
                    self.log_info("Datafeed token refreshed after LTP failure")
                except Exception as refresh_err:
                    self.log_error(f"Token refresh failed: {refresh_err}")
                time.sleep(2)
        return None

    def _fetch_multiple_ltp(self, datafeed_handler, instruments: list[Instrument]) -> dict[int, float]:
        """Fetch LTP for multiple instruments. Retries indefinitely with token refresh on failure."""
        if not instruments:
            return {}
        attempt = 0
        while self.is_running:
            attempt += 1
            try:
                result: dict[int, float] = {}
                response = datafeed_handler.get_multiple_ltp(instruments)
                if response and "data" in response:
                    for item in response["data"].get("ltp_list", []):
                        token = item.get("instrument_token")
                        ltp = item.get("ltp")
                        if token and ltp:
                            result[token] = ltp
                return result  # Successful call — return even if empty
            except Exception as e:
                self.log_warning(
                    f"Multiple LTP fetch failed (attempt {attempt}) for "
                    f"{len(instruments)} instruments: {e}"
                )
                try:
                    from datafeed.rest.handler import DataFeedHandler
                    DataFeedHandler(self.datafeed_obj).update_token()
                    self.datafeed_obj.refresh_from_db()
                    self.log_info("Datafeed token refreshed after multi-LTP failure")
                except Exception as refresh_err:
                    self.log_error(f"Token refresh failed: {refresh_err}")
                time.sleep(2)
        return {}

    def _place_order(
        self,
        instrument: Instrument,
        side: str,
        quantity: int,
        price: Optional[Decimal],
        order_intent: str,
        tag: str = "",
        dry_run: bool = False,
    ) -> tuple[bool, object]:
        """Place an order via OrderManager. Supports dry-run mode."""
        order_type = "LIMIT" if price is not None else "MARKET"
        price_str = str(price) if price is not None else "MKT"

        if dry_run:
            self.log_info(
                f"  [DRY-RUN][{tag}] {order_intent} {side} {quantity}x"
                f" {instrument.tradingsymbol}"
                f" | {order_type} @ {price_str}"
                f" | NRML"
                f" | expiry={instrument.expiry}"
            )
            return True, None

        success, msg, parent_order, _ = order_manager.create_and_execute_order(
            strategy=self.strategy_obj,
            instrument=instrument,
            side=side,
            quantity=quantity,
            order_type=order_type,
            product_type="NRML",
            price=price,
            order_intent=order_intent,    
            metadata={
                "strategy_code": self.strategy_obj.strategy_code,
                "instrument_type": instrument.instrument_type,
                "stock_name": instrument.name,
                "tag": tag,
            },
        )
        if success:
            self.log_info(
                f"  [{tag}] {side} {quantity}x {instrument.tradingsymbol}"
                f" @ {price_str}"
            )
        else:
            self.log_error(f"  [{tag}] FAILED {side} {instrument.tradingsymbol}: {msg}")
        return success, parent_order

    # =========================================================================
    # STATE RECOVERY
    # =========================================================================

    def _bootstrap_from_db(self) -> bool:
        """
        Restore state from DB if strategy was restarted mid-position.
        Follows orb_short pattern: iterates open positions, restores CE/PE legs.

        Returns:
            True  -> Found open position(s); state restored.
            False -> No open position; fresh run.
        """
        db_positions = StrategyPosition.objects.filter(
            strategy=self.strategy_obj,
            status="OPEN",
        ).select_related("instrument")

        if not db_positions.exists():
            self.log_info("No existing open positions found. Fresh run.")
            return False

        for pos in db_positions:
            meta = pos.strategy_metadata or {}
            opt_type = meta.get("option_type")  # "CE" or "PE"

            if opt_type == "CE":
                self.entry_ce = pos.instrument
                self.open_positions["CE"] = pos
            elif opt_type == "PE":
                self.entry_pe = pos.instrument
                self.open_positions["PE"] = pos
            else:
                self.log_warning(
                    f"RECOVERY: Skipping position {pos.trade_id} "
                    f"with unknown option_type={opt_type}"
                )
                continue

            # Restore signal state from first leg encountered
            if self.position == 0:
                forward_dir = meta.get("forward_direction", "LONG")
                self.position = 1 if forward_dir == "LONG" else -1
                self.entry_price = meta.get("spot_signal", float(pos.entry_price))
                self.entry_time = pos.entry_time

                saved_sl = meta.get("sl_price")
                if saved_sl is not None:
                    self.sl_price = float(saved_sl)
                else:
                    self.sl_price = None

            self.log_warning(
                f"RECOVERY: Restored {opt_type} leg | "
                f"instrument={pos.instrument.tradingsymbol} "
                f"@ {pos.entry_price:.2f} | entered={pos.entry_time}"
            )

        self.log_warning(
            f"RECOVERY: position={'LONG' if self.position == 1 else 'SHORT'} "
            f"| SL={self.sl_price} | legs={list(self.open_positions.keys())}"
        )
        return True

    # =========================================================================
    # CSV STATE PERSISTENCE
    # =========================================================================

    def _get_csv_path(self) -> str:
        """Return today's CSV state file path."""
        code = self.strategy_obj.strategy_code.lower()
        return os.path.join(IDXLS_DUMP_DIR, f"{code}_{date.today().strftime('%Y%m%d')}.csv")

    def _append_csv_event(self, event: str, **kwargs) -> None:
        """Append a single event row to today's CSV state file."""
        csv_path = self._get_csv_path()
        os.makedirs(os.path.dirname(csv_path), exist_ok=True)

        file_exists = os.path.isfile(csv_path)

        row = {col: '' for col in CSV_COLUMNS}
        row['timestamp'] = datetime.now().isoformat()
        row['event'] = event
        row.update({k: v for k, v in kwargs.items() if k in CSV_COLUMNS})

        try:
            with open(csv_path, 'a', newline='') as f:
                writer = csv.DictWriter(f, fieldnames=CSV_COLUMNS)
                if not file_exists:
                    writer.writeheader()
                writer.writerow(row)
        except Exception as e:
            self.log_error(f"Failed to write CSV event: {e}")

    def _write_ema_init_event(self) -> None:
        """Write EMA_INIT event after historical EMA calculation."""
        self._append_csv_event('EMA_INIT', prev_ema=self.prev_ema)

    def _write_candle_event(self, candle: dict, candle_idx: int) -> None:
        """Write CANDLE event after hourly candle processing.
        Captures full signal state snapshot."""
        self._append_csv_event(
            'CANDLE',
            prev_ema=self.prev_ema,
            candle_idx=candle_idx,
            candle_open=candle['open'],
            candle_high=candle['high'],
            candle_low=candle['low'],
            candle_close=candle['close'],
            position=self.position,
            trigger=self.trigger,
            sl_price=self.sl_price if self.sl_price is not None else '',
            ema_trigger=self.ema_trigger if self.ema_trigger is not None else '',
            high_trigger=self.high_trigger if self.high_trigger is not None else '',
            low_trigger=self.low_trigger if self.low_trigger is not None else '',
            day_high=self.day_high if self.day_high is not None else '',
            day_low=self.day_low if self.day_low is not None else '',
        )

    def _write_entry_event(
        self, atm_strike: float, expiry: date, spot_price: float
    ) -> None:
        """Write ENTRY event after forward entry placed."""
        self._append_csv_event(
            'ENTRY',
            position=self.position,
            trigger=self.trigger,
            entry_price=self.entry_price,
            sl_price=self.sl_price,
            ce_token=self.entry_ce.instrument_token if self.entry_ce else '',
            ce_tradingsymbol=self.entry_ce.tradingsymbol if self.entry_ce else '',
            pe_token=self.entry_pe.instrument_token if self.entry_pe else '',
            pe_tradingsymbol=self.entry_pe.tradingsymbol if self.entry_pe else '',
            expiry=str(expiry),
            atm_strike=atm_strike,
            spot_price=spot_price,
        )

    def _write_box_exit_event(
        self, exit_spot: float, exit_atm: float, exit_type: str = "BOX_SPREAD"
    ) -> None:
        """Write BOX_EXIT event after box spread exit."""
        self._append_csv_event(
            'BOX_EXIT',
            exit_type=exit_type,
            spot_price=exit_spot,
            exit_atm_strike=exit_atm,
        )

    def _write_rollover_event(self, nw_expiry: date, atm_strike: float) -> None:
        """Write ROLLOVER event after rollover complete."""
        self._append_csv_event(
            'ROLLOVER',
            ce_token=self.entry_ce.instrument_token if self.entry_ce else '',
            ce_tradingsymbol=self.entry_ce.tradingsymbol if self.entry_ce else '',
            pe_token=self.entry_pe.instrument_token if self.entry_pe else '',
            pe_tradingsymbol=self.entry_pe.tradingsymbol if self.entry_pe else '',
            expiry=str(nw_expiry),
            atm_strike=atm_strike,
            sl_price=self.sl_price,
            rollover_done=1,
        )

    def _write_day_reset_event(self) -> None:
        """Write DAY_RESET event on day boundary change."""
        self._append_csv_event('DAY_RESET')

    def _load_state_from_csv(self) -> Optional[str]:
        """
        Restore signal state from today's CSV event log.
        Restores: EMA, trigger, day state, candle tracking, rollover flag.
        Position/instrument state is handled by _bootstrap_from_db.

        Returns phase string or None if no CSV found.
        """
        csv_path = self._get_csv_path()
        if not os.path.isfile(csv_path):
            return None

        try:
            df = pd.read_csv(csv_path, on_bad_lines='skip')
        except Exception as e:
            self.log_error(f"Failed to read CSV state: {e}")
            return None

        if df.empty:
            return None

        latest_phase = None

        for _, row in df.iterrows():
            event = row.get('event', '')

            if event == 'EMA_INIT':
                ema = row.get('prev_ema')
                if not pd.isna(ema):
                    self.prev_ema = float(ema)
                latest_phase = 'EMA_READY'

            elif event == 'CANDLE':
                # Restore EMA
                ema = row.get('prev_ema')
                if not pd.isna(ema):
                    self.prev_ema = float(ema)

                # Restore trigger state
                trigger = row.get('trigger')
                if not pd.isna(trigger):
                    self.trigger = int(trigger)
                for field in ('ema_trigger', 'high_trigger', 'low_trigger',
                              'day_high', 'day_low'):
                    val = row.get(field)
                    if not pd.isna(val) and val != '':
                        setattr(self, field, float(val))

                # Restore candle index
                idx = row.get('candle_idx')
                if not pd.isna(idx):
                    self.last_processed_candle_idx = int(idx)

                # Rebuild hourly_candles
                co = row.get('candle_open')
                ch = row.get('candle_high')
                cl = row.get('candle_low')
                cc = row.get('candle_close')
                if not any(pd.isna(v) for v in [co, ch, cl, cc]):
                    cidx = int(idx) if not pd.isna(idx) else len(self.hourly_candles)
                    if cidx < len(VALID_HOURLY_TIMES):
                        self.hourly_candles.append({
                            'timestamp': pd.Timestamp.combine(
                                date.today(), VALID_HOURLY_TIMES[cidx]
                            ),
                            'open': float(co), 'high': float(ch),
                            'low': float(cl), 'close': float(cc),
                        })

                # SL may have been trailed in candle processing
                sl = row.get('sl_price')
                if not pd.isna(sl) and sl != '':
                    self.sl_price = float(sl)

                latest_phase = 'RUNNING'

            elif event == 'ENTRY':
                trigger = row.get('trigger')
                if not pd.isna(trigger):
                    self.trigger = int(trigger)
                latest_phase = 'IN_POSITION'

            elif event == 'BOX_EXIT':
                self.trigger = 0
                self.ema_trigger = None
                self.high_trigger = None
                self.low_trigger = None
                latest_phase = 'RUNNING'

            elif event == 'ROLLOVER':
                rollover = row.get('rollover_done')
                if not pd.isna(rollover):
                    self._rollover_done_today = bool(int(rollover))
                latest_phase = 'IN_POSITION'

            elif event == 'DAY_RESET':
                self.trigger = 0
                self.ema_trigger = None
                self.high_trigger = None
                self.low_trigger = None
                self.hourly_candles.clear()
                self.last_processed_candle_idx = -1
                self._rollover_done_today = False
                latest_phase = 'RUNNING'

        self.log_info(
            f"CSV RECOVERY: phase={latest_phase} | EMA={self.prev_ema:.2f} "
            f"trigger={self.trigger} | candle_idx={self.last_processed_candle_idx} "
            f"| hourly_candles={len(self.hourly_candles)} "
            f"| rollover_done={self._rollover_done_today}"
        )
        return latest_phase

    # =========================================================================
    # TIME UTILITIES
    # =========================================================================

    def _get_today_datetime(self, time_obj) -> datetime:
        """Convert a time object to today's datetime in local timezone."""
        today = timezone.now().date()
        naive_dt = datetime.combine(today, time_obj)
        return timezone.make_aware(naive_dt)

    def _wait_until(self, target_time: datetime) -> bool:
        """Wait until target_time. Returns False if stop() was called."""
        while self.is_running:
            now = timezone.now()
            if now >= target_time:
                return True
            remaining = (target_time - now).total_seconds()
            if remaining > 60:
                self.log_info(
                    f"Waiting {int(remaining // 60)}m {int(remaining % 60)}s "
                    f"until {target_time.strftime('%H:%M:%S')}"
                )
                time.sleep(30)
            else:
                time.sleep(1)
        return False

    # =========================================================================
    # BASE STRATEGY INTERFACE
    # =========================================================================

    def verify(self) -> bool:
        """Verify strategy prerequisites before running."""
        if not self.datafeed_obj:
            self.log_error("No datafeed object provided.")
            return False

        if self.datafeed_obj.is_token_expired:
            self.log_warning("Datafeed token expired — attempting refresh...")
            from datafeed.rest.handler import DataFeedHandler
            handler = DataFeedHandler(self.datafeed_obj)
            if not handler.update_token():
                self.log_error("Failed to refresh datafeed token.")
                return False

        self.log_info("Verification passed.")
        return True

    # def _refresh_broker_tokens(self) -> None:  # Centralized — handled by TokenRefreshManager
    #     """Periodically refresh broker account tokens to prevent order failures."""
    #     from accounts.models import StrategyAccountMapping
    #     from accounts.brokers.handler import BrokerAccountHandler
    #
    #     mappings = StrategyAccountMapping.objects.filter(
    #         strategy=self.strategy_obj,
    #         is_active=True,
    #     ).select_related('broker_account', 'broker_account__broker')
    #
    #     for mapping in mappings:
    #         ba = mapping.broker_account
    #         ba.refresh_from_db()
    #         if ba.is_token_expired:
    #             self.log_warning(f"Broker token expired for {ba.account_name} — refreshing...")
    #             try:
    #                 BrokerAccountHandler(ba).update_token()
    #                 ba.refresh_from_db()
    #                 self.log_info(f"Broker token refreshed for {ba.account_name}")
    #             except Exception as e:
    #                 self.log_error(f"Broker token refresh failed for {ba.account_name}: {e}")
    #
    #     # Also refresh datafeed token if needed
    #     self.datafeed_obj.refresh_from_db()
    #     if self.datafeed_obj.is_token_expired:
    #         self.log_warning("Datafeed token expired — refreshing...")
    #         try:
    #             from datafeed.rest.handler import DataFeedHandler
    #             DataFeedHandler(self.datafeed_obj).update_token()
    #             self.datafeed_obj.refresh_from_db()
    #             self.log_info("Datafeed token refreshed")
    #         except Exception as e:
    #             self.log_error(f"Datafeed token refresh failed: {e}")

    def stop(self):
        """Stop the strategy gracefully."""
        self.log_info("Stopping IndexLongShort...")
        self.is_running = False

    def run(self):
        """
        Main orchestration loop:
          1. Verify → 2. Wait for entry time → 3. Init EMA
          4. Restore state → 5. TBT poll loop
             (hourly candle processing + tick-level entry/SL via synthetic forwards)
        """
        params = self.strategy_obj.strategy_params or {}
        dry_run = bool(params.get("dry_run", False))

        self.log_info("=" * 60)
        self.log_info(f"Starting IndexLongShort")
        self.log_info(f"Entry Time : {self.strategy_obj.entry_time}")
        self.log_info(f"Exit Time  : {self.strategy_obj.exit_time}")
        self.log_info(f"Mode       : {'DRY-RUN' if dry_run else 'LIVE'}")
        self.log_info("=" * 60)

        # Step 1: Verify
        if not self.verify():
            self.log_error("Verification failed. Exiting.")
            return

        self.is_running = True

        from datafeed.rest.handler import DataFeedHandler
        datafeed_handler = DataFeedHandler(self.datafeed_obj)

        # Step 2: Wait for entry time
        entry_dt = self._get_today_datetime(self.strategy_obj.entry_time)
        self.log_info(f"Waiting for entry time: {entry_dt.strftime('%H:%M:%S')}")
        if not self._wait_until(entry_dt):
            self.log_info("Strategy stopped while waiting.")
            return
        if not self.is_running:
            return

        # Step 3: Fetch historical data and initialize EMA
        df = self._fetch_historical_hourly_data()
        if df is None:
            self.log_error("Failed to fetch historical data. Exiting.")
            self.is_running = False
            return
        self._calculate_initial_ema(df)

        # Step 4: Restore state from CSV (signal state) + DB (position state)
        self._bootstrap_from_db()           # Authoritative for position/instrument state
        csv_phase = self._load_state_from_csv()  # Fills in EMA, triggers, day state

        if csv_phase is not None:
            # Consistency check: CSV says in position but DB has no open positions
            if self.position != 0 and not self.open_positions:
                self.log_warning(
                    "RECOVERY: CSV shows position but no open DB positions. "
                    "Resetting to flat."
                )
                self.position = 0
                self.trigger = 0
                self.sl_price = None
        else:
            self._write_ema_init_event()    # Fresh run — start CSV log

        # Protect recovered state from being wiped by the day-boundary check
        self._current_trading_date = date.today()

        # Step 5: Main TBT polling loop
        self.log_info("Entering main TBT polling loop...")
        exit_dt = self._get_today_datetime(self.strategy_obj.exit_time)

        while self.is_running:
            # Check exit time
            if timezone.now() >= exit_dt:
                self.log_info("Exit time reached. Stopping loop.")
                break

            # Periodic broker + datafeed token refresh — centralized in TokenRefreshManager
            # if time.time() - self._last_broker_token_refresh >= BROKER_TOKEN_REFRESH_INTERVAL_SECS:
            #     try:
            #         self._refresh_broker_tokens()
            #     except Exception as e:
            #         self.log_error(f"Broker token refresh cycle failed: {e}")
            #     self._last_broker_token_refresh = time.time()

            try:
                # Day-boundary reset: clear stale state when date changes
                today = date.today()
                if self._current_trading_date != today:
                    if self._current_trading_date is not None:
                        self.log_info(
                            f"New trading day: {today}. "
                            f"Resetting candle index and hourly_candles."
                        )
                    self._current_trading_date = today
                    self.last_processed_candle_idx = -1
                    self.hourly_candles.clear()
                    self._rollover_done_today = False
                    self._last_good_max_ts = None
                    self._write_day_reset_event()

                # 5a: Copy and parse TBT file (single copy per iteration)
                local_path = self._copy_tbt_file()
                if local_path is None:
                    time.sleep(TBT_COPY_INTERVAL_SECS)
                    continue

                tbt_df = self._parse_tbt_data(local_path)
                if tbt_df is None or tbt_df.empty:
                    time.sleep(TBT_COPY_INTERVAL_SECS)
                    continue

                # 5a-guard: Validate staleness & timestamp regression
                if not self._validate_tbt_data(tbt_df):
                    time.sleep(TBT_COPY_INTERVAL_SECS)
                    continue

                # 5b: Rollover check — on expiry day, if position still open
                #     at ROLLOVER_CHECK_TIME, box exit CW and re-enter at NW.
                if (
                    self.position != 0
                    and not self._rollover_done_today
                    and datetime.now().time() >= ROLLOVER_CHECK_TIME
                    and self._get_nearest_option_expiry() == date.today()
                ):
                    tick_result = self._get_latest_tbt_price(tbt_df)
                    if tick_result:
                        self._execute_rollover(
                            tick_result[0], datafeed_handler, dry_run
                        )

                # 5c: Check latest tick FIRST — SL must be evaluated against
                #     the current (un-trailed) level before candle processing
                #     updates it.  This matches the backtest, which checks
                #     SL on the old level and only trails in the else branch.
                tick_result = self._get_latest_tbt_price(tbt_df)
                if tick_result:
                    price, ts = tick_result
                    signal = self._check_tick(price, ts)

                    if signal:
                        self._execute_signal(signal, datafeed_handler, dry_run)

                    # Update last_price and unrealized_pnl for open positions
                    if self.open_positions:
                        open_insts = [p.instrument for p in self.open_positions.values()]
                        try:
                            pos_ltps = self._fetch_multiple_ltp(datafeed_handler, open_insts)
                        except Exception as e:
                            self.log_warning(f"Failed to fetch LTPs for position update: {e}")
                            pos_ltps = {}
                        for opt_type, pos in list(self.open_positions.items()):
                            ltp_val = pos_ltps.get(pos.instrument.instrument_token)
                            if ltp_val is None:
                                continue
                            try:
                                self._sync_position_entry_fill(pos)
                                pos.last_price = Decimal(str(ltp_val))
                                pos.last_price_updated_at = timezone.now()
                                if pos.position_type == "LONG":
                                    pos.unrealized_pnl = (pos.last_price - pos.entry_price) * pos.quantity
                                else:
                                    pos.unrealized_pnl = (pos.entry_price - pos.last_price) * pos.quantity
                                pos.save(update_fields=[
                                    "entry_price", "strategy_metadata",
                                    "last_price", "last_price_updated_at", "unrealized_pnl",
                                ])
                            except Exception as e:
                                self.log_warning(f"Failed to update position {opt_type}: {e}")

                # 5c: Check for completed hourly candles (EMA update,
                #     trailing SL, trigger set/flip)
                now_time = datetime.now().time()
                for i, (start, end) in enumerate(HOURLY_BOUNDARIES):
                    if i <= self.last_processed_candle_idx:
                        continue  # Already processed
                    if now_time < end:
                        break  # This boundary hasn't closed yet

                    # Boundary i has closed — resample and process
                    candle_df = self._resample_tbt_to_hourly(tbt_df)
                    if candle_df.empty:
                        continue

                    # Find the candle matching this boundary
                    target_time = VALID_HOURLY_TIMES[i]
                    matching = candle_df[
                        candle_df["timestamp"].dt.time == target_time
                    ]
                    if matching.empty:
                        continue

                    candle = matching.iloc[-1].to_dict()

                    # Update EMA incrementally
                    self._update_ema(candle["close"])

                    # Process signal logic
                    self._on_candle_close(candle)

                    # Track candle for day_high/day_low
                    self.hourly_candles.append(candle)
                    self.last_processed_candle_idx = i

                    # Persist signal state to CSV
                    self._write_candle_event(candle, i)

                    pos_label = {0: "FLAT", 1: "LONG", -1: "SHORT"}.get(self.position, "?")
                    trig_label = {0: "none", 1: "bull", -1: "bear"}.get(self.trigger, "?")
                    self.log_info(
                        f"Processed candle {target_time}: "
                        f"O={candle['open']:.2f} H={candle['high']:.2f} "
                        f"L={candle['low']:.2f} C={candle['close']:.2f} "
                        f"EMA={self.prev_ema:.2f} | "
                        f"pos={pos_label} trigger={trig_label} SL={self.sl_price}"
                    )

            except Exception as e:
                self.log_exception(f"Error in main loop: {e}")

            time.sleep(TBT_COPY_INTERVAL_SECS)

        self.is_running = False
        self.log_info("IndexLongShort completed.")

    # =========================================================================
    # SIGNAL → ORDER EXECUTION
    # =========================================================================

    def _execute_signal(self, signal: dict, datafeed_handler, dry_run: bool) -> None:
        """Translate a signal from _check_tick() into synthetic forward orders.
        Entry: ATM CE + ATM PE at CW expiry (with rollover).
        Exit: Opposing forward at current ATM, same expiry → box spread."""
        action = signal["action"]

        if action == "ENTER_LONG":
            self._execute_forward_entry(signal, "LONG", datafeed_handler, dry_run)

        elif action == "ENTER_SHORT":
            self._execute_forward_entry(signal, "SHORT", datafeed_handler, dry_run)

        elif action in ("EXIT_LONG", "EXIT_SHORT"):
            self._execute_forward_exit(signal, datafeed_handler, dry_run)

    def _execute_forward_entry(
        self, signal: dict, direction: str, datafeed_handler, dry_run: bool
    ) -> None:
        """
        Place a synthetic forward entry:
          LONG  forward = BUY ATM CE + SELL ATM PE
          SHORT forward = BUY ATM PE + SELL ATM CE
        """
        spot_price = signal["price"]

        # 1. Resolve expiry (CW with rollover on expiry day)
        expiry = self._resolve_expiry()
        if not expiry:
            self.log_error("Cannot resolve option expiry. Refusing to trade.")
            return

        # 2. Find ATM strike from spot price
        ce_strikes = self._get_available_strikes(expiry, "CE")
        atm_strike = self._find_atm_strike(spot_price, ce_strikes)
        if atm_strike is None:
            self.log_error(
                f"No ATM strike found for spot={spot_price:.2f} expiry={expiry}"
            )
            return

        # 3. Get CE and PE instruments at ATM strike
        ce_inst = self._get_option_instrument(expiry, atm_strike, "CE")
        pe_inst = self._get_option_instrument(expiry, atm_strike, "PE")
        if not ce_inst or not pe_inst:
            self.log_error(
                f"ATM instruments not found: strike={atm_strike} expiry={expiry} "
                f"CE={'found' if ce_inst else 'MISSING'} "
                f"PE={'found' if pe_inst else 'MISSING'}"
            )
            return

        lot_size = ce_inst.lot_size

        # 4. Fetch LTPs for both legs in one call
        ltps = self._fetch_multiple_ltp(datafeed_handler, [ce_inst, pe_inst])
        ce_ltp = ltps.get(ce_inst.instrument_token)
        pe_ltp = ltps.get(pe_inst.instrument_token)

        self.log_info(
            f"ENTER_{direction} (synthetic forward): spot={spot_price:.2f} "
            f"ATM={atm_strike} expiry={expiry} "
            f"CE_LTP={ce_ltp} PE_LTP={pe_ltp}"
        )

        # 5. Determine sides based on direction
        if direction == "LONG":
            ce_side, pe_side = "BUY", "SELL"
            ce_tag, pe_tag = "IDXLS_LONG_CE_BUY", "IDXLS_LONG_PE_SELL"
            ce_pos_type, pe_pos_type = "LONG", "SHORT"
        else:
            ce_side, pe_side = "SELL", "BUY"
            ce_tag, pe_tag = "IDXLS_SHORT_CE_SELL", "IDXLS_SHORT_PE_BUY"
            ce_pos_type, pe_pos_type = "SHORT", "LONG"

        # 6. Place CE leg
        ce_price = self._limit_price(ce_side, ce_ltp) if ce_ltp else None
        if ce_ltp is None:
            self.log_warning("CE LTP unavailable — placing MARKET order")
        success_ce, po_ce = self._place_order(
            ce_inst, ce_side, lot_size, ce_price,
            order_intent="ENTRY", tag=ce_tag, dry_run=dry_run,
        )

        # 7. Place PE leg
        pe_price = self._limit_price(pe_side, pe_ltp) if pe_ltp else None
        if pe_ltp is None:
            self.log_warning("PE LTP unavailable — placing MARKET order")
        success_pe, po_pe = self._place_order(
            pe_inst, pe_side, lot_size, pe_price,
            order_intent="ENTRY", tag=pe_tag, dry_run=dry_run,
        )

        # 8. Create DB positions (one per leg, following orb_short pattern)
        common_meta = {
            "forward_direction": direction,
            "atm_strike": float(atm_strike),
            "expiry": str(expiry),
            "spot_signal": spot_price,
            "sl_price": signal.get("sl_price"),
        }

        if success_ce:
            self.entry_ce = ce_inst
            self.open_positions["CE"] = StrategyPosition.objects.create(
                trade_id=f"IDXLS_{self.strategy_obj.id}_{uuid.uuid4().hex[:8]}",
                strategy=self.strategy_obj,
                instrument=ce_inst,
                position_type=ce_pos_type,
                status="OPEN",
                quantity=lot_size,
                entry_price=Decimal(str(ce_ltp)) if ce_ltp else (ce_price or Decimal("0")),
                entry_time=timezone.now(),
                entry_parent_order=po_ce,
                last_price=Decimal(str(ce_ltp)) if ce_ltp else Decimal("0"),
                last_price_updated_at=timezone.now(),
                strategy_metadata={
                    "option_type": "CE",
                    "ce_tradingsymbol": ce_inst.tradingsymbol,
                    "pe_tradingsymbol": pe_inst.tradingsymbol,
                    **common_meta,
                },
            )

        if success_pe:
            self.entry_pe = pe_inst
            self.open_positions["PE"] = StrategyPosition.objects.create(
                trade_id=f"IDXLS_{self.strategy_obj.id}_{uuid.uuid4().hex[:8]}",
                strategy=self.strategy_obj,
                instrument=pe_inst,
                position_type=pe_pos_type,
                status="OPEN",
                quantity=lot_size,
                entry_price=Decimal(str(pe_ltp)) if pe_ltp else (pe_price or Decimal("0")),
                entry_time=timezone.now(),
                entry_parent_order=po_pe,
                last_price=Decimal(str(pe_ltp)) if pe_ltp else Decimal("0"),
                last_price_updated_at=timezone.now(),
                strategy_metadata={
                    "option_type": "PE",
                    "ce_tradingsymbol": ce_inst.tradingsymbol,
                    "pe_tradingsymbol": pe_inst.tradingsymbol,
                    **common_meta,
                },
            )

        if success_ce and success_pe:
            self.log_info(
                f"  {direction} synthetic forward opened: ATM={atm_strike} "
                f"expiry={expiry} CE={ce_inst.tradingsymbol} "
                f"PE={pe_inst.tradingsymbol} SL={signal.get('sl_price')} "
                f"lot={lot_size}"
            )
            self._write_entry_event(float(atm_strike), expiry, spot_price)
        else:
            self.log_error("=" * 20)
            self.log_error(f"  CRITICAL ALERT: PARTIAL ENTRY DETECTED! ")
            self.log_error(f"  Strategy attempted {direction} entry but only one leg filled!")
            self.log_error(f"  CE={'FILLED' if success_ce else 'FAILED'} | PE={'FILLED' if success_pe else 'FAILED'}")
            self.log_error(f"  YOU NOW HAVE NAKED DIRECTIONAL EXPOSURE. INTERVENE IMMEDIATELY!")
            self.log_error("=" * 20)


    def _execute_forward_exit(
        self, signal: dict, datafeed_handler, dry_run: bool
    ) -> None:
        """
        Exit a synthetic forward by creating an opposing forward at current ATM,
        SAME expiry as entry — forming a box spread that locks P&L until expiry.

        Long  position exit → SHORT forward (SELL CE + BUY PE) at current ATM
        Short position exit → LONG  forward (BUY CE + SELL PE) at current ATM

        Example:
          Entry (long fwd, spot=23000): BUY CE 23000 CW + SELL PE 23000 CW
          SL hit (spot=22750):          SELL CE 22750 CW + BUY PE 22750 CW
          → Box spread locked, realized at expiry.
        """
        exit_spot = signal["exit_price"]

        # ── 1. Retrieve entry expiry from existing position metadata ─────
        if not self.open_positions:
            self.log_error("No open positions to exit. Resetting state.")
            self.entry_ce = None
            self.entry_pe = None
            self.open_positions.clear()
            self.position = 0
            self.trigger = 0
            self.sl_price = None
            return

        first_pos = next(iter(self.open_positions.values()))
        entry_meta = first_pos.strategy_metadata or {}
        entry_expiry_str = entry_meta.get("expiry")
        if not entry_expiry_str:
            self.log_error("No expiry in position metadata. Cannot create box spread.")
            return
        entry_expiry = date.fromisoformat(entry_expiry_str)
        entry_atm = entry_meta.get("atm_strike")

        self.log_info(
            f"EXIT via box spread: entry_ATM={entry_atm} | "
            f"exit_spot={exit_spot:.2f} | expiry={entry_expiry}"
        )

        # ── 2. Find ATM strike at current spot ──────────────────────────
        ce_strikes = self._get_available_strikes(entry_expiry, "CE")
        atm_strike = self._find_atm_strike(exit_spot, ce_strikes)
        if atm_strike is None:
            self.log_error(
                f"No ATM strike for exit: spot={exit_spot:.2f} expiry={entry_expiry}"
            )
            return

        # ── 3. Get exit CE and PE instruments ────────────────────────────
        ce_inst = self._get_option_instrument(entry_expiry, atm_strike, "CE")
        pe_inst = self._get_option_instrument(entry_expiry, atm_strike, "PE")
        if not ce_inst or not pe_inst:
            self.log_error(
                f"Exit instruments not found: strike={atm_strike} expiry={entry_expiry} "
                f"CE={'found' if ce_inst else 'MISSING'} "
                f"PE={'found' if pe_inst else 'MISSING'}"
            )
            return

        lot_size = ce_inst.lot_size

        # ── 4. Fetch LTPs (exit legs + entry legs for exit_price) ────────
        all_instruments = [ce_inst, pe_inst]
        if self.entry_ce:
            all_instruments.append(self.entry_ce)
        if self.entry_pe:
            all_instruments.append(self.entry_pe)
        ltps = self._fetch_multiple_ltp(datafeed_handler, all_instruments)

        ce_ltp = ltps.get(ce_inst.instrument_token)
        pe_ltp = ltps.get(pe_inst.instrument_token)

        # ── 5. Determine sides (opposite of entry direction) ─────────────
        if signal["direction"] == 1:  # was LONG → exit with SHORT forward
            ce_side, pe_side = "SELL", "BUY"
            ce_tag, pe_tag = "IDXLS_BOX_CE_SELL", "IDXLS_BOX_PE_BUY"
            exit_fwd_dir = "SHORT"
        else:  # was SHORT → exit with LONG forward
            ce_side, pe_side = "BUY", "SELL"
            ce_tag, pe_tag = "IDXLS_BOX_CE_BUY", "IDXLS_BOX_PE_SELL"
            exit_fwd_dir = "LONG"

        self.log_info(
            f"  Box {exit_fwd_dir} forward: ATM={atm_strike} "
            f"CE_{ce_side} PE_{pe_side} | CE_LTP={ce_ltp} PE_LTP={pe_ltp}"
        )

        # ── 6. Place CE exit leg ─────────────────────────────────────────
        ce_price = self._limit_price(ce_side, ce_ltp) if ce_ltp else None
        if ce_ltp is None:
            self.log_warning("Exit CE LTP unavailable — placing MARKET order")
        success_ce, po_ce = self._place_order(
            ce_inst, ce_side, lot_size, ce_price,
            order_intent="BOX_EXIT", tag=ce_tag, dry_run=dry_run,
        )

        # ── 7. Place PE exit leg ─────────────────────────────────────────
        pe_price = self._limit_price(pe_side, pe_ltp) if pe_ltp else None
        if pe_ltp is None:
            self.log_warning("Exit PE LTP unavailable — placing MARKET order")
        success_pe, po_pe = self._place_order(
            pe_inst, pe_side, lot_size, pe_price,
            order_intent="BOX_EXIT", tag=pe_tag, dry_run=dry_run,
        )

        # ── 8. Handle results ────────────────────────────────────────────
        if not success_ce and not success_pe:
            self.log_error(
                "  Both exit legs FAILED — position remains open, SL still active!"
            )
            return  # Don't reset; keep monitoring for next SL tick

        if success_ce and success_pe:
            # Full success — close both entry positions in DB
            for opt_type, pos in self.open_positions.items():
                entry_inst = self.entry_ce if opt_type == "CE" else self.entry_pe
                entry_ltp = ltps.get(entry_inst.instrument_token) if entry_inst else None

                pos.status = "CLOSED"
                pos.exit_price = Decimal(str(entry_ltp)) if entry_ltp else pos.entry_price
                pos.exit_time = timezone.now()
                if opt_type == "CE" and po_ce:
                    pos.exit_parent_order = po_ce
                elif opt_type == "PE" and po_pe:
                    pos.exit_parent_order = po_pe

                meta = pos.strategy_metadata or {}
                meta["exit_type"] = "BOX_SPREAD"
                meta["exit_atm_strike"] = float(atm_strike)
                meta["exit_spot"] = exit_spot
                meta["exit_fwd_direction"] = exit_fwd_dir
                meta["exit_ce_tradingsymbol"] = ce_inst.tradingsymbol
                meta["exit_pe_tradingsymbol"] = pe_inst.tradingsymbol
                pos.strategy_metadata = meta
                pos.save()

            self.log_info(
                f"  Box spread locked: entry_ATM={entry_atm} → exit_ATM={atm_strike} "
                f"| expiry={entry_expiry} | entry_spot={signal.get('entry_price'):.2f} "
                f"exit_spot={exit_spot:.2f}"
            )
        else:
            self.log_error("=" * 20)
            self.log_error(f"  CRITICAL ALERT: PARTIAL BOX EXIT DETECTED! ")
            self.log_error(f"  CE={'EXITED' if success_ce else 'FAILED'} | PE={'EXITED' if success_pe else 'FAILED'}")
            self.log_error(f"  STRATEGY STATE IS BEING WIPED. THE ORPHANED LEG IS UNMANAGED!")
            self.log_error(f"  YOU MUST MANUALLY CLOSE THE REMAINING LEG IMMEDIATELY!")
            self.log_error("=" * 20)

        # ── 9. Persist to CSV, then reset signal state ─────────────────
        if success_ce or success_pe:
            self._write_box_exit_event(exit_spot, float(atm_strike))
        self.entry_ce = None
        self.entry_pe = None
        self.open_positions.clear()
        self.position = 0
        self.trigger = 0
        self.sl_price = None

    def _execute_rollover(
        self, spot_price: float, datafeed_handler, dry_run: bool
    ) -> None:
        """
        Roll position from CW to NW on expiry day:
          1. Box exit current CW position (opposing forward, same expiry)
          2. Re-enter same direction at NW (new expiry, current ATM)
          Signal state (position, trigger, sl_price) is preserved.

        Example (LONG, spot moved 23500→24000):
          Box exit CW:  SELL CE 24000 CW + BUY PE 24000 CW
          Enter NW:     BUY  CE 24000 NW + SELL PE 24000 NW
        """
        if not self.open_positions or self.position == 0:
            return

        direction = "LONG" if self.position == 1 else "SHORT"

        # ── Get CW expiry from existing positions ────────────────────────
        first_pos = next(iter(self.open_positions.values()))
        entry_meta = first_pos.strategy_metadata or {}
        cw_expiry_str = entry_meta.get("expiry")
        if not cw_expiry_str:
            self.log_error("ROLLOVER: No expiry in position metadata.")
            return
        cw_expiry = date.fromisoformat(cw_expiry_str)

        # ── Get NW expiry ────────────────────────────────────────────────
        nw_expiry = self._get_next_week_expiry()
        if not nw_expiry:
            self.log_error("ROLLOVER: Cannot find NW expiry.")
            return

        self.log_info("=" * 60)
        self.log_info(
            f"ROLLOVER: {direction} | CW={cw_expiry} -> NW={nw_expiry} "
            f"| spot={spot_price:.2f}"
        )
        self.log_info("=" * 60)

        # ── Find ATM strike at current spot ──────────────────────────────
        ce_strikes_cw = self._get_available_strikes(cw_expiry, "CE")
        atm_strike = self._find_atm_strike(spot_price, ce_strikes_cw)
        if atm_strike is None:
            self.log_error(f"ROLLOVER: No ATM strike for spot={spot_price:.2f}")
            return

        # ── Get all 4 instruments ────────────────────────────────────────
        cw_ce = self._get_option_instrument(cw_expiry, atm_strike, "CE")
        cw_pe = self._get_option_instrument(cw_expiry, atm_strike, "PE")
        nw_ce = self._get_option_instrument(nw_expiry, atm_strike, "CE")
        nw_pe = self._get_option_instrument(nw_expiry, atm_strike, "PE")

        if not all([cw_ce, cw_pe, nw_ce, nw_pe]):
            self.log_error(
                f"ROLLOVER: Missing instruments at ATM={atm_strike} | "
                f"CW_CE={'OK' if cw_ce else 'MISSING'} "
                f"CW_PE={'OK' if cw_pe else 'MISSING'} "
                f"NW_CE={'OK' if nw_ce else 'MISSING'} "
                f"NW_PE={'OK' if nw_pe else 'MISSING'}"
            )
            return

        lot_size = cw_ce.lot_size

        # ── Fetch LTPs for all instruments ───────────────────────────────
        all_insts = [cw_ce, cw_pe, nw_ce, nw_pe]
        if self.entry_ce:
            all_insts.append(self.entry_ce)
        if self.entry_pe:
            all_insts.append(self.entry_pe)
        ltps = self._fetch_multiple_ltp(datafeed_handler, all_insts)

        # ── Determine sides ──────────────────────────────────────────────
        if direction == "LONG":
            # Box exit (SHORT fwd at CW): SELL CE, BUY PE
            box_ce_side, box_pe_side = "SELL", "BUY"
            box_ce_tag = "IDXLS_ROLL_BOX_CE_SELL"
            box_pe_tag = "IDXLS_ROLL_BOX_PE_BUY"
            # NW entry (LONG fwd): BUY CE, SELL PE
            nw_ce_side, nw_pe_side = "BUY", "SELL"
            nw_ce_tag, nw_pe_tag = "IDXLS_ROLL_NW_CE_BUY", "IDXLS_ROLL_NW_PE_SELL"
            nw_ce_pos_type, nw_pe_pos_type = "LONG", "SHORT"
        else:
            # Box exit (LONG fwd at CW): BUY CE, SELL PE
            box_ce_side, box_pe_side = "BUY", "SELL"
            box_ce_tag = "IDXLS_ROLL_BOX_CE_BUY"
            box_pe_tag = "IDXLS_ROLL_BOX_PE_SELL"
            # NW entry (SHORT fwd): SELL CE, BUY PE
            nw_ce_side, nw_pe_side = "SELL", "BUY"
            nw_ce_tag, nw_pe_tag = "IDXLS_ROLL_NW_CE_SELL", "IDXLS_ROLL_NW_PE_BUY"
            nw_ce_pos_type, nw_pe_pos_type = "SHORT", "LONG"

        # ── Step 1: Box exit at CW (opposing forward) ────────────────────
        self.log_info(
            f"  ROLL Step 1: Box exit at CW={cw_expiry} ATM={atm_strike}"
        )

        cw_ce_ltp = ltps.get(cw_ce.instrument_token)
        cw_pe_ltp = ltps.get(cw_pe.instrument_token)

        box_ce_price = self._limit_price(box_ce_side, cw_ce_ltp) if cw_ce_ltp else None
        if cw_ce_ltp is None:
            self.log_warning("Roll box CE LTP unavailable — placing MARKET order")
        box_ce_ok, box_ce_po = self._place_order(
            cw_ce, box_ce_side, lot_size, box_ce_price,
            order_intent="BOX_EXIT", tag=box_ce_tag, dry_run=dry_run,
        )

        box_pe_price = self._limit_price(box_pe_side, cw_pe_ltp) if cw_pe_ltp else None
        if cw_pe_ltp is None:
            self.log_warning("Roll box PE LTP unavailable — placing MARKET order")
        box_pe_ok, box_pe_po = self._place_order(
            cw_pe, box_pe_side, lot_size, box_pe_price,
            order_intent="BOX_EXIT", tag=box_pe_tag, dry_run=dry_run,
        )

        if not box_ce_ok or not box_pe_ok:
            self.log_error("=" * 20)
            self.log_error(f"  CRITICAL ALERT: ROLLOVER BOX EXIT FAILED OR PARTIAL! ")
            self.log_error(f"  Box Exit CE={'OK' if box_ce_ok else 'FAILED'} | PE={'OK' if box_pe_ok else 'FAILED'}")
            self.log_error(f"  ROLLOVER ABORTED AND WILL NOT RETRY. OPEN POSITIONS IN IMMINENT DANGER OF EXPIRY!")
            self.log_error(f"  MANUAL INTERVENTION URGENTLY REQUIRED!")
            self.log_error("=" * 20)
            self._rollover_done_today = True  # Don't retry
            return

        # ── Close entry positions in DB ──────────────────────────────────
        for opt_type, pos in self.open_positions.items():
            entry_inst = self.entry_ce if opt_type == "CE" else self.entry_pe
            entry_ltp = ltps.get(entry_inst.instrument_token) if entry_inst else None

            pos.status = "CLOSED"
            pos.exit_price = Decimal(str(entry_ltp)) if entry_ltp else pos.entry_price
            pos.exit_time = timezone.now()
            if opt_type == "CE" and box_ce_po:
                pos.exit_parent_order = box_ce_po
            elif opt_type == "PE" and box_pe_po:
                pos.exit_parent_order = box_pe_po

            meta = pos.strategy_metadata or {}
            meta["exit_type"] = "ROLLOVER_BOX"
            meta["exit_atm_strike"] = float(atm_strike)
            meta["exit_spot"] = spot_price
            meta["rolled_to_expiry"] = str(nw_expiry)
            pos.strategy_metadata = meta
            pos.save()

        self._write_box_exit_event(spot_price, float(atm_strike), exit_type="ROLLOVER_BOX")

        # ── Step 2: Enter same direction at NW ───────────────────────────
        self.log_info(
            f"  ROLL Step 2: Enter {direction} at NW={nw_expiry} ATM={atm_strike}"
        )

        nw_ce_ltp = ltps.get(nw_ce.instrument_token)
        nw_pe_ltp = ltps.get(nw_pe.instrument_token)

        nw_ce_price = self._limit_price(nw_ce_side, nw_ce_ltp) if nw_ce_ltp else None
        if nw_ce_ltp is None:
            self.log_warning("Roll NW CE LTP unavailable — placing MARKET order")
        nw_ce_ok, nw_ce_po = self._place_order(
            nw_ce, nw_ce_side, lot_size, nw_ce_price,
            order_intent="ENTRY", tag=nw_ce_tag, dry_run=dry_run,
        )

        nw_pe_price = self._limit_price(nw_pe_side, nw_pe_ltp) if nw_pe_ltp else None
        if nw_pe_ltp is None:
            self.log_warning("Roll NW PE LTP unavailable — placing MARKET order")
        nw_pe_ok, nw_pe_po = self._place_order(
            nw_pe, nw_pe_side, lot_size, nw_pe_price,
            order_intent="ENTRY", tag=nw_pe_tag, dry_run=dry_run,
        )

        if not nw_ce_ok or not nw_pe_ok:
            self.log_error("=" * 20)
            self.log_error(f"  CRITICAL ALERT: ROLLOVER NW ENTRY FAILED OR PARTIAL! ")
            self.log_error(f"  NW Entry CE={'OK' if nw_ce_ok else 'FAILED'} | PE={'OK' if nw_pe_ok else 'FAILED'}")
            self.log_error(f"  YOU HAVE A NAKED POSITION IN THE NEW WEEK! SQUASH THE ORPHAN LEG IMMEDIATELY!")
            self.log_error("=" * 20)

        # ── Update state for NW positions ────────────────────────────────
        self.open_positions.clear()
        self.entry_ce = None
        self.entry_pe = None

        common_meta = {
            "forward_direction": direction,
            "atm_strike": float(atm_strike),
            "expiry": str(nw_expiry),
            "spot_signal": self.entry_price,
            "sl_price": self.sl_price,
            "rolled_from_expiry": str(cw_expiry),
            "rollover_spot": spot_price,
        }

        if nw_ce_ok:
            self.entry_ce = nw_ce
            self.open_positions["CE"] = StrategyPosition.objects.create(
                trade_id=f"IDXLS_{self.strategy_obj.id}_{uuid.uuid4().hex[:8]}",
                strategy=self.strategy_obj,
                instrument=nw_ce,
                position_type=nw_ce_pos_type,
                status="OPEN",
                quantity=lot_size,
                entry_price=Decimal(str(nw_ce_ltp)) if nw_ce_ltp else (nw_ce_price or Decimal("0")),
                entry_time=timezone.now(),
                entry_parent_order=nw_ce_po,
                last_price=Decimal(str(nw_ce_ltp)) if nw_ce_ltp else Decimal("0"),
                last_price_updated_at=timezone.now(),
                strategy_metadata={
                    "option_type": "CE",
                    "ce_tradingsymbol": nw_ce.tradingsymbol,
                    "pe_tradingsymbol": nw_pe.tradingsymbol,
                    **common_meta,
                },
            )

        if nw_pe_ok:
            self.entry_pe = nw_pe
            self.open_positions["PE"] = StrategyPosition.objects.create(
                trade_id=f"IDXLS_{self.strategy_obj.id}_{uuid.uuid4().hex[:8]}",
                strategy=self.strategy_obj,
                instrument=nw_pe,
                position_type=nw_pe_pos_type,
                status="OPEN",
                quantity=lot_size,
                entry_price=Decimal(str(nw_pe_ltp)) if nw_pe_ltp else (nw_pe_price or Decimal("0")),
                entry_time=timezone.now(),
                entry_parent_order=nw_pe_po,
                last_price=Decimal(str(nw_pe_ltp)) if nw_pe_ltp else Decimal("0"),
                last_price_updated_at=timezone.now(),
                strategy_metadata={
                    "option_type": "PE",
                    "ce_tradingsymbol": nw_ce.tradingsymbol,
                    "pe_tradingsymbol": nw_pe.tradingsymbol,
                    **common_meta,
                },
            )

        self._rollover_done_today = True

        self._write_rollover_event(nw_expiry, float(atm_strike))

        self.log_info(
            f"  ROLLOVER COMPLETE: {direction} CW({cw_expiry}) -> NW({nw_expiry}) "
            f"| ATM={atm_strike} | SL={self.sl_price} (preserved)"
        )
