"""  GEX Regime Trader  """

import json
import math
import os
import shutil
import time
import uuid
from dataclasses import dataclass
from datetime import date, datetime, time as dt_time
from decimal import Decimal
from typing import Optional

import pandas as pd
import requests as http_requests

import scipy.optimize as spo
from scipy.special import ndtr
from scipy.stats import norm

from django.db.models import Min
from django.utils import timezone

from instruments.models import BrokerInstrument, Instrument
from orders.order_manager import order_manager
from strategy.models import StrategyPosition
from strategy.strategy_class.base_strategy import BaseStrategy
from utils.ttm_helper import ttm as compute_ttm


# =============================================================================
# CONSTANTS 
# =============================================================================

INDEX_NAME = "NIFTY 50"
TICKER     = "NIFTY"

# ── TBT (Tick-By-Tick) ──────────────────────────────────────────────────────
TBT_DATA_PATH = r"\\10.211.8.76\GFD MBM Data\Momentum\logs"
TBT_INDEX_NAME = "Nifty 50"
LOCAL_TBT_DIR = os.path.join(
    os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))),
    "dump", "tbt_local",
)

# ── TBT Guard Constants ──────────────────────────────────────────────────────
TBT_MARKET_OPEN = dt_time(9, 15, 0)
TBT_MARKET_CLOSE = dt_time(15, 30, 0)
TBT_MAX_STALENESS_SECS = 120          # Reject if latest tick > 2 min behind wall clock

# ── GEX / GTBR parameters ────────────────────────────────────────────────────
GEX_THRESHOLD    = 0.0       # GEX must be strictly < 0
GTBR_MULTIPLIER  = 0.2       # |move| must exceed GTBR × this
GTBR_EXIT_FRAC   = 0.5       # exit when |move| < GTBR × this
SL_FRAC          = 0.3       # exit if option LTP <= entry_prem × SL_FRAC

N_STRIKES        = 10        # ATM ± N strikes for GEX summation
RISK_FREE_RATE   = 0.00     # annualised risk-free rate for BS model

ROLLOVER_DAYS_BEFORE = 0     # switch to NW expiry on expiry day itself

# BROKER_TOKEN_REFRESH_INTERVAL_SECS = 900  # Centralized — handled by TokenRefreshManager

# ── Session State Persistence ────────────────────────────────────────────────
_BASE_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
GEX_DUMP_DIR = os.path.join(_BASE_DIR, 'dump', 'gex')

# ── Time gates ───────────────────────────────────────────────────────────────
ENTRY_START  = dt_time(9, 15, 2)
ENTRY_END    = dt_time(14, 44, 59)
HARD_EXIT_T  = dt_time(15, 14, 59)

# ── Hourly bar boundaries (BAR_INTERVAL clock) ──────────────────────────────
HOURLY_BOUNDARIES = [
    (dt_time(9, 15, 0),  dt_time(10, 15, 0)),
    (dt_time(10, 15, 0), dt_time(11, 15, 0)),
    (dt_time(11, 15, 0), dt_time(12, 15, 0)),
    (dt_time(12, 15, 0), dt_time(13, 15, 0)),
    (dt_time(13, 15, 0), dt_time(14, 15, 0)),
    (dt_time(14, 15, 0), dt_time(15, 15, 0)),
]

# ── Polling ───────────────────────────────────────────────────────────────────
MONITOR_INTERVAL_SEC = 5    # exit monitoring clock (every 5 seconds)

PRICE_OFFSET = Decimal("0.05")

# =============================================================================
# BLACK-SCHOLES FORMULAS
# =============================================================================

def _d1(S, K, T, sigma, r):
    """Black-Scholes d1. T is in calendar days."""
    if sigma <= 1e-8:
        sigma = 1e-8
    return (math.log(S / K) + (r + sigma ** 2 / 2) * T / 365) / (sigma * math.sqrt(T / 365))


def _d2(d1_val, T, sigma):
    """Black-Scholes d2."""
    if sigma <= 1e-8:
        sigma = 1e-8
    return d1_val - sigma * math.sqrt(T / 365)


def _bs_call(S, K, r, T, sigma):
    """Black-Scholes call price."""
    d1 = _d1(S, K, T, sigma, r)
    d2 = _d2(d1, T, sigma)
    return S * ndtr(d1) - K * math.exp(-r * T / 365) * ndtr(d2)


def _bs_put(S, K, r, T, sigma):
    """Black-Scholes put price."""
    d1 = _d1(S, K, T, sigma, r)
    d2 = _d2(d1, T, sigma)
    return K * math.exp(-r * T / 365) * ndtr(-d2) - S * ndtr(-d1)


def _solve_call_iv(S, K, r, T, market_price, a=-2, b=5, xtol=1e-5):
    """Implied vol for a call via Brent's method."""
    try:
        result = spo.brentq(
            lambda sigma: _bs_call(S, K, r, T, sigma) - market_price,
            a=a, b=b, xtol=xtol,
        )
        return max(result, xtol)
    except ValueError:
        return float("nan")


def _solve_put_iv(S, K, r, T, market_price, a=-2, b=5, xtol=1e-5):
    """Implied vol for a put via Brent's method."""
    try:
        result = spo.brentq(
            lambda sigma: _bs_put(S, K, r, T, sigma) - market_price,
            a=a, b=b, xtol=xtol,
        )
        return max(result, xtol)
    except ValueError:
        return float("nan")


def _bs_gamma(S, K, T, sigma, r):
    """Black-Scholes gamma (same for calls and puts)."""
    d1 = _d1(S, K, T, sigma, r)
    return norm.pdf(d1) / (S * sigma * math.sqrt(T / 365))


def _bs_theta(option_type, S, K, T, sigma, r):
    """Black-Scholes theta (per calendar day)."""
    d1 = _d1(S, K, T, sigma, r)
    d2 = _d2(d1, T, sigma)
    term1 = (S * norm.pdf(d1) * sigma * (-1)) / (2 * math.sqrt(T / 365))
    if option_type == "CE":
        term2 = -r * K * math.exp(-r * T / 365) * ndtr(d2)
    else:
        term2 = r * K * math.exp(-r * T / 365) * ndtr(-d2)
    return (term1 + term2) / 365


# =============================================================================
# ENRICHED CHAIN DATA STRUCTURE
# =============================================================================

@dataclass
class StrikeGreeks:
    """Greeks + market data for one strike at one instant."""
    strike: float
    option_type: str          # "CE" or "PE"
    ltp: float
    oi: int
    iv: float = 0.0
    gamma: float = 0.0
    theta: float = 0.0


# =============================================================================
# STRATEGY CLASS
# =============================================================================

class GexRegimeTrader(BaseStrategy):
    """
    Production GEX Regime Trader.

    """

    def __init__(self, strategy_obj, datafeed_obj, ws_manager=None):
        super().__init__(strategy_obj, datafeed_obj, ws_manager)
        self.is_running = False

        # ── Session State ──────────────────────────────────────────────────
        self.session_open: Optional[float] = None     # spot at session open

        # ── Position State (Phase 2) ──────────────────────────────────────
        self.position: Optional[dict] = None          # active position dict
        self.open_positions: dict[str, StrategyPosition] = {}
        self.entry_orders: dict[str, object] = {}
        self.exit_orders: dict[str, object] = {}
        # self._last_broker_token_refresh: float = 0.0  # Centralized — handled by TokenRefreshManager
        self._last_good_max_ts: Optional[datetime] = None        # For timestamp regression detection

        # ── Bar Tracking State ────────────────────────────────────────
        self._last_bar_idx: int = -1             # last processed hourly boundary
        self._last_gex: Optional[float] = None   # cached from last bar close
        self._last_gtbr: Optional[float] = None  # cached from last bar close
        self._last_bar_spot: Optional[float] = None   # spot at last bar close
        self._last_ce_greeks: list = []           # cached CE greeks for GTBR recomputation
        self._last_pe_greeks: list = []           # cached PE greeks for GTBR recomputation

        self.log_info(
            f"Initializing {self.strategy_obj.strategy_code} — "
            f"{self.strategy_obj.strategy_name}"
        )

    # =========================================================================
    # INSTRUMENT LOOKUPS
    # =========================================================================

    def _copy_tbt_file(self, file_date: Optional[date] = None) -> Optional[str]:
        """Copy today's TBT file from network share to local directory.
        Returns the local file path, or None on failure."""
        target_date = file_date or date.today()
        filename = target_date.strftime("%Y%m%d") + ".txt"
        source = os.path.join(TBT_DATA_PATH, filename)

        os.makedirs(LOCAL_TBT_DIR, exist_ok=True)
        dest = os.path.join(LOCAL_TBT_DIR, filename)

        try:
            shutil.copy2(source, dest)
            return dest
        except FileNotFoundError:
            self.log_error(f"TBT file not found: {source}")
            return None
        except Exception as e:
            self.log_error(f"Failed to copy TBT file: {e}")
            return None

    def _parse_tbt_data(self, file_path: str) -> Optional[pd.DataFrame]:
        """Parse TBT file and filter for Nifty 50 ticks."""
        try:
            df = pd.read_csv(
                file_path,
                sep=r"\s*\|\s*",
                header=None,
                names=["timestamp", "index_name", "price", "seq_id"],
                engine="python",
            )
        except Exception as e:
            self.log_error(f"Failed to parse TBT file: {e}")
            return None

        df = df[df["index_name"] == TBT_INDEX_NAME].copy()
        if df.empty:
            self.log_error(f"No '{TBT_INDEX_NAME}' ticks found in TBT file.")
            return None

        df["timestamp"] = pd.to_datetime(df["timestamp"], format = "mixed")
        df["price"] = pd.to_numeric(df["price"], errors="coerce")
        df = df.dropna(subset=["price"])
        df = df.sort_values("timestamp").reset_index(drop=True)

        # ── Market hours filter: keep only 9:15–15:30 ────────────────────
        pre_filter_count = len(df)
        df = df[
            (df["timestamp"].dt.time >= TBT_MARKET_OPEN)
            & (df["timestamp"].dt.time <= TBT_MARKET_CLOSE)
        ].reset_index(drop=True)
        rejected = pre_filter_count - len(df)
        if rejected > 0:
            self.log_info(f"Market hours filter: rejected {rejected} ticks outside 09:15–15:30")

        if df.empty:
            self.log_error("No ticks remain after market hours filter.")
            return None

        self.log_info(f"Parsed {len(df)} Nifty 50 ticks from TBT file")
        return df[["timestamp", "price"]]

    def _validate_tbt_data(self, tbt_df: pd.DataFrame) -> bool:
        """Validate parsed TBT data for staleness and timestamp regression.
        Returns True if data is safe to use, False if it should be rejected."""

        max_ts: datetime = tbt_df["timestamp"].max().to_pydatetime()
        now = datetime.now()

        # ── Staleness: reject if latest tick is too far behind wall clock ─
        staleness_secs = (now - max_ts).total_seconds()
        if staleness_secs > TBT_MAX_STALENESS_SECS:
            self.log_error(
                f"TBT REJECTED (stale): latest tick {max_ts.strftime('%H:%M:%S')} "
                f"is {staleness_secs:.0f}s behind wall clock "
                f"(threshold: {TBT_MAX_STALENESS_SECS}s)"
            )
            return False

        # ── Timestamp regression: reject if max timestamp went backwards ──
        if self._last_good_max_ts is not None and max_ts < self._last_good_max_ts:
            regression_secs = (self._last_good_max_ts - max_ts).total_seconds()
            self.log_error(
                f"TBT REJECTED (regression): max tick {max_ts.strftime('%H:%M:%S')} "
                f"< previous good {self._last_good_max_ts.strftime('%H:%M:%S')} "
                f"(regressed {regression_secs:.0f}s)"
            )
            return False

        # ── All checks passed — update tracking state ────────────────────
        self._last_good_max_ts = max_ts
        return True

    def _fetch_spot_from_tbt(self) -> Optional[float]:
        """Fetch latest NIFTY 50 spot price from TBT file."""
        local_path = self._copy_tbt_file()
        if local_path is None:
            return None
        df = self._parse_tbt_data(local_path)
        if df is None or df.empty:
            return None
        if not self._validate_tbt_data(df):
            return None
        return float(df["price"].iloc[-1])

    def _get_nearest_option_expiry(self) -> Optional[date]:
        """Get the nearest weekly option expiry for NIFTY."""
        today = date.today()
        result = Instrument.objects.filter(
            name=TICKER,
            exchange="NFO",
            instrument_type__in=["CE", "PE"],
            is_active=True,
            expiry__gte=today,
        ).aggregate(min_expiry=Min("expiry"))
        return result.get("min_expiry")

    def _get_next_week_expiry(self) -> Optional[date]:
        """Get the second-nearest option expiry."""
        today = date.today()
        expiries = (
            Instrument.objects.filter(
                name=TICKER,
                exchange="NFO",
                instrument_type__in=["CE", "PE"],
                is_active=True,
                expiry__gte=today,
            )
            .values_list("expiry", flat=True)
            .distinct()
            .order_by("expiry")[:2]
        )
        expiry_list = list(expiries)
        if len(expiry_list) >= 2:
            return expiry_list[1]
        return expiry_list[0] if expiry_list else None

    def _resolve_expiry(self) -> Optional[date]:
        """Pick CW or NW expiry based on rollover rule (same as backtest)."""
        cw = self._get_nearest_option_expiry()
        if cw is None:
            self.log_error("No option expiry found.")
            return None

        days_to_cw = (cw - date.today()).days
        if days_to_cw <= ROLLOVER_DAYS_BEFORE:
            nw = self._get_next_week_expiry()
            if nw:
                self.log_info(f"Rollover: CW={cw} ({days_to_cw}d), using NW={nw}")
                return nw

        self.log_info(f"Using CW expiry: {cw} ({days_to_cw}d away)")
        return cw

    def _get_all_option_instruments(
        self, expiry: date, option_type: str
    ) -> list[Instrument]:
        """Get all active option instruments for a given expiry and type."""
        return list(
            Instrument.objects.filter(
                name=TICKER,
                exchange="NFO",
                instrument_type=option_type,
                expiry=expiry,
                is_active=True,
            ).order_by("strike")
        )

    def _get_option_instrument(
        self, expiry: date, strike: Decimal, option_type: str
    ) -> Optional[Instrument]:
        """Get a single option instrument."""
        return Instrument.objects.filter(
            name=TICKER,
            exchange="NFO",
            instrument_type=option_type,
            expiry=expiry,
            strike=strike,
            is_active=True,
        ).first()

    # =========================================================================
    # DATA FEED
    # =========================================================================

    def _fetch_ltp(
        self, datafeed_handler, instrument: Instrument
    ) -> Optional[float]:
        """Fetch LTP for a single instrument. On 400/401, refreshes token and retries indefinitely."""
        attempt = 0
        while self.is_running:
            attempt += 1
            try:
                response = datafeed_handler.get_multiple_ltp([instrument])
                if response and "data" in response:
                    for item in response["data"].get("ltp_list", []):
                        if item.get("instrument_token") == instrument.instrument_token:
                            return item.get("ltp")
                return None
            except Exception as e:
                status = getattr(getattr(e, "response", None), "status_code", None)
                is_auth_error = status in (400, 401) or "Unauthorized" in str(e)

                if is_auth_error:
                    self.log_warning(
                        f"LTP fetch failed for {instrument} (attempt {attempt}: {e}) "
                        f"— refreshing datafeed token..."
                    )
                    try:
                        from datafeed.rest.handler import DataFeedHandler
                        DataFeedHandler(self.datafeed_obj).update_token()
                        self.datafeed_obj.refresh_from_db()
                        datafeed_handler = DataFeedHandler(self.datafeed_obj)
                    except Exception as refresh_err:
                        self.log_error(f"Token refresh failed: {refresh_err}")
                    time.sleep(2)
                    continue
                self.log_error(f"Error fetching LTP for {instrument}: {e}")
                return None
        return None

    def _fetch_multiple_ltp(
        self, datafeed_handler, instruments: list[Instrument]
    ) -> dict[int, float]:
        """Fetch LTP for multiple instruments. Returns {token: ltp}. Retries on 400/401."""
        if not instruments:
            return {}
        attempt = 0
        while self.is_running:
            attempt += 1
            try:
                response = datafeed_handler.get_multiple_ltp(instruments)
                result: dict[int, float] = {}
                if response and "data" in response:
                    for item in response["data"].get("ltp_list", []):
                        token = item.get("instrument_token")
                        ltp = item.get("ltp")
                        if token and ltp:
                            result[token] = ltp
                return result
            except Exception as e:
                status = getattr(getattr(e, "response", None), "status_code", None)
                is_auth_error = status in (400, 401) or "Unauthorized" in str(e)

                if is_auth_error:
                    self.log_warning(
                        f"Multiple LTP fetch failed (attempt {attempt}: {e}) "
                        f"— refreshing datafeed token..."
                    )
                    try:
                        from datafeed.rest.handler import DataFeedHandler
                        DataFeedHandler(self.datafeed_obj).update_token()
                        self.datafeed_obj.refresh_from_db()
                        datafeed_handler = DataFeedHandler(self.datafeed_obj)
                    except Exception as refresh_err:
                        self.log_error(f"Token refresh failed: {refresh_err}")
                    time.sleep(2)
                    continue
                self.log_error(f"Error fetching multiple LTP: {e}")
                return {}
        return {}

    def _xts_request(self, instrument_payloads: list[dict], message_code: int) -> dict:
        """Make a direct XTS quotes API call. Retries indefinitely on Invalid Token."""
        account = self.datafeed_obj
        if account.extra_data and account.extra_data.get("hostlookup"):
            base_url = account.extra_data.get("connectionString", "")
        else:
            base_url = account.base_url

        url = f"{base_url}/apimarketdata/instruments/quotes"
        payload = {"instruments": instrument_payloads, "xtsMessageCode": message_code, "publishFormat": "JSON"}

        attempt = 0
        while self.is_running:
            attempt += 1
            headers = {"Content-Type": "application/json", "Authorization": account.access_token}
            resp = http_requests.post(url, headers=headers, data=json.dumps(payload))
            if resp.status_code == 400 and "e-session-0007" in resp.text:
                self.log_warning(f"Invalid Token (attempt {attempt}) — refreshing token...")
                try:
                    from datafeed.rest.handler import DataFeedHandler
                    DataFeedHandler(account).update_token()
                    account.refresh_from_db()
                except Exception as e:
                    self.log_error(f"Token refresh failed: {e}")
                time.sleep(2)
                continue
            resp.raise_for_status()
            try:
                return resp.json()
            except (json.JSONDecodeError, ValueError):
                self.log_warning(f"Non-JSON response (attempt {attempt}): {resp.text[:200]}")
                time.sleep(2)
                continue
        return {}

    def _fetch_chain_quotes(
        self, datafeed_handler, instruments: list[Instrument]
    ) -> dict[int, dict]:
        """
        Fetch LTP + OI for an option chain.
        Two XTS calls: 1501 (Touchline) for LTP, 1510 (OI) for OpenInterest,
        then merge results.
        Returns {instrument_token: {instrument_token, ltp, oi}}.
        """
        XTS_TOUCHLINE = 1501
        XTS_OI = 1510

        result: dict[int, dict] = {}
        if not instruments:
            return result

        # Build XTS instrument payloads
        broker_name = self.datafeed_obj.provider.provider_name.upper()
        token_list = [inst.instrument_token for inst in instruments]
        bi_map = BrokerInstrument.bulk_get_by_instruments_and_broker(token_list, broker_name)
        if not bi_map:
            self.log_error("No broker instrument mappings found for chain.")
            return result

        payloads = []
        xts_id_to_inst: dict[int, Instrument] = {}
        for inst in instruments:
            bi = bi_map.get(inst.instrument_token)
            if bi:
                extra = bi.extra_data or {}
                payloads.append({
                    "exchangeSegment": extra.get("exchange_segment_code", 2),
                    "exchangeInstrumentID": int(bi.broker_token),
                })
                xts_id_to_inst[int(bi.broker_token)] = inst

        if not payloads:
            return result

        # ── Call 1: Touchline (1501) for LTP ─────────────────────────────
        try:
            data = self._xts_request(payloads, XTS_TOUCHLINE)
            if data.get("type") == "success" and "result" in data:
                for qs in data["result"].get("listQuotes", []):
                    qd = json.loads(qs)
                    xts_id = int(qd.get("ExchangeInstrumentID", 0))
                    inst = xts_id_to_inst.get(xts_id)
                    if inst:
                        result[inst.instrument_token] = {
                            "instrument_token": inst.instrument_token,
                            "ltp": float(qd.get("LastTradedPrice", 0)),
                            "oi": 0,
                        }
        except Exception as e:
            resp_body = getattr(getattr(e, "response", None), "text", "")
            self.log_error(f"Error fetching LTP (1501): {e}")
            if resp_body:
                self.log_error(f"API response: {resp_body}")
            return result

        # ── Call 2: OI (1510) for OpenInterest ───────────────────────────
        try:
            data = self._xts_request(payloads, XTS_OI)
            if data.get("type") == "success" and "result" in data:
                for qs in data["result"].get("listQuotes", []):
                    qd = json.loads(qs)
                    xts_id = int(qd.get("ExchangeInstrumentID", 0))
                    inst = xts_id_to_inst.get(xts_id)
                    if inst and inst.instrument_token in result:
                        result[inst.instrument_token]["oi"] = int(qd.get("OpenInterest", 0))
            self.log_info(
                f"Chain quotes fetched: {len(result)} instruments | "
                f"sample OI: {[v['oi'] for v in list(result.values())[:3]]}"
            )
        except Exception as e:
            resp_body = getattr(getattr(e, "response", None), "text", "")
            self.log_error(f"Error fetching OI (1510): {e}")
            if resp_body:
                self.log_error(f"API response: {resp_body}")

        return result

    # =========================================================================
    # GREEK ENRICHMENT 
    # =========================================================================

    def _enrich_chain_with_greeks(
        self,
        instruments: list[Instrument],
        quotes: dict[int, dict],
        spot: float,
        expiry: date,
    ) -> list[StrikeGreeks]:
        """
        Args:
            instruments: list of CE or PE Instrument objects
            quotes:      {instrument_token: {ltp, oi, ...}} from touchline
            spot:        current NIFTY 50 spot price
            expiry:      option expiry date

        Returns:
            list[StrikeGreeks] with IV, gamma, theta populated
        """
        now = datetime.now()
        ttm_days = max(compute_ttm(now, expiry), 1e-6)   # fractional trading days, floor to avoid /0
        enriched: list[StrikeGreeks] = []
        skipped_no_quote = 0
        skipped_invalid = 0
        skipped_iv = 0

        for inst in instruments:
            quote = quotes.get(inst.instrument_token)
            if not quote:
                skipped_no_quote += 1
                continue

            ltp = quote.get("ltp", 0)
            oi  = quote.get("oi", 0)

            if ltp <= 0 or oi <= 0:
                skipped_invalid += 1
                continue

            strike = float(inst.strike)
            option_type = inst.instrument_type  # "CE" or "PE"

            # ── Step 1: Solve for Implied Volatility ──────────────────────
            try:
                if option_type == "CE":
                    iv = _solve_call_iv(spot, strike, RISK_FREE_RATE, ttm_days, ltp)
                else:
                    iv = _solve_put_iv(spot, strike, RISK_FREE_RATE, ttm_days, ltp)
            except Exception:
                continue

            if iv is None or math.isnan(iv) or iv <= 0:
                skipped_iv += 1
                continue

            # ── Step 2: Compute Gamma ─────────────────────────────────────
            try:
                gamma_val = _bs_gamma(spot, strike, ttm_days, iv, RISK_FREE_RATE)
            except Exception:
                gamma_val = 0.0

            # ── Step 3: Compute Theta ─────────────────────────────────────
            try:
                theta_val = _bs_theta(option_type, spot, strike, ttm_days, iv, RISK_FREE_RATE)
            except Exception:
                theta_val = 0.0

            enriched.append(StrikeGreeks(
                strike=strike,
                option_type=option_type,
                ltp=ltp,
                oi=oi,
                iv=iv,
                gamma=gamma_val,
                theta=theta_val,
            ))

        opt_label = instruments[0].instrument_type if instruments else "?"
        self.log_debug(
            f"Greek enrichment ({opt_label}): {len(enriched)}/{len(instruments)} enriched "
            f"(no_quote={skipped_no_quote}, invalid_ltp_oi={skipped_invalid}, iv_fail={skipped_iv})"
        )
        return enriched

    # =========================================================================
    # GEX / GTBR COMPUTATION
    # =========================================================================

    def _compute_gex(
        self,
        ce_greeks: list[StrikeGreeks],
        pe_greeks: list[StrikeGreeks],
        spot: float,
        n_strikes: int = N_STRIKES,
    ) -> float:
        """
        GEX = Σ_k [ CE_OI(k) × γ_CE(k) − PE_OI(k) × γ_PE(k) ] × spot

        Limited to ATM ± n_strikes (2*n_strikes + 1 total), resolved from
        actual chain strikes.
        """
        gex = 0.0

        for greeks_list, sign in [(ce_greeks, +1), (pe_greeks, -1)]:
            if not greeks_list:
                continue

            # Filter to valid entries (oi > 0, gamma is finite)
            valid = [
                g for g in greeks_list
                if g.oi > 0 and g.gamma != 0.0 and math.isfinite(g.gamma)
            ]
            if not valid:
                continue

            # Rank by distance from spot, keep nearest N on each side + ATM
            sorted_by_dist = sorted(valid, key=lambda g: abs(g.strike - spot))
            keep = sorted_by_dist[:2 * n_strikes + 1]

            for g in keep:
                gex += sign * g.oi * g.gamma * spot

            label = "CE" if sign == +1 else "PE"
            self.log_debug(f"GEX {label}: {len(valid)} valid strikes, kept {len(keep)} nearest ATM")

        return gex

    def _compute_gtbr(
        self,
        ce_greeks: list[StrikeGreeks],
        pe_greeks: list[StrikeGreeks],
        spot: float,
    ) -> Optional[float]:
        """
        GTBR = √( 2 × |θ_ATM| / γ_ATM )

        ATM = nearest available strike to spot. Uses whichever leg (CE or PE)
        has the higher gamma at ATM.
        Returns None when no valid ATM gamma is available.
        """
        best_gamma: Optional[float] = None
        best_theta: Optional[float] = None

        for greeks_list in [ce_greeks, pe_greeks]:
            if not greeks_list:
                continue

            # Find ATM strike (nearest to spot)
            atm = min(greeks_list, key=lambda g: abs(g.strike - spot))

            if atm.gamma > 0 and math.isfinite(atm.gamma) and math.isfinite(atm.theta):
                if best_gamma is None or atm.gamma > best_gamma:
                    best_gamma = atm.gamma
                    best_theta = atm.theta
                    self.log_debug(
                        f"GTBR ATM candidate: {atm.option_type} strike={atm.strike} "
                        f"gamma={atm.gamma:.6f} theta={atm.theta:.6f}"
                    )

        if best_gamma is None or best_gamma <= 0:
            self.log_warning("GTBR: no valid ATM gamma found, returning None (entry/exit skipped)")
            return None

        gtbr = math.sqrt(2.0 * abs(best_theta) / best_gamma)
        self.log_debug(f"GTBR={gtbr:.2f} (gamma={best_gamma:.6f}, theta={best_theta:.6f})")
        return gtbr

    # =========================================================================
    # TIME UTILITIES
    # =========================================================================

    def _get_today_datetime(self, time_obj) -> datetime:
        """Convert a time object to today's datetime in local timezone."""
        today = timezone.now().date()
        naive_dt = datetime.combine(today, time_obj)
        return timezone.make_aware(naive_dt)

    def _wait_until(self, target_time: datetime) -> bool:
        """Wait until target_time. Returns False if stop() was called."""
        while self.is_running:
            now = timezone.now()
            if now >= target_time:
                return True
            remaining = (target_time - now).total_seconds()
            if remaining > 60:
                self.log_info(
                    f"Waiting {int(remaining // 60)}m {int(remaining % 60)}s "
                    f"until {target_time.strftime('%H:%M:%S')}"
                )
                time.sleep(30)
            else:
                time.sleep(1)
        return False

    # =========================================================================
    # ORDER MANAGEMENT
    # =========================================================================

    def _limit_price(self, side: str, ltp: float) -> Decimal:
        """Passive limit: SELL → LTP + offset, BUY → LTP − offset."""
        base = Decimal(str(ltp))
        return base + PRICE_OFFSET if side == "SELL" else base - PRICE_OFFSET

    def _place_order(
        self,
        instrument: Instrument,
        side: str,
        quantity: int,
        price: Optional[Decimal],
        order_intent: str,
        tag: str = "",
        dry_run: bool = False,
    ) -> tuple[bool, object]:
        """Place an order via OrderManager. Supports dry-run mode."""
        order_type = "LIMIT" if price is not None else "MARKET"
        price_str = str(price) if price is not None else "MKT"

        if dry_run:
            self.log_info(
                f"  [DRY-RUN][{tag}] {order_intent} {side} {quantity}x"
                f" {instrument.tradingsymbol}"
                f" | {order_type} @ {price_str}"
                f" | NRML"
                f" | expiry={instrument.expiry}"
            )
            return True, None

        success, msg, parent_order, _ = order_manager.create_and_execute_order(
            strategy=self.strategy_obj,
            instrument=instrument,
            side=side,
            quantity=quantity,
            order_type=order_type,
            product_type="NRML",
            price=price,
            order_intent=order_intent,
            metadata={
                "strategy_code": self.strategy_obj.strategy_code,
                "instrument_type": instrument.instrument_type,
                "stock_name": instrument.name,
                "tag": tag,
            },
        )
        if success:
            self.log_info(
                f"  [{tag}] {side} {quantity}x {instrument.tradingsymbol}"
                f" @ {price_str}"
            )
        else:
            self.log_error(f"  [{tag}] FAILED {side} {instrument.tradingsymbol}: {msg}")
        return success, parent_order

    def _execute_entry(
        self, opt_type: str, instrument: Instrument,
        entry_ltp: float, gtbr: float,
        datafeed_handler, dry_run: bool,
    ) -> None:
        """Execute a new LONG trade (buy option)."""
        lot_size = instrument.lot_size
        price = self._limit_price("BUY", entry_ltp)
        tag = f"GEX_{opt_type}_ENTRY"

        self.log_info(
            f"ENTRY BUY {opt_type}: strike={instrument.strike} "
            f"ltp={entry_ltp:.2f} limit={price}"
        )

        success, parent_order = self._place_order(
            instrument, "BUY", lot_size, price,
            order_intent="ENTRY", tag=tag, dry_run=dry_run,
        )

        if not success:
            return

        sl_price = entry_ltp * SL_FRAC
        now = timezone.now()

        pos = StrategyPosition.objects.create(
            trade_id=f"GEX_{self.strategy_obj.id}_{uuid.uuid4().hex[:8]}",
            strategy=self.strategy_obj,
            instrument=instrument,
            position_type="LONG",
            status="OPEN",
            quantity=lot_size,
            entry_price=Decimal(str(entry_ltp)),
            entry_time=now,
            entry_parent_order=parent_order,
            last_price=Decimal(str(entry_ltp)),
            last_price_updated_at=now,
            strategy_metadata={
                "option_type": opt_type,
                "strike": float(instrument.strike),
                "expiry": str(instrument.expiry),
                "entry_prem": entry_ltp,
                "gtbr": gtbr,
                "sl_price": sl_price,
                "session_open": self.session_open,
            },
        )

        self.open_positions[opt_type] = pos
        self.entry_orders[opt_type] = parent_order
        self.position = {
            "strike": float(instrument.strike),
            "kind": opt_type,
            "entry_prem": entry_ltp,
            "gtbr": gtbr,
            "sl_price": sl_price,
            "instrument": instrument,
        }
        self.log_info(
            f"  {opt_type} position opened: entry={entry_ltp:.2f} "
            f"SL={sl_price:.2f} ({SL_FRAC*100:.0f}% of entry) "
            f"GTBR={gtbr:.2f} lot_size={lot_size}"
        )

    def _execute_exit(
        self, opt_type: str, exit_ltp: Optional[float], reason: str,
        datafeed_handler, dry_run: bool,
    ) -> None:
        """Sell one option leg and close in DB. exit_ltp=None → MARKET order."""
        pos = self.open_positions.get(opt_type)
        if not pos:
            self.log_warning(f"EXIT called for {opt_type} but no open position found")
            return

        instrument = pos.instrument
        lot_size = pos.quantity
        price = self._limit_price("SELL", exit_ltp) if exit_ltp is not None else None
        tag = f"GEX_{opt_type}_EXIT_{reason}"

        if exit_ltp is not None:
            self.log_info(
                f"EXIT SELL {opt_type} ({reason}): ltp={exit_ltp:.2f} "
                f"entry={pos.entry_price:.2f} limit={price}"
            )
        else:
            self.log_warning(
                f"EXIT SELL {opt_type} ({reason}): LTP unavailable — "
                f"placing MARKET order for {instrument.tradingsymbol}"
            )

        success, parent_order = self._place_order(
            instrument, "SELL", lot_size, price,
            order_intent="EXIT", tag=tag, dry_run=dry_run,
        )

        if success:
            pos.status = "CLOSED"
            pos.exit_time = timezone.now()
            pos.exit_parent_order = parent_order
            pos.unrealized_pnl = Decimal("0.00")

            if exit_ltp is not None:
                pnl = (exit_ltp - float(pos.entry_price)) * lot_size
                pos.exit_price = Decimal(str(exit_ltp))
                pos.realized_pnl = Decimal(str(pnl))

            meta = pos.strategy_metadata or {}
            meta["exit_reason"] = reason
            meta["exit_prem"] = exit_ltp
            pos.strategy_metadata = meta
            pos.save()

            del self.open_positions[opt_type]
            self.exit_orders[opt_type] = parent_order
            self.position = None
            if exit_ltp is not None:
                pnl = (exit_ltp - float(pos.entry_price)) * lot_size
                self.log_info(f"  {opt_type} closed. PNL={pnl:+.2f}")
            else:
                self.log_info(f"  {opt_type} closed via MARKET order (PNL unknown until fill)")

    # =========================================================================
    # STATE RECOVERY
    # =========================================================================

    def _bootstrap_from_db(self) -> bool:
        """
        Restore state from DB if strategy was restarted mid-position.
        Returns True if open positions found, False for a fresh run.
        """
        db_positions = StrategyPosition.objects.filter(
            strategy=self.strategy_obj,
            status="OPEN",
        ).select_related("instrument")

        if not db_positions.exists():
            self.log_info("No existing open positions. Fresh run.")
            return False

        for pos in db_positions:
            meta = pos.strategy_metadata or {}
            opt_type = meta.get("option_type")  # "CE" or "PE"
            if opt_type in ("CE", "PE"):
                self.open_positions[opt_type] = pos
                self.log_warning(
                    f"RECOVERY: Restored {opt_type} position "
                    f"@ {pos.entry_price} | {pos.instrument.tradingsymbol}"
                )
            else:
                self.log_warning(f"RECOVERY: Skipping position {pos.trade_id} with unknown option_type={opt_type}")

        if self.open_positions:
            # Reconstruct position dict for exit monitoring
            first_pos = list(self.open_positions.values())[0]
            meta = first_pos.strategy_metadata or {}
            self.position = {
                "strike": meta.get("strike"),
                "kind": meta.get("option_type"),
                "entry_prem": float(first_pos.entry_price),
                "gtbr": meta.get("gtbr", 0.0),
                "sl_price": meta.get("sl_price", float(first_pos.entry_price) * SL_FRAC),
                "instrument": first_pos.instrument,
            }

            # Restore cached GTBR so exit monitoring works immediately
            self._last_gtbr = meta.get("gtbr", 0.0)

            # Restore session_open from entry-time metadata to avoid
            # corrupting move calculations if strategy restarts mid-day
            saved_session_open = meta.get("session_open")
            if saved_session_open is not None:
                self.session_open = float(saved_session_open)
                self.log_info(f"RECOVERY: Restored session_open={self.session_open:.2f}")

        return bool(self.open_positions)

    # =========================================================================
    # BASE STRATEGY INTERFACE
    # =========================================================================

    def verify(self) -> bool:
        """Verify strategy prerequisites before running."""
        if not self.datafeed_obj:
            self.log_error("No datafeed object provided.")
            return False

        if self.datafeed_obj.is_token_expired:
            self.log_warning("Datafeed token expired — attempting refresh...")
            from datafeed.rest.handler import DataFeedHandler
            handler = DataFeedHandler(self.datafeed_obj)
            if not handler.update_token():
                self.log_error("Failed to refresh datafeed token.")
                return False

        self.log_info("Verification passed.")
        return True

    def stop(self):
        """Stop the strategy gracefully."""
        self.log_info("Stopping GexRegimeTrader...")
        self.is_running = False

    # def _refresh_broker_tokens(self) -> None:  # Centralized — handled by TokenRefreshManager
    #     """Periodically refresh broker account tokens to prevent order failures."""
    #     from accounts.models import StrategyAccountMapping
    #     from accounts.brokers.handler import BrokerAccountHandler
    #
    #     mappings = StrategyAccountMapping.objects.filter(
    #         strategy=self.strategy_obj,
    #         is_active=True,
    #     ).select_related('broker_account', 'broker_account__broker')
    #
    #     for mapping in mappings:
    #         ba = mapping.broker_account
    #         ba.refresh_from_db()
    #         if ba.is_token_expired:
    #             self.log_warning(f"Broker token expired for {ba.account_name} — refreshing...")
    #             try:
    #                 BrokerAccountHandler(ba).update_token()
    #                 ba.refresh_from_db()
    #                 self.log_info(f"Broker token refreshed for {ba.account_name}")
    #             except Exception as e:
    #                 self.log_error(f"Broker token refresh failed for {ba.account_name}: {e}")
    #
    #     # Also refresh datafeed token if needed
    #     self.datafeed_obj.refresh_from_db()
    #     if self.datafeed_obj.is_token_expired:
    #         self.log_warning("Datafeed token expired — refreshing...")
    #         try:
    #             from datafeed.rest.handler import DataFeedHandler
    #             DataFeedHandler(self.datafeed_obj).update_token()
    #             self.datafeed_obj.refresh_from_db()
    #             self.log_info("Datafeed token refreshed")
    #         except Exception as e:
    #             self.log_error(f"Datafeed token refresh failed: {e}")

    # =========================================================================
    # SESSION STATE PERSISTENCE
    # =========================================================================

    def _get_state_path(self) -> str:
        """Return today's JSON state file path."""
        code = self.strategy_obj.strategy_code.lower()
        return os.path.join(GEX_DUMP_DIR, f"{code}_{date.today().strftime('%Y%m%d')}.json")

    def _save_session_state(self) -> None:
        """Persist session_open and _last_bar_idx to a JSON file."""
        state_path = self._get_state_path()
        os.makedirs(os.path.dirname(state_path), exist_ok=True)
        state = {
            "date": str(date.today()),
            "session_open": self.session_open,
            "last_bar_idx": self._last_bar_idx,
        }
        try:
            with open(state_path, 'w') as f:
                json.dump(state, f)
        except Exception as e:
            self.log_error(f"Failed to save session state: {e}")

    def _load_session_state(self) -> bool:
        """Load session_open and _last_bar_idx from today's JSON file.
        Returns True if state was restored, False otherwise."""
        state_path = self._get_state_path()
        if not os.path.isfile(state_path):
            return False
        try:
            with open(state_path, 'r') as f:
                state = json.load(f)
            if state.get("date") != str(date.today()):
                self.log_info("Session state file is stale (wrong date). Ignoring.")
                return False
            if state.get("session_open") is not None:
                self.session_open = float(state["session_open"])
                self.log_info(f"RECOVERY: Restored session_open={self.session_open:.2f} from state file")
            if state.get("last_bar_idx") is not None:
                self._last_bar_idx = int(state["last_bar_idx"])
                self.log_info(f"RECOVERY: Restored last_bar_idx={self._last_bar_idx} from state file")
            return True
        except Exception as e:
            self.log_error(f"Failed to load session state: {e}")
            return False

    # =========================================================================
    # MAIN RUN LOOP
    # =========================================================================

    def run(self):
        """
        Main orchestration loop:
          1. Verify
          2. Wait for entry window
          3. Resolve expiry, fetch session open
          4. Fetch full option chain (CE + PE)
          5. Enrich chain with Greeks via helpers/greeks.py
          6. Compute GEX and GTBR
          7. Log values every polling interval

        Phase 2 (added): Handles live entry/exit evaluation, order placement,
        and database state tracking.
        """
        params = self.strategy_obj.strategy_params or {}
        dry_run = bool(params.get("dry_run", False))

        self.log_info("=" * 60)
        self.log_info("Starting GexRegimeTrader")
        self.log_info(f"Entry Time : {self.strategy_obj.entry_time}")
        self.log_info(f"Exit Time  : {self.strategy_obj.exit_time}")
        self.log_info(f"Mode       : {'DRY-RUN' if dry_run else 'LIVE'}")
        self.log_info("=" * 60)

        # Option expiry lookup uses `_get_nearest_option_expiry()` etc.
        # Ensure we properly log verification failure
        if not self.verify():
            self.log_error("Verification failed. Exiting.")
            return

        self.is_running = True

        from datafeed.rest.handler import DataFeedHandler
        datafeed_handler = DataFeedHandler(self.datafeed_obj)

        # ── Step 2: Bootstrap (in case of restart) ────────────────────────
        resume_only = self._bootstrap_from_db()
        self._load_session_state()  # Restore session_open + last_bar_idx from file

        # ── Step 3: Wait for entry start time ─────────────────────────────
        entry_start_dt = self._get_today_datetime(ENTRY_START)
        self.log_info(f"Waiting for entry start: {entry_start_dt.strftime('%H:%M:%S')}")
        if not self._wait_until(entry_start_dt):
            self.log_info("Stopped while waiting for entry start.")
            return
        if not self.is_running:
            return

        # ── Step 4: Resolve expiry ────────────────────────────────────────
        expiry = self._resolve_expiry()
        if not expiry:
            self.log_error("Could not resolve option expiry. Exiting.")
            self.is_running = False
            return

        # ── Step 5: Fetch session open (spot from TBT) ──────────────────
        # On recovery, session_open was restored from DB metadata.
        # Only fetch fresh if not already set (fresh run).
        if self.session_open is None:
            for attempt in range(1, 6):
                try:
                    self.session_open = self._fetch_spot_from_tbt()
                except Exception as e:
                    self.log_error(f"TBT spot fetch attempt {attempt}/5 exception: {e}")
                if self.session_open is not None:
                    break
                self.log_warning(f"TBT spot fetch attempt {attempt}/5 failed. Retrying in 10s...")
                time.sleep(10)
            if self.session_open is None:
                self.log_error("Could not fetch spot price from TBT after 5 attempts. Exiting.")
                self.is_running = False
                return

        self.log_info(f"Session open (spot) = {self.session_open:.2f}")
        self._save_session_state()  # Persist immediately so it survives restarts

        # ── Step 6: Pre-load full option chain instruments ────────────────
        ce_instruments = self._get_all_option_instruments(expiry, "CE")
        pe_instruments = self._get_all_option_instruments(expiry, "PE")

        if not ce_instruments or not pe_instruments:
            self.log_error(
                f"Insufficient option instruments: "
                f"CE={len(ce_instruments)}, PE={len(pe_instruments)}. Exiting."
            )
            self.is_running = False
            return

        self.log_info(
            f"Option chain loaded: {len(ce_instruments)} CE + "
            f"{len(pe_instruments)} PE strikes | expiry={expiry}"
        )

        # ── Step 7: Two-Tier Polling Loop ─────────────────────────────────
        #   BAR_INTERVAL (hourly):   chain fetch, Greeks, GEX/GTBR, entry
        #   MONITOR_INTERVAL (5s):   spot fetch, exit checks (SL, GTBR reversion)
        hard_exit_dt = self._get_today_datetime(HARD_EXIT_T)
        entry_end_dt = self._get_today_datetime(ENTRY_END)

        self.log_info("Entering two-tier polling loop (hourly bars + 5s monitoring)...")

        while self.is_running:
            now = timezone.now()
            now_t = timezone.localtime(now).time()

            # Hard exit boundary
            if now >= hard_exit_dt:
                self.log_info(">>> HARD EXIT TIME REACHED <<<")
                if self.position:
                    kind = self.position["kind"]
                    inst = self.position["instrument"]
                    exit_ltp = self._fetch_ltp(datafeed_handler, inst)
                    self._execute_exit(kind, exit_ltp, "HARD_EXIT", datafeed_handler, dry_run)
                break

            try:
                # Periodic broker + datafeed token refresh — centralized in TokenRefreshManager
                # if time.time() - self._last_broker_token_refresh >= BROKER_TOKEN_REFRESH_INTERVAL_SECS:
                #     try:
                #         self._refresh_broker_tokens()
                #     except Exception as e:
                #         self.log_error(f"Broker token refresh cycle failed: {e}")
                #     self._last_broker_token_refresh = time.time()

                # 7a. Fetch current spot from TBT (every 5s, cheap)
                spot = None
                tbt_attempt = 0
                while self.is_running and spot is None:
                    tbt_attempt += 1
                    try:
                        spot = self._fetch_spot_from_tbt()
                    except Exception as tbt_err:
                        self.log_warning(f"TBT spot exception (attempt {tbt_attempt}): {tbt_err}")
                    if spot is None:
                        self.log_warning(f"TBT spot fetch attempt {tbt_attempt} failed. Retrying in 5s...")
                        time.sleep(5)
                if spot is None:
                    continue

                move = abs(spot - self.session_open)

                # ──────────────────────────────────────────────────────────
                # HOURLY BAR: Chain + Greeks + GEX/GTBR + Entry eval
                # ──────────────────────────────────────────────────────────
                new_bar = False
                for i, (_bar_start, bar_end) in enumerate(HOURLY_BOUNDARIES):
                    if i <= self._last_bar_idx:
                        continue
                    if now_t < bar_end:
                        break
                    self._last_bar_idx = i
                    new_bar = True
                    self._save_session_state()  # Persist bar progress

                if new_bar:
                    # 7b. Filter to ATM ± N_STRIKES, then fetch quotes (LTP + OI)
                    ce_near = sorted(ce_instruments, key=lambda i: abs(float(i.strike) - spot))[:2 * N_STRIKES + 1]
                    pe_near = sorted(pe_instruments, key=lambda i: abs(float(i.strike) - spot))[:2 * N_STRIKES + 1]
                    ce_quotes = self._fetch_chain_quotes(datafeed_handler, ce_near)
                    pe_quotes = self._fetch_chain_quotes(datafeed_handler, pe_near)

                    if ce_quotes and pe_quotes:
                        # 7c. Enrich chains with Greeks
                        ce_greeks = self._enrich_chain_with_greeks(
                            ce_near, ce_quotes, spot, expiry
                        )
                        pe_greeks = self._enrich_chain_with_greeks(
                            pe_near, pe_quotes, spot, expiry
                        )

                        if ce_greeks and pe_greeks:
                            # 7d. Compute GEX and GTBR
                            gex  = self._compute_gex(ce_greeks, pe_greeks, spot)
                            gtbr = self._compute_gtbr(ce_greeks, pe_greeks, spot)
                            self._last_gex = gex
                            self._last_gtbr = gtbr
                            self._last_bar_spot = spot
                            self._last_ce_greeks = ce_greeks
                            self._last_pe_greeks = pe_greeks

                            gtbr_str = f"{gtbr:.2f}" if gtbr is not None else "N/A"
                            self.log_info(
                                f"[BAR {bar_end.strftime('%H:%M')}] "
                                f"Spot={spot:.2f} (Open={self.session_open:.2f}) | "
                                f"Move={move:.2f} | GEX={gex:.0f} | GTBR={gtbr_str}"
                            )

                            # --- ENTRY LOGIC (only at bar close) ---
                            if self.position is None and ENTRY_START <= now_t <= ENTRY_END:
                                if gtbr is None:
                                    self.log_warning("  Skipping entry: GTBR unavailable (no valid ATM gamma)")
                                elif gex < GEX_THRESHOLD:
                                    if move >= gtbr * GTBR_MULTIPLIER:
                                        direction = "CE" if spot > self.session_open else "PE"
                                        self.log_info(
                                            f"  ENTRY SIGNAL: GEX={gex:.0f} < 0, "
                                            f"Move={move:.2f} >= GTBR*Mul={gtbr * GTBR_MULTIPLIER:.2f} "
                                            f"-> BUY ATM {direction}"
                                        )

                                        greeks_arr = ce_greeks if direction == "CE" else pe_greeks
                                        atm_greeks = min(greeks_arr, key=lambda g: abs(g.strike - spot))
                                        self.log_info(
                                            f"  ATM {direction}: strike={atm_greeks.strike} "
                                            f"ltp={atm_greeks.ltp:.2f} iv={atm_greeks.iv:.4f} "
                                            f"gamma={atm_greeks.gamma:.6f}"
                                        )

                                        inst = self._get_option_instrument(
                                            expiry, Decimal(str(atm_greeks.strike)), direction
                                        )
                                        if inst:
                                            entry_ltp = self._fetch_ltp(datafeed_handler, inst) or atm_greeks.ltp
                                            self._execute_entry(
                                                direction, inst, entry_ltp, gtbr,
                                                datafeed_handler, dry_run,
                                            )
                                        else:
                                            self.log_error(f"Could not find ATM {direction} instrument for strike {atm_greeks.strike}")
                                    else:
                                        self.log_debug(f"  Skipping: Move ({move:.2f}) < GTBR*Mul ({gtbr * GTBR_MULTIPLIER:.2f})")
                                else:
                                    self.log_debug(f"  Skipping: GEX ({gex:.0f}) >= {GEX_THRESHOLD}")
                        else:
                            self.log_warning("Greek enrichment returned empty at bar close.")
                    else:
                        self.log_warning("Insufficient chain quotes at bar close.")

                # ──────────────────────────────────────────────────────────
                # MONITOR: Exit checks (every 5s)
                # ──────────────────────────────────────────────────────────
                if self.position is not None:
                    kind = self.position["kind"]
                    entry_prem = self.position["entry_prem"]
                    sl_price = self.position["sl_price"]
                    inst = self.position["instrument"]

                    pos_ltp = self._fetch_ltp(datafeed_handler, inst)
                    if pos_ltp is None:
                        self.log_warning(f"Could not fetch LTP for active position {inst.tradingsymbol}")
                        time.sleep(MONITOR_INTERVAL_SEC)
                        continue

                    # Update last_price in DB
                    db_pos = self.open_positions.get(kind)
                    if db_pos:
                        db_pos.last_price = Decimal(str(pos_ltp))
                        db_pos.last_price_updated_at = timezone.now()
                        db_pos.save(update_fields=["last_price", "last_price_updated_at"])

                    # Move uses live spot (tick-by-tick)
                    bar_move = abs(spot - self.session_open)

                    # Refresh greeks from live chain data on each tick
                    ce_near_live = sorted(ce_instruments, key=lambda i: abs(float(i.strike) - spot))[:2 * N_STRIKES + 1]
                    pe_near_live = sorted(pe_instruments, key=lambda i: abs(float(i.strike) - spot))[:2 * N_STRIKES + 1]
                    ce_quotes_live = self._fetch_chain_quotes(datafeed_handler, ce_near_live)
                    pe_quotes_live = self._fetch_chain_quotes(datafeed_handler, pe_near_live)

                    if ce_quotes_live and pe_quotes_live:
                        ce_greeks_live = self._enrich_chain_with_greeks(ce_near_live, ce_quotes_live, spot, expiry)
                        pe_greeks_live = self._enrich_chain_with_greeks(pe_near_live, pe_quotes_live, spot, expiry)
                        if ce_greeks_live and pe_greeks_live:
                            self._last_ce_greeks = ce_greeks_live
                            self._last_pe_greeks = pe_greeks_live
                            live_gtbr = self._compute_gtbr(ce_greeks_live, pe_greeks_live, spot)
                            self._last_gtbr = live_gtbr
                        else:
                            # Greek enrichment failed — fall back to cached
                            live_gtbr = self._compute_gtbr(self._last_ce_greeks, self._last_pe_greeks, spot) if self._last_ce_greeks and self._last_pe_greeks else self._last_gtbr
                    else:
                        # Chain fetch failed — fall back to cached greeks
                        live_gtbr = self._compute_gtbr(self._last_ce_greeks, self._last_pe_greeks, spot) if self._last_ce_greeks and self._last_pe_greeks else self._last_gtbr

                    gtbr_exit = live_gtbr * GTBR_EXIT_FRAC if live_gtbr is not None else 0.0
                    self.log_debug(
                        f"Exit check {kind} {inst.tradingsymbol}: ltp={pos_ltp:.2f} "
                        f"entry={entry_prem:.2f} sl={sl_price:.2f} "
                        f"bar_move={bar_move:.2f} gtbr_exit={gtbr_exit:.2f}"
                    )

                    # GTBR Reversion Check (helper checks this FIRST — L285-286)
                    if live_gtbr is not None and bar_move < live_gtbr * GTBR_EXIT_FRAC:
                        self._execute_exit(kind, pos_ltp, f"GTBR_REVERSION (Move {bar_move:.2f} < Exit {live_gtbr * GTBR_EXIT_FRAC:.2f})", datafeed_handler, dry_run)
                        time.sleep(MONITOR_INTERVAL_SEC)
                        continue

                    # Stop Loss Check
                    if pos_ltp <= sl_price:
                        self._execute_exit(kind, pos_ltp, f"STOP_LOSS (LTP {pos_ltp} <= SL {sl_price:.2f})", datafeed_handler, dry_run)
                        time.sleep(MONITOR_INTERVAL_SEC)
                        continue

                    self.log_info(f"  > Holding {kind} {inst.strike} | Prem {entry_prem:.2f} -> {pos_ltp:.2f} | SL {sl_price:.2f}")

            except Exception as e:
                self.log_exception(f"Error in main loop: {e}")

            time.sleep(MONITOR_INTERVAL_SEC)

        # ── End-of-day force-close (safety net) ───────────────────────
        # Only force-close if we're actually past hard exit time.
        # If the loop exited due to an external stop(), leave the position
        # intact in DB so it survives a restart.
        now_t = timezone.localtime(timezone.now()).time()
        if self.position and now_t >= HARD_EXIT_T:
            kind = self.position["kind"]
            inst = self.position["instrument"]
            ltp = self._fetch_ltp(datafeed_handler, inst)
            self._execute_exit(kind, ltp, "EOD_FORCE", datafeed_handler, dry_run)
            if self.position is not None:
                self.log_error(f"FAILED to close orphan {kind} position at EOD — position remains OPEN in DB")
            else:
                self.log_warning(f"Force-closed orphan {kind} position at EOD")
        elif self.position:
            self.log_info(f"Loop exited but NOT EOD — keeping {self.position['kind']} position open in DB for recovery")

        self.is_running = False
        self.log_info("GexRegimeTrader completed.")
