from abc import ABC, abstractmethod
from typing import Optional

from utils.logger import get_app_logger


class BaseStrategy(ABC):
    """
    Abstract base class for all trading strategies.

    Provides:
    - Common initialization with strategy and datafeed objects
    - Optional WebSocket manager for real-time tick data
    - Unique logger per strategy (logs to logs/strategy/<strategy_code>.log)
    - Abstract methods that must be implemented by subclasses
    """

    def __init__(self, strategy_obj, datafeed_obj, ws_manager=None):
        self.strategy_obj = strategy_obj
        self.datafeed_obj = datafeed_obj
        self.ws_manager = ws_manager  # WebSocketManager for real-time ticks

        # Create unique logger for this strategy using strategy_code
        # e.g., VOLLS -> logs/strategy/VOLLS.log
        # e.g., CCALL -> logs/strategy/CCALL.log
        strategy_code = getattr(strategy_obj, 'strategy_code', 'unknown')
        self.logger = get_app_logger("strategy", strategy_code.lower())

        self.logger.info(
            f"Strategy initialized: {strategy_code} - "
            f"{getattr(strategy_obj, 'strategy_name', 'Unknown Strategy')}"
        )

    @abstractmethod
    def run(self):
        """Main strategy execution loop."""
        pass

    @abstractmethod
    def verify(self) -> bool:
        """Verify strategy prerequisites before running."""
        pass

    @abstractmethod
    def stop(self):
        """Stop the strategy gracefully."""
        pass

    def log_info(self, message: str, **kwargs):
        """Convenience method for info logging."""
        self.logger.info(message, **kwargs)

    def log_debug(self, message: str, **kwargs):
        """Convenience method for debug logging."""
        self.logger.debug(message, **kwargs)

    def log_warning(self, message: str, **kwargs):
        """Convenience method for warning logging."""
        self.logger.warning(message, **kwargs)

    def log_error(self, message: str, **kwargs):
        """Convenience method for error logging."""
        self.logger.error(message, **kwargs)

    def log_exception(self, message: str):
        """Log exception with traceback."""
        self.logger.exception(message)

    def _sync_position_entry_fill(self, pos) -> bool:
        """
        Sync entry_price from actual BrokerOrder fill (weighted average across accounts).
        Runs once per position — guarded by strategy_metadata['fill_synced'].
        Returns True when synced (or already synced), False if fills not yet available.
        """
        from decimal import Decimal
        from orders.models import BrokerOrder

        meta = pos.strategy_metadata or {}
        if meta.get("fill_synced"):
            return True
        if not pos.entry_parent_order_id:
            return False

        filled = list(
            BrokerOrder.objects.filter(
                parent_order_id=pos.entry_parent_order_id,
                status="COMPLETED",
            ).exclude(average_price__isnull=True)
        )
        if not filled:
            return False

        total_qty = sum(bo.filled_quantity for bo in filled)
        if not total_qty:
            return False

        weighted_avg = sum(float(bo.average_price) * bo.filled_quantity for bo in filled) / total_qty
        pos.entry_price = Decimal(str(round(weighted_avg, 2)))
        meta["fill_synced"] = True
        pos.strategy_metadata = meta
        return True
