import time
from datetime import date
from decimal import Decimal
from typing import Optional
from instruments.models import Instrument
from orders.order_manager import order_manager
from strategy.strategy_class.base_strategy import BaseStrategy

TICKER = "NIFTY"
PRICE_OFFSET = Decimal("0.5")

class ShortFuture(BaseStrategy):

    def __init__(self, strategy_obj, datafeed_obj, ws_manager=None):
        super().__init__(strategy_obj, datafeed_obj, ws_manager)
        self.is_running = False

    def verify(self) -> bool:
        if not self.datafeed_obj:
            self.log_error("No datafeed object provided.")
            return False

        if self.datafeed_obj.is_token_expired:
            self.log_warning("Datafeed token expired — attempting refresh...")
            from datafeed.rest.handler import DataFeedHandler
            handler = DataFeedHandler(self.datafeed_obj)
            if not handler.update_token():
                self.log_error("Failed to refresh datafeed token.")
                return False

        self.log_info("Verification passed.")
        return True

    def _get_nearest_future(self, ticker: str) -> Optional[Instrument]:

        today = date.today()
        future = Instrument.objects.filter(
            name=ticker,
            exchange="NFO",
            instrument_type="FUT",
            is_active=True,
            expiry__gt=today,
        ).order_by("expiry").first()

        if future:
            self.log_info(
                f"Found future: {future.tradingsymbol} "
                f"(Expiry: {future.expiry}, Lot Size: {future.lot_size})"
            )
        else:
            self.log_error(f"No active future found for {ticker} on NFO.")

        return future

    def _fetch_ltp(self, datafeed_handler, instrument: Instrument) -> Optional[float]:

        try:
            response = datafeed_handler.get_multiple_ltp([instrument])
            if response and "data" in response:
                for item in response["data"].get("ltp_list", []):
                    if item.get("instrument_token") == instrument.instrument_token:
                        return item.get("ltp")
        except Exception as e:
            self.log_error(f"Error fetching LTP: {e}")

        return None

    def _limit_price(self, side: str, ltp: float) -> Decimal:
        
        base = Decimal(str(ltp))
        return base + PRICE_OFFSET if side == "SELL" else base - PRICE_OFFSET

    def run(self):
        """
          1. Verify → 2. Find Future → 3. Fetch LTP → 4. SELL 1 lot → 5. Wait → 6. Exit
        """
        # Read ticker from strategy_params, fall back to default
        params = self.strategy_obj.strategy_params or {}
        ticker = params.get("ticker", TICKER)
        dry_run = bool(params.get("dry_run", False))

        self.log_info("=" * 60)
        self.log_info(f"Starting ShortFuture strategy for {ticker}")
        self.log_info(f"Mode: {'DRY-RUN (no orders placed)' if dry_run else 'LIVE'}")
        self.log_info("=" * 60)

        # Step 1: Verify
        if not self.verify():
            self.log_error("Verification failed. Exiting.")
            return

        self.is_running = True

        # Step 2: Find the nearest future
        future = self._get_nearest_future(ticker)
        if not future:
            self.is_running = False
            return

        # Step 3: Fetch LTP
        from datafeed.rest.handler import DataFeedHandler
        datafeed_handler = DataFeedHandler(self.datafeed_obj)

        ltp = self._fetch_ltp(datafeed_handler, future)
        if ltp is None:
            self.log_error(
                f"Could not fetch LTP for {future.tradingsymbol}. Aborting."
            )
            self.is_running = False
            return

        # Step 4: Calculate limit price and place order
        limit_price = self._limit_price("SELL", ltp)
        quantity = future.lot_size  # Must trade in lot-size multiples

        self.log_info(
            f"LTP: {ltp} | Limit Price: {limit_price} | "
            f"Quantity: {quantity} (1 lot) | Symbol: {future.tradingsymbol}"
        )

        if dry_run:
            self.log_info(
                f"[DRY-RUN] Would SELL {quantity}x {future.tradingsymbol} "
                f"LIMIT @ {limit_price} | NRML"
            )
            self.is_running = False
            self.log_info("ShortFuture dry-run completed.")
            return

        success, msg, parent_order, _ = order_manager.create_and_execute_order(
            strategy=self.strategy_obj,
            instrument=future,
            side="SELL",
            quantity=quantity,
            order_type="LIMIT",
            product_type="NRML",
            price=limit_price,
            order_intent="ENTRY",
            metadata={
                "strategy_code": self.strategy_obj.strategy_code,
                "instrument_type": future.instrument_type,
                "stock_name": future.name,
                "tag": f"{ticker}_FUT_SHORT",
            },
        )

        # Step 5: Log result and keep thread alive for fill processing
        if success:
            self.log_info(f"Successfully placed order! Parent Order ID: {parent_order.order_id}")
            self.log_info("Waiting 60 seconds to allow order fills to process before exiting...")

            wait_time = 60
            while self.is_running and wait_time > 0:
                time.sleep(1)
                wait_time -= 1

            self.log_info("Wait complete. Exiting strategy thread.")
        else:
            self.log_error(f"Failed to place order: {msg}")

        self.is_running = False

    def stop(self):
        """Stop the strategy."""
        self.log_info("Stopping ShortFuture...")
        self.is_running = False
