import pandas as pd
import datetime as dt
import numpy as np


NIFTY_CONST_PATH = r"\\10.211.8.76\GFD MBM Data\PG_staging_files\Index\Index_Constituents\NIFTY 50.csv"
OSC_PATH = r"C:\Dev\AutomatedInfra\src\system\dump\covered_call\osc_sheet.csv"
nifty_weights = pd.read_csv(NIFTY_CONST_PATH)
osc_weights = pd.read_csv(OSC_PATH)
nifty_weights = nifty_weights.merge(osc_weights, how="left", on="Company Name").drop(columns="Company Name")
nifty_weights.set_index("NSE symbol", inplace=True)


nifty_weights = nifty_weights.reset_index().rename(columns={"NSE symbol": "Ticker"})


df_corp = pd.read_excel(r"D:\OneDrive - Neo Group\Desktop\Data\Corporate_Actions-Formatted - 2025 August added.xlsx").rename(columns={"Security Name": "Ticker"}).dropna(subset=["Dividend"])
df_corp["Date"] = pd.to_datetime(df_corp["Ex Date"], format="%d-%m-%Y %H:%M:%S",
                                 dayfirst=True)