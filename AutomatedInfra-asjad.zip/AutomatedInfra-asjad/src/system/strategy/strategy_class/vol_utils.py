"""
Volatility utilities for the Vol Long Short strategy.

Black-76 pricing, Newton-Raphson IV solver, Welford online statistics,
and z-score ranking.
"""
import csv
import math
from dataclasses import dataclass
from datetime import date, datetime

from scipy.stats import norm


# =============================================================================
# TIME-TO-MATURITY
# =============================================================================

def calculate_ttm(expiry: date, now: datetime) -> float:
    """Return time-to-maturity in years (minimum 1/365)."""
    if isinstance(expiry, datetime):
        delta = expiry - now
    else:
        delta = datetime.combine(expiry, datetime.min.time()) - now
    days = max(delta.total_seconds() / 86400, 0)
    return max(days / 365.0, 1.0 / 365.0)


# =============================================================================
# BLACK-76 PRICING
# =============================================================================

def bs_call_price(forward: float, strike: float, ttm: float, sigma: float) -> float:
    """Black-76 call price."""
    if sigma <= 0 or ttm <= 0:
        return max(forward - strike, 0.0)
    sqrt_t = math.sqrt(ttm)
    d1 = (math.log(forward / strike) + 0.5 * sigma * sigma * ttm) / (sigma * sqrt_t)
    d2 = d1 - sigma * sqrt_t
    return forward * norm.cdf(d1) - strike * norm.cdf(d2)


def bs_put_price(forward: float, strike: float, ttm: float, sigma: float) -> float:
    """Black-76 put price."""
    if sigma <= 0 or ttm <= 0:
        return max(strike - forward, 0.0)
    sqrt_t = math.sqrt(ttm)
    d1 = (math.log(forward / strike) + 0.5 * sigma * sigma * ttm) / (sigma * sqrt_t)
    d2 = d1 - sigma * sqrt_t
    return strike * norm.cdf(-d2) - forward * norm.cdf(-d1)


def bs_vega(forward: float, strike: float, ttm: float, sigma: float) -> float:
    """Black-76 vega (d(price)/d(sigma))."""
    if sigma <= 0 or ttm <= 0:
        return 0.0
    sqrt_t = math.sqrt(ttm)
    d1 = (math.log(forward / strike) + 0.5 * sigma * sigma * ttm) / (sigma * sqrt_t)
    return forward * sqrt_t * norm.pdf(d1)


# =============================================================================
# IMPLIED VOLATILITY (NEWTON-RAPHSON)
# =============================================================================

def implied_volatility(
    market_price: float,
    forward: float,
    strike: float,
    ttm: float,
    option_type: str,
    max_iter: int = 100,
    tol: float = 1e-6,
) -> float:
    """
    Newton-Raphson implied volatility solver for Black-76.

    Args:
        market_price: Observed option premium.
        forward: Futures price (used as forward).
        strike: Strike price.
        ttm: Time to maturity in years.
        option_type: 'CE' or 'PE'.
        max_iter: Maximum iterations.
        tol: Convergence tolerance.

    Returns:
        Implied volatility (annualised).  Returns 0.0 on failure.
    """
    if market_price <= 0 or forward <= 0 or strike <= 0 or ttm <= 0:
        return 0.0

    price_fn = bs_call_price if option_type == 'CE' else bs_put_price
    sigma = 0.3  # initial guess

    for _ in range(max_iter):
        price = price_fn(forward, strike, ttm, sigma)
        vega = bs_vega(forward, strike, ttm, sigma)
        if vega < 1e-12:
            break
        diff = price - market_price
        if abs(diff) < tol:
            return sigma
        sigma -= diff / vega
        sigma = max(sigma, 1e-6)  # keep positive
        sigma = min(sigma, 5.0)   # cap at 500%

    return sigma


def compute_straddle_iv(
    forward: float,
    strike: float,
    ttm: float,
    ce_premium: float,
    pe_premium: float,
) -> float:
    """
    Compute combined straddle IV = CE_IV + PE_IV.

    Returns 0.0 if either leg fails.
    """
    ce_iv = implied_volatility(ce_premium, forward, strike, ttm, 'CE')
    pe_iv = implied_volatility(pe_premium, forward, strike, ttm, 'PE')
    if ce_iv <= 0 or pe_iv <= 0:
        return 0.0
    return ce_iv + pe_iv


# =============================================================================
# WELFORD ONLINE STATISTICS
# =============================================================================

@dataclass
class WelfordState:
    """Running statistics for one ticker (Welford's algorithm)."""
    n: float
    mean: float
    m2: float


def load_welford_states(csv_path: str) -> dict[str, WelfordState]:
    """
    Load Welford states from a transposed CSV.

    Expected format (no header row):
        Row 0: ticker names
        Row 1: n  (observation count)
        Row 2: mean
        Row 3: m2

    Returns:
        dict mapping ticker -> WelfordState
    """
    with open(csv_path, 'r') as f:
        reader = csv.reader(f)
        rows = [row for row in reader]

    if len(rows) < 4:
        return {}

    tickers = rows[0]
    states: dict[str, WelfordState] = {}
    for i, ticker in enumerate(tickers):
        ticker = ticker.strip()
        if not ticker:
            continue
        states[ticker] = WelfordState(
            n=float(rows[1][i]),
            mean=float(rows[2][i]),
            m2=float(rows[3][i]),
        )
    return states


def welford_update(state: WelfordState, new_value: float) -> WelfordState:
    """One step of Welford's online algorithm.  Returns a *new* state."""
    n = state.n + 1
    delta = new_value - state.mean
    mean = state.mean + delta / n
    delta2 = new_value - mean
    m2 = state.m2 + delta * delta2
    return WelfordState(n=n, mean=mean, m2=m2)


def welford_std(state: WelfordState) -> float:
    """Sample standard deviation from a WelfordState."""
    if state.n < 2:
        return 0.0
    return math.sqrt(state.m2 / (state.n - 1))


def compute_z_score(current_iv: float, state: WelfordState) -> tuple[float, WelfordState]:
    """
    Update the Welford state with the new IV observation and return the
    z-score *before* the update (using the prior distribution).

    Returns:
        (z_score, updated_state)

    If insufficient history (n < 2), returns z_score = 0.0.
    """
    std = welford_std(state)
    if std < 1e-12 or state.n < 2:
        z = 0.0
    else:
        z = (current_iv - state.mean) / std

    new_state = welford_update(state, current_iv)
    return z, new_state


# =============================================================================
# RANKING
# =============================================================================

def rank_stocks_by_zscore(
    zscores: dict[str, float],
    n_long: int = 5,
    n_short: int = 5,
) -> tuple[list[str], list[str]]:
    """
    Rank stocks by z-score.

    - Bottom `n_long` z-scores  -> LONG  straddle (IV is cheap)
    - Top    `n_short` z-scores -> SHORT straddle (IV is rich)

    Returns:
        (long_stocks, short_stocks)
    """
    sorted_items = sorted(zscores.items(), key=lambda x: x[1])
    long_stocks = [ticker for ticker, _ in sorted_items[:n_long]]
    short_stocks = [ticker for ticker, _ in sorted_items[-n_short:]]
    return long_stocks, short_stocks
