from unittest.mock import MagicMock, patch, call
from django.test import TestCase
from requests.exceptions import HTTPError


class FetchLtpTokenRefreshTest(TestCase):
    """Test that _fetch_ltp retries after refreshing the datafeed token on 400/401."""

    def _make_trader(self):
        """Create a GexRegimeTrader with mocked dependencies."""
        from strategy.strategy_class.gex_regime_trader import GexRegimeTrader

        strategy_obj = MagicMock()
        strategy_obj.strategy_code = "GEXRT01"
        strategy_obj.strategy_name = "GEX Regime Trader"

        datafeed_obj = MagicMock()
        datafeed_obj.is_token_expired = False

        trader = GexRegimeTrader(strategy_obj, datafeed_obj)
        trader.is_running = True
        return trader

    def _make_instrument(self, token=12345):
        inst = MagicMock()
        inst.instrument_token = token
        inst.tradingsymbol = "NIFTY26MAR23300CE"
        inst.__str__ = lambda self: self.tradingsymbol
        return inst

    def _make_http_error(self, status_code):
        """Create an HTTPError with a given status code, like the 400s in the logs."""
        response = MagicMock()
        response.status_code = status_code
        error = HTTPError(response=response)
        return error

    def test_returns_ltp_on_success(self):
        """Happy path: LTP fetch succeeds on first try."""
        trader = self._make_trader()
        inst = self._make_instrument()
        handler = MagicMock()
        handler.get_multiple_ltp.return_value = {
            "data": {"ltp_list": [{"instrument_token": 12345, "ltp": 305.50}]}
        }

        result = trader._fetch_ltp(handler, inst)
        self.assertEqual(result, 305.50)
        handler.get_multiple_ltp.assert_called_once()

    @patch("datafeed.rest.handler.DataFeedHandler")
    @patch("strategy.strategy_class.gex_regime_trader.time")
    def test_refreshes_token_and_retries_on_400(self, mock_time, mock_dfh_class):
        """
        Reproduces today's bug: XTS returns 400, token refresh should happen,
        and the retry should succeed with the new handler.
        """
        trader = self._make_trader()
        inst = self._make_instrument()

        # Original handler: 400 error (expired token)
        handler = MagicMock()
        handler.get_multiple_ltp.side_effect = self._make_http_error(400)

        # After refresh, the new DataFeedHandler instance succeeds
        mock_dfh_instance = mock_dfh_class.return_value
        mock_dfh_instance.update_token.return_value = True
        mock_dfh_instance.get_multiple_ltp.return_value = {
            "data": {"ltp_list": [{"instrument_token": 12345, "ltp": 280.30}]}
        }

        result = trader._fetch_ltp(handler, inst)

        # Token refresh was triggered
        mock_dfh_instance.update_token.assert_called_once()
        trader.datafeed_obj.refresh_from_db.assert_called()

        # Retry succeeded with refreshed handler
        self.assertEqual(result, 280.30)

    @patch("datafeed.rest.handler.DataFeedHandler")
    @patch("strategy.strategy_class.gex_regime_trader.time")
    def test_refreshes_token_on_401_plain_exception(self, mock_time, mock_dfh_class):
        """xts.py raises plain Exception('Unauthorized: ...') on 401 — should still trigger refresh."""
        trader = self._make_trader()
        inst = self._make_instrument()

        # xts.py 401 path raises plain Exception, not HTTPError
        handler = MagicMock()
        handler.get_multiple_ltp.side_effect = Exception("Unauthorized: Token expired or invalid.")

        mock_dfh_instance = mock_dfh_class.return_value
        mock_dfh_instance.update_token.return_value = True
        mock_dfh_instance.get_multiple_ltp.return_value = {
            "data": {"ltp_list": [{"instrument_token": 12345, "ltp": 290.00}]}
        }

        result = trader._fetch_ltp(handler, inst)
        mock_dfh_instance.update_token.assert_called_once()
        self.assertEqual(result, 290.00)

    @patch("datafeed.rest.handler.DataFeedHandler")
    @patch("strategy.strategy_class.gex_regime_trader.time")
    def test_refreshes_token_on_http_401(self, mock_time, mock_dfh_class):
        """HTTPError with status 401 should also trigger refresh."""
        trader = self._make_trader()
        inst = self._make_instrument()

        handler = MagicMock()
        handler.get_multiple_ltp.side_effect = self._make_http_error(401)

        mock_dfh_instance = mock_dfh_class.return_value
        mock_dfh_instance.update_token.return_value = True
        mock_dfh_instance.get_multiple_ltp.return_value = {
            "data": {"ltp_list": [{"instrument_token": 12345, "ltp": 290.00}]}
        }

        result = trader._fetch_ltp(handler, inst)
        mock_dfh_instance.update_token.assert_called_once()
        self.assertEqual(result, 290.00)

    @patch("datafeed.rest.handler.DataFeedHandler")
    def test_no_refresh_on_other_errors(self, mock_dfh_class):
        """Non-HTTP errors (network timeout, etc.) should NOT trigger token refresh."""
        trader = self._make_trader()
        inst = self._make_instrument()
        handler = MagicMock()
        handler.get_multiple_ltp.side_effect = ConnectionError("network down")

        result = trader._fetch_ltp(handler, inst)
        mock_dfh_class.return_value.update_token.assert_not_called()
        self.assertIsNone(result)

    @patch("datafeed.rest.handler.DataFeedHandler")
    @patch("strategy.strategy_class.gex_regime_trader.time")
    def test_stops_retrying_when_strategy_stopped(self, mock_time, mock_dfh_class):
        """If is_running becomes False mid-retry, should stop looping and return None."""
        trader = self._make_trader()
        inst = self._make_instrument()

        handler = MagicMock()
        handler.get_multiple_ltp.side_effect = self._make_http_error(400)

        # After first refresh attempt, simulate strategy being stopped
        mock_dfh_instance = mock_dfh_class.return_value
        mock_dfh_instance.update_token.return_value = True
        mock_dfh_instance.get_multiple_ltp.side_effect = self._make_http_error(400)

        def stop_after_two_attempts(*args, **kwargs):
            if mock_dfh_instance.update_token.call_count >= 2:
                trader.is_running = False

        mock_time.sleep.side_effect = stop_after_two_attempts

        result = trader._fetch_ltp(handler, inst)
        self.assertIsNone(result)
        self.assertGreaterEqual(mock_dfh_instance.update_token.call_count, 2)
