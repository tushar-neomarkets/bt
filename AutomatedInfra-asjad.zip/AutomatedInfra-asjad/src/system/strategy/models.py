from django.db import models
from django.contrib.auth.models import User

# Create your models here.
class Strategy(models.Model):
    id = models.AutoField(primary_key=True)
    strategy_code = models.CharField(max_length=10, unique=True)
    strategy_name = models.CharField(max_length=100,unique=True)
    description = models.TextField()
    entry_time = models.TimeField()
    exit_time = models.TimeField()
    strategy_params = models.JSONField(null=True, blank=True)
    extra_data = models.JSONField(null=True, blank=True)
    strategy_class = models.CharField(max_length=10)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'strategies'

    def __str__(self):
        return self.strategy_name
class UserStrategyPermission(models.Model):
    user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='strategy_permissions'
    )

    strategy = models.ForeignKey(
        Strategy,
        on_delete=models.CASCADE,
        related_name='authorized_users'
    )

    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ('user', 'strategy')
        verbose_name = "User Strategy Permission"
        db_table = 'user_strategy_permissions'

    def __str__(self):
        return f"{self.user.username} - {self.strategy.strategy_name}"

class StrategyPosition(models.Model):
    """
    Strategy-level position tracking.
    """
    POSITION_TYPE_CHOICES = (
        ('LONG', 'LONG'),
        ('SHORT', 'SHORT'),
    )
    STATUS_CHOICES = (
        ('ENTRY_PENDING', 'ENTRY_PENDING'),  # Position created, entry order not yet filled
        ('OPEN', 'OPEN'),  # Position is open (entry filled)
        ('CLOSED', 'CLOSED'),  # Position closed (exit filled)
        ('CANCELLED', 'CANCELLED'),  # Cancelled before entry
        ('ERROR', 'ERROR'),  # Error in lifecycle
    )
    position_id = models.BigAutoField(primary_key=True)
    trade_id = models.CharField(
        max_length=100,
        unique=True,
        db_index=True,
        help_text="Unique identifier for this trade"
    )
    strategy = models.ForeignKey(
        Strategy,
        on_delete=models.PROTECT,
        related_name='positions',
        db_index=True
    )
    instrument = models.ForeignKey(
        'instruments.Instrument',
        on_delete=models.SET_NULL,
        related_name='strategy_positions',
        null=True,
        blank=True
    )
    position_type = models.CharField(
        max_length=5,
        choices=POSITION_TYPE_CHOICES,
        db_index=True
    )
    status = models.CharField(
        max_length=20,
        choices=STATUS_CHOICES,
        default='ENTRY_PENDING',
        db_index=True
    )
    quantity = models.IntegerField(
        help_text="Base quantity for this position"
    )
    entry_parent_order = models.OneToOneField(
        'orders.ParentOrder',
        on_delete=models.PROTECT,
        related_name='position_entry',
        null=True,
        blank=True,
        help_text="Entry parent order"
    )
    entry_price = models.DecimalField(
        max_digits=12,
        decimal_places=2,
        null=True,
        blank=True,
        help_text="Entry price (saved when position opens)"
    )
    entry_time = models.DateTimeField(
        null=True,
        blank=True,
        help_text="When position opened"
    )
    exit_parent_order = models.OneToOneField(
        'orders.ParentOrder',
        on_delete=models.PROTECT,
        related_name='position_exit',
        null=True,
        blank=True,
        help_text="Exit parent order"
    )

    exit_price = models.DecimalField(
        max_digits=12,
        decimal_places=2,
        null=True,
        blank=True,
        help_text="Exit price (saved when position closes)"
    )

    exit_time = models.DateTimeField(
        null=True,
        blank=True,
        help_text="When position closed"
    )
    realized_pnl = models.DecimalField(
        max_digits=15,
        decimal_places=2,
        default=0.00,
        help_text="Realized P&L (when closed)"
    )

    unrealized_pnl = models.DecimalField(
        max_digits=15,
        decimal_places=2,
        default=0.00,
        help_text="Unrealized P&L (when open, from LTP)"
    )
    last_price = models.DecimalField(
        max_digits=12,
        decimal_places=2,
        null=True,
        blank=True,
        help_text="Last known market price (LTP)"
    )

    last_price_updated_at = models.DateTimeField(null=True, blank=True)
    entry_signal = models.JSONField(
        null=True,
        blank=True,
        help_text="Entry signal data from strategy"
    )

    exit_signal = models.JSONField(
        null=True,
        blank=True,
        help_text="Exit signal data from strategy"
    )

    strategy_metadata = models.JSONField(
        null=True,
        blank=True,
        help_text="Additional strategy-specific data (SL, target, etc.)"
    )

    # Tags for filtering/grouping
    tags = models.JSONField(
        default=list,
        blank=True,
        help_text="Tags for categorization"
    )

    # Remarks
    remarks = models.TextField(null=True, blank=True)

    # Timestamps
    created_at = models.DateTimeField(auto_now_add=True, db_index=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['strategy', 'status', 'created_at']),
            models.Index(fields=['instrument', 'status']),
            models.Index(fields=['status', 'created_at']),
            models.Index(fields=['trade_id']),
            models.Index(fields=['entry_time']),
            models.Index(fields=['exit_time']),
        ]
        db_table = 'strategy_position'
        verbose_name = "Strategy Position"
        verbose_name_plural = "Strategy Positions"

    @property
    def is_open(self):
        return self.status == 'OPEN'

    @property
    def is_closed(self):
        return self.status == 'CLOSED'
