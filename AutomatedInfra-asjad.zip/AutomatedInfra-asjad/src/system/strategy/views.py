
from strategy.strategy_manager import strategy_manager
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from strategy.strategy_manager import strategy_manager
from strategy.models import Strategy, UserStrategyPermission


class StrategyListView(APIView):
    """
    List all strategies that the authenticated user has permission to access.
    """
    def get(self, request):
        try:
            # Get all strategies the user has permission to access
            strategies = Strategy.objects.filter(
                authorized_users__user=request.user
            ).values(
                'id',
                'strategy_code',
                'strategy_name',
                'description',
                'entry_time',
                'exit_time',
                'strategy_params',
                'extra_data',
                'strategy_class',
                'created_at',
                'updated_at'
            )

            # Add running status to each strategy
            strategies_list = list(strategies)
            for strategy in strategies_list:
                strategy_code = strategy['strategy_code']
                strategy['is_running'] = strategy_code in strategy_manager.running_strategies

            return Response({
                "status": "success",
                "data": strategies_list
            }, status=status.HTTP_200_OK)

        except Exception as e:
            return Response(
                {"error": str(e)},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )
class StrategyDetailView(APIView):
    """
    Get details of a specific strategy.
    """
    def get(self, request, strategy_id):
        return self._handle_strategy_request(request, strategy_id, 'get_detail')

    def _handle_strategy_request(self, request, strategy_id, method_name):
        """
        Reusable handler logic for strategy operations.
        """
        if not strategy_id:
            return Response(
                {"error": "strategy_id is required"},
                status=status.HTTP_400_BAD_REQUEST
            )

        try:
            # Check if user has permission to access this strategy
            strategy = Strategy.objects.get(
                id=strategy_id,
                authorized_users__user=request.user
            )
        except Strategy.DoesNotExist:
            return Response(
                {"error": "Strategy not found or access denied"},
                status=status.HTTP_403_FORBIDDEN
            )

        try:
            if method_name == 'get_detail':
                strategy_data = {
                    'id': strategy.id,
                    'strategy_code': strategy.strategy_code,
                    'strategy_name': strategy.strategy_name,
                    'description': strategy.description,
                    'entry_time': strategy.entry_time,
                    'exit_time': strategy.exit_time,
                    'strategy_params': strategy.strategy_params,
                    'extra_data': strategy.extra_data,
                    'strategy_class': strategy.strategy_class,
                    'created_at': strategy.created_at,
                    'updated_at': strategy.updated_at,
                    'is_running': strategy.strategy_code in strategy_manager.running_strategies
                }
                return Response({
                    "status": "success",
                    "data": strategy_data
                }, status=status.HTTP_200_OK)

        except Exception as e:
            return Response(
                {"error": str(e)},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )
class StartStrategyView(APIView):
    """
    Start or stop a strategy.
    """
    def post(self, request, strategy_id):
        """Start a strategy"""
        return self._handle_strategy_action(request, strategy_id, 'start')

    def delete(self, request, strategy_id):
        """Stop a strategy"""
        return self._handle_strategy_action(request, strategy_id, 'stop')

    def _handle_strategy_action(self, request, strategy_id, action):
        """
        Reusable handler for start/stop actions.
        """
        if not strategy_id:
            return Response(
                {"error": "strategy_id is required"},
                status=status.HTTP_400_BAD_REQUEST
            )

        try:
            # Check if user has permission to access this strategy
            strategy = Strategy.objects.get(
                id=strategy_id,
                authorized_users__user=request.user
            )
        except Strategy.DoesNotExist:
            return Response(
                {"error": "Strategy not found or access denied"},
                status=status.HTTP_403_FORBIDDEN
            )

        try:
            if action == 'start':
                success, message = strategy_manager.start_strategy(strategy_id)
                if success:
                    return Response({
                        "status": "success",
                        "message": message
                    }, status=status.HTTP_200_OK)
                else:
                    return Response({
                        "status": "error",
                        "message": message
                    }, status=status.HTTP_400_BAD_REQUEST)

            elif action == 'stop':
                success, message = strategy_manager.stop_strategy(strategy_id)
                if success:
                    return Response({
                        "status": "success",
                        "message": message
                    }, status=status.HTTP_200_OK)
                else:
                    return Response({
                        "status": "error",
                        "message": message
                    }, status=status.HTTP_400_BAD_REQUEST)

        except Exception as e:
            return Response(
                {"error": str(e)},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )