from django.urls import path
from strategy.views import StrategyListView, StrategyDetailView, StartStrategyView

urlpatterns = [
    path('', StrategyListView.as_view(), name='strategy_list'),
    path('<int:strategy_id>', StrategyDetailView.as_view(), name='strategy_detail'),
    path('<int:strategy_id>/start', StartStrategyView.as_view(), name='strategy_start'),
    path('<int:strategy_id>/stop', StartStrategyView.as_view(), name='strategy_stop'),
]