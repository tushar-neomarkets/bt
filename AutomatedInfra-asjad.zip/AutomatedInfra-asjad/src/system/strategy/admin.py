from django.contrib import admin

# Register your models here.
from strategy.models import Strategy,UserStrategyPermission,StrategyPosition

admin.site.register(UserStrategyPermission)
admin.site.register(Strategy)
admin.site.register(StrategyPosition)