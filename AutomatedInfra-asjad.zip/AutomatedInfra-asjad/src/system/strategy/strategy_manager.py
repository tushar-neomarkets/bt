from strategy.strategy_class.covered_call import CoveredCall
from strategy.strategy_class.vol_trading_new import VolLongShort as VolLongShortNew
from strategy.strategy_class.nifty_straddle import NiftyDeltaHedgedStraddle
from strategy.strategy_class.short_future import ShortFuture
from strategy.strategy_class.long_stock import LongStock
from strategy.strategy_class.index_long_short import IndexLongShort
from strategy.strategy_class.index_mom_long_short_asymm import IndexMomLongShort
from strategy.strategy_class.index_mom_long_short_symm  import IndexMomLongShortSymm
from strategy.strategy_class.index_mom_long_short_asymm_banknifty import BankNiftyMomLongShort
from strategy.strategy_class.index_mom_long_short_symm_banknifty  import BankNiftyMomLongShortSymm
from strategy.strategy_class.hedged_otm_strangle import HedgedOtmStrangle
from strategy.strategy_class.state_machine_strangle import StateMachineShortStrangle
from strategy.strategy_class.index_short import IndexShort
from strategy.strategy_class.orb_short import OrbShort
from strategy.strategy_class.gex_regime_trader import GexRegimeTrader
from strategy.strategy_class.gex_vol import GexRegimeTrader as GexVolTrader
from strategy.strategy_class.put_bear_spread import PutBearSpread
from strategy.strategy_class.delta_straddle import DeltaStraddle


from strategy.models import Strategy
from threading import Thread
from datafeed.models import DataFeedAccount
from datafeed.websocket.manager import websocket_manager
from orders.order_manager import auto_modify_manager
from accounts.token_refresh_manager import token_refresh_manager
from utils.logger import get_logger

# Module logger
logger = get_logger(__name__)


class StrategyManager:

    def __init__(self):
        self.running_strategies = {}
        self.strategy_classes = {
            "CCALL": CoveredCall,
            "VOLLS": VolLongShortNew,
            "NSTRD": NiftyDeltaHedgedStraddle,
            "VNEWS":VolLongShortNew,
            "LSTOK":LongStock,
            "SFUT":ShortFuture,
            "IDXLS":IndexLongShort,
            "IDXMA":IndexMomLongShort,
            "IDXMS":IndexMomLongShortSymm,
            "BNKMA": BankNiftyMomLongShort,
            "BNKMS": BankNiftyMomLongShortSymm,
            "HOTMS": HedgedOtmStrangle,
            "SMSS":StateMachineShortStrangle,
            "IDXSH":IndexShort,
            "ORBSH":OrbShort,
            "GEXRT":GexRegimeTrader,
            "GEXVL":GexVolTrader,
            "EPBS": PutBearSpread,
            "EDS": DeltaStraddle,
        }
        self._datafeed_for_auto_modify = None

    def start_strategy(self, strategy_id):
        strategy = Strategy.objects.get(id=strategy_id)
        strategy_code = strategy.strategy_class

        if strategy_id in self.running_strategies:  # Changed from strategy_code
            return False, "Strategy already running"

        if strategy_code in self.strategy_classes:
            strategy_class = self.strategy_classes[strategy_code]
            # Get Random Datafeed Account with token not expired
            datafeed_account = DataFeedAccount.objects.first()

            # Ensure WebSocket manager is running for real-time ticks
            self._ensure_websocket_manager_running()
            self._ensure_token_refreshers_running()

            # Create strategy instance with websocket_manager reference
            strategy_instance = strategy_class(
                strategy,
                datafeed_account,
                ws_manager=websocket_manager
            )

            # Start auto-modify manager if not already running
            self._ensure_auto_modify_running(datafeed_account)

            t1 = Thread(target=strategy_instance.run)
            t1.start()  # Fixed: Thread().start() returns None
            self.running_strategies[strategy_id] = strategy_instance  # Changed from strategy_code
            logger.info(f"Strategy {strategy_code} (ID: {strategy_id}) started successfully")
            return True, "Strategy started"
        else:
            logger.error(f"Strategy class not found: {strategy_code}")
            return False, "Strategy not found"

    def _ensure_auto_modify_running(self, datafeed_account):
        """
        Start the auto-modify manager if it's not already running.
        Only one instance will ever run (AutoModifyManager has internal lock).
        """
        if auto_modify_manager.is_running():
            logger.debug("AutoModifyManager already running")
            return

        if datafeed_account:
            self._datafeed_for_auto_modify = datafeed_account
            started = auto_modify_manager.start(datafeed_account)
            if started:
                logger.info("AutoModifyManager started by StrategyManager")
            else:
                logger.error("Failed to start AutoModifyManager")
        else:
            logger.warning("No datafeed account available for AutoModifyManager")

    def _ensure_websocket_manager_running(self):
        """
        Start the WebSocket manager if it's not already running.
        Provides real-time tick data for strategies.
        """
        if websocket_manager.is_running():
            logger.debug("WebSocketManager already running")
            return

        started = websocket_manager.initialize_and_connect()
        if started:
            logger.info("WebSocketManager started by StrategyManager")
        else:
            logger.warning("WebSocketManager failed to start (will use REST fallback)")

    def _ensure_token_refreshers_running(self):
        """
        Start the token refresh manager if it's not already running.
        Keeps broker account and datafeed tokens fresh for all active strategies.
        """
        if token_refresh_manager.is_running():
            logger.debug("TokenRefreshManager already running")
            return

        started = token_refresh_manager.start()
        if started:
            logger.info("TokenRefreshManager started by StrategyManager")
        else:
            logger.error("Failed to start TokenRefreshManager")

    def stop_strategy(self, strategy_id):
        strategy = Strategy.objects.get(id=strategy_id)

        if strategy_id not in self.running_strategies:  # Changed from strategy_code
            return False, "Strategy not running"

        strategy_instance = self.running_strategies[strategy_id]  # Changed from strategy_code
        strategy_instance.stop()
        del self.running_strategies[strategy_id]  # Changed from strategy_code

        # Stop auto-modify manager if no strategies are running
        self._stop_auto_modify_if_idle()

        return True, "Strategy stopped"

    def _stop_auto_modify_if_idle(self):
        """
        Stop the auto-modify manager if no strategies are running.
        """
        if not self.running_strategies and auto_modify_manager.is_running():
            auto_modify_manager.stop()
            self._datafeed_for_auto_modify = None
            print("AutoModifyManager stopped (no strategies running)")
            token_refresh_manager.stop()

    def stop_all_strategies(self):
        """
        Stop all running strategies and the auto-modify manager.
        """
        strategy_ids = list(self.running_strategies.keys())
        for strategy_id in strategy_ids:
            self.stop_strategy(strategy_id)

        # Ensure auto-modify is stopped
        if auto_modify_manager.is_running():
            auto_modify_manager.stop()
            self._datafeed_for_auto_modify = None
        token_refresh_manager.stop()


strategy_manager = StrategyManager()
