"""

"""
import os
import time
import logging
from datetime import datetime
from pathlib import Path

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Configuration
SOURCE_PATH = r"\\10.211.9.164\Greek\Greek Logs\Algo Trades\NSE\FO"
PATH_A_NIFTY = r"\\10.211.9.164\Greek\Greek Logs\Suraj Algo\AutoOnlineBackup\NSE\FO"
PATH_B_OTHERS = r"\\10.211.9.164\Greek\Greek Logs\Quant\NSE\FO"

ALGO_CODE_NIFTY = "ALGO"
ALGO_CODE_OTHERS = "QUANTALGO"

INTERVAL_SECONDS = 60  # Run every minute


def get_filename_for_today() -> str:
    """Generate filename in MMDDAUTOTRD.txt format for current date."""
    today = datetime.now()
    return f"{today.month:02d}{today.day:02d}AUTOTRD.txt"


def replace_algo_code(line: str, new_algo_code: str) -> str:
    """
    Replace 'Algo' with new algo code while preserving the line structure.

    The file has two Algo fields:
    - Field 11: 'Algo' (4 chars)
    - Field 17: 'Algo  ' (with trailing spaces)

    We replace the text while trying to preserve comma separation.
    """
    # Split by comma to work with fields
    parts = line.split(',')

    if len(parts) > 17:
        # Field 11 (index 11) - 'Algo'
        if parts[11].strip() == 'Algo':
            parts[11] = new_algo_code

        # Field 17 (index 17) - 'Algo  ' (with trailing spaces)
        if parts[17].strip() == 'Algo':
            parts[17] = new_algo_code

    return ','.join(parts)


def is_nifty_trade(line: str) -> bool:
    """
    Check if the trade line contains NIFTY in the symbol field.
    Symbol is in field 3 (index 3) after comma split.
    Also check field 7 (full trading symbol) for NIFTY.
    """
    parts = line.split(',')
    if len(parts) > 7:
        symbol = parts[3].strip().upper()
        full_symbol = parts[7].strip().upper()
        # Check both symbol field and full trading symbol
        return 'NIFTY' in symbol or 'NIFTY' in full_symbol
    return False


def process_file(source_file: str, dest_nifty: str, dest_others: str) -> tuple:
    """
    Read source file, split by NIFTY/others, replace algo codes, write to destinations.
    Returns tuple of (nifty_count, others_count).
    """
    nifty_lines = []
    other_lines = []

    try:
        # Read source file
        with open(source_file, 'r', encoding='utf-8', errors='ignore') as f:
            lines = f.readlines()

        for line in lines:
            # Skip empty lines
            if not line.strip():
                continue

            if is_nifty_trade(line):
                # NIFTY trade → SURAJALGO
                modified_line = replace_algo_code(line, ALGO_CODE_NIFTY)
                nifty_lines.append(modified_line)
            else:
                # Other trades → QUANTALGO
                modified_line = replace_algo_code(line, ALGO_CODE_OTHERS)
                other_lines.append(modified_line)

        # Write NIFTY trades to Path A
        with open(dest_nifty, 'w', encoding='utf-8') as f:
            f.writelines(nifty_lines)

        # Write other trades to Path B
        with open(dest_others, 'w', encoding='utf-8') as f:
            f.writelines(other_lines)

        return len(nifty_lines), len(other_lines)

    except FileNotFoundError:
        logger.warning(f"Source file not found: {source_file}")
        return 0, 0
    except PermissionError as e:
        logger.error(f"Permission error: {e}")
        return 0, 0
    except Exception as e:
        logger.error(f"Error processing file: {e}")
        return 0, 0


def ensure_directories_exist():
    """Ensure destination directories exist."""
    for path in [PATH_A_NIFTY, PATH_B_OTHERS]:
        try:
            os.makedirs(path, exist_ok=True)
        except Exception as e:
            logger.warning(f"Could not create directory {path}: {e}")


def run_once():
    """Run the splitter once for current date's file."""
    filename = get_filename_for_today()

    source_file = os.path.join(SOURCE_PATH, filename)
    dest_nifty = os.path.join(PATH_A_NIFTY, filename)
    dest_others = os.path.join(PATH_B_OTHERS, filename)

    logger.info(f"Processing: {filename}")

    nifty_count, others_count = process_file(source_file, dest_nifty, dest_others)

    logger.info(f"Processed - NIFTY: {nifty_count} trades → {dest_nifty}")
    logger.info(f"Processed - Others: {others_count} trades → {dest_others}")

    return nifty_count, others_count


def run_loop():
    """Run continuously, processing every minute."""
    logger.info("=" * 60)
    logger.info("Trade Log Splitter Started")
    logger.info(f"Source: {SOURCE_PATH}")
    logger.info(f"Path A (NIFTY → {ALGO_CODE_NIFTY}): {PATH_A_NIFTY}")
    logger.info(f"Path B (Others → {ALGO_CODE_OTHERS}): {PATH_B_OTHERS}")
    logger.info(f"Interval: {INTERVAL_SECONDS} seconds")
    logger.info("=" * 60)

    ensure_directories_exist()

    while True:
        try:
            run_once()
        except Exception as e:
            logger.error(f"Error in main loop: {e}")

        time.sleep(INTERVAL_SECONDS)


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Trade Log Splitter")
    parser.add_argument('--once', action='store_true', help="Run once and exit")
    parser.add_argument('--test', action='store_true', help="Test with local file")
    args = parser.parse_args()

    if args.test:
        # Test mode - use local file
        SOURCE_PATH = r"C:\Dev\AutomatedInfra"
        PATH_A_NIFTY = r"C:\Dev\AutomatedInfra\test_nifty"
        PATH_B_OTHERS = r"C:\Dev\AutomatedInfra\test_others"
        logger.info("Running in TEST mode with local paths")
        ensure_directories_exist()
        run_once()
    elif args.once:
        run_once()
    else:
        run_loop()
