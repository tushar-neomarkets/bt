"""
Centralized Logging Utility

Creates app-wise and file-wise log files automatically.
Logs are organized by Django app and source file:
    logs/
    ├── datafeed/
    │   ├── views.log
    │   └── handler.log
    ├── strategy/
    │   ├── strategy_manager.log
    │   └── vol_trading.log
    ├── orders/
    │   └── order_manager.log
    └── app.log  (fallback for unknown sources)

Usage:
    from utils.logger import get_logger

    # Automatically detects calling file and creates appropriate log file
    logger = get_logger(__name__)

    # Simple logging functions
    logger.info("This is an info message")
    logger.debug("Debug details here")
    logger.warning("Warning message")
    logger.error("Error occurred")
    logger.critical("Critical failure")

    # With extra context
    logger.info("Order placed", extra={"order_id": 123, "symbol": "NIFTY"})

    # Exception logging with traceback
    try:
        ...
    except Exception as e:
        logger.exception("Failed to process order")
"""

import contextvars
import logging
import os
import sys
from datetime import datetime
from logging.handlers import RotatingFileHandler, TimedRotatingFileHandler
from pathlib import Path
from typing import Optional


# =============================================================================
# CONFIGURATION
# =============================================================================

# Base directory for all logs (relative to Django project root)
LOG_BASE_DIR = Path(__file__).resolve().parent.parent / "logs"

# Log format configurations
DETAILED_FORMAT = (
    "%(asctime)s | %(levelname)-8s | %(app_name)s/%(file_name)s:%(lineno)d | "
    "%(funcName)s | %(message)s"
)
SIMPLE_FORMAT = "%(asctime)s | %(levelname)-8s | %(message)s"
CONSOLE_FORMAT = "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s"

# Date format
DATE_FORMAT = "%Y-%m-%d %H:%M:%S"

# Log levels
DEFAULT_LOG_LEVEL = logging.DEBUG
CONSOLE_LOG_LEVEL = logging.INFO
FILE_LOG_LEVEL = logging.DEBUG

# File rotation settings
MAX_BYTES = 10 * 1024 * 1024  # 10 MB per file
BACKUP_COUNT = 5  # Keep 5 backup files


# =============================================================================
# CUSTOM FORMATTER
# =============================================================================

class AppFileFormatter(logging.Formatter):
    """
    Custom formatter that adds app_name and file_name to log records.
    """

    def format(self, record):
        # Add default values if not present
        if not hasattr(record, 'app_name'):
            record.app_name = 'unknown'
        if not hasattr(record, 'file_name'):
            record.file_name = 'unknown'
        return super().format(record)


# =============================================================================
# CUSTOM FILTER
# =============================================================================

class ContextFilter(logging.Filter):
    """
    Filter that adds contextual information to log records.
    """

    def __init__(self, app_name: str, file_name: str):
        super().__init__()
        self.app_name = app_name
        self.file_name = file_name

    def filter(self, record):
        record.app_name = self.app_name
        record.file_name = self.file_name
        return True


# =============================================================================
# LOGGER FACTORY
# =============================================================================

# Cache for loggers to avoid creating duplicates
_logger_cache: dict[str, logging.Logger] = {}


def _parse_module_name(module_name: str) -> tuple[str, str]:
    """
    Parse a module name to extract app name and file name.

    Examples:
        'datafeed.views' -> ('datafeed', 'views')
        'strategy.strategy_class.vol_trading' -> ('strategy', 'vol_trading')
        'orders.order_manager' -> ('orders', 'order_manager')
        '__main__' -> ('app', 'main')

    Args:
        module_name: The __name__ of the calling module

    Returns:
        tuple: (app_name, file_name)
    """
    if module_name == '__main__':
        return 'app', 'main'

    parts = module_name.split('.')

    if len(parts) == 1:
        return 'app', parts[0]

    # First part is typically the Django app name
    app_name = parts[0]

    # Last part is the file name (without .py)
    file_name = parts[-1]

    return app_name, file_name


def _ensure_log_directory(app_name: str) -> Path:
    """
    Ensure the log directory exists for the given app.

    Args:
        app_name: Name of the Django app

    Returns:
        Path: The directory path for the app's logs
    """
    log_dir = LOG_BASE_DIR / app_name
    log_dir.mkdir(parents=True, exist_ok=True)
    return log_dir


def _create_file_handler(
    log_path: Path,
    level: int = FILE_LOG_LEVEL,
    formatter: Optional[logging.Formatter] = None
) -> RotatingFileHandler:
    """
    Create a rotating file handler for the given log path.

    Args:
        log_path: Path to the log file
        level: Logging level for this handler
        formatter: Optional custom formatter

    Returns:
        RotatingFileHandler: Configured file handler
    """
    handler = RotatingFileHandler(
        log_path,
        maxBytes=MAX_BYTES,
        backupCount=BACKUP_COUNT,
        encoding='utf-8'
    )
    handler.setLevel(level)

    if formatter:
        handler.setFormatter(formatter)
    else:
        handler.setFormatter(AppFileFormatter(DETAILED_FORMAT, DATE_FORMAT))

    return handler


def _create_console_handler(
    level: int = CONSOLE_LOG_LEVEL
) -> logging.StreamHandler:
    """
    Create a console handler for stdout logging.

    Args:
        level: Logging level for console output

    Returns:
        StreamHandler: Configured console handler
    """
    handler = logging.StreamHandler(sys.stdout)
    handler.setLevel(level)
    handler.setFormatter(logging.Formatter(CONSOLE_FORMAT, DATE_FORMAT))
    return handler


# =============================================================================
# PER-STRATEGY LOG MIRRORING
# =============================================================================

_current_strategy_code: contextvars.ContextVar[Optional[str]] = contextvars.ContextVar(
    "current_strategy_code", default=None
)


def set_strategy_log_context(strategy_code: Optional[str]):
    """Bind a strategy code so that subsequent log records emitted on this
    thread/task get mirrored to logs/strategy/<code>.log. Returns a token;
    pass it to reset_strategy_log_context() when the work is done."""
    return _current_strategy_code.set(strategy_code)


def reset_strategy_log_context(token) -> None:
    """Clear the strategy code binding. Always pair with set_strategy_log_context()
    in a try/finally so a crash inside the work doesn't leak the binding."""
    _current_strategy_code.reset(token)


class StrategyMirrorHandler(logging.Handler):
    """
    Logging handler that mirrors each record into the strategy's existing
    per-strategy log file (logs/strategy/<code>.log), where <code> is the
    lowercase strategy code currently bound via set_strategy_log_context().
    When no code is bound, this handler does nothing.

    To avoid having two RotatingFileHandlers fighting over the same file
    (which would corrupt rotation), this handler does NOT open its own file.
    Instead it reuses the FileHandler that base_strategy.py already creates
    via get_app_logger("strategy", <code>) — which is cached, so we get the
    exact same handler the strategy itself writes through.
    """

    def emit(self, record):
        try:
            code = _current_strategy_code.get()
            if not code:
                return

            strategy_logger = get_app_logger("strategy", code.lower())

            for h in strategy_logger.handlers:
                if isinstance(h, logging.FileHandler):
                    h.emit(record)
                    break
        except Exception:
            self.handleError(record)


def get_logger(
    module_name: str,
    console_output: bool = True,
    level: int = DEFAULT_LOG_LEVEL
) -> logging.Logger:
    """
    Get or create a logger for the given module.

    The logger will automatically create log files in the appropriate
    directory structure based on the module name.

    Args:
        module_name: Usually __name__ from the calling module
        console_output: Whether to also log to console (default: True)
        level: Logging level (default: DEBUG)

    Returns:
        logging.Logger: Configured logger instance

    Example:
        from utils.logger import get_logger
        logger = get_logger(__name__)
        logger.info("Hello from this module!")
    """
    # Check cache first
    if module_name in _logger_cache:
        return _logger_cache[module_name]

    # Parse module name to get app and file names
    app_name, file_name = _parse_module_name(module_name)

    # Ensure log directory exists
    log_dir = _ensure_log_directory(app_name)

    # Create log file path
    log_path = log_dir / f"{file_name}.log"

    # Create logger
    logger = logging.getLogger(module_name)
    logger.setLevel(level)

    # Prevent propagation to root logger (avoid duplicate logs)
    logger.propagate = False

    # Clear any existing handlers (in case of reload)
    logger.handlers.clear()

    # Add context filter
    context_filter = ContextFilter(app_name, file_name)
    logger.addFilter(context_filter)

    # Add file handler
    file_handler = _create_file_handler(log_path)
    file_handler.addFilter(context_filter)
    logger.addHandler(file_handler)

    # Add console handler if requested
    if console_output:
        console_handler = _create_console_handler()
        logger.addHandler(console_handler)

    # Cache the logger
    _logger_cache[module_name] = logger

    return logger


# =============================================================================
# CONVENIENCE FUNCTIONS
# =============================================================================

def get_app_logger(
    app_name: str,
    file_name: str = "app",
    console_output: bool = True,
    level: int = DEFAULT_LOG_LEVEL
) -> logging.Logger:
    """
    Get a logger with explicit app and file names.

    Useful when you want to specify the log location explicitly
    rather than deriving it from __name__.

    Args:
        app_name: Name of the app/directory for logs
        file_name: Name of the log file (without .log extension)
        console_output: Whether to also log to console
        level: Logging level

    Returns:
        logging.Logger: Configured logger instance

    Example:
        logger = get_app_logger("orders", "auto_modify")
        # Creates logs/orders/auto_modify.log
    """
    # Create a unique logger name
    logger_name = f"{app_name}.{file_name}"

    # Check cache
    if logger_name in _logger_cache:
        return _logger_cache[logger_name]

    # Ensure directory exists
    log_dir = _ensure_log_directory(app_name)
    log_path = log_dir / f"{file_name}.log"

    # Create and configure logger
    logger = logging.getLogger(logger_name)
    logger.setLevel(level)
    logger.propagate = False
    logger.handlers.clear()

    # Add context filter
    context_filter = ContextFilter(app_name, file_name)
    logger.addFilter(context_filter)

    # Add handlers
    file_handler = _create_file_handler(log_path)
    file_handler.addFilter(context_filter)
    logger.addHandler(file_handler)

    if console_output:
        logger.addHandler(_create_console_handler())

    # Cache
    _logger_cache[logger_name] = logger

    return logger


def log_function_call(logger: logging.Logger):
    """
    Decorator to log function entry and exit.

    Usage:
        @log_function_call(logger)
        def my_function(arg1, arg2):
            ...
    """
    def decorator(func):
        def wrapper(*args, **kwargs):
            func_name = func.__name__
            logger.debug(f"ENTER: {func_name}(args={args}, kwargs={kwargs})")
            try:
                result = func(*args, **kwargs)
                logger.debug(f"EXIT: {func_name} -> {result}")
                return result
            except Exception as e:
                logger.exception(f"EXCEPTION in {func_name}: {e}")
                raise
        return wrapper
    return decorator


# =============================================================================
# SPECIALIZED LOGGERS
# =============================================================================

def get_order_logger() -> logging.Logger:
    """Get a dedicated logger for order-related operations."""
    return get_app_logger("orders", "orders")


def get_strategy_logger() -> logging.Logger:
    """Get a dedicated logger for strategy operations."""
    return get_app_logger("strategy", "strategy")


def get_datafeed_logger() -> logging.Logger:
    """Get a dedicated logger for datafeed operations."""
    return get_app_logger("datafeed", "datafeed")


def get_auto_modify_logger() -> logging.Logger:
    """Get a dedicated logger for auto-modify operations."""
    return get_app_logger("orders", "auto_modify")


# =============================================================================
# LOG MANAGEMENT
# =============================================================================

def get_all_log_files() -> list[Path]:
    """
    Get a list of all log files in the logs directory.

    Returns:
        list[Path]: List of log file paths
    """
    if not LOG_BASE_DIR.exists():
        return []

    return list(LOG_BASE_DIR.rglob("*.log"))


def get_log_stats() -> dict:
    """
    Get statistics about the logging system.

    Returns:
        dict: Statistics including file counts, sizes, etc.
    """
    log_files = get_all_log_files()
    total_size = sum(f.stat().st_size for f in log_files if f.exists())

    stats = {
        "log_base_dir": str(LOG_BASE_DIR),
        "total_files": len(log_files),
        "total_size_bytes": total_size,
        "total_size_mb": round(total_size / (1024 * 1024), 2),
        "active_loggers": len(_logger_cache),
        "files_by_app": {}
    }

    # Group by app
    for log_file in log_files:
        app_name = log_file.parent.name
        if app_name not in stats["files_by_app"]:
            stats["files_by_app"][app_name] = []
        stats["files_by_app"][app_name].append({
            "name": log_file.name,
            "size_kb": round(log_file.stat().st_size / 1024, 2) if log_file.exists() else 0
        })

    return stats


def clear_old_logs(days: int = 7) -> int:
    """
    Remove log files older than specified days.

    Args:
        days: Number of days to keep logs

    Returns:
        int: Number of files deleted
    """
    import time

    cutoff_time = time.time() - (days * 24 * 60 * 60)
    deleted_count = 0

    for log_file in get_all_log_files():
        if log_file.stat().st_mtime < cutoff_time:
            log_file.unlink()
            deleted_count += 1

    return deleted_count