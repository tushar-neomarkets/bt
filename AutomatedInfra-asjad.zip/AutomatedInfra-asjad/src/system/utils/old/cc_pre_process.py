
import pandas as pd
import numpy as np
import os

# from nifty_list import nifty50_list
#
# all_df_list = []
# ticker = []
# base_dir = r"D:\OneDrive - Neo Group\Desktop\Strategies\covered_call\Results\Results"
# for file in os.listdir(base_dir):
#     # if file.replace("finally.xlsx", "") in nifty50_list:
#     all_df_list.append(pd.read_excel(base_dir + "/" + file))
#     ticker.extend([file.replace("finally.xlsx", "") for i in range(len(pd.read_excel(base_dir + "/" + file)))])


nifty_constituents = pd.read_csv(r"D:\OneDrive - Neo Group\Desktop\Strategies\covered_call\Nifty-Weightage.csv")
name_mapping = pd.read_csv("osc_sheet_51.csv")
nifty_constituents = nifty_constituents.merge(name_mapping, how="left", on="Company Name").drop(columns="Company Name")
nifty_constituents.set_index("NSE symbol", inplace=True)
nifty_constituents


df_all = pd.read_csv(r"D:\OneDrive - Neo Group\Desktop\Strategies\covered_call\Original_data_checking_file_April_onwards_added.csv")

df_all

nifty_data = pd.read_parquet(r"D:\OneDrive - Neo Group\Desktop\Data\adjusted_combined_data.parquet")
nifty_data = nifty_data[nifty_data['Ticker'] == "NIFTY"]
nifty_data_relevant_dates = nifty_data[nifty_data["Datetime"].isin(df_all["Date"].unique())]
nifty_data_relevant_dates["1M_pct_change"] = nifty_data_relevant_dates["Close"].pct_change()
nifty_data_relevant_dates["Volatility"] = nifty_data_relevant_dates["1M_pct_change"].pct_change(12)



df_all["Date"] = pd.to_datetime(df_all["Date"])
df_all= df_all.merge(nifty_data_relevant_dates[["Datetime", "1M_pct_change"]].rename(
    columns={
        "Datetime": "Date",
        "1M_pct_change": "1M_pct_change_NIFTY",
    }
)
    , how = "left", on = "Date")
df_all

df_all["Date"] = pd.to_datetime(df_all["Date"])

# df_corp = pd.read_excel(r"D:\OneDrive - Neo Group\Desktop\Strategies\Corporate_Actions-Formatted 4.xlsx").rename(columns={"Security Name": "Ticker"})

df_corp = pd.read_excel(r"D:\OneDrive - Neo Group\Desktop\Data\Corporate_Actions-Formatted.xlsx").rename(columns={"Security Name": "Ticker"}).dropna(subset=["Dividend"])
df_corp["Date"] = pd.to_datetime(df_corp["Ex Date"], format="%d-%m-%Y %H:%M:%S",
                                 dayfirst=True)

df_all = df_all.dropna(subset=["F1"])

df_corp["Div_Date"] = df_corp["Date"]
df_with_dividends = pd.merge_asof(df_all.sort_values("Date"), df_corp[["Date", "Ticker",
                                                              "Dividend", "Div_Date"]],
                                  by="Ticker", left_on="Date", right_on="Date",
                                  direction="backward")

# df_with_dividends = df_all

df_with_dividends

def adjust_for_missing_months(df):

    df = df.sort_values(["Ticker", "Date"]).copy()

    def adjust_group(g):
        g["Shifted_Date"] = g["Date"].shift(1)
        g["Time_gap"] = g["Date"] - g["Shifted_Date"]
        # g = g[g["Time_gap"] <= pd.Timedelta(days = 40)].dropna(subset=["Time_gap"])

        return g

    return df.groupby("Ticker", group_keys=False).apply(adjust_group)

df_with_dividends = adjust_for_missing_months(df_with_dividends)

# df_with_dividends["Div_Date"] = pd.to_datetime(df_with_dividends["Div_Date"], format="%d-%m-%Y")
#
# df_with_dividends["Dividend_Change"] = np.where(
#     df_with_dividends["Div_Date"] != df_with_dividends["Div_Date"].shift(),
#     df_with_dividends["Dividend"],
#     0
# )
# df_with_dividends["Dividend_yield"] = (df_with_dividends["Dividend_Change"]/df_with_dividends["F1"]).shift(1).rolling(36).sum()
#
# df_with_dividends[df_with_dividends["Ticker"] == "ONGC"].to_csv("ONGC.csv")


def monthly_range_score(df, price_col="F1", date_col="Date", lookback_months=3):
    """
    Compute predictive range score on monthly data.
    Each row in df is already one month (end-of-month snapshot).

    RangeScore for month M = based on last `lookback_months` months.
    """
    df = df.copy()
    df[date_col] = pd.to_datetime(df[date_col])
    df = df.sort_values(date_col).reset_index(drop=True)

    scores = []
    score_values = []
    for i in range(len(df)):
        if i < lookback_months:
            scores.append({"Month": df.loc[i, date_col], "RangeScore": np.nan})
            # continue
            # score_values.append(np.nan)

        past = df.iloc[i - lookback_months:i]

        H = past[price_col].max()
        L = past[price_col].min()
        R = H - L

        if R == 0:
            score = 1.0
        else:
            std_val = past[price_col].std()
            sigma = std_val / R
            score = max(0, min(1, 1 - sigma))

        scores.append({"Month": df.loc[i, date_col], "RangeScore": score})
        score_values.append(score)
    # print(scores, len(df), len(scores))
    return score_values
    if len(scores) == 0:
        return pd.DataFrame(columns=["Month", "RangeScore"]).set_index("Month")
    return pd.DataFrame(scores).set_index("Month")


def get_vol_and_mom(df):

    df = df.sort_values(["Ticker", "Date"]).copy()

    def adjust_group(g):

        # ms = monthly_range_score(g)
        # if len(ms) != len(g):
        #     padding = [np.nan for i in range(len(g) - len(ms))]
        #     padding.extend(ms)
        # else:
        #     padding = ms
        #
        # g["Monthly_Score"] = padding

        g["1M_price_pct_Change"] = g["F1"].pct_change()
        g["3M_price_pct_Change"] = g["F1"].pct_change(3)
        g["vol"] = g["1M_price_pct_Change"].rolling(3).std()
        # g["Dividend_yield"] = g["Dividend"]/g["F1"]
        g["Div_Date"] = pd.to_datetime(g["Div_Date"], format="%d-%m-%Y")

        g["Dividend_Change"] = np.where(
            g["Div_Date"] != g["Div_Date"].shift(),
            g["Dividend"],
            0
        )


        g["Dividend_yield"] = (g["Dividend_Change"]/g["F1"]).shift(1).rolling(36,
                                                                     min_periods=36).sum()

        g["Date"] = pd.to_datetime(g["Date"])
        g["Last_Div_Difference"] = (g["Date"] - g["Div_Date"])


        window_size = 30
        epsilon = 0.001
        rolling_covariance = g["1M_price_pct_Change"].rolling(window=window_size).cov(g["1M_pct_change_NIFTY"])
        rolling_variance = g["1M_pct_change_NIFTY"].rolling(window=window_size).var()

        g["Beta"] = rolling_covariance / rolling_variance
        g["Beta_OG"] = g["Beta"]
        g["Beta"] = 1/(g["Beta"].abs() + epsilon)
        g = g[g["Last_Div_Difference"] <= pd.Timedelta(days = 700)]


        # g["signal_descriptor"] = (g["Beta"]*-1)
        # g["signal_descriptor"] = (g["vol"])
        # g["signal_descriptor"] = (g["Dividend_yield"])
        # g["signal_descriptor"] = (g["1M_price_pct_Change"]*1)
        # g["signal_descriptor"] = (g["3M_price_pct_Change"]*1)

        # g["signal_descriptor"] = g["Beta"]*-1 + g["Dividend_yield"] + g["vol"]

        # g["signal_descriptor"] = (g["Beta"]*-1 + g["Dividend_yield"] + g["vol"] +
        #                           g["1M_price_pct_Change"]*-1)


        return g

    def cross_sectional_exposurization(g):
        # clip values below 10 and above 90 %ile
        # lower_bound = g['Beta'].quantile(0.05)
        # upper_bound = g['Beta'].quantile(0.90)
        # g = g[(g["Beta"] > upper_bound)]
        beta_mean = g["Beta"].median()
        beta_std = g["Beta"].std()
        g["Mean_Beta"] = beta_mean
        g["Std_Beta"] = beta_std
        g["Beta_normalised"] = ((g["Beta"] - beta_mean)/beta_std).clip(-3, 3)
        # g["Beta_normalised"] = g["Beta"]
        dividend_yield_mean = g["Dividend_yield"].median()
        dividend_yield_std = g["Dividend_yield"].std()
        g["Dividend_yield_normalised"] = ((g["Dividend_yield"] - dividend_yield_mean)/dividend_yield_std).clip(-3, 3)

        # ms_mean = g["Monthly_Score"].median()
        # ms_std = g["Monthly_Score"].std()
        # g["ms_normalised"] = (g["Monthly_Score"] - ms_mean)/ms_std

        vol_mean = g["vol"].median()
        vol_std = g["vol"].std()
        g["vol_normalised"] = (g["vol"] - vol_mean)/vol_std
        one_month_pct_change_mean = g["1M_price_pct_Change"].mean()
        one_month_pct_change_std = g["1M_price_pct_Change"].std()
        g["1M_price_pct_Change_normalised"] = (g["1M_price_pct_Change"] - one_month_pct_change_mean)/one_month_pct_change_std
        return g


    df = df.groupby("Ticker", group_keys=False).apply(adjust_group)
    df = df.groupby("Date", group_keys=False).apply(cross_sectional_exposurization)

    df["signal_descriptor"] = (df["Beta_normalised"] + df["Dividend_yield_normalised"])
    # df["signal_descriptor"] = df["Monthly_Score"]
    # df["signal_descriptor"] = (df["Beta_normalised"]*-1 + df["Dividend_yield_normalised"] + df["vol_normalised"] + df["1M_price_pct_Change_normalised"]*-1)
    return df




df = get_vol_and_mom(df_with_dividends)

df[df["Ticker"] == "ADANIENT"].iloc[-1]



slippage_pct = 0.00135
t_cost = 0.00035
df["slippage_and_costs"] = (df["F1"] + df["C1"])*slippage_pct
df["after_cost_profit"] = df["profit"] -df["slippage_and_costs"]
df["ronF"] = df["after_cost_profit"]*(df["ronF"]/df["profit"])

df.groupby("Date")["ronF"].mean().describe()


# arr = np.array(sorted(pd.to_datetime(nifty_constituents.columns)))
#
# def fast_find_next(x):
#     idx = np.searchsorted(arr, x, side="right")
#     return arr[idx] if idx < len(arr) else pd.NaT
#
# df["next_higher_date"] = pd.to_datetime(df["Date"]).apply(fast_find_next)

# nifty_constituents = nifty_constituents.reset_index().rename(columns={"NSE symbol": "Ticker"})
# nifty_long = nifty_constituents.melt(
#     id_vars='Ticker',
#     value_vars=[i for i in nifty_constituents if "index" not in i ],
#     var_name='next_higher_date',
#     value_name='Weightage'
# )
# nifty_long["next_higher_date"] = pd.to_datetime(nifty_long["next_higher_date"])
# df["next_higher_date"] = pd.to_datetime(df["next_higher_date"])
# df = df.merge(nifty_long, how="left", on=["Ticker", "next_higher_date"])

# df = df.dropna(subset=["Weightage"])

df["signal_descriptor"] = df["signal_descriptor"].replace(np.inf, np.nan)
df["F1"] = df["F1"].replace(0, np.nan)
df = df.dropna(subset=["F1"])

formulate_results_long = []
formulate_results_short = []
date_ticker_mapping = {}
for i,date in enumerate(sorted(df["Date"].unique())):
    current_df = df[df["Date"] == date].sort_values(["signal_descriptor"], ascending=False)
    current_df = current_df.dropna(subset=["signal_descriptor"])
    formulate_results_long.append(current_df.iloc[:10])
    formulate_results_short.append(current_df.iloc[-10:])

date_ticker_mapping

formulate_results_long = pd.concat(formulate_results_long)


df_daily = formulate_results_long.groupby("Date")["ronF"].mean()/100

# def wavg(x):
#     return np.average(x["ronF"], weights=x["Weightage"].abs())
#
# df_daily = formulate_results_long.groupby("Date").apply(wavg)/100

# ((df["C1"] - df["C2"])/df["F1"]).describe()

# ((formulate_results_long["C1"] - formulate_results_long["C2"])/formulate_results_long["F1"]).describe()
#

formulate_results_long.groupby("Date")["ronF"].mean().describe()


((formulate_results_long["F2"] - formulate_results_long["F1"]) / formulate_results_long["F1"]).describe()


((formulate_results_long["F2"] - formulate_results_long["F1"]) / formulate_results_long["F1"]).describe()

# df_daily= df_daily[df_daily.index != pd.to_datetime("26-03-2020")]



import matplotlib.pyplot as plt

def portfolio_analysis(file_path: str, rf_rate: float = 0.0,
                       trading_days: int = 252, plot: bool = True,
                       df_or_path="path"):
    """
    Comprehensive portfolio analysis from Daily Logs CSV.
    Includes:
      - CAGR, Sharpe, Sortino, Calmar, Omega
      - Volatility, Skew, Kurtosis
      - Max Drawdown, Avg Drawdown, Avg Duration
      - Trade stats (aggregate, long, short)
      - Hit rate, Avg winner/loser %
      - PnL breakdowns (weekly, monthly, yearly)
      - Average Gain per Day, Average Gain per Trade
      - Plots: Equity curve, Drawdown curve, Periodic returns
    """
    # Load data
    if df_or_path == "path":
        df = pd.read_csv(file_path)
    else:
        df = file_path
    df["Trade_Date"] = pd.to_datetime(df["Trade_Date"])
    df = df.sort_values("Trade_Date")

    # Daily returns
    df["Return"] = df["Capital"].pct_change().fillna(0)

    # CAGR
    start_capital = df["Capital"].iloc[0]
    end_capital = df["Capital"].iloc[-1]
    n_years = (df["Trade_Date"].iloc[-1] - df["Trade_Date"].iloc[0]).days / 365.25
    cagr = (end_capital / start_capital) ** (1 / n_years) - 1

    # Sharpe & Sortino
    excess_ret = df["Return"] - rf_rate / trading_days
    sharpe = (excess_ret.mean() / excess_ret.std()) * np.sqrt(trading_days)
    downside = df.loc[df["Return"] < 0, "Return"]
    downside_std = downside.std()
    sortino = (df["Return"].mean() / downside_std) * np.sqrt(trading_days) if downside_std > 0 else np.nan

    # Volatility
    volatility = df["Return"].std() * np.sqrt(trading_days)

    # Drawdown stats
    roll_max = df["Capital"].cummax()
    drawdown = df["Capital"] / roll_max - 1
    max_dd = drawdown.min()
    end_date = drawdown.idxmin()
    start_date = df.loc[:end_date, "Capital"].idxmax()
    dd_start, dd_end = df.loc[start_date, "Trade_Date"], df.loc[end_date, "Trade_Date"]

    # Avg drawdown & duration
    dd_durations, dd_depths = [], []
    in_dd = False
    for i in range(len(df)):
        if drawdown.iloc[i] < 0:
            if not in_dd:
                start_idx = i
                in_dd = True
            if i == len(df) - 1:
                dd_durations.append(i - start_idx + 1)
                dd_depths.append(drawdown.iloc[start_idx:i + 1].min())
        else:
            if in_dd:
                end_idx = i
                dd_durations.append(end_idx - start_idx)
                dd_depths.append(drawdown.iloc[start_idx:end_idx].min())
                in_dd = False
    avg_dd_duration = np.mean(dd_durations) if dd_durations else 0
    avg_dd_depth = np.mean(dd_depths) if dd_depths else 0

    # Calmar
    calmar = cagr / abs(max_dd) if max_dd < 0 else np.nan

    # Omega ratio
    gains = df.loc[df["Return"] > 0, "Return"].sum()
    losses = abs(df.loc[df["Return"] < 0, "Return"].sum())
    omega = gains / losses if losses > 0 else np.nan

    # ---- Trade Metrics ----
    def trade_metrics(pnl_series):
        trades = len(pnl_series[pnl_series != 0])
        winners = pnl_series[pnl_series > 0]
        losers = pnl_series[pnl_series < 0]
        hit_rate = len(winners) / trades if trades > 0 else np.nan
        avg_win = winners.mean() / abs(start_capital) if len(winners) > 0 else np.nan
        avg_loss = losers.mean() / abs(start_capital) if len(losers) > 0 else np.nan
        return {
            "Trades": trades,
            "HitRate": hit_rate,
            "AvgProfitPerWinnerPct": avg_win * 100 if avg_win is not np.nan else np.nan,
            "AvgLossPerLoserPct": avg_loss * 100 if avg_loss is not np.nan else np.nan
        }

    # agg_metrics = trade_metrics(df["PnL"])
    # long_metrics = trade_metrics(df["Long_PnL"])
    # short_metrics = trade_metrics(df["Short_PnL"])

    # ---- Periodic PnL ----
    df["Week"] = df["Trade_Date"].dt.to_period("W")
    df["Month"] = df["Trade_Date"].dt.to_period("M")
    df["Year"] = df["Trade_Date"].dt.to_period("Y")

    weekly_pnl = df.groupby("Week")["Return"].sum() * 100
    monthly_pnl = df.groupby("Month")["Return"].sum() * 100
    yearly_pnl = df.groupby("Year")["Return"].sum() * 100

    # ---- New Metrics ----
    avg_gain_per_day = df["Return"].mean() * 100  # %
    # total_trades = agg_metrics["Trades"]
    # avg_gain_per_trade = (df["PnL"].sum() / total_trades / start_capital * 100) if total_trades > 0 else np.nan

    # Collect stats
    stats = {
        "CAGR": cagr,
        "Sharpe": sharpe,
        "Sortino": sortino,
        "Calmar": calmar,
        "Omega": omega,
        "Max_Drawdown": max_dd,
        "Avg_Drawdown": avg_dd_depth,
        "Avg_Drawdown_Duration": avg_dd_duration,
        "Drawdown_Start": dd_start,
        "Drawdown_End": dd_end,
        "Volatility": volatility,
        # "Aggregate_Trade_Metrics": agg_metrics,
        # "Long_Trade_Metrics": long_metrics,
        # "Short_Trade_Metrics": short_metrics,
        "Weekly_PnL_%": weekly_pnl,
        "Monthly_PnL_%": monthly_pnl,
        "Yearly_PnL_%": yearly_pnl,
        "Avg_Gain_Per_Day_%": avg_gain_per_day,
        # "Avg_Gain_Per_Trade_%": avg_gain_per_trade
    }

    positive_days = (df["Return"] > 0).mean() * 100
    positive_weeks = (weekly_pnl > 0).mean() * 100
    positive_months = (monthly_pnl > 0).mean() * 100
    positive_years = (yearly_pnl > 0).mean() * 100

    stats.update({
        "Positive_Days_%": positive_days,
        "Positive_Weeks_%": positive_weeks,
        "Positive_Months_%": positive_months,
        "Positive_Years_%": positive_years
    })

    # ---- Plots ----
    if plot:
        fig, axs = plt.subplots(3, 1, figsize=(14, 10), gridspec_kw={'height_ratios': [2, 1, 1]})
        # Equity curve
        axs[0].plot(df["Trade_Date"], np.log(df["Capital"]), label="Equity Curve", color="blue")
        axs[0].set_ylabel("Capital (log scale)")
        axs[0].set_title("Equity Curve")
        axs[0].legend()
        # Drawdown curve
        axs[1].plot(df["Trade_Date"], drawdown, label="Drawdown", color="red")
        axs[1].fill_between(df["Trade_Date"], drawdown, 0, color="red", alpha=0.3)
        axs[1].set_ylabel("Drawdown")
        axs[1].set_title("Drawdown Curve")
        axs[1].legend()
        # Yearly bar plot
        yearly_pnl.plot(kind="bar", ax=axs[2], color="green", alpha=0.7)
        axs[2].set_title("Yearly Returns (%)")
        axs[2].set_ylabel("Return %")
        axs[2].axhline(0, color="black", linewidth=0.8)
        plt.tight_layout()
        plt.show()

        # Separate Monthly & Weekly plots
        plt.figure(figsize=(14, 4))
        monthly_pnl.plot(kind="bar", color="orange", alpha=0.7)
        plt.title("Monthly Returns (%)")
        plt.ylabel("Return %")
        plt.axhline(0, color="black", linewidth=0.8)
        plt.show()

        plt.figure(figsize=(14, 4))
        weekly_pnl.plot(kind="bar", color="purple", alpha=0.7)
        plt.title("Weekly Returns (%)")
        plt.ylabel("Return %")
        plt.axhline(0, color="black", linewidth=0.8)
        plt.show()

    return stats



capital_series = 100 * (1 + df_daily).cumprod()
df_check = pd.DataFrame()
df_check["Trade_Date"] = capital_series.index
df_check["Capital"] = capital_series.values
df_check["Returns"] = df_daily.values

print(df_check)
results = portfolio_analysis(df_check, plot=True, rf_rate=0.06, df_or_path="df")
print(results)

results["Monthly_PnL_%"].to_csv(r"D:\OneDrive - Neo Group\Desktop\Strategies\covered_call\FNO_uni_results\All_FNO_uni_Beta_Dividend_top_10_without_hedge.csv")
formulate_results_long.to_csv(r"D:\OneDrive - Neo Group\Desktop\Strategies\covered_call\FNO_uni_results\All_FNO_uni_selected_stocks_Beta_Dividend_check_results.csv", index = False)
df.to_csv(r"D:\OneDrive - Neo Group\Desktop\Strategies\covered_call\FNO_uni_results\All_FNO_uni_complete_uni_Beta_Dividend_check_results.csv", index = False)


# results["Monthly_PnL_%"].to_csv(r"D:\OneDrive - Neo Group\Desktop\Strategies\covered_call\NIFTY_equal_weighted_uni_results\NIFTY_equal_weighted_uni_Beta_Dividend_top_10_without_hedge.csv")
# formulate_results_long.to_csv(r"D:\OneDrive - Neo Group\Desktop\Strategies\covered_call\NIFTY_equal_weighted_uni_results\NIFTY_equal_weighted_uni_selected_stocks_Beta_Dividend_check_results.csv", index = False)
# df.to_csv(r"D:\OneDrive - Neo Group\Desktop\Strategies\covered_call\NIFTY_equal_weighted_uni_results\NIFTY_equal_weighted_uni_complete_uni_Beta_Dividend_check_results.csv", index = False)


# results["Monthly_PnL_%"].to_csv(r"D:\OneDrive - Neo Group\Desktop\Strategies\covered_call\NIFTY_mkt_cap_weighted_uni_results\NIFTY_mkt_weighted_uni_Beta_Dividend_top_10_without_hedge.csv")
# formulate_results_long.to_csv(r"D:\OneDrive - Neo Group\Desktop\Strategies\covered_call\NIFTY_mkt_cap_weighted_uni_results\NIFTY_mkt_weighted_uni_selected_stocks_Beta_Dividend_check_results.csv", index = False)
# df.to_csv(r"D:\OneDrive - Neo Group\Desktop\Strategies\covered_call\NIFTY_mkt_cap_weighted_uni_results\NIFTY_mkt_weighted_uni_complete_uni_Beta_Dividend_check_results.csv", index = False)




import pandas as pd
import numpy as np

import pandas as pd
import numpy as np

def yoy_performance_metrics(returns: pd.Series, rf: float = 0.06):
    """
    Calculate yearly performance metrics: YoY Return, Std, Sharpe, Sortino, Calmar.

    Parameters
    ----------
    returns : pd.Series
        Periodic returns indexed by datetime (daily, weekly, monthly, etc.).
        Example: [0.01, -0.02, 0.005] meaning +1%, -2%, +0.5% per period.
    rf : float
        Annual risk-free rate (default = 0).

    Returns
    -------
    pd.DataFrame
        Yearly metrics: ['YoY Return', 'Std', 'Sharpe', 'Sortino', 'Calmar']
    """

    # Ensure datetime index
    returns = returns.copy()
    returns.index = pd.to_datetime(returns.index)

    # Detect frequency
    freq = pd.infer_freq(returns.index)
    print(freq)
    if freq is None:
        periods_per_year = 12   # fallback → assume monthly
    elif freq.startswith("M"):
        periods_per_year = 12
    elif freq.startswith("W"):
        periods_per_year = 52
    elif freq.startswith("D"):
        periods_per_year = 252
    else:
        periods_per_year = 12

    yearly = {}
    for year, r in returns.groupby(returns.index.year):
        if r.empty:
            continue

        # Stats
        mean_return = r.mean()
        std_return = (r -rf).std()
        downside = r[r < 0].std()

        # Cumulative equity curve (for Calmar)
        cumret = (1 + r).cumprod()
        peak = cumret.cummax()
        drawdown = (cumret - peak) / peak
        max_dd = drawdown.min()

        # Annualized metrics
        ann_return = (1 + mean_return) ** periods_per_year - 1
        ann_std = std_return * np.sqrt(periods_per_year)
        ann_downside = downside * np.sqrt(periods_per_year)

        sharpe = (ann_return - rf) / ann_std if ann_std != 0 else np.nan


        sortino = (ann_return - rf) / ann_downside if ann_downside != 0 else np.nan
        calmar = ann_return / abs(max_dd) if max_dd != 0 else np.nan

        # YoY return (realized)
        yoy_return = (1 + r).prod() - 1

        yearly[year] = {
            "YoY Return": yoy_return*100,
            "Std": ann_std*100,
            "Sharpe": sharpe,
            "Sortino": sortino,
            "Calmar": calmar,
        }

    return pd.DataFrame(yearly).T


yoy_performance_metrics(df_daily)

# yoy_performance_metrics(df_daily).to_csv(r"D:\OneDrive - Neo Group\Desktop\Strategies\covered_call\Strategy_Results\With_vol_top_20_without_hedge.csv")


formulate_results_long.to_csv("NIFTY_check_results.csv", index = False)

