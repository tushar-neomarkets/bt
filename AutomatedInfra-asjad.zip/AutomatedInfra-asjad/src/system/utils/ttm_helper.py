"""
ttm_helper.py
=============
Pure-function TTM (Time-to-Maturity) utility.

Implements fractional trading-day TTM with intraday resolution.

No Django dependency.
"""

import logging
from datetime import date, time, datetime, timedelta
from pathlib import Path
from typing import Optional

import pandas as pd

log = logging.getLogger(__name__)

# =============================================================================
# CALENDAR PATH
# =============================================================================

_CALENDAR_PATH = str(Path(__file__).with_name("Calendar-New.xlsx"))

# Module-level cache: populated only on a successful load.
# On failure we leave these as None so the next call retries.
_HOLIDAYS: Optional[dict[date, date]] = None
_EXTRAS: Optional[dict[date, date]] = None
_LOAD_FAILURES = 0
_MAX_LOAD_FAILURES = 5


# =============================================================================
# HOLIDAY LOADING
# =============================================================================

def _load_calendar() -> Optional[tuple[dict[date, date], dict[date, date]]]:
    """
    Load holidays and special (extra) trading days from Calendar-New.xlsx.

    Sheet "Holidays"  -> {holiday_date: announced_on_date}
    Sheet "Special"   -> {extra_date:   announced_on_date}

    Returns (holidays, extras) on success, or None on any failure
    (so the caller can decide whether to retry, raise, or degrade).
    """
    holidays: dict[date, date] = {}
    extras: dict[date, date] = {}

    try:
        xl = pd.ExcelFile(_CALENDAR_PATH)

        # ── Holidays sheet ─────────────────────────────────────────────────
        if "Holidays" in xl.sheet_names:
            df_h = xl.parse("Holidays")
            for _, row in df_h.iterrows():
                try:
                    hdate = pd.to_datetime(row["date"]).date()
                    announced = pd.to_datetime(row["announced_on"]).date()
                    holidays[hdate] = announced
                except Exception:
                    continue
        else:
            log.warning("Calendar-New.xlsx: 'Holidays' sheet not found.")

        # ── Special sheet ──────────────────────────────────────────────────
        if "Special" in xl.sheet_names:
            df_s = xl.parse("Special")
            for _, row in df_s.iterrows():
                try:
                    edate = pd.to_datetime(row["date"]).date()
                    announced = pd.to_datetime(row["announced_on"]).date()
                    extras[edate] = announced
                except Exception:
                    continue
        else:
            log.warning("Calendar-New.xlsx: 'Special' sheet not found.")

    except Exception as exc:
        log.error(f"Could not load Calendar-New.xlsx from '{_CALENDAR_PATH}': {exc}")
        return None

    return holidays, extras


def _get_holidays() -> tuple[dict[date, date], dict[date, date]]:
    """
    Return module-level cached (holidays, extras).

    Cache is populated only on a successful load.

    Failed loads return empty dicts for that call so TTM can still be
    computed. After _MAX_LOAD_FAILURES consecutive failures, the helper logs
    that it is calculating TTM without the calendar file and continues
    returning empty dicts instead of raising.
    """
    global _HOLIDAYS, _EXTRAS, _LOAD_FAILURES
    if _HOLIDAYS is not None and _EXTRAS is not None:
        return _HOLIDAYS, _EXTRAS

    result = _load_calendar()
    if result is None:
        _LOAD_FAILURES += 1
        if _LOAD_FAILURES >= _MAX_LOAD_FAILURES:
            log.error(
                f"TTM calendar load failed {_LOAD_FAILURES} consecutive times "
                f"from {_CALENDAR_PATH!r}. Calculating TTM without the calendar file."
            )
            return {}, {}
        log.warning(
            f"TTM calendar load failed ({_LOAD_FAILURES}/{_MAX_LOAD_FAILURES}); "
            "returning empty calendar for this call. Will retry on next call."
        )
        return {}, {}

    _HOLIDAYS, _EXTRAS = result
    _LOAD_FAILURES = 0
    return _HOLIDAYS, _EXTRAS


# =============================================================================
# CORE FUNCTIONS  (1:1 port from calendar_math.py)
# =============================================================================

def is_trading_day(
    trade_date: date,
    as_on: date,
    holidays: dict[date, date],
    extras: dict[date, date],
) -> bool:
    """Return True if trade_date is an active trading day as known on as_on."""
    extra_announced = extras.get(trade_date)
    if extra_announced is not None and extra_announced <= as_on:
        return True

    if trade_date.weekday() >= 5:          # Saturday=5, Sunday=6
        return False

    holiday_announced = holidays.get(trade_date)
    if holiday_announced is not None and holiday_announced <= as_on:
        return False

    return True


def trading_days(
    trade_date: date,
    expiry_date: date,
    holidays: dict[date, date],
    extras: dict[date, date],
) -> int:
    """Count active trading days in [trade_date, expiry_date)."""
    count = 0
    d = trade_date
    while d < expiry_date:
        if is_trading_day(d, as_on=trade_date, holidays=holidays, extras=extras):
            count += 1
        d += timedelta(days=1)
    return count


def dte(
    trade_date: date,
    expiry_date: date,
    holidays: dict[date, date],
    extras: dict[date, date],
    strict: bool = False,
) -> int:
    """
    Days-to-Expiry in trading days.

    Parameters
    ----------
    strict : if True, raises ValueError when trade_date is not a trading day.
    """
    if strict and not is_trading_day(trade_date, trade_date, holidays, extras):
        raise ValueError(f"trade_date: {trade_date} is not an active trading day")

    if expiry_date < trade_date:
        raise ValueError(f"expiry_date: {expiry_date} < trade_date: {trade_date}")

    if expiry_date == trade_date:
        return 0

    return trading_days(trade_date, expiry_date, holidays, extras)


def ttm(
    timestamp: datetime,
    expiry_date: date,
    holidays: Optional[dict[date, date]] = None,
    extras: Optional[dict[date, date]] = None,
    market_open_time: time = time(9, 15),
    market_close_time: time = time(15, 30),
    total_trading_seconds: int = 22500,   # 6h 15m in seconds
    strict: bool = False,
) -> float:
    """
    Fractional trading-day Time-to-Maturity with intraday resolution.

    When holidays / extras are None the module-level cached dicts are used.

    Returns
    -------
    float : fractional trading days remaining until expiry.
            Examples:
              - Expiry day, pre-open  -> 1.0
              - Expiry day at 12:00   -> ~0.47
              - 1 full trading day ahead, at close -> 1.0
    """
    if holidays is None or extras is None:
        _h, _e = _get_holidays()
        holidays = holidays if holidays is not None else _h
        extras = extras if extras is not None else _e

    trade_dt = timestamp.replace(tzinfo=None)
    trade_date = trade_dt.date()

    if strict and not is_trading_day(trade_date, trade_date, holidays, extras):
        raise ValueError(f"trade_date: {trade_date} is not an active trading day")

    if expiry_date < trade_date:
        raise ValueError(f"expiry_date: {expiry_date} < trade_date: {trade_date}")

    open_dt  = datetime.combine(trade_date, market_open_time)
    close_dt = datetime.combine(trade_date, market_close_time)

    # ── Same-day expiry ────────────────────────────────────────────────────
    if expiry_date == trade_date:
        if trade_dt <= open_dt:
            return 1.0
        seconds = max(0.0, (close_dt - trade_dt).total_seconds())
        seconds = min(seconds, float(total_trading_seconds))
        return seconds / total_trading_seconds

    # ── Future expiry ──────────────────────────────────────────────────────
    days = dte(trade_date, expiry_date, holidays, extras)

    seconds = max(0.0, (close_dt - trade_dt).total_seconds())

    if days == 0 and trade_dt < datetime.combine(expiry_date, market_open_time):
        seconds = float(total_trading_seconds)

    return days + (seconds / total_trading_seconds)


# =============================================================================
# TEST HELPER
# =============================================================================

def test_ttm(timestamp_str: Optional[str] = None, expiry_str: Optional[str] = None) -> None:
    """
    Compare old (naive calendar-days) vs new (fractional trading-day) TTM.

    Parameters
    ----------
    timestamp_str : e.g. "2025-04-09 11:30:00"  (defaults to now)
    expiry_str    : e.g. "2025-04-10"            (defaults to tomorrow)
    """
    now = datetime.now()
    tomorrow = (now + timedelta(days=1)).date()

    ts = datetime.strptime(timestamp_str, "%Y-%m-%d %H:%M:%S") if timestamp_str else now
    exp = date.fromisoformat(expiry_str) if expiry_str else tomorrow

    # Old calculation
    # old_ttm = max((exp - ts.date()).days, 1)

    # New calculation
    new_ttm = ttm(ts, exp)

    print(f"Timestamp : {ts}")
    print(f"Expiry    : {exp}")
    # print(f"Old TTM   : {old_ttm} (calendar days, floor=1)")
    print(f"TTM   : {new_ttm:.6f} (fractional trading days)")
    # print(f"Delta     : {new_ttm - old_ttm:+.6f}")


# =============================================================================
# CLI ENTRY POINT
# =============================================================================

if __name__ == "__main__":
    import sys

    logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")

    ts_arg  = sys.argv[1] if len(sys.argv) > 1 else None
    exp_arg = sys.argv[2] if len(sys.argv) > 2 else None

    test_ttm(ts_arg, exp_arg)
