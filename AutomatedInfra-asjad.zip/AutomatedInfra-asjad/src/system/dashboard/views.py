import re
import json
from datetime import datetime
from decimal import Decimal
from django.shortcuts import render, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.views.decorators.http import require_GET, require_POST
from django.http import JsonResponse
from django.db.models import Q
from django.db.models import Sum
from django.utils import timezone
from accounts.models import BrokerAccount
from accounts.services.pnl_calculator import AccountPnLCalculator
from accounts.brokers.handler import BrokerAccountHandler
from datafeed.models import DataFeedAccount
from datafeed.rest.handler import DataFeedHandler
from instruments.models import Instrument, BrokerInstrument
from orders.models import ParentOrder, BrokerOrder, StrategyAlert
from strategy.models import Strategy, StrategyPosition
from strategy.strategy_manager import strategy_manager


@login_required
def dashboard_home(request):
    """
    Renders the main dashboard list with accounts and strategies.
    """
    accounts = BrokerAccount.objects.filter(authorized_users__user=request.user)
    datafeed_accounts = DataFeedAccount.objects.filter(is_active=True)
    return render(request, 'dashboard/index.html', {
        'accounts': accounts,
        'datafeed_accounts': datafeed_accounts,
    })


@login_required
def account_detail(request, account_id):
    """
    Renders the detail page for a specific account.
    """
    account = get_object_or_404(BrokerAccount, id=account_id, authorized_users__user=request.user)

    context = {
        'account': account,
        'account_id': account_id
    }
    return render(request, 'dashboard/detail.html', context)


@login_required
def strategy_list(request):
    """
    Renders the strategy management page.
    """
    return render(request, 'dashboard/strategies.html')


def _avg_fill(parent_order):
    """Weighted-avg actual fill price across a parent's broker orders. None if no fills."""
    if not parent_order:
        return None
    bos = [bo for bo in parent_order.broker_orders.all()
           if bo.filled_quantity and bo.average_price]
    if not bos:
        return None
    qty = sum(bo.filled_quantity for bo in bos)
    return Decimal(str(sum(float(bo.average_price) * bo.filled_quantity for bo in bos) / qty))


def _traded_qty(parent_order):
    """Total executed quantity across a parent's broker orders (sum of base * multiplier per account)."""
    if not parent_order:
        return None
    total = sum((bo.quantity or 0) for bo in parent_order.broker_orders.all())
    return total or None


@login_required
def strategy_detail(request, strategy_id):
    """
    Renders the strategy detail page with open and today's closed positions.
    Prices and PnL are overridden in-memory with actual broker fills so the
    page reflects execution reality, not LTP-at-decision.
    """
    strategy = get_object_or_404(
        Strategy,
        id=strategy_id,
        authorized_users__user=request.user
    )

    # Check if strategy is running
    is_running = strategy_id in strategy_manager.running_strategies

    # Get open positions
    open_positions = list(StrategyPosition.objects.filter(
        strategy=strategy,
        status='OPEN'
    ).select_related('instrument').prefetch_related(
        'entry_parent_order__broker_orders'
    ).order_by('-entry_time'))

    # Get today's closed positions
    today = timezone.now().date()
    closed_positions = list(StrategyPosition.objects.filter(
        strategy=strategy,
        status='CLOSED',
        exit_time__date=today
    ).select_related('instrument').prefetch_related(
        'entry_parent_order__broker_orders',
        'exit_parent_order__broker_orders',
    ).order_by('-exit_time'))

    for pos in open_positions:
        traded = _traded_qty(pos.entry_parent_order)
        if traded is not None:
            pos.quantity = traded
        entry_fill = _avg_fill(pos.entry_parent_order)
        if entry_fill is not None:
            pos.entry_price = entry_fill
            if pos.last_price is not None:
                direction = 1 if pos.position_type == "LONG" else -1
                pos.unrealized_pnl = (pos.last_price - entry_fill) * pos.quantity * direction

    for pos in closed_positions:
        traded = _traded_qty(pos.entry_parent_order)
        if traded is not None:
            pos.quantity = traded
        entry_fill = _avg_fill(pos.entry_parent_order)
        exit_fill = _avg_fill(pos.exit_parent_order)
        if entry_fill is not None:
            pos.entry_price = entry_fill
        if exit_fill is not None:
            pos.exit_price = exit_fill
        if entry_fill is not None and exit_fill is not None:
            direction = 1 if pos.position_type == "LONG" else -1
            pos.realized_pnl = (exit_fill - entry_fill) * pos.quantity * direction

    # Roll up summaries from the in-memory (overridden) values
    open_pnl = sum((p.unrealized_pnl or 0) for p in open_positions)
    closed_pnl = sum((p.realized_pnl or 0) for p in closed_positions)
    total_pnl = open_pnl + closed_pnl

    alerts = list(
        StrategyAlert.objects.filter(strategy=strategy, dismissed_at__isnull=True)
        .select_related('broker_order')
        .order_by('-created_at')
    )

    context = {
        'strategy': strategy,
        'strategy_id': strategy_id,
        'is_running': is_running,
        'open_positions': open_positions,
        'closed_positions': closed_positions,
        'open_pnl': open_pnl,
        'closed_pnl': closed_pnl,
        'total_pnl': total_pnl,
        'alerts': alerts,
    }
    return render(request, 'dashboard/strategy_detail.html', context)


@login_required
@require_POST
def dismiss_strategy_alert(request, alert_id):
    """Mark a StrategyAlert as dismissed. Returns {success: True}."""
    alert = get_object_or_404(
        StrategyAlert, pk=alert_id,
        strategy__authorized_users__user=request.user,
    )
    alert.dismissed_at = timezone.now()
    alert.save(update_fields=['dismissed_at'])
    return JsonResponse({'success': True})


@login_required
def parent_orders_list(request):
    """
    Renders the parent orders page with today's orders.
    """
    today = timezone.now().date()

    # Get today's orders by default, with option to show all
    show_all = request.GET.get('all', '').lower() == 'true'

    if show_all:
        orders = ParentOrder.objects.all()
    else:
        orders = ParentOrder.objects.filter(created_at__date=today)

    orders = orders.select_related('strategy', 'instrument').order_by('-created_at')

    # Get summary stats
    total_orders = orders.count()
    completed_orders = orders.filter(status='COMPLETED').count()
    open_orders = orders.filter(status__in=['SUBMITTED', 'OPEN', 'PARTIALLY_FILLED']).count()
    failed_orders = orders.filter(status__in=['REJECTED', 'ERROR', 'CANCELLED']).count()

    context = {
        'orders': orders,
        'show_all': show_all,
        'total_orders': total_orders,
        'completed_orders': completed_orders,
        'open_orders': open_orders,
        'failed_orders': failed_orders,
    }
    return render(request, 'dashboard/parent_orders.html', context)


@login_required
def broker_orders_list(request):
    """
    Renders the broker orders page with today's orders.
    """
    today = timezone.now().date()

    # Get today's orders by default, with option to show all
    show_all = request.GET.get('all', '').lower() == 'true'

    if show_all:
        orders = BrokerOrder.objects.all()
    else:
        orders = BrokerOrder.objects.filter(created_at__date=today)

    orders = orders.select_related(
        'parent_order',
        'parent_order__strategy',
        'parent_order__instrument',
        'broker_account',
        'broker_instrument'
    ).order_by('-created_at')

    # Get summary stats
    total_orders = orders.count()
    completed_orders = orders.filter(status='COMPLETED').count()
    open_orders = orders.filter(status__in=['SUBMITTED', 'OPEN']).count()
    failed_orders = orders.filter(status__in=['REJECTED', 'ERROR', 'CANCELLED']).count()

    context = {
        'orders': orders,
        'show_all': show_all,
        'total_orders': total_orders,
        'completed_orders': completed_orders,
        'open_orders': open_orders,
        'failed_orders': failed_orders,
    }
    return render(request, 'dashboard/broker_orders.html', context)


@login_required
def account_pnl(request, account_id):
    """
    Renders the account-level PnL page showing P&L calculated from
    actual BrokerOrder fill prices for this specific account.
    """
    account = get_object_or_404(
        BrokerAccount,
        id=account_id,
        authorized_users__user=request.user
    )

    # Get LTP provider using REST-based DataFeedHandler
    ltp_provider = None
    try:
        from datafeed.rest.handler import DataFeedHandler

        datafeed_account = DataFeedAccount.objects.filter(is_active=True).first()
        if datafeed_account and not datafeed_account.is_token_expired:
            handler = DataFeedHandler(datafeed_account)

            def fetch_ltp(instruments: list) -> dict:
                if not instruments:
                    return {}
                try:
                    response = handler.get_multiple_ltp(instruments)
                    if response and 'data' in response:
                        ltp_list = response['data'].get('ltp_list', [])
                        return {
                            item.get('instrument_token'): item.get('ltp')
                            for item in ltp_list
                            if item.get('instrument_token') and item.get('ltp')
                        }
                except Exception:
                    pass
                return {}

            ltp_provider = fetch_ltp
    except Exception:
        pass

    # Calculate PnL using actual fill prices
    calculator = AccountPnLCalculator(
        broker_account=account,
        ltp_provider=ltp_provider
    )
    result = calculator.calculate_pnl()

    # Convert to template-friendly format
    pnl_data = {
        'account_id': result.account_id,
        'account_name': result.account_name,
        'total_pnl': float(result.total_pnl),
        'total_open_pnl': float(result.total_open_pnl),
        'total_closed_pnl': float(result.total_closed_pnl),
        'last_updated': result.last_updated,
        'strategies': []
    }

    for strategy in result.strategies:
        strategy_data = {
            'strategy_id': strategy.strategy_id,
            'strategy_code': strategy.strategy_code,
            'strategy_name': strategy.strategy_name,
            'open_pnl': float(strategy.open_pnl),
            'closed_pnl': float(strategy.closed_pnl),
            'total_pnl': float(strategy.total_pnl),
            'positions': []
        }

        for pos in strategy.positions:
            position_data = {
                'instrument_token': pos.instrument_token,
                'instrument': pos.tradingsymbol,
                'exchange': pos.exchange,
                'position_type': pos.position_type,
                'quantity': pos.quantity,
                'entry_avg_price': float(pos.entry_avg_price),
                'current_ltp': float(pos.current_ltp) if pos.current_ltp else None,
                'unrealized_pnl': float(pos.unrealized_pnl),
                'realized_pnl': float(pos.realized_pnl),
                'status': pos.status
            }
            strategy_data['positions'].append(position_data)

        pnl_data['strategies'].append(strategy_data)

    context = {
        'account': account,
        'account_id': account_id,
        'pnl_data': pnl_data,
    }
    return render(request, 'dashboard/account_pnl.html', context)


# =============================================================================
# Manual Order Placement Views
# =============================================================================

SEGMENT_EXCHANGE_MAP = {
    'EQ': ['NSE', 'BSE'],
    'OPTIDX': ['NFO', 'BFO'],
    'FUTIDX': ['NFO', 'BFO'],
    'OPTSTK': ['NFO'],
    'FUTSTK': ['NFO'],
    'FUTCOM': ['MCX'],
    'OPTCOM': ['MCX'],
}

EXCHANGE_SEGMENT_MAP = {
    'NSE': 'NSECM',
    'BSE': 'BSECM',
    'NFO': 'NSEFO',
    'BFO': 'BSEFO',
    'MCX': 'MCXFO',
}


def _extract_underlying(tradingsymbol: str) -> str:
    """Extract underlying from tradingsymbol for derivatives."""
    # Pattern: NIFTY23JAN24000CE → NIFTY
    # BANKNIFTY23JAN50000PE → BANKNIFTY
    # RELIANCE24JAN2500CE → RELIANCE
    match = re.match(r'^([A-Z&-]+)\d{2}[A-Z]{3}', tradingsymbol)
    if match:
        return match.group(1)
    return None


@login_required
def manual_order_page(request):
    """Renders the manual order placement page."""
    accounts = BrokerAccount.objects.filter(
        authorized_users__user=request.user,
        is_active=True
    ).select_related('broker')

    return render(request, 'dashboard/manual_order.html', {
        'accounts': accounts,
    })


@login_required
@require_GET
def api_instrument_segments(request):
    """GET /dashboard/api/instruments/segments/ - Returns distinct active segments."""
    segments = Instrument.objects.filter(
        is_active=True
    ).values_list('segment', flat=True).distinct()

    # Filter to relevant segments (exclude index types)
    relevant_segments = [s for s in segments if s not in ['NSE_INDEX', 'BSE_INDEX']]

    return JsonResponse({
        'status': 'success',
        'data': {'segments': sorted(relevant_segments)}
    })


@login_required
@require_GET
def api_instrument_exchanges(request):
    """GET /dashboard/api/instruments/exchanges/?segment=OPTIDX - Returns exchanges for segment."""
    segment = request.GET.get('segment')
    if not segment:
        return JsonResponse({'status': 'error', 'message': 'segment required'}, status=400)

    # Use predefined mapping for consistency
    exchanges = SEGMENT_EXCHANGE_MAP.get(segment, [])

    # Also verify from DB
    db_exchanges = list(Instrument.objects.filter(
        segment=segment,
        is_active=True
    ).values_list('exchange', flat=True).distinct())

    # Return intersection of predefined and actual
    valid_exchanges = [e for e in exchanges if e in db_exchanges]

    return JsonResponse({
        'status': 'success',
        'data': {'exchanges': valid_exchanges}
    })


@login_required
@require_GET
def api_instrument_symbols(request):
    """GET /dashboard/api/instruments/symbols/?segment=EQ&exchange=NSE - Returns symbols/underlyings."""
    segment = request.GET.get('segment')
    exchange = request.GET.get('exchange')

    if not segment or not exchange:
        return JsonResponse({'status': 'error', 'message': 'segment and exchange required'}, status=400)

    instruments = Instrument.objects.filter(
        segment=segment,
        exchange=exchange,
        is_active=True
    )

    if segment == 'EQ':
        # For equities, return actual instruments
        symbols = list(instruments.values(
            'instrument_token', 'tradingsymbol', 'name', 'lot_size'
        ).order_by('tradingsymbol')[:500])  # Limit for performance

        return JsonResponse({
            'status': 'success',
            'data': {
                'symbols': symbols,
                'is_equity': True
            }
        })
    else:
        # For derivatives, extract unique underlyings
        underlyings = set()
        for inst in instruments.values_list('tradingsymbol', flat=True):
            underlying = _extract_underlying(inst)
            if underlying:
                underlyings.add(underlying)

        return JsonResponse({
            'status': 'success',
            'data': {
                'symbols': sorted(list(underlyings)),
                'is_equity': False
            }
        })


@login_required
@require_GET
def api_instrument_search(request):
    """GET /dashboard/api/instruments/search/?segment=EQ&exchange=NSE&q=INFY - Typeahead search for EQ instruments."""
    segment = request.GET.get('segment')
    exchange = request.GET.get('exchange')
    q = request.GET.get('q', '').strip().upper()

    if not segment or not exchange:
        return JsonResponse({'status': 'error', 'message': 'segment and exchange required'}, status=400)

    if len(q) < 2:
        return JsonResponse({'status': 'success', 'data': {'instruments': []}})

    instruments = list(
        Instrument.objects.filter(
            segment=segment,
            exchange=exchange,
            is_active=True
        ).filter(
            Q(tradingsymbol__istartswith=q) | Q(name__icontains=q)
        ).values('instrument_token', 'tradingsymbol', 'name', 'lot_size')
        .order_by('tradingsymbol')[:20]
    )

    return JsonResponse({'status': 'success', 'data': {'instruments': instruments}})


@login_required
@require_GET
def api_instrument_expiries(request):
    """GET /dashboard/api/instruments/expiries/?segment=OPTIDX&exchange=NFO&underlying=NIFTY"""
    segment = request.GET.get('segment')
    exchange = request.GET.get('exchange')
    underlying = request.GET.get('underlying')

    if not all([segment, exchange, underlying]):
        return JsonResponse({'status': 'error', 'message': 'segment, exchange, underlying required'}, status=400)

    # Get distinct expiries for this underlying
    expiries = Instrument.objects.filter(
        segment=segment,
        exchange=exchange,
        tradingsymbol__startswith=underlying,
        is_active=True,
        expiry__isnull=False
    ).values_list('expiry', flat=True).distinct().order_by('expiry')

    # Format expiries
    expiry_list = [
        {'value': exp.isoformat(), 'display': exp.strftime('%d %b %Y')}
        for exp in expiries if exp
    ]

    return JsonResponse({
        'status': 'success',
        'data': {'expiries': expiry_list}
    })


@login_required
@require_GET
def api_instrument_strikes(request):
    """GET /dashboard/api/instruments/strikes/?segment=OPTIDX&exchange=NFO&underlying=NIFTY&expiry=2024-01-25"""
    segment = request.GET.get('segment')
    exchange = request.GET.get('exchange')
    underlying = request.GET.get('underlying')
    expiry = request.GET.get('expiry')

    if not all([segment, exchange, underlying, expiry]):
        return JsonResponse({'status': 'error', 'message': 'all params required'}, status=400)

    try:
        expiry_date = datetime.strptime(expiry, '%Y-%m-%d').date()
    except ValueError:
        return JsonResponse({'status': 'error', 'message': 'Invalid expiry format'}, status=400)

    # For options, return strikes with option types
    if segment in ['OPTIDX', 'OPTSTK', 'OPTCOM']:
        instruments = Instrument.objects.filter(
            segment=segment,
            exchange=exchange,
            tradingsymbol__startswith=underlying,
            expiry=expiry_date,
            is_active=True,
            instrument_type__in=['CE', 'PE']
        ).values(
            'instrument_token', 'tradingsymbol', 'strike',
            'instrument_type', 'lot_size'
        ).order_by('strike', 'instrument_type')

        # Group by strike
        strikes_map = {}
        for inst in instruments:
            strike = float(inst['strike']) if inst['strike'] else 0
            if strike not in strikes_map:
                strikes_map[strike] = {'strike': strike, 'CE': None, 'PE': None}
            strikes_map[strike][inst['instrument_type']] = {
                'instrument_token': inst['instrument_token'],
                'tradingsymbol': inst['tradingsymbol'],
                'lot_size': inst['lot_size']
            }

        return JsonResponse({
            'status': 'success',
            'data': {
                'strikes': list(strikes_map.values()),
                'is_option': True
            }
        })
    else:
        # For futures, return the single instrument
        instrument = Instrument.objects.filter(
            segment=segment,
            exchange=exchange,
            tradingsymbol__startswith=underlying,
            expiry=expiry_date,
            instrument_type='FUT',
            is_active=True
        ).values(
            'instrument_token', 'tradingsymbol', 'lot_size'
        ).first()

        return JsonResponse({
            'status': 'success',
            'data': {
                'instrument': instrument,
                'is_option': False
            }
        })


@login_required
@require_POST
def api_verify_order(request):
    """POST /dashboard/api/orders/verify/ - Fetches current quote for instrument."""
    try:
        data = json.loads(request.body)
    except json.JSONDecodeError:
        return JsonResponse({'status': 'error', 'message': 'Invalid JSON'}, status=400)

    instrument_token = data.get('instrument_token')
    if not instrument_token:
        return JsonResponse({'status': 'error', 'message': 'instrument_token required'}, status=400)

    try:
        instrument = Instrument.objects.get(instrument_token=int(instrument_token))
    except Instrument.DoesNotExist:
        return JsonResponse({'status': 'error', 'message': 'Instrument not found'}, status=404)

    # Get active datafeed account
    datafeed_account = DataFeedAccount.objects.filter(is_active=True).first()
    if not datafeed_account:
        return JsonResponse({'status': 'error', 'message': 'No active datafeed account'}, status=503)

    if datafeed_account.is_token_expired:
        return JsonResponse({'status': 'error', 'message': 'Datafeed token expired'}, status=401)

    try:
        handler = DataFeedHandler(datafeed_account)
        result = handler.get_single_quote(instrument)
        quote = result.get('data', {}).get('quote', {})

        return JsonResponse({
            'status': 'success',
            'data': {
                'instrument_token': instrument.instrument_token,
                'tradingsymbol': instrument.tradingsymbol,
                'exchange': instrument.exchange,
                'lot_size': instrument.lot_size,
                'tick_size': float(instrument.tick_size),
                'ltp': quote.get('ltp'),
                'bid': quote.get('best_bid_price'),
                'bid_qty': quote.get('best_bid_qty'),
                'ask': quote.get('best_ask_price'),
                'ask_qty': quote.get('best_ask_qty'),
                'open': quote.get('open'),
                'high': quote.get('high'),
                'low': quote.get('low'),
                'close': quote.get('close'),
                'volume': quote.get('volume'),
            }
        })
    except Exception as e:
        return JsonResponse({'status': 'error', 'message': str(e)}, status=500)


@login_required
@require_POST
def api_place_order(request):
    """POST /dashboard/api/orders/place/ - Places an order via BrokerAccountHandler."""
    try:
        data = json.loads(request.body)
    except json.JSONDecodeError:
        return JsonResponse({'status': 'error', 'message': 'Invalid JSON'}, status=400)

    # Required fields
    account_id = data.get('account_id')
    instrument_token = data.get('instrument_token')
    order_side = data.get('order_side')
    order_type = data.get('order_type')
    quantity = data.get('quantity')
    product_type = data.get('product_type', 'NRML')

    # Conditional fields
    limit_price = data.get('limit_price')
    trigger_price = data.get('trigger_price')

    # Validate required fields
    if not all([account_id, instrument_token, order_side, order_type, quantity]):
        return JsonResponse({
            'status': 'error',
            'message': 'account_id, instrument_token, order_side, order_type, quantity required'
        }, status=400)

    # Validate account access
    try:
        account = BrokerAccount.objects.get(
            id=account_id,
            authorized_users__user=request.user,
            is_active=True
        )
    except BrokerAccount.DoesNotExist:
        return JsonResponse({'status': 'error', 'message': 'Account not found or access denied'}, status=403)

    if account.is_token_expired:
        return JsonResponse({'status': 'error', 'message': 'Broker token expired'}, status=401)

    # Get instrument
    try:
        instrument = Instrument.objects.get(instrument_token=int(instrument_token))
    except Instrument.DoesNotExist:
        return JsonResponse({'status': 'error', 'message': 'Instrument not found'}, status=404)

    # Get broker instrument mapping
    broker_inst = BrokerInstrument.get_by_instrument_and_broker(
        instrument.instrument_token,
        account.broker.broker_name.upper()
    )
    if not broker_inst:
        return JsonResponse({
            'status': 'error',
            'message': f'No broker mapping for {instrument.tradingsymbol} on {account.broker.broker_name}'
        }, status=404)

    # Map exchange to broker exchange segment
    exchange_segment = EXCHANGE_SEGMENT_MAP.get(instrument.exchange, instrument.exchange)

    # Build order params
    order_params = {
        'exchangeSegment': exchange_segment,
        'exchangeInstrumentID': int(broker_inst.broker_token),
        'productType': product_type,
        'orderType': order_type,
        'orderSide': order_side,
        'timeInForce': 'DAY',
        'disclosedQuantity': 0,
        'orderQuantity': int(quantity),
        'orderUniqueIdentifier': f'MANUAL_{request.user.username[:10]}'
    }

    # Add price fields based on order type
    if order_type in ['LIMIT', 'STOPLIMIT']:
        if not limit_price:
            return JsonResponse({'status': 'error', 'message': 'limit_price required for LIMIT orders'}, status=400)
        order_params['limitPrice'] = float(limit_price)

    if order_type in ['STOPLIMIT', 'STOPMARKET']:
        if not trigger_price:
            return JsonResponse({'status': 'error', 'message': 'trigger_price required for SL orders'}, status=400)
        order_params['stopPrice'] = float(trigger_price)

    # Place order
    try:
        handler = BrokerAccountHandler(account)
        result = handler.place_order(order_params)

        return JsonResponse({
            'status': 'success',
            'message': 'Order placed successfully',
            'data': result
        })
    except Exception as e:
        return JsonResponse({'status': 'error', 'message': str(e)}, status=500)


@login_required
@require_POST
def api_modify_order(request):
    """POST /dashboard/api/orders/modify/ - Modifies a BrokerOrder's price."""
    from decimal import Decimal, InvalidOperation
    from orders.order_manager import order_manager

    try:
        data = json.loads(request.body)
    except json.JSONDecodeError:
        return JsonResponse({'status': 'error', 'message': 'Invalid JSON'}, status=400)

    # Required fields
    order_id = data.get('order_id')
    new_price = data.get('new_price')

    # Optional fields
    new_trigger_price = data.get('new_trigger_price')

    if not order_id:
        return JsonResponse({'status': 'error', 'message': 'order_id required'}, status=400)

    if new_price is None:
        return JsonResponse({'status': 'error', 'message': 'new_price required'}, status=400)

    # Get the BrokerOrder
    try:
        broker_order = BrokerOrder.objects.select_related(
            'broker_account', 'broker_account__broker', 'parent_order__instrument'
        ).get(order_id=order_id)
    except BrokerOrder.DoesNotExist:
        return JsonResponse({'status': 'error', 'message': 'Order not found'}, status=404)

    # Validate user has access to this order's account
    if not broker_order.broker_account.authorized_users.filter(user=request.user).exists():
        return JsonResponse({'status': 'error', 'message': 'Access denied'}, status=403)

    # Validate order can be modified (not in terminal state)
    if broker_order.status in ['COMPLETED', 'CANCELLED', 'REJECTED', 'ERROR']:
        return JsonResponse({
            'status': 'error',
            'message': f'Cannot modify order with status: {broker_order.status}'
        }, status=400)

    # Validate order type can be modified
    if broker_order.order_type not in ['LIMIT', 'SL']:
        return JsonResponse({
            'status': 'error',
            'message': f'Cannot modify order type: {broker_order.order_type}'
        }, status=400)

    # Validate account token
    if broker_order.broker_account.is_token_expired:
        return JsonResponse({'status': 'error', 'message': 'Broker token expired'}, status=401)

    # Parse prices
    try:
        price_decimal = Decimal(str(new_price))
        trigger_decimal = Decimal(str(new_trigger_price)) if new_trigger_price else None
    except (InvalidOperation, ValueError):
        return JsonResponse({'status': 'error', 'message': 'Invalid price format'}, status=400)

    # Validate price is positive
    if price_decimal <= 0:
        return JsonResponse({'status': 'error', 'message': 'Price must be positive'}, status=400)

    # Optionally get current quote for history tracking
    quote_data = None
    try:
        datafeed_account = DataFeedAccount.objects.filter(is_active=True).first()
        if datafeed_account and not datafeed_account.is_token_expired:
            handler = DataFeedHandler(datafeed_account)
            instrument = broker_order.parent_order.instrument
            result = handler.get_single_quote(instrument)
            quote = result.get('data', {}).get('quote', {})
            if quote:
                quote_data = {
                    'ltp': quote.get('ltp'),
                    'best_bid_price': quote.get('best_bid_price'),
                    'best_bid_qty': quote.get('best_bid_qty'),
                    'best_ask_price': quote.get('best_ask_price'),
                    'best_ask_qty': quote.get('best_ask_qty'),
                    'total_buy_qty': quote.get('total_buy_qty'),
                    'total_sell_qty': quote.get('total_sell_qty'),
                    'volume': quote.get('volume'),
                }
    except Exception:
        pass  # Quote data is optional

    # Perform the modification
    success, message = order_manager.modify_broker_order(
        broker_order=broker_order,
        new_price=price_decimal,
        new_trigger_price=trigger_decimal,
        quote_data=quote_data
    )

    if success:
        # Refresh order from DB to get updated values
        broker_order.refresh_from_db()
        return JsonResponse({
            'status': 'success',
            'message': message,
            'data': {
                'order_id': broker_order.order_id,
                'new_price': float(broker_order.price) if broker_order.price else None,
                'new_trigger_price': float(broker_order.trigger_price) if broker_order.trigger_price else None,
                'modification_count': len(broker_order.modification_history) if broker_order.modification_history else 0
            }
        })
    else:
        return JsonResponse({'status': 'error', 'message': message}, status=400)


@login_required
@require_POST
def api_modify_broker_order_direct(request):
    """
    POST /dashboard/api/orders/modify-direct/
    Modifies an order directly via broker API (for orders from live orderbook).
    """
    try:
        data = json.loads(request.body)
    except json.JSONDecodeError:
        return JsonResponse({'status': 'error', 'message': 'Invalid JSON'}, status=400)

    # Required fields
    account_id = data.get('account_id')
    app_order_id = data.get('app_order_id')
    new_price = data.get('new_price')

    # Optional fields
    new_trigger_price = data.get('new_trigger_price')
    order_quantity = data.get('order_quantity')
    order_type = data.get('order_type', 'LIMIT')
    product_type = data.get('product_type', 'NRML')

    if not account_id:
        return JsonResponse({'status': 'error', 'message': 'account_id required'}, status=400)

    if not app_order_id:
        return JsonResponse({'status': 'error', 'message': 'app_order_id required'}, status=400)

    if new_price is None:
        return JsonResponse({'status': 'error', 'message': 'new_price required'}, status=400)

    # Validate account access
    try:
        account = BrokerAccount.objects.get(
            id=account_id,
            authorized_users__user=request.user,
            is_active=True
        )
    except BrokerAccount.DoesNotExist:
        return JsonResponse({'status': 'error', 'message': 'Account not found or access denied'}, status=403)

    if account.is_token_expired:
        return JsonResponse({'status': 'error', 'message': 'Broker token expired'}, status=401)

    # Build modification parameters
    modify_params = {
        'orderType': order_type,
        'productType': product_type,
        'limitPrice': float(new_price),
        'stopPrice': float(new_trigger_price) if new_trigger_price else 0.0,
        'disclosedQuantity': 0,
        'timeInForce': 'DAY',
    }

    if order_quantity:
        modify_params['orderQuantity'] = int(order_quantity)

    try:
        handler = BrokerAccountHandler(account)
        result = handler.modify_order(app_order_id, modify_params)

        return JsonResponse({
            'status': 'success',
            'message': 'Order modified successfully',
            'data': result
        })
    except Exception as e:
        return JsonResponse({'status': 'error', 'message': str(e)}, status=500)


@login_required
@require_POST
def api_cancel_broker_order_direct(request):
    """
    POST /dashboard/api/orders/cancel-direct/
    Cancels an order directly via broker API (for orders from live orderbook).
    """
    try:
        data = json.loads(request.body)
    except json.JSONDecodeError:
        return JsonResponse({'status': 'error', 'message': 'Invalid JSON'}, status=400)

    account_id = data.get('account_id')
    app_order_id = data.get('app_order_id')

    if not account_id:
        return JsonResponse({'status': 'error', 'message': 'account_id required'}, status=400)

    if not app_order_id:
        return JsonResponse({'status': 'error', 'message': 'app_order_id required'}, status=400)

    try:
        account = BrokerAccount.objects.get(
            id=account_id,
            authorized_users__user=request.user,
            is_active=True
        )
    except BrokerAccount.DoesNotExist:
        return JsonResponse({'status': 'error', 'message': 'Account not found or access denied'}, status=403)

    if account.is_token_expired:
        return JsonResponse({'status': 'error', 'message': 'Broker token expired'}, status=401)

    try:
        handler = BrokerAccountHandler(account)
        result = handler.cancel_order(app_order_id)

        return JsonResponse({
            'status': 'success',
            'message': 'Order cancelled successfully',
            'data': result
        })
    except Exception as e:
        return JsonResponse({'status': 'error', 'message': str(e)}, status=500)