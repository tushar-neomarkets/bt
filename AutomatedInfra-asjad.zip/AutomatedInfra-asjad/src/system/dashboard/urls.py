from django.urls import path
from dashboard.views import (
    dashboard_home, account_detail, strategy_list, strategy_detail,
    parent_orders_list, broker_orders_list, account_pnl,
    manual_order_page, api_instrument_segments, api_instrument_exchanges,
    api_instrument_symbols, api_instrument_search, api_instrument_expiries, api_instrument_strikes,
    api_verify_order, api_place_order, api_modify_order, api_modify_broker_order_direct,
    api_cancel_broker_order_direct, dismiss_strategy_alert,
)

urlpatterns = [
    path('', dashboard_home, name='dashboard-home'),
    path('accounts/<int:account_id>/', account_detail, name='dashboard-detail'),
    path('accounts/<int:account_id>/pnl/', account_pnl, name='dashboard-account-pnl'),
    path('strategies/', strategy_list, name='dashboard-strategies'),
    path('strategies/<int:strategy_id>/', strategy_detail, name='dashboard-strategy-detail'),
    path('alerts/<int:alert_id>/dismiss/', dismiss_strategy_alert, name='dashboard-alert-dismiss'),
    path('orders/', parent_orders_list, name='dashboard-parent-orders'),
    path('orders/broker/', broker_orders_list, name='dashboard-broker-orders'),
    # Manual order placement
    path('orders/manual/', manual_order_page, name='dashboard-manual-order'),
    # Instrument filter APIs (under dashboard namespace)
    path('dashboard/api/instruments/segments/', api_instrument_segments, name='api-instrument-segments'),
    path('dashboard/api/instruments/exchanges/', api_instrument_exchanges, name='api-instrument-exchanges'),
    path('dashboard/api/instruments/symbols/', api_instrument_symbols, name='api-instrument-symbols'),
    path('dashboard/api/instruments/search/', api_instrument_search, name='api-instrument-search'),
    path('dashboard/api/instruments/expiries/', api_instrument_expiries, name='api-instrument-expiries'),
    path('dashboard/api/instruments/strikes/', api_instrument_strikes, name='api-instrument-strikes'),
    # Order APIs (under dashboard namespace)
    path('dashboard/api/orders/verify/', api_verify_order, name='api-verify-order'),
    path('dashboard/api/orders/place/', api_place_order, name='api-place-order'),
    path('dashboard/api/orders/modify/', api_modify_order, name='api-modify-order'),
    path('dashboard/api/orders/modify-direct/', api_modify_broker_order_direct, name='api-modify-order-direct'),
    path('dashboard/api/orders/cancel-direct/', api_cancel_broker_order_direct, name='api-cancel-order-direct'),
]