from django.core.cache import cache
from django.utils import timezone
from django.db import transaction

from instruments.models import Instrument,BrokerInstrument
import datetime as dt
CACHE_KEY_LAST_RUN = 'instruments_last_run_date'
BATCH_SIZE = 5000

def has_run_today():
    """
    Check if the script has already run today.
    Returns: (bool, datetime|None) - (has_run, last_run_time)
    """
    last_run = cache.get(CACHE_KEY_LAST_RUN)

    if last_run:
        last_run_date = last_run.date() if isinstance(last_run, dt.datetime) else last_run
        today = timezone.now().date()

        if last_run_date == today:
            print(f"✓ Script already ran today at {last_run}")
            return True, last_run

    return False, last_run

def mark_as_run():
    """Mark the script as run today."""
    now = timezone.now()
    # Cache for 24 hours
    cache.set(CACHE_KEY_LAST_RUN, now, timeout=86400)
    print(f"✓ Marked script as run at {now}")


def deactivate_expired_instruments():
    """Soft-delete expired instruments, skipping any still held by an open StrategyPosition.

    Hard deletes cascade to BrokerInstrument and SET_NULL the instrument FK on
    StrategyPosition / ParentOrder / BrokerOrder, which makes open positions appear
    blank in the UI. Always soft-delete here, and never deactivate something we still hold.
    """
    print("\n=== Deactivating Expired Instruments ===")

    from strategy.models import StrategyPosition  # local import avoids app-load cycles

    today = timezone.now().date()
    held_tokens = set(
        StrategyPosition.objects.exclude(quantity=0)
                                .values_list('instrument_id', flat=True)
    )

    n = Instrument.objects.filter(expiry__lt=today, is_active=True)\
                          .exclude(instrument_token__in=held_tokens)\
                          .update(is_active=False)

    print(f"✓ Deactivated {n} expired instruments (skipped {len(held_tokens)} held)")
    return n

def sync_instruments(df, source_name):
    """
        Sync instruments from DataFrame to database.

        Args:
            df: DataFrame with columns matching Instrument model fields
            source_name: Name of the data source (for logging)

        Expected DataFrame columns:
            - instrument_token (required)
            - exchange_token
            - tradingsymbol (required)
            - name
            - exchange (required)
            - segment (required)
            - instrument_type (required)
            - expiry
            - strike
            - lot_size
            - tick_size
            - freeze_quantity
    """
    print(f"\n=== Syncing Instruments from {source_name} ===")
    print(f"Total records to process: {len(df)}")

    # Convert DataFrame to dict records
    records = df.to_dict('records')

    # Get existing instrument tokens
    existing_tokens = set(
        Instrument.objects.values_list('instrument_token', flat=True)
    )

    to_create = []
    to_update = []

    for record in records:
        token = record['instrument_token']

        if token in existing_tokens:
            to_update.append(record)
        else:
            to_create.append(record)

    print(f"New instruments to create: {len(to_create)}")
    print(f"Existing instruments to update: {len(to_update)}")

    created_count = 0
    if to_create:
        with transaction.atomic():
            for i in range(0, len(to_create), BATCH_SIZE):
                batch = to_create[i:i + BATCH_SIZE]
                instruments = [
                    Instrument(
                        instrument_token=r['instrument_token'],
                        exchange_token=r.get('exchange_token'),
                        tradingsymbol=r['tradingsymbol'],
                        name=r.get('name'),
                        exchange=r['exchange'],
                        segment=r['segment'],
                        instrument_type=r['instrument_type'],
                        expiry=r.get('expiry'),
                        strike=r.get('strike'),
                        lot_size=r.get('lot_size', 1),
                        tick_size=r.get('tick_size', 0.05),
                        freeze_quantity=r.get('freeze_quantity'),
                        is_active=True
                    )
                    for r in batch
                ]
                Instrument.objects.bulk_create(instruments, batch_size=BATCH_SIZE)
                created_count += len(instruments)
                print(f"  Created batch: {created_count}/{len(to_create)}")
    updated_count = 0
    if to_update:
        with transaction.atomic():
            for i in range(0, len(to_update), BATCH_SIZE):
                batch = to_update[i:i + BATCH_SIZE]

                # Fetch existing instruments
                tokens = [r['instrument_token'] for r in batch]
                existing = {
                    inst.instrument_token: inst
                    for inst in Instrument.objects.filter(instrument_token__in=tokens)
                }

                # Update fields
                to_bulk_update = []
                for r in batch:
                    inst = existing.get(r['instrument_token'])
                    if inst:
                        inst.exchange_token = r.get('exchange_token')
                        inst.tradingsymbol = r['tradingsymbol']
                        inst.name = r.get('name')
                        inst.exchange = r['exchange']
                        inst.segment = r['segment']
                        inst.instrument_type = r['instrument_type']
                        inst.expiry = r.get('expiry')
                        inst.strike = r.get('strike')
                        inst.lot_size = r.get('lot_size', 1)
                        inst.tick_size = r.get('tick_size', 0.05)
                        inst.freeze_quantity = r.get('freeze_quantity')
                        inst.is_active = True
                        to_bulk_update.append(inst)

                Instrument.objects.bulk_update(
                    to_bulk_update,
                    fields=[
                        'exchange_token', 'tradingsymbol', 'name', 'exchange',
                        'segment', 'instrument_type', 'expiry', 'strike',
                        'lot_size', 'tick_size', 'freeze_quantity', 'is_active'
                    ],
                    batch_size=BATCH_SIZE
                )
                updated_count += len(to_bulk_update)
                print(f"  Updated batch: {updated_count}/{len(to_update)}")

    print(f"✓ Instruments synced: {created_count} created, {updated_count} updated")
    return created_count, updated_count


def sync_broker_instruments(df, broker_name):
    """
    Sync broker instruments from DataFrame to database.

    Args:
        df: DataFrame with broker instrument data
        broker_name: Name of the broker (ZERODHA, UPSTOX, etc.)

    Expected DataFrame columns:
        - broker_token (required)
        - broker_exchange (required)
        - broker_symbol
        - instrument_token (required) - maps to Instrument
    """
    print(f"\n=== Syncing Broker Instruments for {broker_name} ===")
    print(f"Total records to process: {len(df)}")

    # Convert DataFrame to dict records
    records = df.to_dict('records')

    # Get existing broker instruments
    existing = {}
    broker_instruments = BrokerInstrument.objects.filter(
        broker_name=broker_name
    ).values('broker_token', 'broker_exchange', 'id', 'instrument_id')

    for bi in broker_instruments:
        key = (bi['broker_token'], bi['broker_exchange'])
        existing[key] = (bi['id'], bi['instrument_id'])

    # Get valid instrument tokens
    valid_instrument_tokens = set(
        Instrument.objects.filter(is_active=True).values_list('instrument_token', flat=True)
    )

    to_create = []
    to_update = []

    for record in records:
        broker_token = record['broker_token']
        broker_exchange = record['broker_exchange']
        instrument_token = record['instrument_token']

        # Skip if instrument doesn't exist
        if instrument_token not in valid_instrument_tokens:
            continue

        key = (broker_token, broker_exchange)

        if key in existing:
            # Check if instrument mapping changed
            existing_id, existing_inst_token = existing[key]
            if existing_inst_token != instrument_token:
                to_update.append((existing_id, record))
        else:
            to_create.append(record)

    print(f"New broker instruments to create: {len(to_create)}")
    print(f"Existing broker instruments to update: {len(to_update)}")

    # Bulk create new broker instruments
    created_count = 0
    if to_create:
        with transaction.atomic():
            for i in range(0, len(to_create), BATCH_SIZE):
                batch = to_create[i:i + BATCH_SIZE]
                broker_instruments = [
                    BrokerInstrument(
                        broker_name=broker_name,
                        broker_token=r['broker_token'],
                        broker_exchange=r['broker_exchange'],
                        broker_symbol=r.get('broker_symbol'),
                        instrument_id=r['instrument_token'],
                        extra_data=r.get('extra_data'),
                        is_active=True
                    )
                    for r in batch
                ]
                BrokerInstrument.objects.bulk_create(
                    broker_instruments,
                    batch_size=BATCH_SIZE,
                    ignore_conflicts=True  # Skip if unique constraint violated
                )
                created_count += len(broker_instruments)
                print(f"  Created batch: {created_count}/{len(to_create)}")

    # Bulk update existing broker instruments
    updated_count = 0
    if to_update:
        with transaction.atomic():
            for i in range(0, len(to_update), BATCH_SIZE):
                batch = to_update[i:i + BATCH_SIZE]

                # Fetch existing broker instruments
                ids = [item[0] for item in batch]
                existing_objs = {
                    obj.id: obj
                    for obj in BrokerInstrument.objects.filter(id__in=ids)
                }

                # Update fields
                to_bulk_update = []
                for existing_id, record in batch:
                    obj = existing_objs.get(existing_id)
                    if obj:
                        obj.broker_symbol = record.get('broker_symbol')
                        obj.instrument_id = record['instrument_token']
                        obj.extra_data = record.get('extra_data')
                        obj.is_active = True
                        to_bulk_update.append(obj)

                BrokerInstrument.objects.bulk_update(
                    to_bulk_update,
                    fields=['broker_symbol', 'instrument_id', 'extra_data', 'is_active'],
                    batch_size=BATCH_SIZE
                )
                updated_count += len(to_bulk_update)
                print(f"  Updated batch: {updated_count}/{len(to_update)}")

    print(f"✓ Broker instruments synced: {created_count} created, {updated_count} updated")
    return created_count, updated_count


def run_initialization():
    """Main initialization function."""
    start_time = timezone.now()
    print(f"\n{'=' * 60}")
    print(f"INSTRUMENT INITIALIZATION SCRIPT")
    print(f"Started at: {start_time}")
    print(f"{'=' * 60}")

    # Check if already run today
    has_run, last_run = has_run_today()

    if has_run:
        print("\n✓ Skipping - script already ran today")
        return
    try:
        # Step 1: Deactivate expired instruments (soft-delete, skipping held)
        deactivate_expired_instruments()

        # Step 2: Fetch and sync instruments from brokers
        print("\n=== Fetching Instrument Data ===")

        # Zerodha
        try:
            print("\nFetching from Zerodha...")
            from instruments.brokers.zerodha import get_instruments_zerodha
            df_zerodha = get_instruments_zerodha()

            # Uncomment when function is ready:
            sync_instruments(df_zerodha, "ZERODHA")
            print("✓ Zerodha sync complete")
        except Exception as e:
            print(f"✗ Zerodha sync failed: {str(e)}")

        # Upstox
        try:
            print("\nFetching from Upstox...")
            from instruments.brokers.upstox import get_instruments_upstox
            df_upstox = get_instruments_upstox()
            # Uncomment when function is ready:
            sync_instruments(df_upstox, "UPSTOX")
            print("✓ Upstox sync complete")
        except Exception as e:
            print(f"✗ Upstox sync failed: {str(e)}")

        # Step 3: Fetch and sync broker instruments
        print("\n=== Fetching Broker Instrument Data ===")

        # Zerodha broker instruments
        try:
            print("\nFetching Zerodha broker instruments...")
            from instruments.brokers.zerodha import get_broker_instruments_zerodha
            df_broker_zerodha = get_broker_instruments_zerodha()
            # Uncomment when function is ready:
            sync_broker_instruments(df_broker_zerodha, "ZERODHA")
            print("✓ Zerodha broker instruments sync complete")
        except Exception as e:
            print(f"✗ Zerodha broker instruments sync failed: {str(e)}")

        # Upstox broker instruments
        try:
            print("\nFetching Upstox broker instruments...")
            from instruments.brokers.upstox import get_broker_instruments_upstox
            df_broker_upstox = get_broker_instruments_upstox()
            # Uncomment when function is ready:
            sync_broker_instruments(df_broker_upstox, "UPSTOX")
            print("✓ Upstox broker instruments sync complete")
        except Exception as e:
            print(f"✗ Upstox broker instruments sync failed: {str(e)}")

        # XTS broker instruments (uses Zerodha dump with exchange_token mapping)
        try:
            print("\nFetching XTS broker instruments...")
            from instruments.brokers.xts import get_broker_instruments_xts
            df_broker_xts = get_broker_instruments_xts()
            sync_broker_instruments(df_broker_xts, "XTS")
            print("✓ XTS broker instruments sync complete")
        except Exception as e:
            print(f"✗ XTS broker instruments sync failed: {str(e)}")

        # Mark as run
        mark_as_run()

        # Summary
        end_time = timezone.now()
        duration = (end_time - start_time).total_seconds()

        print(f"\n{'=' * 60}")
        print(f"INITIALIZATION COMPLETE")
        print(f"Duration: {duration:.2f} seconds")
        print(f"Finished at: {end_time}")
        print(f"{'=' * 60}\n")

    except Exception as e:
        print(f"\n✗ INITIALIZATION FAILED: {str(e)}")
        import traceback
        traceback.print_exc()
        raise

if __name__ == "__main__":
    run_initialization()
