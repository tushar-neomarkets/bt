from django.db import models


class Instrument(models.Model):
    EXCHANGE_CHOICES = (
        ("NSE", "NSE"),
        ("BSE", "BSE"),
        ("NFO", "NFO"),
        ("BFO", "BFO"),
        ("MCX", "MCX"),
    )
    SEGMENT_CHOICES = (
        ("OPTIDX", "OPTIDX"),
        ("FUTIDX", "FUTIDX"),
        ("OPTSTK", "OPTSTK"),
        ("FUTSTK", "FUTSTK"),
        ("EQ", "EQ"),
        ("NSE_INDEX", "NSE_INDEX"),
        ("BSE_INDEX", "BSE_INDEX"),
        ("FUTCOM", "FUTCOM"),
        ("OPTCOM", "OPTCOM"),
    )
    INSTRUMENT_TYPE_CHOICES = (
        ("EQ", "EQ"),
        ("FUT", "FUT"),
        ("CE", "CE"),
        ("PE", "PE"),
        ("IDX", "IDX"),
    )

    """
    TradingSymbol Standardized Format
    For OPT: UNDERLYING+EXPIRY(DDMMYYYY)+STRIKE(XX.XX)+OPT_TYPE(CE/PE)
    For FUT: UNDERLYING+EXPIRY(DDMMYYYY)+FUT
    For EQ: UNDERLYING
    """

    # Primary identifiers
    instrument_token = models.BigIntegerField(unique=True, db_index=True, primary_key=True)
    exchange_token = models.IntegerField(null=True, blank=True)

    # Trading identifiers
    tradingsymbol = models.CharField(max_length=50, db_index=True)
    name = models.CharField(max_length=100, null=True, blank=True)

    # Exchange and segment
    exchange = models.CharField(max_length=3, choices=EXCHANGE_CHOICES, db_index=True)
    segment = models.CharField(max_length=10, choices=SEGMENT_CHOICES, db_index=True)
    instrument_type = models.CharField(max_length=3, choices=INSTRUMENT_TYPE_CHOICES)

    # Derivatives data
    expiry = models.DateField(null=True, blank=True, db_index=True)
    strike = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    lot_size = models.IntegerField(default=1)
    tick_size = models.DecimalField(max_digits=10, decimal_places=4, default=0.05)
    freeze_quantity = models.IntegerField(null=True, blank=True)

    # Metadata
    is_active = models.BooleanField(default=True, db_index=True)
    created_at = models.DateTimeField(auto_now_add=True, db_index=False)
    updated_at = models.DateTimeField(auto_now=True, db_index=False)

    class Meta:
        ordering = []
        indexes = [
            models.Index(fields=['exchange', 'segment', 'is_active']),
            models.Index(fields=['tradingsymbol', 'exchange']),
            models.Index(fields=['expiry', 'is_active']),
            models.Index(fields=['instrument_type', 'is_active']),
        ]
        verbose_name = "Instrument"
        verbose_name_plural = "Instruments"
        db_table = 'instrument'

    def __str__(self):
        return f"{self.tradingsymbol} ({self.exchange})"

    def is_option(self):
        return self.instrument_type in ('CE', 'PE')

    def is_future(self):
        return self.instrument_type == 'FUT'

    def is_equity(self):
        return self.instrument_type == 'EQ'

    def is_index(self):
        return self.instrument_type == 'IDX'

    def is_expired(self):
        if self.expiry:
            from django.utils import timezone
            return self.expiry < timezone.now().date()
        return False


class BrokerInstrument(models.Model):
    """
    Maps broker-specific instrument identifiers to standardized Instrument model.
    """
    BROKER_CHOICES = (
        ("ZERODHA", "ZERODHA"),
        ("UPSTOX", "UPSTOX"),
        ("XTS", "XTS"),
    )

    id = models.BigAutoField(primary_key=True)
    broker_name = models.CharField(max_length=10, choices=BROKER_CHOICES, db_index=True)
    broker_token = models.CharField(max_length=50, db_index=True)
    broker_exchange = models.CharField(max_length=10, db_index=True)
    broker_symbol = models.CharField(max_length=50, null=True, blank=True)

    instrument = models.ForeignKey(
        Instrument,
        on_delete=models.CASCADE,
        related_name='broker_mappings',
        db_index=True
    )
    extra_data = models.JSONField(null=True, blank=True)
    is_active = models.BooleanField(default=True, db_index=True)
    created_at = models.DateTimeField(auto_now_add=True, db_index=False)
    updated_at = models.DateTimeField(auto_now=True, db_index=False)

    class Meta:
        unique_together = [['broker_name', 'broker_token', 'broker_exchange']]

        indexes = [
            # Primary lookup: by broker details
            models.Index(fields=['broker_name', 'broker_exchange', 'broker_token', 'is_active']),
            # Reverse lookup: find broker mappings for an instrument
            models.Index(fields=['instrument', 'broker_name', 'is_active']),
            # Broker-exchange queries
            models.Index(fields=['broker_name', 'broker_exchange', 'is_active']),
        ]

        ordering = []
        verbose_name = "Broker Instrument Mapping"
        verbose_name_plural = "Broker Instrument Mappings"
        db_table = 'broker_instrument'

    def __str__(self):
        return f"{self.broker_name}: {self.broker_exchange}:{self.broker_token} -> {self.instrument.tradingsymbol}"

    @classmethod
    def get_by_instrument_and_broker(cls, instrument_token, broker_name):
        """
        Get BrokerInstrument by Instrument token and broker name.

        Args:
            instrument_token: Instrument token (primary key of Instrument)
            broker_name: Broker name (e.g., 'ZERODHA')

        Returns:
            BrokerInstrument object or None

        Usage:
            broker_inst = BrokerInstrument.get_by_instrument_and_broker(123456, 'ZERODHA')
        """
        try:
            return cls.objects.select_related('instrument').get(
                instrument_id=instrument_token,
                broker_name=broker_name,
                is_active=True
            )
        except cls.DoesNotExist:
            return None

    @classmethod
    def get_by_broker_details(cls, broker_name, broker_exchange, broker_token):
        """
        Get BrokerInstrument by broker name, exchange, and token.

        Args:
            broker_name: Broker name (e.g., 'ZERODHA')
            broker_exchange: Broker's exchange name (e.g., 'NSE')
            broker_token: Broker's instrument token

        Returns:
            BrokerInstrument object or None

        Usage:
            broker_inst = BrokerInstrument.get_by_broker_details('ZERODHA', 'NSE', '123456')
        """
        try:
            return cls.objects.select_related('instrument').get(
                broker_name=broker_name,
                broker_exchange=broker_exchange,
                broker_token=broker_token,
                is_active=True
            )
        except cls.DoesNotExist:
            return None

    @classmethod
    def bulk_get_by_instruments_and_broker(cls, instrument_tokens, broker_name):
        """
        Bulk fetch BrokerInstruments for multiple instrument tokens and a broker.

        Args:
            instrument_tokens: List of instrument tokens
            broker_name: Broker name

        Returns:
            Dict mapping instrument_token -> BrokerInstrument

        Usage:
            mappings = BrokerInstrument.bulk_get_by_instruments_and_broker([123456, 123457], 'ZERODHA')
        """
        mappings = cls.objects.filter(
            instrument_id__in=instrument_tokens,
            broker_name=broker_name,
            is_active=True
        ).select_related('instrument')

        return {
            mapping.instrument_id: mapping
            for mapping in mappings
        }

    @classmethod
    def bulk_get_by_broker_details(cls, broker_name, broker_exchange, broker_tokens):
        """
        Bulk fetch BrokerInstruments for multiple broker tokens on a specific exchange.

        Args:
            broker_name: Broker name
            broker_exchange: Broker's exchange name
            broker_tokens: List of broker tokens

        Returns:
            Dict mapping broker_token -> BrokerInstrument

        Usage:
            mappings = BrokerInstrument.bulk_get_by_broker_details('ZERODHA', 'NSE', ['123456', '123457'])
        """
        mappings = cls.objects.filter(
            broker_name=broker_name,
            broker_exchange=broker_exchange,
            broker_token__in=broker_tokens,
            is_active=True
        ).select_related('instrument')

        return {
            mapping.broker_token: mapping
            for mapping in mappings
        }