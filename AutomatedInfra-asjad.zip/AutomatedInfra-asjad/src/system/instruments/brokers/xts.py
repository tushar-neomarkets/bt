"""
XTS Broker Instrument Mapping.

Uses Zerodha's instrument dump and maps via exchange_token to create
XTS-compatible BrokerInstrument entries.

XTS Exchange Segment Mapping:
    NSECM: 1  (NSE Cash Market)
    NSEFO: 2  (NSE F&O)
    NSECD: 3  (NSE Currency Derivatives)
    BSECM: 11 (BSE Cash Market)
    BSEFO: 12 (BSE F&O)
    MCXFO: 51 (MCX F&O)
"""
import pandas as pd
from typing import Optional

from instruments.brokers.zerodha import get_instruments_zerodha


# XTS Exchange Segment Mappings - Bidirectional
XTS_EXCHANGE_SEGMENT_TO_CODE = {
    "NSECM": 1,
    "NSEFO": 2,
    "NSECD": 3,
    "BSECM": 11,
    "BSEFO": 12,
    "MCXFO": 51,
}

XTS_CODE_TO_EXCHANGE_SEGMENT = {v: k for k, v in XTS_EXCHANGE_SEGMENT_TO_CODE.items()}

# Map our standard exchange to XTS exchange segment
EXCHANGE_TO_XTS_SEGMENT = {
    "NSE": "NSECM",
    "NFO": "NSEFO",
    "BSE": "BSECM",
    "BFO": "BSEFO",
    "MCX": "MCXFO",
}

# Map our segment types to help determine correct XTS segment
SEGMENT_TO_XTS_SEGMENT = {
    ("NSE", "EQ"): "NSECM",
    ("NSE", "NSE_INDEX"): "NSECM",
    ("NFO", "OPTIDX"): "NSEFO",
    ("NFO", "FUTIDX"): "NSEFO",
    ("NFO", "OPTSTK"): "NSEFO",
    ("NFO", "FUTSTK"): "NSEFO",
    ("BSE", "EQ"): "BSECM",
    ("BSE", "BSE_INDEX"): "BSECM",
    ("BFO", "OPTIDX"): "BSEFO",
    ("BFO", "FUTIDX"): "BSEFO",
    ("BFO", "OPTSTK"): "BSEFO",
    ("BFO", "FUTSTK"): "BSEFO",
    ("MCX", "FUTCOM"): "MCXFO",
    ("MCX", "OPTCOM"): "MCXFO",
}


def get_xts_exchange_segment(exchange: str, segment: str) -> str:
    """
    Get XTS exchange segment string for given exchange and segment.

    Args:
        exchange: Standard exchange code (NSE, NFO, BSE, BFO, MCX)
        segment: Standard segment code (EQ, OPTIDX, FUTIDX, etc.)

    Returns:
        XTS exchange segment string (NSECM, NSEFO, etc.)
    """
    # Try specific mapping first
    xts_segment = SEGMENT_TO_XTS_SEGMENT.get((exchange, segment))
    if xts_segment:
        return xts_segment

    # Fall back to exchange-level mapping
    return EXCHANGE_TO_XTS_SEGMENT.get(exchange, "NSECM")


def get_xts_exchange_code(xts_segment: str) -> int:
    """
    Get XTS numeric exchange code for given segment string.

    Args:
        xts_segment: XTS segment string (NSECM, NSEFO, etc.)

    Returns:
        XTS numeric code (1, 2, 11, etc.)
    """
    return XTS_EXCHANGE_SEGMENT_TO_CODE.get(xts_segment, 1)


def get_xts_segment_from_code(code: int) -> str:
    """
    Get XTS segment string from numeric code.

    Args:
        code: XTS numeric code (1, 2, 11, etc.)

    Returns:
        XTS segment string (NSECM, NSEFO, etc.)
    """
    return XTS_CODE_TO_EXCHANGE_SEGMENT.get(code, "NSECM")


def get_broker_instruments_xts() -> pd.DataFrame:
    """
    Create XTS broker instrument mappings using Zerodha's instrument dump.

    Uses exchange_token from Zerodha as the XTS instrument ID (exchangeInstrumentID).
    XTS uses exchange_token (not instrument_token) for API calls.

    Returns:
        DataFrame with columns:
            - broker_token: XTS exchangeInstrumentID (Zerodha's exchange_token)
            - broker_exchange: XTS exchange segment string (NSEFO, NSECM, etc.)
            - broker_symbol: Trading symbol
            - instrument_token: Standardized instrument token (maps to Instrument model)
            - extra_data: JSON with additional XTS-specific data
    """
    # Fetch standardized instruments from Zerodha
    zerodha_df = get_instruments_zerodha()
    print(f"Processing {len(zerodha_df)} instruments for XTS mapping")

    # Create XTS broker instrument DataFrame
    xts_df = pd.DataFrame()

    # XTS uses exchange_token as the exchangeInstrumentID
    xts_df['broker_token'] = zerodha_df['exchange_token'].astype(str)

    # Map to XTS exchange segments
    xts_df['broker_exchange'] = zerodha_df.apply(
        lambda row: get_xts_exchange_segment(row['exchange'], row['segment']),
        axis=1
    )

    # Trading symbol
    xts_df['broker_symbol'] = zerodha_df['tradingsymbol'].astype(str)

    # Reference to standardized instrument
    xts_df['instrument_token'] = zerodha_df['instrument_token'].astype('int64')

    # Extra data with both segment formats for flexibility
    xts_df['extra_data'] = xts_df.apply(
        lambda row: {
            'exchange_segment_code': get_xts_exchange_code(row['broker_exchange']),
            'exchange_segment_string': row['broker_exchange'],
        },
        axis=1
    )

    print(f"Created {len(xts_df)} XTS broker instrument mappings")

    # Show distribution by exchange segment
    segment_counts = xts_df['broker_exchange'].value_counts()
    print("XTS instruments by segment:")
    for segment, count in segment_counts.items():
        code = get_xts_exchange_code(segment)
        print(f"  {segment} ({code}): {count}")

    return xts_df


def save_broker_instruments_xts() -> int:
    """
    Fetch and save XTS broker instrument mappings to database.

    Returns:
        int: Number of instruments created/updated
    """
    from django.db import transaction
    from instruments.models import Instrument, BrokerInstrument

    xts_df = get_broker_instruments_xts()

    created_count = 0
    updated_count = 0
    skipped_count = 0

    with transaction.atomic():
        for _, row in xts_df.iterrows():
            try:
                # Get the standardized instrument
                instrument = Instrument.objects.filter(
                    instrument_token=row['instrument_token']
                ).first()

                if not instrument:
                    skipped_count += 1
                    continue

                # Create or update BrokerInstrument
                broker_inst, created = BrokerInstrument.objects.update_or_create(
                    broker_name='XTS',
                    broker_token=row['broker_token'],
                    broker_exchange=row['broker_exchange'],
                    defaults={
                        'broker_symbol': row['broker_symbol'],
                        'instrument': instrument,
                        'extra_data': row['extra_data'],
                        'is_active': True,
                    }
                )

                if created:
                    created_count += 1
                else:
                    updated_count += 1

            except Exception as e:
                print(f"Error saving XTS mapping for token {row['broker_token']}: {e}")
                skipped_count += 1

    print(f"XTS Broker Instruments: {created_count} created, {updated_count} updated, {skipped_count} skipped")
    return created_count + updated_count


def get_xts_instrument_payload(instrument_token: int) -> Optional[dict]:
    """
    Get the XTS API payload for a given instrument token.

    Args:
        instrument_token: Standardized instrument token

    Returns:
        dict with exchangeSegment and exchangeInstrumentID, or None if not found

    Usage:
        payload = get_xts_instrument_payload(123456)
        # Returns: {"exchangeSegment": "NSEFO", "exchangeInstrumentID": 12345}
    """
    from instruments.models import BrokerInstrument

    broker_inst = BrokerInstrument.get_by_instrument_and_broker(
        instrument_token=instrument_token,
        broker_name='XTS'
    )

    if not broker_inst:
        return None

    return {
        "exchangeSegment": broker_inst.broker_exchange,
        "exchangeInstrumentID": int(broker_inst.broker_token)
    }


def get_xts_instrument_payload_by_code(instrument_token: int) -> Optional[dict]:
    """
    Get the XTS API payload using numeric exchange code.

    Some XTS APIs accept numeric codes instead of segment strings.

    Args:
        instrument_token: Standardized instrument token

    Returns:
        dict with numeric exchangeSegment and exchangeInstrumentID, or None

    Usage:
        payload = get_xts_instrument_payload_by_code(123456)
        # Returns: {"exchangeSegment": 2, "exchangeInstrumentID": 12345}
    """
    from instruments.models import BrokerInstrument

    broker_inst = BrokerInstrument.get_by_instrument_and_broker(
        instrument_token=instrument_token,
        broker_name='XTS'
    )

    if not broker_inst:
        return None

    # Get numeric code from extra_data or convert from string
    if broker_inst.extra_data and 'exchange_segment_code' in broker_inst.extra_data:
        exchange_code = broker_inst.extra_data['exchange_segment_code']
    else:
        exchange_code = get_xts_exchange_code(broker_inst.broker_exchange)

    return {
        "exchangeSegment": exchange_code,
        "exchangeInstrumentID": int(broker_inst.broker_token)
    }


def bulk_get_xts_payloads(instrument_tokens: list[int]) -> dict:
    """
    Bulk fetch XTS payloads for multiple instruments.

    Args:
        instrument_tokens: List of standardized instrument tokens

    Returns:
        Dict mapping instrument_token -> XTS payload dict

    Usage:
        payloads = bulk_get_xts_payloads([123456, 789012])
        # Returns: {123456: {"exchangeSegment": "NSEFO", ...}, ...}
    """
    from instruments.models import BrokerInstrument

    mappings = BrokerInstrument.bulk_get_by_instruments_and_broker(
        instrument_tokens=instrument_tokens,
        broker_name='XTS'
    )

    result = {}
    for token, broker_inst in mappings.items():
        result[token] = {
            "exchangeSegment": broker_inst.broker_exchange,
            "exchangeInstrumentID": int(broker_inst.broker_token)
        }

    return result


def convert_segment_format(segment: str | int) -> dict:
    """
    Convert between XTS segment string and numeric code.

    Args:
        segment: Either segment string (NSEFO) or numeric code (2)

    Returns:
        dict with both formats: {"string": "NSEFO", "code": 2}
    """
    if isinstance(segment, int):
        segment_str = get_xts_segment_from_code(segment)
        return {"string": segment_str, "code": segment}
    else:
        segment_code = get_xts_exchange_code(segment)
        return {"string": segment, "code": segment_code}
