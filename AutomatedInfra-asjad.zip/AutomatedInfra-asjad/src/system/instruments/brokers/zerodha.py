import pandas as pd
from kiteconnect import KiteConnect
import datetime as dt
NFO_INDEX_NAMES = ['NIFTY', 'BANKNIFTY', 'MIDCPNIFTY', 'FINNIFTY', 'NIFTYNXT50']
BFO_INDEX_NAMES = ['SENSEX', 'BANKEX', 'SENSEX50']
SEGMENT_MAPPING = {
    'CDS-FUT': 'FUTCOM',
    'CDS-OPT': 'OPTCOM',
    'MCX-FUT': 'FUTCOM',
    'MCX-OPT': 'OPTCOM',
    'BSE': 'EQ',
    'NSE': 'EQ',
}
EXCHANGE_MAPPING = {
    'BFO': 'BFO',
    'NFO': 'NFO',
    # 'BSE': 'BSE',
    'NSE': 'NSE',
    'CDS': 'MCX',
    'MCX': 'MCX',
}
INSTRUMENT_TYPE_MAPPING = {
    'FUT': 'FUT',
    'CE': 'CE',
    'PE': 'PE',
    'EQ': 'EQ',
}

def standardize_segment(exchange, segment_str, name, instrument_type):
    # print(exchange, segment_str, name, instrument_type)
    if exchange == 'NFO':
        if instrument_type in ['CE', 'PE']:
            if exchange == 'NFO':
                if instrument_type in ['CE', 'PE']:  # Options
                    if name in NFO_INDEX_NAMES:
                        return 'OPTIDX'
                    else:
                        return 'OPTSTK'
        elif instrument_type == 'FUT':  # Futures
            if name in NFO_INDEX_NAMES:
                return 'FUTIDX'
            else:
                return 'FUTSTK'

    # Handle BFO derivatives
    elif exchange == 'BFO':
        if instrument_type in ['CE', 'PE']:  # Options
            if name in BFO_INDEX_NAMES:
                return 'OPTIDX'
            else:
                return 'OPTSTK'
        elif instrument_type == 'FUT':  # Futures
            if name in BFO_INDEX_NAMES:
                return 'FUTIDX'
            else:
                return 'FUTSTK'

    # For other exchanges, use the mapping table
    return SEGMENT_MAPPING.get(segment_str, segment_str)

def parse_expiry_date(expiry):
    """
    Parse expiry date from various formats.

    Args:
        expiry: Could be datetime, string, or None

    Returns:
        date object or None
    """
    if pd.isna(expiry) or expiry == '' or expiry == 0.0 or expiry == '0.0':
        return None

    if isinstance(expiry, dt.datetime):
        return expiry.date()

    if isinstance(expiry, pd.Timestamp):
        return expiry.date()

    if isinstance(expiry, str):
        try:
            print(expiry)
            return dt.datetime.strptime(expiry, '%d-%m-%Y').date()
        except:
            return None
    if isinstance(expiry, dt.date):
        return expiry
    return None
def standardize_instrument_type(inst_type):
    """Convert Zerodha instrument type to standardized type."""
    if inst_type == 'EQ':
        return 'EQ'
    elif inst_type == 'FUT':
        return 'FUT'
    elif inst_type == 'CE':
        return 'CE'
    elif inst_type == 'PE':
        return 'PE'
    elif inst_type in ['INDEX', 'INDICES']:
        return 'IDX'
    else:
        return INSTRUMENT_TYPE_MAPPING.get(inst_type, 'EQ')
def standardize_exchange(exchange_str):
    """Convert Zerodha exchange to standardized exchange."""
    return EXCHANGE_MAPPING.get(exchange_str, exchange_str)
def get_instruments_zerodha():
    kite = KiteConnect(api_key = "abc")
    kite.set_access_token("abc")
    df = pd.DataFrame(kite.instruments())
    print(f"Fetched {len(df)} instruments from Zerodha")
    df = df[df['exchange'].isin(EXCHANGE_MAPPING.keys())].copy()
    print(f"After filtering {len(df)} instruments from Zerodha")
    standardized_df = pd.DataFrame()
    standardized_df['instrument_token'] = df['instrument_token'].astype('int64')
    standardized_df['exchange_token'] = df['exchange_token'].fillna(0).astype('int64')
    standardized_df['tradingsymbol'] = df['tradingsymbol'].astype(str)
    standardized_df['name'] = df['name'].fillna('').str.strip().str.upper().astype(str)

    # Filter valid exchanges first
    df = df[df['exchange'].isin(EXCHANGE_MAPPING.keys())].copy()


    # Standardize exchange and instrument type
    df['std_exchange'] = df['exchange'].str.strip().apply(standardize_exchange)
    df['std_instrument_type'] = df['instrument_type'].apply(standardize_instrument_type)

    standardized_df['exchange'] = df['std_exchange']
    standardized_df['instrument_type'] = df['std_instrument_type']

    # Standardize segment using the helper function
    standardized_df['segment'] = df.apply(
        lambda row: standardize_segment(
            row['std_exchange'],
            row['segment'],
            row['name'].strip().upper() if pd.notna(row['name']) else '',
            row['std_instrument_type']
        ),
        axis=1
    )

    standardized_df['expiry'] = df['expiry'].apply(parse_expiry_date)

    standardized_df['strike'] = df['strike'].apply(
        lambda x: float(x) if pd.notna(x) and x != 0.0 else None
    )

    standardized_df['lot_size'] = df['lot_size'].fillna(1).astype(int)
    standardized_df['tick_size'] = df['tick_size'].fillna(0.05).astype(float)

    standardized_df['freeze_quantity'] = 0
    standardized_df['strike'] = standardized_df['strike'].fillna(0.0).astype(float)

    return standardized_df


def get_broker_instruments_zerodha():
    """
    Fetch broker-specific instrument mappings from Zerodha.

    Returns:
        DataFrame with columns:
            - broker_token: Zerodha's instrument token
            - broker_exchange: Zerodha's exchange code
            - broker_symbol: Zerodha's trading symbol
            - instrument_token: Standardized instrument token (maps to Instrument model)
    """
    kite = KiteConnect(api_key="abc")
    kite.set_access_token("abc")

    # Fetch instruments from Zerodha
    df = pd.DataFrame(kite.instruments())
    print(f"Fetched {len(df)} broker instruments from Zerodha")

    # Filter for valid exchanges (same as in get_instruments_zerodha)
    df = df[df['exchange'].isin(EXCHANGE_MAPPING.keys())].copy()
    print(f"After filtering {len(df)} broker instruments from Zerodha")

    # Create broker instrument mapping DataFrame
    broker_df = pd.DataFrame()

    # Broker-specific identifiers (what Zerodha uses internally)
    broker_df['broker_token'] = df['instrument_token'].astype(str)  # Convert to string for consistency
    broker_df['broker_exchange'] = df['exchange'].astype(str)  # Zerodha's exchange code (NSE, NFO, etc.)
    broker_df['broker_symbol'] = df['tradingsymbol'].astype(str)  # Zerodha's trading symbol

    # Standardized instrument token (maps to our Instrument model)
    broker_df['instrument_token'] = df['instrument_token'].astype('int64')

    print(f"Created {len(broker_df)} broker instrument mappings for Zerodha")

    return broker_df