INSTRUMENTS_URL = "https://assets.upstox.com/market-quote/instruments/exchange/complete.json.gz"
EXCHANGE_MAP = {
        "NSE_EQ": "NSE",
        "NSE_FO": "NFO",
        "NCD_FO": "CDS",
        "NSE_INDEX": "INDEX",
        "BSE_INDEX": "INDEX",
        "BSE_EQ": "BSE",
        "BSE_FO": "BFO",
        "BCD_FO": "BCD",
        "MCX_FO": "MCX"
    }
SYMBOL_REPLACEMENTS = {
        'INDIA VIX': 'INDIAVIX'
    }
NON_EQUITY_INSTRUMENT_TYPES = {"FUT", "CE", "PE", "INDEX"}


def get_instruments_upstox():
    #Temporary
    from instruments.brokers.zerodha import get_instruments_zerodha
    return get_instruments_zerodha()