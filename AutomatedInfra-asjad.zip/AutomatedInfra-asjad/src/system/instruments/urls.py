from django.urls import  path
from instruments.views import UpdateInstrumentsDumpView
urlpatterns = [

    path('update-instruments/', UpdateInstrumentsDumpView.as_view(), name='update-instruments'),

]