from django.shortcuts import render
from rest_framework.response import Response
from rest_framework.status import HTTP_200_OK
from rest_framework.views import APIView
from instruments.init_instruments import run_initialization
# Create your views here.

class UpdateInstrumentsDumpView(APIView):
    def post(self,request):
        print(f"Updating Instruments Dump")
        run_initialization()
        print("Instrument Dump Done")
        return Response(status=HTTP_200_OK,data={"message":"Instrument Dump Done"})
