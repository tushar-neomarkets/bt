from django.contrib import admin
from instruments.models import Instrument,BrokerInstrument
# Register your models here.

admin.site.register(BrokerInstrument)
admin.site.register(Instrument)
