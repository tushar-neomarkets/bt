from django.contrib import admin

from orders.models import ParentOrder, BrokerOrder


@admin.register(ParentOrder)
class ParentOrderAdmin(admin.ModelAdmin):
    list_display = ['order_id', 'strategy', 'side', 'quantity', 'status', 'created_at']
    list_filter = ['status', 'side', 'strategy']
    search_fields = ['order_id', 'strategy__strategy_code']
    raw_id_fields = ['instrument', 'strategy']  # Prevents loading all instruments
    readonly_fields = ['created_at', 'updated_at']
    ordering = ['-created_at']


@admin.register(BrokerOrder)
class BrokerOrderAdmin(admin.ModelAdmin):
    list_display = ['order_id', 'parent_order', 'broker_account', 'side', 'quantity', 'status', 'created_at']
    list_filter = ['status', 'side', 'broker_account']
    search_fields = ['order_id', 'broker_order_id', 'exchange_order_id']
    raw_id_fields = ['parent_order', 'broker_account', 'broker_instrument']  # Prevents loading all instruments
    readonly_fields = ['created_at', 'updated_at']
    ordering = ['-created_at']