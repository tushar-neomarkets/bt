from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):

    dependencies = [
        ('strategy', '0003_alter_strategyposition_instrument'),
        ('orders', '0004_alter_brokerorder_broker_instrument_and_more'),
    ]

    operations = [
        migrations.AddField(
            model_name='brokerorder',
            name='retry_of',
            field=models.ForeignKey(
                blank=True,
                null=True,
                on_delete=django.db.models.deletion.SET_NULL,
                related_name='retries',
                to='orders.brokerorder',
                help_text='If set, this BO is a retry of the referenced failed BO.',
            ),
        ),
        migrations.CreateModel(
            name='StrategyAlert',
            fields=[
                ('id', models.AutoField(
                    auto_created=True, primary_key=True, serialize=False, verbose_name='ID',
                )),
                ('kind', models.CharField(
                    choices=[
                        ('REJECTED', 'REJECTED'),
                        ('CANCELLED', 'CANCELLED'),
                        ('STALE_OPEN', 'STALE_OPEN'),
                    ],
                    db_index=True,
                    max_length=20,
                )),
                ('message', models.TextField()),
                ('created_at', models.DateTimeField(auto_now_add=True, db_index=True)),
                ('dismissed_at', models.DateTimeField(blank=True, null=True)),
                ('broker_order', models.ForeignKey(
                    blank=True,
                    null=True,
                    on_delete=django.db.models.deletion.CASCADE,
                    related_name='alerts',
                    to='orders.brokerorder',
                )),
                ('strategy', models.ForeignKey(
                    on_delete=django.db.models.deletion.CASCADE,
                    related_name='alerts',
                    to='strategy.strategy',
                )),
            ],
            options={
                'verbose_name': 'Strategy Alert',
                'verbose_name_plural': 'Strategy Alerts',
                'db_table': 'strategy_alert',
                'ordering': ['-created_at'],
            },
        ),
    ]
