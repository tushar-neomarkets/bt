from django.db import models
from django.forms import JSONField
from instruments.models import BrokerInstrument
from django.utils import timezone
# Create your models here.
class ParentOrder(models.Model):
    """
    Strategy-level order intent. Created by strategy engine.
    Spawns multiple BrokerOrders for execution.
    """
    ORDER_TYPE_CHOICES = (
        ('MARKET', 'MARKET'),
        ('LIMIT', 'LIMIT'),
        ('SL', 'STOPLOSS'),
        ('SL-M', 'STOPLOSS-MARKET'),
    )
    SIDE_CHOICES = (
        ('BUY', 'BUY'),
        ('SELL', 'SELL'),
    )
    PRODUCT_TYPE_CHOICES = (
        ('NRML', 'NRML'),
        ('MIS', 'MIS'),
        ('CNC', 'CNC'),
    )
    STATUS_CHOICES = (
        ('PENDING', 'PENDING'),  # Created, not yet submitted
        ('VALIDATED', 'VALIDATED'),  # Passed validation
        ('SUBMITTED', 'SUBMITTED'),  # Broker orders created
        ('OPEN', 'OPEN'),  # At least one broker order open
        ('COMPLETED', 'COMPLETED'),  # All broker orders completed
        ('PARTIALLY_FILLED', 'PARTIALLY_FILLED'),
        ('CANCELLED', 'CANCELLED'),  # All cancelled
        ('REJECTED', 'REJECTED'),  # Validation or submission failed
        ('ERROR', 'ERROR'),  # System error
    )
    order_id = models.BigAutoField(primary_key=True)
    strategy = models.ForeignKey(
        'strategy.Strategy',
        on_delete=models.PROTECT,
        related_name='parent_orders',
        db_index=True
    )
    instrument = models.ForeignKey(
        'instruments.Instrument',
        on_delete=models.SET_NULL,
        related_name='parent_orders',
        null=True,
        blank=True
    )
    order_type = models.CharField(
        max_length=10,
        choices=ORDER_TYPE_CHOICES,
        db_index=True
    )
    side = models.CharField(
        max_length=4,
        choices=SIDE_CHOICES,
        db_index=True
    )
    quantity = models.IntegerField(
        help_text="Base quantity (before multiplier)"
    )
    product_type = models.CharField(
        max_length=10,
        choices=PRODUCT_TYPE_CHOICES,
        default='NRML'
    )
    price = models.DecimalField(
        max_digits=12,
        decimal_places=2,
        null=True,
        blank=True,
        help_text="Limit price (for LIMIT/SL orders)"
    )
    trigger_price = models.DecimalField(
        max_digits=12,
        decimal_places=2,
        null=True,
        blank=True,
        help_text="Stop/trigger price (for SL orders)"
    )
    status = models.CharField(
        max_length=20,
        choices=STATUS_CHOICES,
        default='PENDING',
        db_index=True
    )
    order_intent = models.CharField(
        max_length=10,
        choices=(
            ('ENTRY', 'ENTRY'),
            ('EXIT', 'EXIT'),
        ),
        default='ENTRY',
        db_index=True,
        help_text="Purpose of this order"
    )

    total_broker_orders = models.IntegerField(default=0)
    successful_broker_orders = models.IntegerField(default=0)
    failed_broker_orders = models.IntegerField(default=0)

    remarks = models.TextField(null=True, blank=True)
    error_message = models.TextField(null=True, blank=True)
    order_metadata = models.JSONField(
        null=True,
        blank=True,
        help_text="Order Meta data"
    )
    created_at = models.DateTimeField(auto_now_add=True, db_index=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['strategy', 'status', 'created_at']),
            models.Index(fields=['instrument', 'side', 'created_at']),
            models.Index(fields=['status', 'created_at']),
        ]

        db_table = 'parent_order'
        verbose_name = "Parent Order"
        verbose_name_plural = "Parent Orders"

    def __str__(self):
        if self.instrument:
            return f"PO#{self.order_id}: {self.side} {self.quantity}x {self.instrument.tradingsymbol} for {self.strategy.strategy_code}"
        else:
            return f"PO#{self.order_id}: {self.side} {self.quantity}x"
    def update_status(self):
        """
        Recalculates status based on broker orders.
        Called after broker order status changes.
        """
        broker_orders = self.broker_orders.all()
        total = broker_orders.count()

        if total == 0:
            return

        completed = broker_orders.filter(status='COMPLETED').count()
        cancelled = broker_orders.filter(status='CANCELLED').count()
        rejected = broker_orders.filter(status='REJECTED').count()
        open_orders = broker_orders.filter(status__in=['OPEN', 'PENDING', 'SUBMITTED']).count()

        self.total_broker_orders = total
        self.successful_broker_orders = completed
        self.failed_broker_orders = cancelled + rejected

        if completed == total:
            self.status = 'COMPLETED'
        elif (cancelled + rejected) == total:
            self.status = 'REJECTED' if rejected > 0 else 'CANCELLED'
        elif completed > 0 and open_orders == 0:
            self.status = 'PARTIALLY_FILLED'
        elif open_orders > 0:
            self.status = 'OPEN'

        self.save(update_fields=['status', 'total_broker_orders',
                                 'successful_broker_orders', 'failed_broker_orders'
                                 , 'updated_at'])

class BrokerOrder(models.Model):
    """
    Actual order placed with broker for specific account.
    One-to-many relationship with ParentOrder.
    Contains all execution details, fills, and modifications.
    """

    STATUS_CHOICES = (
        ('PENDING', 'PENDING'),  # Created, not yet submitted
        ('SUBMITTED', 'SUBMITTED'),  # Sent to broker
        ('OPEN', 'OPEN'),  # Open at broker
        ('COMPLETED', 'COMPLETED'),  # Fully filled
        ('CANCELLED', 'CANCELLED'),  # Cancelled
        ('REJECTED', 'REJECTED'),  # Rejected by broker/exchange
        ('ERROR', 'ERROR'),  # System error
    )
    order_id = models.BigAutoField(primary_key=True)
    parent_order = models.ForeignKey(
        ParentOrder,
        on_delete=models.CASCADE,
        related_name='broker_orders',
        db_index=True
    )
    broker_account = models.ForeignKey(
        'accounts.BrokerAccount',
        on_delete=models.PROTECT,
        related_name='broker_orders',
        db_index=True
    )
    broker_instrument = models.ForeignKey(
        'instruments.BrokerInstrument',
        on_delete=models.SET_NULL,
        related_name='broker_orders',
        null=True,
        blank=True
    )
    broker_order_id = models.CharField(
        max_length=100,
        null=True,
        blank=True,
        db_index=True,
        help_text="Broker's order ID (AppOrderID)"
    )
    exchange_order_id = models.CharField(
        max_length=100,
        null=True,
        blank=True,
        help_text="Exchange order ID"
    )
    order_type = models.CharField(max_length=10)
    side = models.CharField(max_length=4)
    product_type = models.CharField(max_length=10)
    quantity = models.IntegerField(help_text="Quantity after multiplier")
    price = models.DecimalField(max_digits=12, decimal_places=2, null=True, blank=True)
    trigger_price = models.DecimalField(max_digits=12, decimal_places=2, null=True, blank=True)

    # Execution tracking
    filled_quantity = models.IntegerField(default=0)
    pending_quantity = models.IntegerField(default=0)
    cancelled_quantity = models.IntegerField(default=0)
    average_price = models.DecimalField(
        max_digits=12,
        decimal_places=2,
        null=True,
        blank=True,
        help_text="Average fill price"
    )
    status = models.CharField(
        max_length=20,
        choices=STATUS_CHOICES,
        default='PENDING',
        db_index=True
    )

    # Broker responses
    broker_response = models.JSONField(
        null=True,
        blank=True,
        help_text="Full broker API response"
    )
    broker_placed_payload = models.JSONField(
        null=True,
        blank=True,
        help_text="Broker API POST Data"
    )
    broker_status = models.CharField(
        max_length=50,
        null=True,
        blank=True,
        help_text="Raw broker status string"
    )

    error_message = models.TextField(null=True, blank=True)
    retry_count = models.IntegerField(default=0)
    retry_of = models.ForeignKey(
        'self', on_delete=models.SET_NULL, null=True, blank=True,
        related_name='retries',
        help_text='If set, this BO is a retry of the referenced failed BO.'
    )

    is_modified = models.BooleanField(default=False)
    auto_modify = models.BooleanField(
        default=True,
        help_text="If True, order will be auto-modified to best bid/ask every 10 seconds"
    )
    modification_history = models.JSONField(
        default=list,
        blank=True,
        help_text="Array of modification records"
    )

    fills = models.JSONField(
        default=list,
        blank=True,
        help_text="Array of fill records with price, quantity, timestamp"
    )

    created_at = models.DateTimeField(auto_now_add=True, db_index=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['parent_order', 'status']),
            models.Index(fields=['broker_account', 'status', 'created_at']),
            models.Index(fields=['broker_order_id', 'broker_account']),
            models.Index(fields=['status', 'created_at']),
        ]
        db_table = 'broker_order'
        verbose_name = "Broker Order"
        verbose_name_plural = "Broker Orders"

    def __str__(self):
        return f"BO#{self.order_id}: {self.broker_account.account_name} - {self.status}"


class StrategyAlert(models.Model):
    """
    Operator-facing alert raised when an order fails after one retry, or when
    an order sits OPEN past the stuck-order threshold. Surfaced on the strategy
    detail page; dismissed manually by the operator.
    """
    KIND_CHOICES = (
        ('REJECTED', 'REJECTED'),
        ('CANCELLED', 'CANCELLED'),
        ('STALE_OPEN', 'STALE_OPEN'),
    )
    strategy = models.ForeignKey(
        'strategy.Strategy', on_delete=models.CASCADE,
        related_name='alerts', db_index=True,
    )
    broker_order = models.ForeignKey(
        BrokerOrder, on_delete=models.CASCADE,
        related_name='alerts', null=True, blank=True,
    )
    kind = models.CharField(max_length=20, choices=KIND_CHOICES, db_index=True)
    message = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True, db_index=True)
    dismissed_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ['-created_at']
        db_table = 'strategy_alert'
        verbose_name = "Strategy Alert"
        verbose_name_plural = "Strategy Alerts"

    def __str__(self):
        return f"Alert#{self.pk} [{self.kind}] strategy={self.strategy_id} bo={self.broker_order_id}"




