"""
Order Manager

Handles the conversion of ParentOrders to BrokerOrders and manages order execution.

Flow:
1. Strategy creates ParentOrder (base quantity)
2. OrderManager finds all active StrategyAccountMappings for that strategy
3. For each mapping, creates BrokerOrder with quantity = base_quantity * multiplier
4. Places orders via BrokerAccountHandler
5. Tracks status and updates ParentOrder accordingly
"""
from datetime import timedelta
from decimal import Decimal
from typing import Optional

from django.db import transaction
from django.db.models import F
from django.utils import timezone

from orders.models import ParentOrder, BrokerOrder
from accounts.models import StrategyAccountMapping, BrokerAccount
from instruments.models import Instrument, BrokerInstrument
from strategy.models import Strategy
from utils.logger import (
    get_logger, get_app_logger,
    StrategyMirrorHandler, set_strategy_log_context, reset_strategy_log_context,
)

# Module logger for OrderManager
logger = get_logger(__name__)
# Mirror this logger's records to logs/strategy/<code>.log whenever a strategy
# code is bound via set_strategy_log_context() (see execute_parent_order and
# refresh_order_status below).
logger.addHandler(StrategyMirrorHandler())


# =============================================================================
# EXCHANGE SEGMENT MAPPINGS
# =============================================================================

# Maps (exchange, segment) to XTS exchange segment codes
XTS_EXCHANGE_SEGMENT_MAP = {
    ('NSE', 'EQ'): 'NSECM',
    ('NSE', 'NSE_INDEX'): 'NSECM',
    ('BSE', 'EQ'): 'BSECM',
    ('BSE', 'BSE_INDEX'): 'BSECM',
    ('NFO', 'FUTIDX'): 'NSEFO',
    ('NFO', 'OPTIDX'): 'NSEFO',
    ('NFO', 'FUTSTK'): 'NSEFO',
    ('NFO', 'OPTSTK'): 'NSEFO',
    ('BFO', 'FUTIDX'): 'BSEFO',
    ('BFO', 'OPTIDX'): 'BSEFO',
    ('MCX', 'FUTCOM'): 'MCXFO',
    ('MCX', 'OPTCOM'): 'MCXFO',
}

# Maps internal order type to XTS order type
XTS_ORDER_TYPE_MAP = {
    'MARKET': 'MARKET',
    'LIMIT': 'LIMIT',
    'SL': 'STOPLIMIT',
    'SL-M': 'STOPMARKET',
}

# Maps internal side to XTS side
XTS_ORDER_SIDE_MAP = {
    'BUY': 'BUY',
    'SELL': 'SELL',
}

# Maps internal product type to XTS product type
XTS_PRODUCT_TYPE_MAP = {
    'NRML': 'NRML',
    'MIS': 'MIS',
    'CNC': 'CNC',
}


class OrderManager:
    """
    Manages order execution from ParentOrder to BrokerOrders.

    Usage:
        order_manager = OrderManager()
        success, message, broker_orders = order_manager.execute_parent_order(parent_order)
    """

    def __init__(self):
        self.tracked_orders: dict[int, ParentOrder] = {}

    # =========================================================================
    # MAIN EXECUTION METHODS
    # =========================================================================

    def execute_parent_order(
        self, parent_order: ParentOrder, auto_execute: bool = True,
        auto_modify: bool = True
    ) -> tuple[bool, str, list[BrokerOrder]]:
        """
        Execute a ParentOrder by creating and optionally placing BrokerOrders.

        Args:
            parent_order: The ParentOrder to execute
            auto_execute: If True, place orders with broker. If False, only create BrokerOrder records.
            auto_modify: If True (default), orders will be auto-modified to best bid/ask every 10 seconds.

        Returns:
            tuple: (success, message, list of BrokerOrders)
        """
        # Bind the strategy code so every log line below is also mirrored to
        # logs/strategy/<code>.log via StrategyMirrorHandler.
        _strategy_log_token = set_strategy_log_context(parent_order.strategy.strategy_code)
        try:
            logger.info(f"{'='*60}")
            logger.info(f"EXECUTING PARENT ORDER: {parent_order}")
            logger.info(f"{'='*60}")

            # Validate parent order
            is_valid, validation_msg = self._validate_parent_order(parent_order)
            if not is_valid:
                parent_order.status = 'REJECTED'
                parent_order.error_message = validation_msg
                parent_order.save(update_fields=['status', 'error_message', 'updated_at'])
                return False, validation_msg, []

            # Update status to validated
            parent_order.status = 'VALIDATED'
            parent_order.save(update_fields=['status', 'updated_at'])

            # Get active mappings for this strategy
            mappings = self._get_active_mappings(parent_order.strategy)

            if not mappings:
                msg = f"No active account mappings found for strategy {parent_order.strategy.strategy_code}"
                logger.error(msg)
                parent_order.status = 'REJECTED'
                parent_order.error_message = msg
                parent_order.save(update_fields=['status', 'error_message', 'updated_at'])
                return False, msg, []

            logger.info(f"Found {len(mappings)} active account mapping(s)")

            # Create broker orders for each mapping
            broker_orders = []
            created_count = 0
            failed_count = 0

            for mapping in mappings:
                logger.debug(f"Processing mapping: {mapping}")

                # Skip if multiplier is 0
                if mapping.multiplier == 0:
                    logger.debug(f"  Skipping - multiplier is 0")
                    continue

                # Skip if auto_execute is disabled for this mapping
                if auto_execute and not mapping.auto_execute:
                    logger.debug(f"  Skipping - auto_execute disabled for this mapping")
                    continue

                try:
                    broker_order = self._create_broker_order(parent_order, mapping, auto_modify)
                    if broker_order:
                        broker_orders.append(broker_order)
                        created_count += 1
                        logger.info(f"  Created BrokerOrder: {broker_order}")

                        # Place order if auto_execute is enabled
                        if auto_execute:
                            place_success, place_msg = self._place_broker_order(broker_order)
                            if not place_success:
                                failed_count += 1
                                logger.error(f"  Failed to place: {place_msg}")
                    else:
                        failed_count += 1

                except Exception as e:
                    failed_count += 1
                    logger.exception(f"  Error creating broker order: {e}")

            # Update parent order status
            if created_count == 0:
                parent_order.status = 'REJECTED'
                parent_order.error_message = "Failed to create any broker orders"
            elif failed_count == 0:
                parent_order.status = 'SUBMITTED'
            else:
                parent_order.status = 'SUBMITTED'  # Partial success

            parent_order.total_broker_orders = created_count
            parent_order.save(update_fields=[
                'status', 'total_broker_orders', 'error_message', 'updated_at'
            ])

            # Track the order
            self.tracked_orders[parent_order.order_id] = parent_order

            msg = f"Created {created_count} broker order(s), {failed_count} failed"
            logger.info(msg)
            return created_count > 0, msg, broker_orders
        finally:
            reset_strategy_log_context(_strategy_log_token)

    def create_and_execute_order(
        self,
        strategy: Strategy,
        instrument: Instrument,
        side: str,
        quantity: int,
        order_type: str = 'MARKET',
        product_type: str = 'NRML',
        price: Optional[Decimal] = None,
        trigger_price: Optional[Decimal] = None,
        order_intent: str = 'ENTRY',
        remarks: str = None,
        metadata: dict = None
    ) -> tuple[bool, str, Optional[ParentOrder], list[BrokerOrder]]:
        """
        Convenience method to create a ParentOrder and execute it in one call.

        Args:
            strategy: Strategy model instance
            instrument: Instrument model instance
            side: 'BUY' or 'SELL'
            quantity: Base quantity (before multiplier)
            order_type: 'MARKET', 'LIMIT', 'SL', 'SL-M'
            product_type: 'NRML', 'MIS', 'CNC'
            price: Limit price (required for LIMIT/SL orders)
            trigger_price: Trigger price (required for SL/SL-M orders)
            order_intent: 'ENTRY' or 'EXIT'
            remarks: Optional remarks
            metadata: Optional metadata dict

        Returns:
            tuple: (success, message, ParentOrder, list of BrokerOrders)
        """
        try:
            # Create ParentOrder
            parent_order = ParentOrder.objects.create(
                strategy=strategy,
                instrument=instrument,
                order_type=order_type,
                side=side,
                quantity=quantity,
                product_type=product_type,
                price=price,
                trigger_price=trigger_price,
                order_intent=order_intent,
                remarks=remarks,
                order_metadata=metadata or {},
                status='PENDING'
            )

            logger.info(f"Created ParentOrder: {parent_order}")

            # Execute the order
            success, msg, broker_orders = self.execute_parent_order(parent_order)

            return success, msg, parent_order, broker_orders

        except Exception as e:
            return False, str(e), None, []

    # =========================================================================
    # BROKER ORDER CREATION
    # =========================================================================

    def _create_broker_order(
        self, parent_order: ParentOrder, mapping: StrategyAccountMapping,
        auto_modify: bool = True
    ) -> Optional[BrokerOrder]:
        """
        Create a BrokerOrder for a specific account mapping.

        Args:
            parent_order: The ParentOrder
            mapping: The StrategyAccountMapping
            auto_modify: If True, order will be auto-modified to best bid/ask (default: True)

        Returns:
            BrokerOrder instance or None if creation failed
        """
        broker_account = mapping.broker_account

        # Get broker instrument mapping
        broker_instrument = self._get_broker_instrument(
            parent_order.instrument,
            broker_account
        )

        if not broker_instrument:
            logger.error(f"No broker instrument mapping found for "
                         f"{parent_order.instrument} on {broker_account.broker.broker_name}")
            return None

        # Calculate quantity with multiplier
        final_quantity = parent_order.quantity * mapping.multiplier

        try:
            broker_order = BrokerOrder.objects.create(
                parent_order=parent_order,
                broker_account=broker_account,
                broker_instrument=broker_instrument,
                order_type=parent_order.order_type,
                side=parent_order.side,
                product_type=parent_order.product_type,
                quantity=final_quantity,
                price=parent_order.price,
                trigger_price=parent_order.trigger_price,
                pending_quantity=final_quantity,
                status='PENDING',
                auto_modify=auto_modify
            )

            return broker_order

        except Exception as e:
            logger.exception(f"Error creating BrokerOrder: {e}")
            return None

    def _get_broker_instrument(
        self, instrument: Instrument, broker_account: BrokerAccount
    ) -> Optional[BrokerInstrument]:
        """
        Get the BrokerInstrument mapping for an instrument and broker.

        Args:
            instrument: Instrument model instance
            broker_account: BrokerAccount model instance

        Returns:
            BrokerInstrument or None
        """
        broker_name = broker_account.broker.broker_name.upper()

        return BrokerInstrument.get_by_instrument_and_broker(
            instrument.instrument_token,
            broker_name
        )

    # =========================================================================
    # ORDER PLACEMENT
    # =========================================================================

    def _place_broker_order(self, broker_order: BrokerOrder) -> tuple[bool, str]:
        """
        Place a BrokerOrder with the broker.

        Args:
            broker_order: BrokerOrder to place

        Returns:
            tuple: (success, message)
        """
        from accounts.brokers.handler import BrokerAccountHandler

        broker_account = broker_order.broker_account
        broker_account.refresh_from_db()

        # Check if token is valid
        if broker_account.is_token_expired:
            msg = f"Token expired for {broker_account.account_name}"
            broker_order.status = 'ERROR'
            broker_order.error_message = msg
            broker_order.save(update_fields=['status', 'error_message', 'updated_at'])
            return False, msg

        # Build order parameters for the broker
        order_params = self._build_broker_order_params(broker_order)

        if not order_params:
            msg = "Failed to build order parameters"
            broker_order.status = 'ERROR'
            broker_order.error_message = msg
            broker_order.save(update_fields=['status', 'error_message', 'updated_at'])
            return False, msg

        # Store the payload we're sending
        broker_order.broker_placed_payload = order_params
        broker_order.save(update_fields=['broker_placed_payload', 'updated_at'])

        try:
            handler = BrokerAccountHandler(broker_account)
            response = handler.place_order(order_params)

            if response and 'data' in response:
                order_data = response['data'].get('order', {})

                broker_order.broker_order_id = str(order_data.get('order_id', ''))
                broker_order.exchange_order_id = str(order_data.get('exchange_order_id', ''))
                broker_order.broker_status = order_data.get('order_status', '')
                broker_order.broker_response = order_data.get('raw_response', {})
                broker_order.status = 'SUBMITTED'
                broker_order.save(update_fields=[
                    'broker_order_id', 'exchange_order_id', 'broker_status',
                    'broker_response', 'status', 'updated_at'
                ])

                return True, f"Order placed: {broker_order.broker_order_id}"
            else:
                broker_order.status = 'ERROR'
                broker_order.error_message = "No response from broker"
                broker_order.save(update_fields=['status', 'error_message', 'updated_at'])
                return False, "No response from broker"

        except Exception as e:
            broker_order.status = 'REJECTED'
            broker_order.error_message = str(e)
            broker_order.save(update_fields=['status', 'error_message', 'updated_at'])
            return False, str(e)

    def _retry_broker_order(self, failed_bo: BrokerOrder) -> Optional[BrokerOrder]:
        """Create one sibling BrokerOrder for the unfilled remainder and place it.

        Returns the sibling, or None if retry is blocked (already retried, or
        no leftover quantity). Bookkeeping (retry_count bump + sibling create)
        runs inside an atomic block with select_for_update so two concurrent
        callers can't produce two siblings; the broker API call happens
        outside the transaction so we never hold a row lock during network IO.
        """
        sibling = None
        with transaction.atomic():
            locked = BrokerOrder.objects.select_for_update().get(pk=failed_bo.pk)
            if locked.retry_of_id is not None:
                return None
            if locked.retry_count >= 1:
                return None

            retry_qty = locked.quantity - locked.filled_quantity
            if retry_qty <= 0:
                return None

            locked.retry_count = 1
            locked.save(update_fields=['retry_count', 'updated_at'])

            sibling = BrokerOrder.objects.create(
                parent_order=locked.parent_order,
                broker_account=locked.broker_account,
                broker_instrument=locked.broker_instrument,
                order_type=locked.order_type,
                side=locked.side,
                product_type=locked.product_type,
                quantity=retry_qty,
                pending_quantity=retry_qty,
                price=locked.price,
                trigger_price=locked.trigger_price,
                auto_modify=locked.auto_modify,
                retry_of=locked,
                retry_count=1,
                status='PENDING',
            )
            logger.info(
                f"Retrying BO#{locked.order_id} as BO#{sibling.order_id} "
                f"(filled {locked.filled_quantity}/{locked.quantity}, retry qty={retry_qty})"
            )

        self._place_broker_order(sibling)
        return sibling

    def _raise_strategy_alert(
        self, broker_order: BrokerOrder, kind: str, message: str
    ) -> None:
        """Create one StrategyAlert per (BO, kind) ever; never re-raise after dismiss.

        REJECTED/CANCELLED alerts collapse onto the original BO if this one is
        a retry, so original-fails-then-sibling-fails produces a single alert.
        """
        from orders.models import StrategyAlert
        if kind in ('REJECTED', 'CANCELLED') and broker_order.retry_of_id:
            target = broker_order.retry_of
        else:
            target = broker_order
        if StrategyAlert.objects.filter(broker_order=target, kind=kind).exists():
            return
        StrategyAlert.objects.create(
            strategy=target.parent_order.strategy,
            broker_order=target,
            kind=kind,
            message=message,
        )
        logger.error(f"ALERT [{kind}] BO#{target.order_id}: {message}")

    def _build_broker_order_params(self, broker_order: BrokerOrder) -> Optional[dict]:
        """
        Build broker-specific order parameters from BrokerOrder.

        Args:
            broker_order: BrokerOrder instance

        Returns:
            dict: Order parameters for the broker API, or None if mapping failed
        """
        broker_name = broker_order.broker_account.broker.broker_name.upper()

        if broker_name == 'XTS':
            return self._build_xts_order_params(broker_order)
        else:
            logger.error(f"Unsupported broker: {broker_name}")
            return None

    def _build_xts_order_params(self, broker_order: BrokerOrder) -> Optional[dict]:
        """
        Build XTS-specific order parameters.

        Args:
            broker_order: BrokerOrder instance

        Returns:
            dict: XTS order parameters
        """
        instrument = broker_order.broker_instrument.instrument
        broker_instrument = broker_order.broker_instrument

        # Get exchange segment
        exchange_segment = self._get_xts_exchange_segment(
            instrument.exchange,
            instrument.segment
        )

        if not exchange_segment:
            logger.error(f"Cannot map exchange segment: {instrument.exchange}/{instrument.segment}")
            return None

        # Get order type
        order_type = XTS_ORDER_TYPE_MAP.get(broker_order.order_type)
        if not order_type:
            logger.error(f"Cannot map order type: {broker_order.order_type}")
            return None

        # Get order side
        order_side = XTS_ORDER_SIDE_MAP.get(broker_order.side)
        if not order_side:
            logger.error(f"Cannot map order side: {broker_order.side}")
            return None

        # Get product type
        product_type = XTS_PRODUCT_TYPE_MAP.get(broker_order.product_type)
        if not product_type:
            logger.error(f"Cannot map product type: {broker_order.product_type}")
            return None

        params = {
            'exchangeSegment': exchange_segment,
            'exchangeInstrumentID': int(broker_instrument.broker_token),
            'productType': product_type,
            'orderType': order_type,
            'orderSide': order_side,
            'timeInForce': 'DAY',
            'disclosedQuantity': 0,
            'orderQuantity': broker_order.quantity,
            'limitPrice': float(broker_order.price) if broker_order.price else 0.0,
            'stopPrice': float(broker_order.trigger_price) if broker_order.trigger_price else 0.0,
            'orderUniqueIdentifier': f"BO{broker_order.order_id}"[:20]
        }

        return params

    def _get_xts_exchange_segment(self, exchange: str, segment: str) -> Optional[str]:
        """
        Get XTS exchange segment code from exchange and segment.

        Args:
            exchange: Exchange code (NSE, NFO, etc.)
            segment: Segment code (EQ, FUTIDX, etc.)

        Returns:
            XTS exchange segment code or None
        """
        return XTS_EXCHANGE_SEGMENT_MAP.get((exchange, segment))

    # =========================================================================
    # VALIDATION
    # =========================================================================

    def _validate_parent_order(self, parent_order: ParentOrder) -> tuple[bool, str]:
        """
        Validate a ParentOrder before execution.

        Args:
            parent_order: ParentOrder to validate

        Returns:
            tuple: (is_valid, message)
        """
        # Check status
        if parent_order.status not in ['PENDING']:
            return False, f"Invalid order status: {parent_order.status}"

        # Check quantity
        if parent_order.quantity <= 0:
            return False, "Quantity must be positive"

        # Check order type specific validations
        if parent_order.order_type == 'LIMIT':
            if not parent_order.price or parent_order.price <= 0:
                return False, "LIMIT orders require a valid price"

        if parent_order.order_type in ['SL', 'SL-M']:
            if not parent_order.trigger_price or parent_order.trigger_price <= 0:
                return False, "Stop-loss orders require a valid trigger price"

        if parent_order.order_type == 'SL':
            if not parent_order.price or parent_order.price <= 0:
                return False, "SL orders require a valid limit price"

        # Check instrument
        if not parent_order.instrument.is_active:
            return False, "Instrument is not active"

        return True, "Validation passed"

    # =========================================================================
    # ACCOUNT MAPPING
    # =========================================================================

    def _get_active_mappings(self, strategy: Strategy) -> list[StrategyAccountMapping]:
        """
        Get all active account mappings for a strategy.

        Args:
            strategy: Strategy model instance

        Returns:
            List of active StrategyAccountMapping instances
        """
        return list(StrategyAccountMapping.objects.filter(
            strategy=strategy,
            is_active=True,
            broker_account__is_active=True
        ).select_related('broker_account', 'broker_account__broker'))

    # =========================================================================
    # ORDER CANCELLATION
    # =========================================================================

    def cancel_broker_order(self, broker_order: BrokerOrder) -> tuple[bool, str]:
        """
        Cancel a BrokerOrder.

        Args:
            broker_order: BrokerOrder to cancel

        Returns:
            tuple: (success, message)
        """
        from accounts.brokers.handler import BrokerAccountHandler

        if broker_order.status not in ['SUBMITTED', 'OPEN', 'PENDING']:
            return False, f"Cannot cancel order with status: {broker_order.status}"

        if not broker_order.broker_order_id:
            return False, "No broker order ID - order may not have been placed"

        broker_account = broker_order.broker_account
        broker_name = broker_account.broker.broker_name.upper()

        try:
            if broker_name == 'XTS':
                from accounts.brokers.xts import xts_cancel_order
                result = xts_cancel_order(
                    broker_account,
                    broker_order.broker_order_id
                )

                broker_order.status = 'CANCELLED'
                broker_order.broker_response = result
                broker_order.save(update_fields=['status', 'broker_response', 'updated_at'])

                # Update parent order status
                broker_order.parent_order.update_status()

                return True, f"Order cancelled: {result.get('message', '')}"
            else:
                return False, f"Cancellation not implemented for broker: {broker_name}"

        except Exception as e:
            broker_order.error_message = str(e)
            broker_order.save(update_fields=['error_message', 'updated_at'])
            return False, str(e)

    def cancel_parent_order(self, parent_order: ParentOrder) -> tuple[bool, str]:
        """
        Cancel all broker orders for a ParentOrder.

        Args:
            parent_order: ParentOrder to cancel

        Returns:
            tuple: (success, message)
        """
        broker_orders = parent_order.broker_orders.filter(
            status__in=['SUBMITTED', 'OPEN', 'PENDING']
        )

        if not broker_orders.exists():
            return False, "No active broker orders to cancel"

        success_count = 0
        fail_count = 0

        for broker_order in broker_orders:
            success, msg = self.cancel_broker_order(broker_order)
            if success:
                success_count += 1
            else:
                fail_count += 1
                logger.error(f"Failed to cancel {broker_order}: {msg}")

        # Update parent order
        parent_order.update_status()

        return success_count > 0, f"Cancelled {success_count}, failed {fail_count}"

    # =========================================================================
    # ORDER MODIFICATION
    # =========================================================================

    def modify_broker_order(
        self, broker_order: BrokerOrder, new_price: Decimal,
        new_trigger_price: Optional[Decimal] = None,
        quote_data: Optional[dict] = None
    ) -> tuple[bool, str]:
        """
        Modify a BrokerOrder's price.

        Args:
            broker_order: BrokerOrder to modify
            new_price: New limit price
            new_trigger_price: New trigger price (for SL orders)
            quote_data: Optional market depth/quote data to store with modification history

        Returns:
            tuple: (success, message)
        """
        from accounts.brokers.handler import BrokerAccountHandler

        # Validate order can be modified
        if broker_order.status not in ['SUBMITTED', 'OPEN']:
            return False, f"Cannot modify order with status: {broker_order.status}"

        if not broker_order.broker_order_id:
            return False, "No broker order ID - order may not have been placed"

        # Only modify LIMIT orders
        if broker_order.order_type not in ['LIMIT', 'SL']:
            return False, f"Cannot modify order type: {broker_order.order_type}"

        broker_account = broker_order.broker_account
        broker_account.refresh_from_db()
        broker_name = broker_account.broker.broker_name.upper()

        # Check token validity
        if broker_account.is_token_expired:
            return False, f"Token expired for {broker_account.account_name}"

        # Store old price for history
        old_price = broker_order.price
        old_trigger = broker_order.trigger_price

        try:
            # Build modification parameters
            modify_params = {
                'productType': broker_order.product_type,
                'orderType': XTS_ORDER_TYPE_MAP.get(broker_order.order_type, 'LIMIT'),
                'orderQuantity': broker_order.quantity,
                'limitPrice': float(new_price),
                'stopPrice': float(new_trigger_price) if new_trigger_price else 0.0,
                'disclosedQuantity': 0,
                'timeInForce': 'DAY',
                'orderUniqueIdentifier': f"BO{broker_order.order_id}"[:20]
            }

            handler = BrokerAccountHandler(broker_account)
            response = handler.modify_order(broker_order.broker_order_id, modify_params)

            if response and 'data' in response:
                # Update broker order with new price
                broker_order.price = new_price
                if new_trigger_price:
                    broker_order.trigger_price = new_trigger_price

                broker_order.is_modified = True
                broker_order.broker_response = response['data'].get('modification', {}).get('raw_response', {})

                # Add to modification history
                modification_record = {
                    'timestamp': timezone.now().isoformat(),
                    'old_price': float(old_price) if old_price else None,
                    'new_price': float(new_price),
                    'old_trigger': float(old_trigger) if old_trigger else None,
                    'new_trigger': float(new_trigger_price) if new_trigger_price else None,
                    'reason': 'auto_modify'
                }

                # Add market depth data if available
                if quote_data:
                    modification_record['depth'] = {
                        'ltp': quote_data.get('ltp'),
                        'best_bid_price': quote_data.get('best_bid_price'),
                        'best_bid_qty': quote_data.get('best_bid_qty'),
                        'best_ask_price': quote_data.get('best_ask_price'),
                        'best_ask_qty': quote_data.get('best_ask_qty'),
                        'total_buy_qty': quote_data.get('total_buy_qty'),
                        'total_sell_qty': quote_data.get('total_sell_qty'),
                        'volume': quote_data.get('volume'),
                    }

                broker_order.modification_history.append(modification_record)

                broker_order.save(update_fields=[
                    'price', 'trigger_price', 'is_modified', 'modification_history',
                    'broker_response', 'updated_at'
                ])

                return True, f"Order modified: {old_price} -> {new_price}"
            else:
                return False, "No response from broker for modification"

        except Exception as e:
            broker_order.error_message = str(e)
            broker_order.save(update_fields=['error_message', 'updated_at'])
            return False, str(e)

    def get_orders_for_auto_modify(self) -> list[BrokerOrder]:
        """
        Get all orders eligible for auto-modification.

        Returns:
            List of BrokerOrders with auto_modify=True and status in SUBMITTED/OPEN
        """
        return list(BrokerOrder.objects.filter(
            status__in=['SUBMITTED', 'OPEN'],
            auto_modify=True,
            order_type__in=['LIMIT', 'SL']
        ).select_related(
            'parent_order', 'broker_account', 'broker_instrument',
            'broker_instrument__instrument'
        ))

    # =========================================================================
    # ORDER STATUS UPDATE
    # =========================================================================

    def update_broker_order_status(
        self,
        broker_order: BrokerOrder,
        status: str,
        filled_qty: int = None,
        average_price: Decimal = None,
        broker_status: str = None
    ) -> None:
        """
        Update BrokerOrder status (typically called from order update callbacks).

        Args:
            broker_order: BrokerOrder to update
            status: New status
            filled_qty: Filled quantity (optional)
            average_price: Average fill price (optional)
            broker_status: Raw broker status string (optional)
        """
        broker_order.status = status

        if filled_qty is not None:
            broker_order.filled_quantity = filled_qty
            broker_order.pending_quantity = broker_order.quantity - filled_qty

        if average_price is not None:
            broker_order.average_price = average_price

        if broker_status:
            broker_order.broker_status = broker_status

        broker_order.save()

        # Update parent order status
        broker_order.parent_order.update_status()

    def refresh_order_status(self, broker_order: BrokerOrder) -> tuple[bool, str]:
        """
        Refresh order status from broker.

        Args:
            broker_order: BrokerOrder to refresh

        Returns:
            tuple: (success, message)
        """
        if not broker_order.broker_order_id:
            return False, "No broker order ID"

        # Bind the strategy code so log lines below are also mirrored to
        # logs/strategy/<code>.log via StrategyMirrorHandler.
        _strategy_log_token = set_strategy_log_context(
            broker_order.parent_order.strategy.strategy_code
        )
        try:
            broker_account = broker_order.broker_account
            broker_name = broker_account.broker.broker_name.upper()

            try:
                if broker_name == 'XTS':
                    from accounts.brokers.xts import xts_get_order_status

                    order_data = xts_get_order_status(
                        broker_account,
                        broker_order.broker_order_id
                    )

                    if not order_data:
                        return False, "Order not found in broker"

                    # Map XTS status to internal status
                    xts_status = order_data.get('OrderStatus', '')
                    filled_qty = int(order_data.get('CumulativeQuantity', 0))
                    pending_qty = int(order_data.get('LeavesQuantity', 0))
                    avg_price_raw = order_data.get('OrderAverageTradedPrice', 0)

                    avg_price = float(avg_price_raw) if avg_price_raw not in ('', None) else 0.0

                    # XTS status mapping
                    # Filled, PartiallyFilled, New, PendingNew, Cancelled, Rejected, etc.
                    new_status = broker_order.status
                    if xts_status in ['Filled']:
                        new_status = 'COMPLETED'
                    elif xts_status in ['Cancelled', 'Expired']:
                        new_status = 'CANCELLED'
                    elif xts_status in ['Rejected']:
                        new_status = 'REJECTED'
                    elif xts_status in ['New', 'PendingNew', 'PartiallyFilled', 'Open']:
                        new_status = 'OPEN'

                    # Update if status changed
                    old_status = broker_order.status
                    if new_status != old_status or filled_qty != broker_order.filled_quantity:
                        broker_order.status = new_status
                        broker_order.filled_quantity = filled_qty
                        broker_order.pending_quantity = pending_qty
                        broker_order.broker_status = xts_status
                        if avg_price > 0:
                            broker_order.average_price = Decimal(str(avg_price))

                        broker_order.save(update_fields=[
                            'status', 'filled_quantity', 'pending_quantity',
                            'broker_status', 'average_price', 'updated_at'
                        ])

                        # Update parent order status
                        broker_order.parent_order.update_status()

                        logger.info(f"Order {broker_order.order_id} status updated: {old_status} -> {new_status} "
                                    f"(filled: {filled_qty}, pending: {pending_qty})")

                    return True, f"Status: {new_status}"
                else:
                    return False, f"Broker not supported: {broker_name}"

            except Exception as e:
                logger.exception(f"Error refreshing order status: {e}")
                return False, str(e)
        finally:
            reset_strategy_log_context(_strategy_log_token)

    # =========================================================================
    # QUERY METHODS
    # =========================================================================

    def get_open_orders(self, strategy: Strategy = None) -> list[BrokerOrder]:
        """
        Get all open broker orders, optionally filtered by strategy.

        Args:
            strategy: Optional strategy to filter by

        Returns:
            List of open BrokerOrders
        """
        queryset = BrokerOrder.objects.filter(
            status__in=['SUBMITTED', 'OPEN', 'PENDING']
        ).select_related(
            'parent_order', 'broker_account', 'broker_instrument'
        )

        if strategy:
            queryset = queryset.filter(parent_order__strategy=strategy)

        return list(queryset)

    def get_parent_order_summary(self, parent_order: ParentOrder) -> dict:
        """
        Get a summary of a ParentOrder and its broker orders.

        Args:
            parent_order: ParentOrder instance

        Returns:
            dict: Summary with status counts and details
        """
        broker_orders = parent_order.broker_orders.all()

        return {
            'parent_order_id': parent_order.order_id,
            'status': parent_order.status,
            'instrument': parent_order.instrument.tradingsymbol,
            'side': parent_order.side,
            'quantity': parent_order.quantity,
            'total_broker_orders': broker_orders.count(),
            'submitted': broker_orders.filter(status='SUBMITTED').count(),
            'completed': broker_orders.filter(status='COMPLETED').count(),
            'rejected': broker_orders.filter(status='REJECTED').count(),
            'cancelled': broker_orders.filter(status='CANCELLED').count(),
            'broker_orders': [
                {
                    'order_id': bo.order_id,
                    'account': bo.broker_account.account_name,
                    'quantity': bo.quantity,
                    'status': bo.status,
                    'broker_order_id': bo.broker_order_id,
                    'filled_qty': bo.filled_quantity,
                    'avg_price': float(bo.average_price) if bo.average_price else None
                }
                for bo in broker_orders
            ]
        }


# Singleton instance
order_manager = OrderManager()


# =============================================================================
# AUTO MODIFY MANAGER
# =============================================================================

import threading
import time

# Dedicated logger for auto-modify operations
auto_modify_logger = get_app_logger("orders", "auto_modify")


class AutoModifyManager:
    """
    Background manager that auto-modifies pending orders to best bid/ask prices.

    Features:
    - Runs in a background thread
    - Polls every 10 seconds (configurable)
    - Fetches best bid/ask from datafeed
    - Modifies LIMIT orders: BUY -> best ask, SELL -> best bid

    Usage:
        from orders.order_manager import auto_modify_manager

        # Start auto-modification with a datafeed account
        auto_modify_manager.start(datafeed_account)

        # Stop when done
        auto_modify_manager.stop()
    """

    def __init__(self, interval: int = 10):
        """
        Initialize AutoModifyManager.

        Args:
            interval: Seconds between modification cycles (default: 10)
        """
        self.interval = interval
        self.datafeed_account = None
        self.datafeed_handler = None
        self._running = False
        self._thread: Optional[threading.Thread] = None
        self._lock = threading.Lock()

    def start(self, datafeed_account) -> bool:
        """
        Start the auto-modification background thread.

        Args:
            datafeed_account: DataFeedAccount instance for fetching live prices

        Returns:
            bool: True if started successfully
        """
        from datafeed.rest.handler import DataFeedHandler

        with self._lock:
            if self._running:
                auto_modify_logger.warning("AutoModifyManager already running")
                return False

            self.datafeed_account = datafeed_account
            self.datafeed_handler = DataFeedHandler(datafeed_account)

            # Check token validity
            if datafeed_account.is_token_expired:
                auto_modify_logger.warning("Datafeed token is expired. Attempting to update...")
                try:
                    self.datafeed_handler.update_token()
                except Exception as e:
                    auto_modify_logger.error(f"Failed to update datafeed token: {e}")
                    return False

            self._running = True
            self._thread = threading.Thread(
                target=self._run_loop,
                name="AutoModifyManager",
                daemon=True
            )
            self._thread.start()

            auto_modify_logger.info(f"AutoModifyManager started (interval: {self.interval}s)")
            return True

    def stop(self) -> None:
        """Stop the auto-modification background thread."""
        with self._lock:
            if not self._running:
                return

            self._running = False
            auto_modify_logger.info("AutoModifyManager stopping...")

        # Wait for thread to finish (with timeout)
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=5)

        self._thread = None
        self.datafeed_handler = None
        self.datafeed_account = None
        auto_modify_logger.info("AutoModifyManager stopped")

    def is_running(self) -> bool:
        """Check if auto-modification is running."""
        return self._running

    def _run_loop(self) -> None:
        """Main loop that runs in background thread."""
        auto_modify_logger.info("AutoModifyManager loop started")

        while self._running:
            try:
                self._process_orders()
            except Exception as e:
                auto_modify_logger.exception(f"AutoModifyManager error in process loop: {e}")

            # Sleep in small increments so we can stop quickly
            for _ in range(self.interval):
                if not self._running:
                    break
                time.sleep(1)

        auto_modify_logger.info("AutoModifyManager loop ended")

    def _process_orders(self) -> None:
        """Process all open broker orders this tick.

        Pass A: refresh status from broker for every open BO.
        Pass B: retry originals where status is terminal AND filled<quantity.
        Pass C: alert on retry siblings that themselves end terminal+mismatch.
        Pass D: STALE_OPEN alerts for LIMIT orders open >30s.
        Then: existing auto-modify path (price chasing).
        """
        # All four passes scope to today's BOs only — daily session model;
        # legacy CANCELLED/REJECTED rows from prior sessions must not trigger
        # retries against today's market.
        today = timezone.now().date()

        # Pass A: defensive refresh of every open BO. Covers BOs that aren't in
        # the auto-modify candidate set so retry detection works regardless of
        # per-order config.
        all_open = BrokerOrder.objects.filter(
            status__in=['SUBMITTED', 'OPEN'],
            created_at__date=today,
        ).select_related(
            'parent_order__strategy', 'broker_account', 'broker_account__broker'
        )
        for bo in all_open:
            try:
                order_manager.refresh_order_status(bo)
            except Exception as e:
                auto_modify_logger.warning(f"refresh failed for BO#{bo.order_id}: {e}")

        # Pass B: reconcile originals. Anchor is filled<quantity; status confirms
        # the broker considers the order done so more fills won't arrive.
        needs_retry = BrokerOrder.objects.filter(
            status__in=['CANCELLED', 'REJECTED'],
            retry_of__isnull=True,
            retry_count=0,
            filled_quantity__lt=F('quantity'),
            created_at__date=today,
        ).select_related(
            'parent_order__strategy', 'broker_account', 'broker_instrument'
        )
        for bo in needs_retry:
            auto_modify_logger.info(
                f"Reconcile: BO#{bo.order_id} mismatch "
                f"(filled {bo.filled_quantity}/{bo.quantity}, status={bo.status}) -> retrying"
            )
            sibling = order_manager._retry_broker_order(bo)
            if sibling is None:
                order_manager._raise_strategy_alert(
                    bo, kind=bo.status,
                    message=(
                        f"Order {bo.status.lower()} with mismatch "
                        f"(filled {bo.filled_quantity}/{bo.quantity}); retry blocked"
                    ),
                )
            elif sibling.status in ('REJECTED', 'ERROR'):
                order_manager._raise_strategy_alert(
                    bo, kind=bo.status,
                    message=(
                        f"Order {bo.status.lower()} with mismatch; "
                        f"retry also failed: {sibling.error_message}"
                    ),
                )

        # Pass C: alert on retry siblings that themselves ended terminal+mismatch.
        # _raise_strategy_alert redirects the alert key onto the original.
        failed_retries = BrokerOrder.objects.filter(
            status__in=['CANCELLED', 'REJECTED'],
            retry_of__isnull=False,
            filled_quantity__lt=F('quantity'),
            created_at__date=today,
        ).select_related('retry_of', 'parent_order__strategy')
        for bo in failed_retries:
            order_manager._raise_strategy_alert(
                bo, kind=bo.status,
                message=(
                    f"Order {bo.status.lower()} with mismatch on retry "
                    f"(filled {bo.filled_quantity}/{bo.quantity})"
                ),
            )

        # Pass D: STALE_OPEN alerts for LIMIT orders open >30s.
        threshold = timezone.now() - timedelta(seconds=30)
        stuck = BrokerOrder.objects.filter(
            status__in=['SUBMITTED', 'OPEN'],
            order_type='LIMIT',
            created_at__lt=threshold,
            created_at__date=today,
        ).select_related('parent_order__strategy', 'broker_account')
        for bo in stuck:
            order_manager._raise_strategy_alert(
                bo, kind='STALE_OPEN',
                message=(
                    f"Order open >30s without fill "
                    f"(filled {bo.filled_quantity}/{bo.quantity}, price={bo.price})"
                ),
            )

        # Existing auto-modify path: price-chase LIMIT/SL orders with auto_modify=True.
        orders = order_manager.get_orders_for_auto_modify()

        if not orders:
            return

        auto_modify_logger.info(f"Processing {len(orders)} orders for auto-modification")

        # Group orders by instrument for efficient quote fetching
        orders_by_instrument: dict[int, list[BrokerOrder]] = {}
        for bo in orders:
            instrument = bo.broker_instrument.instrument
            if instrument.instrument_token not in orders_by_instrument:
                orders_by_instrument[instrument.instrument_token] = []
            orders_by_instrument[instrument.instrument_token].append(bo)

        # Fetch quotes for all instruments
        instruments = [
            orders[0].broker_instrument.instrument
            for orders in orders_by_instrument.values()
        ]

        quotes = self._fetch_quotes(instruments)

        if not quotes:
            auto_modify_logger.warning("No quotes fetched, skipping this cycle")
            return

        # Process each order
        for instrument_token, broker_orders in orders_by_instrument.items():
            quote = quotes.get(instrument_token)
            if not quote:
                auto_modify_logger.warning(f"No quote for instrument {instrument_token}")
                continue

            best_bid = quote.get('best_bid_price', 0)
            best_ask = quote.get('best_ask_price', 0)

            if best_bid <= 0 or best_ask <= 0:
                auto_modify_logger.warning(f"Invalid bid/ask for {instrument_token}: bid={best_bid}, ask={best_ask}")
                continue

            for bo in broker_orders:
                self._modify_order_if_needed(bo, best_bid, best_ask, quote_data=quote)

    def _fetch_quotes(self, instruments: list) -> dict:
        """
        Fetch quotes for multiple instruments.

        Args:
            instruments: List of Instrument instances

        Returns:
            dict: Map of instrument_token -> quote data
        """
        if not self.datafeed_handler:
            return {}

        try:
            # if len(instruments) == 1:
            #     response = self.datafeed_handler.get_multiple_quote(instruments)
            #     if response and 'data' in response:
            #         quote = response['data'].get('quote', {})
            #         return {instruments[0].instrument_token: quote}
            # else:
            response = self.datafeed_handler.get_multiple_quote(instruments)
            if response and 'data' in response:
                quote_list = response['data'].get('quote_list', [])
                return {
                    q.get('instrument_token'): q
                    for q in quote_list
                }
        except Exception as e:
            auto_modify_logger.exception(f"Error fetching quotes: {e}")

        return {}

    def _modify_order_if_needed(
        self, broker_order: BrokerOrder, best_bid: float, best_ask: float,
        quote_data: Optional[dict] = None
    ) -> None:
        """
        Modify an order if its price differs from the best bid/ask.

        Pass A in _process_orders already refreshed status from the broker this
        tick; we just reload from DB and skip if no longer open.
        """
        broker_order.refresh_from_db()
        if broker_order.status not in ['SUBMITTED', 'OPEN']:
            auto_modify_logger.info(
                f"BO#{broker_order.order_id} skipped - status is {broker_order.status}"
            )
            return

        current_price = float(broker_order.price) if broker_order.price else 0

        # Determine target price based on side
        # BUY orders should be at best ask (to get filled)
        # SELL orders should be at best bid (to get filled)
        if broker_order.side == 'BUY':
            target_price = best_ask + 0.1
        else:  # SELL
            target_price = best_bid - 0.1

        # Skip if price hasn't changed significantly (avoid unnecessary modifications)
        if abs(current_price - target_price) < 0.01:
            return

        # Skip if target price is 0 or invalid
        if target_price <= 0:
            return

        auto_modify_logger.info(f"Modifying BO#{broker_order.order_id} "
                                f"({broker_order.side}) from {current_price:.2f} to {target_price:.2f}")

        try:
            success, msg = order_manager.modify_broker_order(
                broker_order,
                Decimal(str(target_price)),
                quote_data=quote_data
            )

            if success:
                auto_modify_logger.info(f"  BO#{broker_order.order_id} modified successfully: {msg}")
            else:
                auto_modify_logger.error(f"  BO#{broker_order.order_id} modification failed: {msg}")

        except Exception as e:
            auto_modify_logger.exception(f"  BO#{broker_order.order_id} modification error: {e}")


# Singleton instance for auto-modify manager
auto_modify_manager = AutoModifyManager()
