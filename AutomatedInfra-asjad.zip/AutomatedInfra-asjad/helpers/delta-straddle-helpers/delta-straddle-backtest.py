"""
Signal Generator: Expiry Day Short Straddle (0.7 Call Delta Entry)
Strategy : On each CW expiry day, sell NIFTY straddle at the strike whose CE delta is closest to 0.7.
Entry    : 09:15:59  |  SL: 30% rise in combined straddle price  |  Hard exit: 14:59:59
Legs     : CE + PE at CW expiry
Output   : signal_straddle_0.7deltac.csv
"""

import pandas as pd
import numpy as np
from datetime import date, timedelta
from marketdata import Index, FnO
from tqdm import tqdm

# ── Config ────────────────────────────────────────────────────────────────
TICKER         = "NIFTY"
INDEX_SYMBOL   = "NIFTY 50"
START_DATE     = date(2025, 12, 1)
END_DATE       = date(2025, 12, 31)
EXPIRY         = "cw"
TARGET_DELTA   = 0.7           # CE delta for strike selection
SL_MULTIPLIER  = 1.30          # exit when straddle price rises 20%
ENTRY_TIME     = "09:15:59"
HARD_EXIT_TIME = "14:59:59"
OUTPUT_PATH    = "signal_straddle_0.7deltac.csv"
EXPIRY_FILE    = r"\\10.211.8.76\GFD MBM Data\Auxiliary Data\Expiry File_2025.xlsx"


# ── Helpers ───────────────────────────────────────────────────────────────

def load_cw_expiry_days(start_d: date, end_d: date) -> list:
    """Return sorted list of CW expiry dates within [start_d, end_d]."""
    df_exp = pd.read_excel(EXPIRY_FILE, sheet_name="Nifty 50")
    df_exp.columns = df_exp.columns.str.strip()
    df_exp["Date"]         = pd.to_datetime(df_exp["Date"],         dayfirst=True)
    df_exp["Current Week"] = pd.to_datetime(df_exp["Current Week"], dayfirst=True)
    mask = df_exp["Date"].dt.date == df_exp["Current Week"].dt.date
    return [
        d for d in sorted(df_exp.loc[mask, "Date"].dt.date.unique())
        if start_d <= d <= end_d
    ]


def normalize_ts(df: pd.DataFrame) -> pd.DataFrame:
    """Convert timestamp column to IST tz-naive."""
    df = df.copy()
    df["timestamp"] = (
        pd.to_datetime(df["timestamp"], utc=True)
        .dt.tz_convert("Asia/Kolkata")
        .dt.tz_localize(None)
    )
    return df


def fetch_spot_1m(date_str: str, index_api: Index) -> pd.DataFrame:
    try:
        df = index_api.get_prices(
            INDEX_SYMBOL, date_str, date_str, interval="1m", columns="ohlc"
        )
    except Exception as e:
        print(f"API Error: {e}")
        return pd.DataFrame()
    if df is None or df.empty:
        return pd.DataFrame()
    df = normalize_ts(df)
    df.sort_values("timestamp", inplace=True)
    df.drop_duplicates(subset=["timestamp"], inplace=True)
    return df


def fetch_options_chain(date_str: str, kind: str, fno_api: FnO) -> pd.DataFrame:
    """Fetch all-strike 1m options chain for one day."""
    try:
        df = fno_api.get_prices(
            TICKER, date_str, date_str,
            interval="1m", expiry=EXPIRY, kind=kind, columns="all", include_greeks=True
        )
    except Exception as e:
        print(f"API Error: {e}")
        return pd.DataFrame()
    if df is None or df.empty:
        return pd.DataFrame()
    df = normalize_ts(df)
    df["strike_price"] = pd.to_numeric(df["strike_price"], errors="coerce")
    df.dropna(subset=["strike_price"], inplace=True)
    # API with columns="all" returns both CE and PE rows — keep only the requested kind
    if "option_type" in df.columns:
        df = df[df["option_type"].str.upper() == kind.upper()]
    df.sort_values(["strike_price", "timestamp"], inplace=True)
    df.drop_duplicates(subset=["timestamp", "strike_price"], inplace=True)
    return df


# ── Per-Day Logic ─────────────────────────────────────────────────────────

def process_expiry_day(expiry_date: date, index_api: Index, fno_api: FnO) -> list:
    date_str     = expiry_date.strftime("%Y-%m-%d")
    entry_ts     = pd.Timestamp(f"{date_str} {ENTRY_TIME}")
    hard_exit_ts = pd.Timestamp(f"{date_str} {HARD_EXIT_TIME}")

    # ── 1. Spot at 09:15:59 ───────────────────────────────────────────────
    try:
        spot_df = fetch_spot_1m(date_str, index_api)
    except Exception as e:
        print(f"  ⚠ {expiry_date}: Spot fetch failed: {e}")
        return []
    if spot_df.empty:
        print(f"  ⚠ {expiry_date}: No spot data, skipping")
        return []

    spot_row = spot_df[spot_df["timestamp"] == entry_ts]
    if spot_row.empty:
        print(f"  ⚠ {expiry_date}: No spot bar at {ENTRY_TIME}, skipping")
        return []
    spot_price = float(spot_row.iloc[0]["close"])

    # ── 2. CE and PE chains ───────────────────────────────────────────────
    try:
        ce_chain = fetch_options_chain(date_str, "CE", fno_api)
    except Exception as e:
        print(f"  ⚠ {expiry_date}: CE chain failed: {e}")
        return []
    if ce_chain.empty:
        print(f"  ⚠ {expiry_date}: Empty CE chain, skipping")
        return []

    try:
        pe_chain = fetch_options_chain(date_str, "PE", fno_api)
    except Exception as e:
        print(f"  ⚠ {expiry_date}: PE chain failed: {e}")
        return []
    if pe_chain.empty:
        print(f"  ⚠ {expiry_date}: Empty PE chain, skipping")
        return []

    # ── 3. Strike selection: CE delta closest to TARGET_DELTA at entry ───────
    ce_entry = ce_chain[ce_chain["timestamp"] == entry_ts].copy()
    pe_entry = pe_chain[pe_chain["timestamp"] == entry_ts].copy()

    if ce_entry.empty or pe_entry.empty:
        print(f"  ⚠ {expiry_date}: No chain snapshot at entry time, skipping")
        return []

    ce_entry["delta"] = pd.to_numeric(ce_entry["delta"], errors="coerce")
    ce_valid = ce_entry.dropna(subset=["delta"])
    if ce_valid.empty:
        print(f"  ⚠ {expiry_date}: No delta data in CE chain at entry, skipping")
        return []

    best_idx     = (ce_valid["delta"] - TARGET_DELTA).abs().idxmin()
    entry_strike = float(ce_valid.loc[best_idx, "strike_price"])
    ce_delta     = float(ce_valid.loc[best_idx, "delta"])

    # Ensure entry_strike exists in PE chain at entry time
    if pe_entry[pe_entry["strike_price"] == entry_strike].empty:
        print(f"  ⚠ {expiry_date}: Entry strike {entry_strike} missing in PE chain, skipping")
        return []

    ce_ep = float(ce_entry.loc[ce_entry["strike_price"] == entry_strike, "close"].iloc[0])
    pe_ep = float(pe_entry.loc[pe_entry["strike_price"] == entry_strike, "close"].iloc[0])
    entry_straddle = ce_ep + pe_ep
    sl_level       = entry_straddle * SL_MULTIPLIER

    print(
        f"  {expiry_date}  spot={spot_price:.1f}  entry_K={entry_strike:.0f}"
        f"  CE_delta={ce_delta:.3f}  entry_sdl={entry_straddle:.2f}  SL@{sl_level:.2f}"
    )

    # ── 4. SL monitoring on 1m combined close prices ──────────────────────
    def leg_slice(chain):
        return (
            chain[
                (chain["strike_price"] == entry_strike) &
                (chain["timestamp"]    >  entry_ts)     &
                (chain["timestamp"]    <= hard_exit_ts)
            ][["timestamp", "close"]]
            .reset_index(drop=True)
        )

    ce_leg = leg_slice(ce_chain).rename(columns={"close": "ce"})
    pe_leg = leg_slice(pe_chain).rename(columns={"close": "pe"})

    combined = (
        pd.merge(ce_leg, pe_leg, on="timestamp", how="inner")
        .sort_values("timestamp")
        .reset_index(drop=True)
    )

    actual_exit_ts = hard_exit_ts
    exit_reason    = "HARD_EXIT"

    if not combined.empty:
        combined["straddle"] = combined["ce"] + combined["pe"]
        sl_hit = combined["straddle"] >= sl_level

        if sl_hit.any():
            sl_bar         = int(sl_hit.idxmax())
            actual_exit_ts = combined.loc[sl_bar, "timestamp"]
            exit_reason    = "SL"
        else:
            # Hard exit: if 14:59:59 bar is absent, use last available bar
            if hard_exit_ts not in combined["timestamp"].values:
                actual_exit_ts = combined["timestamp"].max()
                print(f"    ⚠ 14:59:59 bar missing — using {actual_exit_ts} as hard exit")

    print(f"    -> {exit_reason} exit at {actual_exit_ts}")

    # ── 5. Build signal rows ──────────────────────────────────────────────
    entry_str = str(entry_ts)[:19]
    exit_str  = str(actual_exit_ts)[:19]

    def make_row(ts, inst, is_entry):
        return {
            "timestamp":   ts,
            "ticker":      TICKER,
            "entry_long":  0,
            "exit_long":   0,
            "entry_short": 1 if is_entry else 0,
            "exit_short":  0 if is_entry else 1,
            "instrument":  inst,
            "expiry":      EXPIRY,
            "strike":      entry_strike,
            "weight":      1.0,
        }

    return [
        make_row(entry_str, "CE", True),
        make_row(entry_str, "PE", True),
        make_row(exit_str,  "CE", False),
        make_row(exit_str,  "PE", False),
    ]


# ── Main ──────────────────────────────────────────────────────────────────

def main():
    print(f"Loading CW expiry days: {START_DATE} -> {END_DATE}")
    expiry_days = load_cw_expiry_days(START_DATE, END_DATE)
    print(f"  {len(expiry_days)} CW expiry days found\n")

    index_api    = Index()
    fno_api      = FnO()
    all_signals  = []
    skipped_days = []

    for expiry_date in tqdm(expiry_days, desc="Processing expiry days"):
        try:
            rows = process_expiry_day(expiry_date, index_api, fno_api)
        except Exception as e:
            print(f"  ⚠ {expiry_date}: Unexpected error: {e}")
            rows = []

        if rows:
            all_signals.extend(rows)
        else:
            skipped_days.append(expiry_date)

    if not all_signals:
        print("\nNo signals generated — output file not written.")
        return

    df_out = pd.DataFrame(all_signals)
    df_out.to_csv(OUTPUT_PATH, index=False)

    # ── Sanity check ──────────────────────────────────────────────────────
    n_el  = int(df_out["entry_long"].sum())
    n_xl  = int(df_out["exit_long"].sum())
    n_es  = int(df_out["entry_short"].sum())
    n_xs  = int(df_out["exit_short"].sum())
    multi = int(
        (df_out[["entry_long","exit_long","entry_short","exit_short"]].sum(axis=1) > 1).sum()
    )

    print(f"\n{'=' * 60}")
    print("SIGNAL GENERATION COMPLETE")
    print(f"{'=' * 60}")
    print(f"  Output file       : {OUTPUT_PATH}")
    print(f"  Total rows        : {len(df_out)}")
    print(f"  Long  entries     : {n_el}")
    print(f"  Long  exits       : {n_xl}")
    print(f"  Short entries     : {n_es}")
    print(f"  Short exits       : {n_xs}")
    print(f"  Entry/Exit match  : {'OK' if (n_el == n_xl and n_es == n_xs) else 'MISMATCH!'}")
    print(f"  Multi-flag rows   : {multi}{'  FIX THIS!' if multi > 0 else '  OK'}")
    print(f"  Unique tickers    : {df_out['ticker'].unique().tolist()}")
    print(f"  Instruments       : {sorted(df_out['instrument'].unique().tolist())}")
    print(f"  Date range        : {df_out['timestamp'].min()} -> {df_out['timestamp'].max()}")
    print(f"  Straddle trades   : {len(all_signals) // 4}")
    print(f"  Days skipped      : {len(skipped_days)}")
    if skipped_days:
        sample = skipped_days[:8]
        print(f"  Skipped sample    : {sample}{'...' if len(skipped_days) > 8 else ''}")
    print(f"{'=' * 60}")


if __name__ == "__main__":
    main()
