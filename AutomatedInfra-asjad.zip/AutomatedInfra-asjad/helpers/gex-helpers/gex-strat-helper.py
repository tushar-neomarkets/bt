#!/usr/bin/env python3
"""
══════════════════════════════════════════════════════════════════════════════
  GEX Regime Trader — NIFTY Weekly Options Signal Generator
══════════════════════════════════════════════════════════════════════════════

Strategy summary
────────────────
Buy ATM NIFTY weekly options (CE/PE) in the direction of a confirmed
intraday breakout, ONLY when dealer net gamma exposure (GEX) is negative
(dealers must hedge WITH the trend, amplifying momentum).

Academic basis
──────────────
• Barbon & Buraschi (2021) "Gamma Fragility" SSRN 3725454
  Core finding: negative aggregate dealer gamma → dealers hedge WITH price
  moves → intraday momentum amplification.

• "Where Does Gamma Hedge Drive the Intraday Market Move?" (AFA 2024)
  Introduces GTBR: minimum spot move at which gamma PnL of a delta-neutral
  dealer exceeds the theta cost. Beyond GTBR, hedging becomes inelastic.

Key signals
───────────
GEX_t = Σ_k [ CE_OI(k,t) × γ_CE(k,t) − PE_OI(k,t) × γ_PE(k,t) ] × spot_t
  GEX < 0  →  net short gamma  →  trend amplification  →  TRADE
  GEX ≥ 0  →  net long gamma   →  mean-reversion       →  NO TRADE

GTBR_t = √( 2 × |θ_ATM_t| / γ_ATM_t )   [index points]
  |intraday move from open| > GTBR → inelastic demand confirmed → enter

Entry / Exit
────────────
Entry  : 15m bar close | GEX < 0 | |spot-open| > GTBR | buy ATM CE/PE
Exit   : GTBR reversion (move < GTBR×0.5) | SL (LTP < entry×0.40) | 3pm

Output : signal_gex_regime_trader.csv
══════════════════════════════════════════════════════════════════════════════
"""

import pandas as pd
import numpy as np
from datetime import date, time, timedelta
from marketdata import Index, FnO
from tqdm import tqdm

# ═══════════════════════════════════════════════════════════════════════════
# 1.  CONFIGURATION
# ═══════════════════════════════════════════════════════════════════════════

START_DATE   = "2019-03-01"
END_DATE     = "2025-12-31"
TICKER       = "NIFTY"
INDEX_NAME   = "NIFTY 50"
OUTPUT_PATH  = "signal_gex_regime_trader.csv"

EXPIRY_FILE  = r"\\10.211.8.76\GFD MBM Data\Auxiliary Data\Expiry File_2025.xlsx"
EXPIRY_SHEET = "Nifty 50"

BAR_INTERVAL     = "1h"
MONITOR_INTERVAL = "1m"
ROLLOVER_DAYS_BEFORE = 0

# ── Greek column names (adjust if API differs) ────────────────────────────
COL_OI     = "oi"
COL_GAMMA  = "gamma"
COL_THETA  = "theta"

# ── GEX / GTBR params ─────────────────────────────────────────────────────
GEX_THRESHOLD    = 0.0    # GEX must be strictly < 0
GTBR_MULTIPLIER  = 0.2    # set >1 for more conservative entry
GTBR_EXIT_FRAC   = 0.2   # exit when |move| < GTBR × 0.50
SL_FRAC          = 0.50   # exit if LTP drops to entry_prem × SL_FRAC

# ── Time gates ────────────────────────────────────────────────────────────
ENTRY_START  = time(9, 44, 59)
ENTRY_END    = time(14, 44, 59)
HARD_EXIT_T  = time(15, 14, 59)


# ═══════════════════════════════════════════════════════════════════════════
# 2.  DATA UTILITIES
# ═══════════════════════════════════════════════════════════════════════════

def _strip_tz(df, col="timestamp"):
    df[col] = (pd.to_datetime(df[col], utc=True)
               .dt.tz_convert("Asia/Kolkata").dt.tz_localize(None))
    return df


def _fetch_bars(interval, start_date, end_date):
    idx = Index()
    chunks, current, end = [], pd.to_datetime(start_date), pd.to_datetime(end_date)
    if interval == BAR_INTERVAL:
        current -= pd.DateOffset(months=1)
    while current < end:
        chunk_end = min(current + pd.DateOffset(months=3) - pd.Timedelta(days=1), end)
        try:
            df = idx.get_prices(INDEX_NAME,
                                current.strftime("%Y-%m-%d"),
                                chunk_end.strftime("%Y-%m-%d"),
                                interval=interval, columns="ohlc")
            if df is not None and not df.empty:
                chunks.append(df)
        except Exception as e:
            print(f"  ⚠ {interval} {current.date()}→{chunk_end.date()}: {e}")
        current = chunk_end + timedelta(days=1)
    if not chunks:
        raise RuntimeError(f"No {interval} data fetched.")
    full = pd.concat(chunks, ignore_index=True)
    full = _strip_tz(full)
    full.sort_values("timestamp", inplace=True)
    full.drop_duplicates("timestamp", inplace=True)
    full.set_index("timestamp", inplace=True)
    return full.dropna(subset=["close"])


def fetch_option_chain(trade_date, kind, expiry_date, interval="1m"):
    fno = FnO()
    ds, exp = trade_date.strftime("%Y-%m-%d"), expiry_date.strftime("%Y-%m-%d")
    try:
        df = fno.get_prices(TICKER, start_date=ds, end_date=ds,
                            interval=interval, expiry=exp, kind=kind, columns="all", include_greeks=True)
        if df is None or df.empty:
            return pd.DataFrame()
        df = _strip_tz(df)
        df.sort_values("timestamp", inplace=True)
        ot_col = "option_type" if "option_type" in df.columns else "type"
        if ot_col in df.columns:
            df = df.loc[df[ot_col] == kind].copy()
        df.drop_duplicates(["timestamp", "strike_price"], keep="last", inplace=True)
        return df
    except Exception as e:
        print(f"  ⚠ Opt {ds} {kind} exp={exp}: {e}")
        return pd.DataFrame()


def load_expiry_maps():
    df = pd.read_excel(EXPIRY_FILE, sheet_name=EXPIRY_SHEET)
    df.columns = df.columns.str.strip()
    for c in ["Date", "Current Week", "Next Week"]:
        df[c] = pd.to_datetime(df[c], dayfirst=True)
    return (dict(zip(df["Date"].dt.date, df["Current Week"].dt.date)),
            dict(zip(df["Date"].dt.date, df["Next Week"].dt.date)))


# ═══════════════════════════════════════════════════════════════════════════
# 3.  GEX / GTBR MATHS
# ═══════════════════════════════════════════════════════════════════════════

def compute_gex(ce_snap, pe_snap, spot, n_strikes=10):
    """
    GEX = Σ_k [CE_OI(k)×γ_CE(k) − PE_OI(k)×γ_PE(k)] × spot
    Limited to ATM ± n_strikes, resolved from actual chain strikes.
    """
    gex = 0.0
    for snap, sign in [(ce_snap, +1), (pe_snap, -1)]:
        if snap.empty or COL_OI not in snap.columns or COL_GAMMA not in snap.columns:
            continue
        s = snap.dropna(subset=[COL_OI, COL_GAMMA])
        if s.empty:
            continue

        # Rank strikes by distance from spot, keep nearest N on each side + ATM
        strikes = s["strike_price"].unique()
        strikes_sorted = sorted(strikes, key=lambda k: abs(k - spot))
        keep = set(strikes_sorted[:2 * n_strikes + 1])
        s = s.loc[s["strike_price"].isin(keep)]

        gex += sign * (s[COL_OI] * s[COL_GAMMA]).sum() * spot
    return gex


def compute_gtbr(ce_snap, pe_snap, spot):
    best_g, best_t = None, None
    for snap, kind in [(ce_snap, "CE"), (pe_snap, "PE")]:
        if snap.empty or COL_GAMMA not in snap.columns or COL_THETA not in snap.columns:
            continue
        # ATM = nearest available strike to spot
        idx = (snap["strike_price"] - spot).abs().idxmin()
        row = snap.loc[[idx]]
        g = row[COL_GAMMA].iloc[0]
        t = row[COL_THETA].iloc[0]
        if pd.notna(g) and pd.notna(t) and g > 0:
            if best_g is None or g > best_g:
                best_g, best_t = g, t

    if best_g is None or best_g <= 0:
        return 1e9
    return float(np.sqrt(2.0 * abs(best_t) / best_g))


# ═══════════════════════════════════════════════════════════════════════════
# 4.  SIGNAL HELPERS
# ═══════════════════════════════════════════════════════════════════════════

def _entry_row(ts, kind, csv_expiry, strike, premium):
    return {"timestamp": str(ts)[:19], "ticker": TICKER,
            "entry_long": 1, "exit_long": 0,
            "entry_short": 0, "exit_short": 0,
            "instrument": kind, "expiry": csv_expiry,
            "strike": strike, "weight": 1.0,
            "entry_premium": round(premium, 2)}


def _exit_row(ts, pos):
    return {"timestamp": str(ts)[:19], "ticker": TICKER,
            "entry_long": 0, "exit_long": 1,
            "entry_short": 0, "exit_short": 0,
            "instrument": pos["kind"], "expiry": pos["csv_expiry"],
            "strike": pos["strike"], "weight": 1.0, "entry_premium": ""}


# ═══════════════════════════════════════════════════════════════════════════
# 5.  SINGLE-DAY PROCESSOR
# ═══════════════════════════════════════════════════════════════════════════

def process_day(trade_date, df_15m, df_1m_idx, cw_map, nw_map):
    cw_exp = cw_map.get(trade_date)
    nw_exp = nw_map.get(trade_date)
    if not cw_exp or not nw_exp:
        return []

    use_nw     = (cw_exp - trade_date).days <= ROLLOVER_DAYS_BEFORE
    api_expiry = nw_exp if use_nw else cw_exp
    csv_expiry = "nw"  if use_nw else "cw"

    day_15m = df_15m.loc[df_15m.index.date == trade_date]
    day_1m  = df_1m_idx.loc[df_1m_idx.index.date == trade_date]
    if day_15m.empty or day_1m.empty:
        return []

    session_open = float(day_1m.iloc[0]["open"])
    bar_ts_list  = day_15m.index.tolist()
    signals      = []
    position     = None
    day_done     = False
    cache        = {}

    def _chain(kind):
        if kind not in cache:
            cache[kind] = fetch_option_chain(trade_date, kind, api_expiry, MONITOR_INTERVAL)
        return cache[kind]

    def _snap(kind, ts):
        ch = _chain(kind)
        return ch.loc[ch["timestamp"] == ts] if not ch.empty else pd.DataFrame()

    def _s1m(kind, strike):
        ch = _chain(kind)
        if ch.empty:
            return pd.DataFrame()
        s = ch.loc[ch["strike_price"] == strike].drop_duplicates("timestamp")
        return s.set_index("timestamp").sort_index()

    def _close(ts, reason="Unknown"):
        nonlocal position
        print(f"  -> EXIT [{reason}] at {ts}")
        signals.append(_exit_row(ts, position))
        position = None

    # ── Main loop ─────────────────────────────────────────────────────────
    for bar_idx, bar_ts in enumerate(bar_ts_list):
        if day_done:
            break
        bar_t     = bar_ts.time()
        close_val = day_15m.at[bar_ts, "close"]

        # 1m monitoring
        if position is not None and bar_idx > 0:
            s1m = _s1m(position["kind"], position["strike"])
            if not s1m.empty:
                mask = (s1m.index > bar_ts_list[bar_idx-1]) & (s1m.index <= bar_ts)
                for m_ts in s1m.loc[mask].index:
                    if position is None:
                        break
                    if m_ts.time() >= HARD_EXIT_T:
                        _close(m_ts, "HARD_EXIT_T 1m"); day_done = True; break

                    m_close  = float(s1m.at[m_ts, "close"])
                    move_now = abs(close_val - session_open)
                    ce_s = _snap("CE", m_ts); pe_s = _snap("PE", m_ts)
                    gtbr_1m = compute_gtbr(ce_s, pe_s, close_val)

                    if move_now < gtbr_1m * GTBR_EXIT_FRAC:
                        _close(m_ts, "GTBR Reversion"); break
                    if m_close <= position["entry_prem"] * SL_FRAC:
                        _close(m_ts, "Stop Loss"); break

        if day_done:
            break

        if position is not None and bar_t >= HARD_EXIT_T:
            _close(bar_ts, "HARD_EXIT_T 15m"); day_done = True; break

        if not (ENTRY_START <= bar_t <= ENTRY_END) or position is not None:
            continue

        # Compute GEX + GTBR at bar close
        ce_s = _snap("CE", bar_ts); pe_s = _snap("PE", bar_ts)
        if ce_s.empty or pe_s.empty:
            print(f"[{bar_ts.time()}] Missing CE/PE options data")
            continue
        gex  = compute_gex(ce_s, pe_s, close_val)
        gtbr = compute_gtbr(ce_s, pe_s, close_val)

        print(f"[{bar_ts.time()}] Spot: {close_val:.2f} (Open: {session_open:.2f}) | Move: {abs(close_val - session_open):.2f} | GEX: {gex:.0f} | GTBR: {gtbr:.2f}")

        if gex >= GEX_THRESHOLD:
            print(f"  -> Skipping: GEX ({gex:.0f}) >= {GEX_THRESHOLD}")
            continue
        if abs(close_val - session_open) < gtbr * GTBR_MULTIPLIER:
            print(f"  -> Skipping: Move ({abs(close_val - session_open):.2f}) < GTBR * Mul ({gtbr * GTBR_MULTIPLIER:.2f})")
            continue

        kind   = "CE" if close_val > session_open else "PE"

        snap   = ce_s if kind == "CE" else pe_s
        if snap.empty:
            continue
        idx = (snap["strike_price"] - close_val).abs().idxmin()
        strike = float(snap.at[idx, "strike_price"])

        row = snap.loc[snap["strike_price"] == strike]
        if row.empty:
            i   = (snap["strike_price"] - strike).abs().idxmin()
            row = snap.loc[[i]]
            strike = float(row["strike_price"].iloc[0])
        if row.empty:
            continue
        prem = float(row["close"].iloc[0])
        if prem <= 0:
            continue

        print(f"  GEX {trade_date} {bar_ts.time()} {kind} "
              f"stk={strike} prem={prem:.1f} GEX={gex:.0f} GTBR={gtbr:.1f}")
        signals.append(_entry_row(bar_ts, kind, csv_expiry, strike, prem))
        position = dict(strike=strike, kind=kind, csv_expiry=csv_expiry,
                        api_expiry_date=api_expiry, entry_prem=prem)

    if position is not None:
        last_ts = bar_ts_list[-1]
        s1m = _s1m(position["kind"], position["strike"])
        if not s1m.empty:
            late = s1m.loc[s1m.index.map(lambda x: x.time() >= HARD_EXIT_T)]
            if not late.empty:
                last_ts = late.index[0]
        _close(last_ts, "Orphan force-close")

    return signals


# ═══════════════════════════════════════════════════════════════════════════
# 6.  MAIN
# ═══════════════════════════════════════════════════════════════════════════

def generate_signals():
    print("=" * 70)
    print("  GEX Regime Trader — Signal Generator")
    print("=" * 70)

    print(f"\n[1/4] Fetching {BAR_INTERVAL} index bars …")
    df_15m = _fetch_bars(BAR_INTERVAL, START_DATE, END_DATE)
    print(f"  {len(df_15m):,} bars")

    print("\n[2/4] Fetching 1m index bars for session open …")
    df_1m = _fetch_bars("1m", START_DATE, END_DATE)
    print(f"  {len(df_1m):,} bars")

    print("\n[3/4] Loading expiry calendar …")
    cw_map, nw_map = load_expiry_maps()

    start_d = date.fromisoformat(START_DATE)
    end_d   = date.fromisoformat(END_DATE)
    days    = sorted(d for d in set(df_15m.index.date) if start_d <= d <= end_d)
    print(f"\n[4/4] Processing {len(days):,} days …\n")

    all_sigs = []
    for td in tqdm(days, desc="GEX Regime Trader", unit="day"):
        all_sigs.extend(process_day(td, df_15m, df_1m, cw_map, nw_map))

    if not all_sigs:
        print("  ⚠ No signals."); return

    df_out = pd.DataFrame(all_sigs)
    df_out.to_csv(OUTPUT_PATH, index=False)
    n_e = int(df_out["entry_long"].sum())
    n_x = int(df_out["exit_long"].sum())
    print(f"\n{'='*70}\n  Output: {OUTPUT_PATH}  |  Entries: {n_e:,}  |  Exits: {n_x:,}")
    print(f"  Match: {'✓' if n_e==n_x else '✗ MISMATCH'}\n{'='*70}")


if __name__ == "__main__":
    generate_signals()