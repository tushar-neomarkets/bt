import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from pathlib import Path
import json
from itertools import product
import time
from tqdm import tqdm
import warnings
from marketdata.fno_service import FnO as FnOService
from datetime import datetime, timedelta, time as dt_time

fno_svc = FnOService()

warnings.filterwarnings('ignore')

# Set style for better plots
sns.set_style("darkgrid")
plt.rcParams['figure.figsize'] = (14, 8)

EXPIRY_FALLBACK = {'cm': 'nm', 'nm': 'fm', 'fm': 'nm', 'cw': 'nw', 'nw': 'cw'}
CASH_CLOSE_PATH = r"misc-data\all_fno_adj_cash_close 2.csv"

HEDGE_ENTRY_TIME = dt_time(15, 14, 59)
HEDGE_EXIT_TIME = dt_time(9, 30, 59)

SWEEP_INITIAL_CAPITAL = 100_000
SWEEP_POSITION_SIZE = 1.0
SWEEP_RESULTS_DIR = Path("index_short_sweep_results_time_filtered_fut_cm_roll")

HEDGE_EXPIRY = 'cm'
HEDGE_OTM_GRID = [0.00, 0.01, 0.02, 0.03, 0.04, 0.05]
BACKTEST_EXPIRY = 'cm'  # which futures contract the backtest trades on: 'cm', 'nm', 'fm'
CM_ROLL_TTM = 5 


def _build_trading_calendar():
    """Load all dates the market was open. Handles weekends + holidays."""
    cash_df = pd.read_csv(CASH_CLOSE_PATH)
    cash_df["Date"] = pd.to_datetime(cash_df["Date"])
    dates = sorted(cash_df["Date"].dt.date.unique())
    return dates, set(dates)


def get_next_trading_day(date):
    """Next actual market-open day using the trading calendar."""
    d = date + timedelta(days=1)
    while d not in TRADING_DAYS_SET:
        d += timedelta(days=1)
        if d > date + timedelta(days=10):  # safety cap
            break
    return d


def get_futures_price(date, target_time, expiry="fm"):
    """NIFTY futures close at target_time on `date`."""
    try:
        fut = fno_svc.get_prices(
            "NIFTY",
            start_date=date.strftime("%Y-%m-%d"),
            kind="futures",
            interval="1m",
            expiry=expiry,
        )
        if fut is None or fut.empty:
            return None, None

        # Convert UTC → IST for correct time matching
        fut['timestamp'] = pd.to_datetime(fut['timestamp'])
        if fut['timestamp'].dt.tz is not None:
            fut['timestamp'] = fut['timestamp'].dt.tz_convert('Asia/Kolkata').dt.tz_localize(None)
        else:
            fut['timestamp'] = fut['timestamp'] + pd.Timedelta(hours=5, minutes=30)

        contract_expiry = pd.to_datetime(fut["expiry_date"].iloc[0]).date() if "expiry_date" in fut.columns else None

        matched = _filter_by_time(fut, target_time)
        if matched.empty:
            matched = _closest_by_time(fut, target_time)
            print(f"Closest futures time: {matched.iloc[0]['timestamp']}")

        return float(matched.iloc[0]["close"]), contract_expiry

    except Exception as e:
        print(f"Futures error ({date}): {e}")
        return None, None


def is_trading_day(date):
    """Check if a date is in the trading calendar."""
    return date in TRADING_DAYS_SET


def _filter_by_time(df, target_time):
    """Filter rows where timestamp matches target HH:MM."""
    return df[
        (df["timestamp"].dt.hour == target_time.hour) &
        (df["timestamp"].dt.minute == target_time.minute)
        ]


def _closest_by_time(df, target_time):
    """Fallback: row with HH:MM closest to target."""
    tgt = target_time.hour * 60 + target_time.minute
    dist = (df["timestamp"].dt.hour * 60 + df["timestamp"].dt.minute - tgt).abs()
    return df.loc[[dist.idxmin()]]


def _fetch_chain(date, expiry="cm"):
    """Fetch full NIFTY option chain for a date."""
    try:
        chain = fno_svc.get_prices(
            "NIFTY",
            start_date=date.strftime("%Y-%m-%d"),
            kind="options",
            expiry=expiry,
        )
        if chain is None or chain.empty:
            return None
        # Convert UTC → IST for correct time matching
        chain['timestamp'] = pd.to_datetime(chain['timestamp'])
        if chain['timestamp'].dt.tz is not None:
            chain['timestamp'] = chain['timestamp'].dt.tz_convert('Asia/Kolkata').dt.tz_localize(None)
        else:
            chain['timestamp'] = chain['timestamp'] + pd.Timedelta(hours=5, minutes=30)
        return chain
    except Exception as e:
        print(f"Chain error ({date}, {expiry}): {e}")
        return None


def get_hedge_entry(date, futures_price, direction, contract_expiry, otm_pct, default_expiry):
    if direction == 1:
        target_strike = futures_price * (1 - otm_pct)
        option_type = "PE"
        hedge_type = "Long Put (Downside)"
    else:
        target_strike = futures_price * (1 + otm_pct)
        option_type = "CE"
        hedge_type = "Long Call (Upside)"

    exp_label = default_expiry
    chain = _fetch_chain(date, expiry=exp_label)
    if chain is None:
        return None

    chain_expiry = pd.to_datetime(chain['expiry_date'].iloc[0]).date() if 'expiry_date' in chain.columns else None
    if chain_expiry is not None and (chain_expiry - date).days < CM_ROLL_TTM:
        exp_label = EXPIRY_FALLBACK.get(default_expiry, 'nm')
        print(f"{default_expiry.upper()} TTM={( chain_expiry - date).days} < {CM_ROLL_TTM} — rolling to {exp_label.upper()}")
        chain = _fetch_chain(date, expiry=exp_label)
        if chain is None:
            return None

    # Compute exit label for post-expiry label shift
    exit_label = default_expiry
    if exp_label == default_expiry and default_expiry not in ('cm', 'cw'):
        check_label = 'cw' if default_expiry == 'nw' else 'cm'
        check_chain = _fetch_chain(date, expiry=check_label)
        if check_chain is not None:
            check_exp = pd.to_datetime(check_chain['expiry_date'].iloc[0]).date()
            if check_exp == date:
                SHIFT_DOWN = {'nw': 'cw', 'nm': 'cm', 'fm': 'nm'}
                exit_label = SHIFT_DOWN[default_expiry]

                print(f"  Current {check_label.upper()} expires today — exit will use {exit_label.upper()}")

    typed = chain[chain["option_type"] == option_type]
    if typed.empty:
        return None

    strikes = typed["strike_price"].unique()
    s = pd.Series(strikes)
    strike = float(strikes[((s - target_strike).abs()).idxmin()])

    strike_rows = typed[typed["strike_price"] == strike]
    matched = _filter_by_time(strike_rows, HEDGE_ENTRY_TIME)
    if matched.empty:
        matched = _closest_by_time(strike_rows, HEDGE_ENTRY_TIME)
        print(f"Closest option entry time: {matched.iloc[0]['timestamp']}")
    if matched.empty:
        return None

    row = matched.iloc[0]
    opt_expiry = pd.to_datetime(row["expiry_date"]).date() if "expiry_date" in row.index else None

    return {
        "strike": strike,
        "entry_premium": float(row["close"]),
        "option_type": option_type,
        "hedge_type": hedge_type,
        "exit_label": exit_label,
        "expiry_label": exp_label,
        "expiry_date": opt_expiry,
        "otm_pct": abs(strike - futures_price) / futures_price * 100,
        "ticker": row.get("ticker", f"NIFTY {int(strike)} {option_type}"),
    }

def get_hedge_exit(exit_date, strike, option_type, expiry_label, hedge_expiry, option_expiry_date=None):

    tried = set()
    candidates = []
    for label in [expiry_label, hedge_expiry, 'cm', 'nm', 'fm']:
        if label not in tried:
            candidates.append(label)
            tried.add(label)

    chain = None
    used_label = None

    for label in candidates:
        candidate_chain = _fetch_chain(exit_date, expiry=label)
        if candidate_chain is None:
            continue

        if option_expiry_date is not None:
            chain_exp = pd.to_datetime(candidate_chain['expiry_date'].iloc[0]).date()
            if chain_exp == option_expiry_date:
                chain = candidate_chain
                used_label = label
                break
            # Wrong contract — skip
            continue
        else:
            # Legacy fallback: no expiry_date provided, use first available
            chain = candidate_chain
            used_label = label
            break

    # Try to get futures price at exit (needed for intrinsic fallback)
    exit_fut_price, _ = get_futures_price(exit_date, HEDGE_EXIT_TIME)

    if chain is not None:
        mask = (chain["strike_price"] == strike) & (chain["option_type"] == option_type)
        strike_rows = chain[mask]

        if not strike_rows.empty:
            matched = _filter_by_time(strike_rows, HEDGE_EXIT_TIME)
            if matched.empty:
                matched = _closest_by_time(strike_rows, HEDGE_EXIT_TIME)
                print(f"Closest option exit time: {matched.iloc[0]['timestamp']}")

            if not matched.empty:
                row = matched.iloc[0]
                return float(row["close"]), row.get("ticker", f"NIFTY {int(strike)} {option_type}")

        print(f"Strike {strike} {option_type} not in exit chain ({used_label}) — using intrinsic")
    else:
        if option_expiry_date is not None:
            print(f"No chain matching expiry {option_expiry_date} on {exit_date} (tried {candidates}) — using intrinsic")
        else:
            print(f"No exit chain — using intrinsic")

    # Intrinsic value fallback
    if exit_fut_price is None:
        print(f"No futures price either — cannot compute intrinsic")
        return None, None

    if option_type == "PE":
        intrinsic = max(0.05, strike - exit_fut_price)
    else:
        intrinsic = max(0.05, exit_fut_price - strike)

    print(f"Intrinsic: max(0.05, {strike:.0f} - {exit_fut_price:.2f}) = ₹{intrinsic:.2f}" if option_type == "PE"
          else f"Intrinsic: max(0.05, {exit_fut_price:.2f} - {strike:.0f}) = ₹{intrinsic:.2f}")

    return intrinsic, f"NIFTY {int(strike)} {option_type} (intrinsic)"


TRADING_DAYS, TRADING_DAYS_SET = _build_trading_calendar()


def _build_daily_closes(start_date, end_date, expiry=None):
    """Fetch NIFTY futures close for each trading day in range.
       For CM: rolls to NM when TTM < CM_ROLL_TTM.
       Returns {date: {'price': float, 'contract_expiry': date}}"""
    expiry = expiry or BACKTEST_EXPIRY
    closes = {}
    close_time = dt_time(15, 14, 59)
    target_days = [d for d in TRADING_DAYS if start_date <= d <= end_date]

    for d in tqdm(target_days, desc="Building daily closes"):
        fetch_exp = expiry

        if expiry == 'cm':
            # Check CM's TTM first
            price_cm, exp_cm = get_futures_price(d, close_time, expiry='cm')
            if exp_cm is not None:
                ttm = (exp_cm - d).days
                if ttm < CM_ROLL_TTM:
                    fetch_exp = 'nm'
                    # Fetch NM price
                    price, contract_exp = get_futures_price(d, close_time, expiry='nm')
                    if price is not None:
                        closes[d] = {'price': price, 'contract_expiry': contract_exp}
                    continue

            # TTM >= threshold or no CM data → use CM
            if price_cm is not None:
                closes[d] = {'price': price_cm, 'contract_expiry': exp_cm}
            continue

        # NM / FM — unchanged
        price, contract_exp = get_futures_price(d, close_time, expiry=expiry)
        if price is not None:
            closes[d] = {'price': price, 'contract_expiry': contract_exp}

    return closes


_contract_close_cache = {}  # (date, expiry_label) → (price, contract_expiry)


def _get_contract_close(date, entry_contract_expiry, daily_closes):
    """
    Get close price for a SPECIFIC contract on a given date.
    Primary cache (fm) checked first, then cascades nm → cm.
    Matches by contract_expiry to ensure same contract throughout trade.
    """
    # 1. Try primary cache (fm)
    if date in daily_closes:
        info = daily_closes[date]
        if info['contract_expiry'] == entry_contract_expiry:
            return info['price']

    # 2. Cascade: nm, cm — fetch on-demand, cache result
    close_time = dt_time(15, 14, 59)
    for exp in ['nm', 'cm']:
        cache_key = (date, exp)
        if cache_key in _contract_close_cache:
            price, contract_exp = _contract_close_cache[cache_key]
            if contract_exp == entry_contract_expiry:
                return price
            continue

        price, contract_exp = get_futures_price(date, close_time, expiry=exp)
        if price is not None:
            _contract_close_cache[cache_key] = (price, contract_exp)
            if contract_exp == entry_contract_expiry:
                return price

    # 3. No match — fall back to fm price (better than nothing)
    if date in daily_closes:
        print(f"No contract match for {date} (wanted exp {entry_contract_expiry}), using fm")
        return daily_closes[date]['price']
    return None


class StrategyBacktester:
    """
    Comprehensive backtesting framework for multiple short-only strategies
    """

    def __init__(self, df, initial_capital=100000, position_size=1.0):
        self.df = df.copy()
        self.initial_capital = initial_capital
        self.position_size = position_size
        self.results_dir = Path("backtest_results")
        self.results_dir.mkdir(exist_ok=True)

    def calculate_atr(self, period=14):
        """Calculate Average True Range"""
        high = self.df['high']
        low = self.df['low']
        close = self.df['close']

        tr1 = high - low
        tr2 = abs(high - close.shift(1))
        tr3 = abs(low - close.shift(1))

        tr = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)
        atr = tr.rolling(period).mean()
        return atr

    def calculate_adx(self, period=14):
        """Calculate ADX (Average Directional Index)"""
        high = self.df['high']
        low = self.df['low']
        close = self.df['close']

        plus_dm = high.diff()
        minus_dm = -low.diff()

        plus_dm[plus_dm < 0] = 0
        minus_dm[minus_dm < 0] = 0

        tr = self.calculate_atr(1)
        atr = tr.rolling(period).mean()

        plus_di = 100 * (plus_dm.rolling(period).mean() / atr)
        minus_di = 100 * (minus_dm.rolling(period).mean() / atr)

        dx = 100 * abs(plus_di - minus_di) / (plus_di + minus_di)
        adx = dx.rolling(period).mean()

        return adx

    def prepare_indicators(self):
        """Prepare all indicators needed for strategies"""
        df = self.df

        # ATR
        df['atr'] = self.calculate_atr(14)
        df['atr_pct'] = df['atr'] / df['close']

        # ADX
        df['adx'] = self.calculate_adx(14)

        # Volume indicators
        df['volume_ma'] = df['volume'].rolling(20).mean()
        df['volume_ratio'] = df['volume'] / df['volume_ma']

        # Multiple EMAs
        df['ema_8'] = df['close'].ewm(span=8, adjust=False).mean()
        df['ema_21'] = df['close'].ewm(span=21, adjust=False).mean()
        df['ema_50'] = df['close'].ewm(span=50, adjust=False).mean()
        df['ema_55'] = df['close'].ewm(span=55, adjust=False).mean()
        df['ema_200'] = df['close'].ewm(span=200, adjust=False).mean()

        # Z-score for mean reversion
        df['sma_20'] = df['close'].rolling(20).mean()
        df['std_20'] = df['close'].rolling(20).std()
        df['zscore'] = (df['close'] - df['sma_20']) / df['std_20']

        # Support/Resistance
        df['support_20'] = df['low'].rolling(20).min()
        df['resistance_20'] = df['high'].rolling(20).max()

        # Gap analysis
        df['gap'] = (df['open'] - df['close'].shift(1)) / df['close'].shift(1)

        # Time filters
        df['datetime_dt'] = pd.to_datetime(df['datetime'])
        df['hour'] = df['datetime_dt'].dt.hour
        df['day_of_week'] = df['datetime_dt'].dt.dayofweek

        # Multi-timeframe
        df['close_4h'] = df['close'].rolling(4).mean()
        df['downtrend_4h'] = df['close_4h'] < df['close_4h'].shift(4)

        # Bollinger Bands
        df['bb_upper'] = df['sma_20'] + (2 * df['std_20'])
        df['bb_lower'] = df['sma_20'] - (2 * df['std_20'])
        df['bb_pct'] = (df['close'] - df['bb_lower']) / (df['bb_upper'] - df['bb_lower'])

        self.df = df

    def strategy_time_filtered(self):
        """Time-of-Day Filtered Strategy"""
        df = self.df.copy()

        entry = (
                df['rsi_crossover_bearish'] &
                (df['close'] < df['EMA_20']) &
                (df['hour'].isin([9, 10, 15])) &  # First/last hour
                (df['volume_ratio'] >= 1.0)
        )

        return entry, 'Time_Filtered'

    def backtest_strategy(self, entry_signals, strategy_name, dynamic_stops=True):
        """
        Execute backtest for a given strategy
        """
        df = self.df.copy()
        df['entry_signal'] = entry_signals
        df = df.sort_values('datetime').reset_index(drop=True)

        # Initialize tracking
        df['position'] = 0
        df['entry_price'] = np.nan
        df['exit_price'] = np.nan
        df['pnl'] = 0.0
        df['capital'] = float(self.initial_capital)
        df['drawdown'] = 0.0

        current_position = 0
        entry_price = 0
        entry_idx = 0
        trades = []
        peak_capital = self.initial_capital

        for i in range(1, len(df)):
            row = df.iloc[i]
            prev_capital = df.loc[i - 1, 'capital']

            # Entry logic
            if current_position == 0 and row['entry_signal']:
                current_position = -1  # Short position
                entry_price = row['close']
                entry_idx = i
                df.loc[i, 'position'] = -1
                df.loc[i, 'entry_price'] = entry_price

            # Exit logic
            elif current_position == -1:
                df.loc[i, 'position'] = -1
                exit_triggered = False
                exit_reason = ''

                # Dynamic stop loss based on ATR
                if dynamic_stops:
                    stop_loss = entry_price * (1 + 2 * df.loc[i, 'atr'] / df.loc[i, 'close'])
                else:
                    stop_loss = entry_price * 1.03

                # Exit conditions
                if row['close'] > stop_loss:
                    exit_triggered = True
                    exit_reason = 'Stop Loss'
                elif row['rsi_crossover_bullish']:
                    exit_triggered = True
                    exit_reason = 'RSI Bullish Cross'
                elif row['close'] > row['EMA_20']:
                    exit_triggered = True
                    exit_reason = 'Above EMA'
                elif row['rsi'] < 30:
                    exit_triggered = True
                    exit_reason = 'Oversold'

                if exit_triggered:
                    exit_price = row['close']
                    pnl = (entry_price - exit_price) / entry_price * self.position_size * prev_capital

                    df.loc[i, 'exit_price'] = exit_price
                    df.loc[i, 'pnl'] = pnl
                    df.loc[i, 'capital'] = prev_capital + pnl

                    trades.append({
                        'entry_date': df.loc[entry_idx, 'datetime'],
                        'exit_date': row['datetime'],
                        'entry_price': entry_price,
                        'exit_price': exit_price,
                        'pnl': pnl,
                        'return_pct': (entry_price - exit_price) / entry_price * 100,
                        'exit_reason': exit_reason,
                        'hold_periods': i - entry_idx
                    })

                    current_position = 0
                else:
                    df.loc[i, 'capital'] = prev_capital
            else:
                df.loc[i, 'capital'] = prev_capital

            # Track drawdown
            if df.loc[i, 'capital'] > peak_capital:
                peak_capital = df.loc[i, 'capital']
            df.loc[i, 'drawdown'] = (peak_capital - df.loc[i, 'capital']) / peak_capital * 100

        trades_df = pd.DataFrame(trades)

        # Calculate metrics
        metrics = self.calculate_metrics(df, trades_df, strategy_name)

        return df, trades_df, metrics

    def calculate_metrics(self, df, trades_df, strategy_name):
        """Calculate comprehensive performance metrics"""

        if len(trades_df) == 0:
            return {
                'strategy': strategy_name,
                'total_return_pct': 0,
                'total_trades': 0,
                'win_rate': 0,
                'profit_factor': 0,
                'sharpe_ratio': 0,
                'max_drawdown': 0,
                'avg_trade_return': 0
            }

        # Basic metrics
        final_capital = df['capital'].iloc[-1]
        total_return = (final_capital - self.initial_capital) / self.initial_capital * 100

        total_trades = len(trades_df)
        winning_trades = len(trades_df[trades_df['pnl'] > 0])
        losing_trades = len(trades_df[trades_df['pnl'] < 0])
        win_rate = winning_trades / total_trades * 100 if total_trades > 0 else 0

        avg_win = trades_df[trades_df['pnl'] > 0]['pnl'].mean() if winning_trades > 0 else 0
        avg_loss = trades_df[trades_df['pnl'] < 0]['pnl'].mean() if losing_trades > 0 else 0

        profit_factor = abs(
            avg_win * winning_trades / (avg_loss * losing_trades)) if losing_trades > 0 and avg_loss != 0 else np.inf

        # Risk metrics
        returns = df['capital'].pct_change().dropna()
        sharpe_ratio = (returns.mean() / returns.std() * np.sqrt(252 * 24)) if returns.std() != 0 else 0
        max_drawdown = df['drawdown'].max()

        # Trade metrics
        avg_trade_return = trades_df['return_pct'].mean()
        median_trade_return = trades_df['return_pct'].median()
        max_win = trades_df['return_pct'].max()
        max_loss = trades_df['return_pct'].min()
        avg_hold_periods = trades_df['hold_periods'].mean()

        # Monthly analysis
        trades_df['exit_month'] = pd.to_datetime(trades_df['exit_date']).dt.to_period('M')
        monthly_returns = trades_df.groupby('exit_month')['pnl'].sum()
        profitable_months = len(monthly_returns[monthly_returns > 0])
        total_months = len(monthly_returns)
        monthly_win_rate = profitable_months / total_months * 100 if total_months > 0 else 0

        metrics = {
            'strategy': strategy_name,
            'total_return_pct': total_return,
            'final_capital': final_capital,
            'total_trades': total_trades,
            'winning_trades': winning_trades,
            'losing_trades': losing_trades,
            'win_rate': win_rate,
            'avg_win': avg_win,
            'avg_loss': avg_loss,
            'profit_factor': profit_factor,
            'sharpe_ratio': sharpe_ratio,
            'max_drawdown': max_drawdown,
            'avg_trade_return': avg_trade_return,
            'median_trade_return': median_trade_return,
            'max_win': max_win,
            'max_loss': max_loss,
            'avg_hold_periods': avg_hold_periods,
            'monthly_win_rate': monthly_win_rate
        }

        return metrics

    def plot_results(self, df, trades_df, metrics, strategy_name):
        """Create comprehensive visualization plots"""

        strategy_dir = self.results_dir / strategy_name
        strategy_dir.mkdir(exist_ok=True)

        if len(trades_df) == 0:
            print(f"No trades for {strategy_name}, skipping plots")
            return

        # 1. Equity Curve
        fig, axes = plt.subplots(2, 1, figsize=(14, 10))

        axes[0].plot(pd.to_datetime(df['datetime']), df['capital'], linewidth=2)
        axes[0].axhline(y=self.initial_capital, color='r', linestyle='--', alpha=0.5, label='Initial Capital')
        axes[0].set_title(f'{strategy_name} - Equity Curve', fontsize=14, fontweight='bold')
        axes[0].set_ylabel('Capital ($)')
        axes[0].legend()
        axes[0].grid(True, alpha=0.3)

        # 2. Drawdown
        axes[1].fill_between(pd.to_datetime(df['datetime']), 0, -df['drawdown'], alpha=0.3, color='red')
        axes[1].set_title('Drawdown (%)', fontsize=12, fontweight='bold')
        axes[1].set_xlabel('Date')
        axes[1].set_ylabel('Drawdown (%)')
        axes[1].grid(True, alpha=0.3)

        plt.tight_layout()
        plt.savefig(strategy_dir / 'equity_curve.png', dpi=300, bbox_inches='tight')
        plt.close()

        # 3. Trade Distribution
        fig, axes = plt.subplots(2, 2, figsize=(14, 10))

        # Returns histogram
        axes[0, 0].hist(trades_df['return_pct'], bins=50, edgecolor='black', alpha=0.7)
        axes[0, 0].axvline(x=0, color='r', linestyle='--', linewidth=2)
        axes[0, 0].set_title('Trade Returns Distribution', fontweight='bold')
        axes[0, 0].set_xlabel('Return (%)')
        axes[0, 0].set_ylabel('Frequency')

        # Cumulative PnL
        trades_df['cumulative_pnl'] = trades_df['pnl'].cumsum()
        axes[0, 1].plot(trades_df['cumulative_pnl'], linewidth=2)
        axes[0, 1].set_title('Cumulative PnL', fontweight='bold')
        axes[0, 1].set_xlabel('Trade Number')
        axes[0, 1].set_ylabel('Cumulative PnL ($)')
        axes[0, 1].grid(True, alpha=0.3)

        # Win/Loss by exit reason
        exit_reasons = trades_df['exit_reason'].value_counts()
        axes[1, 0].bar(exit_reasons.index, exit_reasons.values, edgecolor='black')
        axes[1, 0].set_title('Exit Reasons', fontweight='bold')
        axes[1, 0].set_xlabel('Reason')
        axes[1, 0].set_ylabel('Count')
        axes[1, 0].tick_params(axis='x', rotation=45)

        # Monthly returns
        trades_df['exit_month'] = pd.to_datetime(trades_df['exit_date']).dt.to_period('M')
        monthly_pnl = trades_df.groupby('exit_month')['pnl'].sum()
        axes[1, 1].bar(range(len(monthly_pnl)), monthly_pnl.values,
                       color=['g' if x > 0 else 'r' for x in monthly_pnl.values],
                       edgecolor='black', alpha=0.7)
        axes[1, 1].set_title('Monthly PnL', fontweight='bold')
        axes[1, 1].set_xlabel('Month')
        axes[1, 1].set_ylabel('PnL ($)')
        axes[1, 1].axhline(y=0, color='black', linestyle='-', linewidth=1)

        plt.tight_layout()
        plt.savefig(strategy_dir / 'trade_analysis.png', dpi=300, bbox_inches='tight')
        plt.close()

        # 4. Save trades CSV
        trades_df.to_csv(strategy_dir / 'trades.csv', index=False)

        # 5. Save metrics JSON
        with open(strategy_dir / 'metrics.json', 'w') as f:
            json.dump(metrics, f, indent=4, default=str)

        print(f"✓ Results saved for {strategy_name}")

    def run_all_strategies(self):
        """Run all strategies and compile results"""

        print("=" * 80)
        print("PREPARING DATA AND INDICATORS")
        print("=" * 80)
        self.prepare_indicators()

        strategies = [
            # self.strategy_baseline,
            # self.strategy_adx_trend,
            self.strategy_time_filtered,
            # self.strategy_combined_best
        ]

        all_metrics = []

        for strategy_func in strategies:
            entry_signals, strategy_name = strategy_func()

            print(f"\n{'=' * 80}")
            print(f"BACKTESTING: {strategy_name}")
            print(f"{'=' * 80}")

            df_result, trades_df, metrics = self.backtest_strategy(entry_signals, strategy_name)

            # Print summary
            print(f"\nTotal Return: {metrics['total_return_pct']:.2f}%")
            print(f"Total Trades: {metrics['total_trades']}")
            print(f"Win Rate: {metrics['win_rate']:.2f}%")
            print(f"Profit Factor: {metrics['profit_factor']:.2f}")
            print(f"Sharpe Ratio: {metrics['sharpe_ratio']:.2f}")
            print(f"Max Drawdown: {metrics['max_drawdown']:.2f}%")

            # Save results
            self.plot_results(df_result, trades_df, metrics, strategy_name)
            all_metrics.append(metrics)

        # Create comparison summary
        self.create_comparison_summary(all_metrics)

        return all_metrics

    def create_comparison_summary(self, all_metrics):
        """Create Excel summary comparing all strategies"""

        comparison_df = pd.DataFrame(all_metrics)

        # Sort by total return
        comparison_df = comparison_df.sort_values('total_return_pct', ascending=False)

        # Save to Excel with formatting
        excel_path = self.results_dir / 'strategy_comparison.xlsx'

        with pd.ExcelWriter(excel_path, engine='openpyxl') as writer:
            comparison_df.to_excel(writer, sheet_name='Summary', index=False)

            # Get workbook and worksheet
            workbook = writer.book
            worksheet = writer.sheets['Summary']

            # Auto-adjust column widths
            for column in worksheet.columns:
                max_length = 0
                column = [cell for cell in column]
                for cell in column:
                    try:
                        if len(str(cell.value)) > max_length:
                            max_length = len(cell.value)
                    except:
                        pass
                adjusted_width = (max_length + 2)
                worksheet.column_dimensions[column[0].column_letter].width = adjusted_width

        print(f"\n{'=' * 80}")
        print(f"COMPARISON SUMMARY SAVED: {excel_path}")
        print(f"{'=' * 80}\n")

        # Print top 3 strategies
        print("TOP 3 STRATEGIES BY RETURN:")
        for i, row in comparison_df.head(3).iterrows():
            print(f"{row['strategy']}: {row['total_return_pct']:.2f}%")

        return comparison_df


# ============================================================================
# DATA LOADING & RSI CALCULATION
# ============================================================================

import pandas as pd
import datetime as dt
import numpy as np
from marketdata.fno_service import FnO
from marketdata.cash_service import Cash
from marketdata.index_service import Index
from datetime import datetime, timedelta

index = Index()
fno = FnO()


def fetch_full_history(index_name, start_date="2024-01-01", end_date="2025-12-31",
                       cash_name="NIFTY 50", expiry=None):
    expiry = expiry or BACKTEST_EXPIRY
    start = pd.to_datetime(start_date)
    end = pd.to_datetime(end_date)

    def _fetch_blocks(exp_label):
        """Fetch in 1-year blocks for a given expiry."""
        dfs = []
        current_start = start
        while current_start < end:
            current_end = min(current_start + pd.DateOffset(years=1) - pd.Timedelta(days=1), end)
            print(f"Fetching {exp_label}: {current_start.date()} → {current_end.date()}")
            chunk = fno.get_prices(
                "NIFTY",
                current_start.strftime("%Y-%m-%d"),
                current_end.strftime("%Y-%m-%d"),
                interval="1h", columns="ohlcv", kind="futures", expiry=exp_label,
            )
            if chunk is not None and len(chunk) > 0:
                chunk = chunk.rename({"timestamp": "datetime"}, axis=1)
                chunk['datetime'] = pd.to_datetime(chunk['datetime'])
                if chunk['datetime'].dt.tz is not None:
                    chunk['datetime'] = chunk['datetime'].dt.tz_convert('Asia/Kolkata').dt.tz_localize(None)
                else:
                    chunk['datetime'] = chunk['datetime'] + pd.Timedelta(hours=5, minutes=30)
                chunk['contract_expiry'] = pd.to_datetime(chunk['expiry_date']).dt.date
                dfs.append(chunk)
            current_start = current_end + timedelta(days=1)
        if not dfs:
            return pd.DataFrame()
        out = pd.concat(dfs, ignore_index=True).sort_values("datetime")
        return out

    # ── Fetch primary series ──
    df_primary = _fetch_blocks(expiry)
    if df_primary.empty:
        return df_primary

    # ── CM rollover logic ──
    if expiry == 'cm':
        df_primary['bar_date'] = pd.to_datetime(df_primary['datetime']).dt.date
        df_primary['ttm'] = df_primary.apply(
            lambda r: (r['contract_expiry'] - r['bar_date']).days, axis=1
        )

        # Preserve original CM prices BEFORE any stitching
        df_primary['close_pre_roll'] = df_primary['close'].copy()
        df_primary['contract_expiry_pre_roll'] = df_primary['contract_expiry'].copy()
        df_primary['was_rolled'] = False

        needs_roll = df_primary['ttm'] < CM_ROLL_TTM
        if needs_roll.any():
            print(f"\n  CM rollover: {needs_roll.sum()} bars with TTM < {CM_ROLL_TTM} → fetching NM")
            df_nm = _fetch_blocks('nm')

            if not df_nm.empty:
                df_primary['_dt_merge'] = pd.to_datetime(df_primary['datetime']).dt.tz_localize(None) \
                    if pd.to_datetime(df_primary['datetime']).dt.tz is not None \
                    else pd.to_datetime(df_primary['datetime'])

                df_nm['_dt_merge'] = pd.to_datetime(df_nm['datetime']).dt.tz_localize(None) \
                    if pd.to_datetime(df_nm['datetime']).dt.tz is not None \
                    else pd.to_datetime(df_nm['datetime'])

                df_nm = df_nm.drop_duplicates(subset='_dt_merge', keep='last')

                replace_cols = ['open', 'high', 'low', 'close', 'volume',
                                'contract_expiry', 'expiry_date']
                nm_lookup = df_nm.set_index('_dt_merge')[replace_cols]

                roll_idx = df_primary[needs_roll].index
                roll_dts = df_primary.loc[roll_idx, '_dt_merge']

                matched = roll_dts.isin(nm_lookup.index)
                matched_idx = roll_idx[matched]
                matched_dts = roll_dts[matched]

                print(f"  Matched {len(matched_idx)} / {len(roll_idx)} bars to NM data")

                if len(matched_idx) > 0:
                    nm_values = nm_lookup.loc[matched_dts.values]
                    nm_values.index = matched_idx
                    df_primary.loc[matched_idx, replace_cols] = nm_values
                    df_primary.loc[matched_idx, 'was_rolled'] = True

                    df_primary.loc[matched_idx, 'ttm'] = df_primary.loc[matched_idx].apply(
                        lambda r: (r['contract_expiry'] - r['bar_date']).days, axis=1
                    )

                unmatched = len(roll_idx) - len(matched_idx)
                if unmatched > 0:
                    print(f"  ⚠ {unmatched} bars had no NM match (missing NM data for those timestamps)")

                df_primary.drop(columns=['_dt_merge'], inplace=True, errors='ignore')
            else:
                print("  ⚠ NM fetch returned empty — no rollover applied")

        df_primary.drop(columns=['bar_date'], inplace=True, errors='ignore')
    else:
        df_primary['bar_date'] = pd.to_datetime(df_primary['datetime']).dt.date
        df_primary['ttm'] = df_primary.apply(
            lambda r: (r['contract_expiry'] - r['bar_date']).days, axis=1
        )
        df_primary.drop(columns=['bar_date'], inplace=True, errors='ignore')

        # Non-CM: no stitching, so pre_roll = close
        df_primary['close_pre_roll'] = df_primary['close'].copy()
        df_primary['contract_expiry_pre_roll'] = df_primary['contract_expiry'].copy()
        df_primary['was_rolled'] = False

    return df_primary


import numpy as np
import pandas as pd
from typing import Tuple, Optional

df = fetch_full_history(index_name="NIFTY 50")


def calculate_rsi(
        data: pd.DataFrame,
        rsi_length: int = 20,
        source_column: str = 'close',
        calculate_divergence: bool = False,
        ma_type: str = "EMA",
        ma_length: int = 14,
        bb_mult: float = 2.0,
        lookback_left: int = 5,
        lookback_right: int = 5,
        range_upper: int = 60,
        range_lower: int = 5
) -> pd.DataFrame:
    """
    Calculate RSI (Relative Strength Index) with optional smoothing MA and divergence detection.
    """

    df = data.copy()
    source = df[source_column]

    # Calculate RSI using RMA (Wilder's smoothing)
    change = source.diff()
    up = change.clip(lower=0)
    down = -change.clip(upper=0)

    # RMA calculation (exponential moving average with alpha = 1/length)
    alpha = 1 / rsi_length
    up_rma = up.ewm(alpha=alpha, adjust=False).mean()
    down_rma = down.ewm(alpha=alpha, adjust=False).mean()

    rs = up_rma / down_rma
    rsi = 100 - (100 / (1 + rs))
    rsi = rsi.fillna(50)  # Handle division by zero cases

    df['rsi'] = rsi

    # Calculate smoothing MA if requested
    if ma_type != "None":
        if ma_type == "SMA" or ma_type == "SMA + Bollinger Bands":
            df['rsi_ma'] = rsi.rolling(window=ma_length).mean()
        elif ma_type == "EMA":
            df['rsi_ma'] = rsi.ewm(span=ma_length, adjust=False).mean()
        elif ma_type == "SMMA (RMA)":
            df['rsi_ma'] = rsi.ewm(alpha=1 / ma_length, adjust=False).mean()
        elif ma_type == "WMA":
            weights = np.arange(1, ma_length + 1)
            df['rsi_ma'] = rsi.rolling(window=ma_length).apply(
                lambda x: np.dot(x, weights) / weights.sum(), raw=True
            )
        elif ma_type == "VWMA":
            if 'volume' in df.columns:
                df['rsi_ma'] = (rsi * df['volume']).rolling(window=ma_length).sum() / \
                               df['volume'].rolling(window=ma_length).sum()
            else:
                df['rsi_ma'] = rsi.rolling(window=ma_length).mean()

        # Bollinger Bands
        if ma_type == "SMA + Bollinger Bands":
            std_dev = rsi.rolling(window=ma_length).std()
            df['bb_upper'] = df['rsi_ma'] + (std_dev * bb_mult)
            df['bb_lower'] = df['rsi_ma'] - (std_dev * bb_mult)

    # Calculate divergences if requested
    if calculate_divergence:
        df['bullish_divergence'] = False
        df['bearish_divergence'] = False
        df['pivot_low'] = False
        df['pivot_high'] = False

        # Find pivot lows and highs
        for i in range(lookback_left, len(df) - lookback_right):
            # Pivot low
            window_low = rsi.iloc[i - lookback_left:i + lookback_right + 1]
            if rsi.iloc[i] == window_low.min():
                df.loc[df.index[i], 'pivot_low'] = True

            # Pivot high
            window_high = rsi.iloc[i - lookback_left:i + lookback_right + 1]
            if rsi.iloc[i] == window_high.max():
                df.loc[df.index[i], 'pivot_high'] = True

        # Detect bullish divergence (Regular Bullish)
        pivot_low_indices = df[df['pivot_low']].index
        for i in range(1, len(pivot_low_indices)):
            curr_idx = pivot_low_indices[i]
            prev_idx = pivot_low_indices[i - 1]

            bars_since = df.index.get_loc(curr_idx) - df.index.get_loc(prev_idx)

            if range_lower <= bars_since <= range_upper:
                curr_pos = df.index.get_loc(curr_idx) + lookback_right
                prev_pos = df.index.get_loc(prev_idx) + lookback_right

                if curr_pos < len(df) and prev_pos < len(df):
                    # RSI: Higher Low
                    rsi_hl = rsi.iloc[curr_pos] > rsi.iloc[prev_pos]
                    # Price: Lower Low
                    price_ll = df['low'].iloc[curr_pos] < df['low'].iloc[prev_pos]

                    if rsi_hl and price_ll:
                        df.loc[df.index[curr_pos], 'bullish_divergence'] = True

        # Detect bearish divergence (Regular Bearish)
        pivot_high_indices = df[df['pivot_high']].index
        for i in range(1, len(pivot_high_indices)):
            curr_idx = pivot_high_indices[i]
            prev_idx = pivot_high_indices[i - 1]

            bars_since = df.index.get_loc(curr_idx) - df.index.get_loc(prev_idx)

            if range_lower <= bars_since <= range_upper:
                curr_pos = df.index.get_loc(curr_idx) + lookback_right
                prev_pos = df.index.get_loc(prev_idx) + lookback_right

                if curr_pos < len(df) and prev_pos < len(df):
                    # RSI: Lower High
                    rsi_lh = rsi.iloc[curr_pos] < rsi.iloc[prev_pos]
                    # Price: Higher High
                    price_hh = df['high'].iloc[curr_pos] > df['high'].iloc[prev_pos]

                    if rsi_lh and price_hh:
                        df.loc[df.index[curr_pos], 'bearish_divergence'] = True

    return df


df['EMA_20'] = df['close'].ewm(span=20, adjust=False).mean()

df = calculate_rsi(
    df,
    rsi_length=40,
    calculate_divergence=True,
    ma_type="EMA",
    ma_length=100,
    bb_mult=2.0)

shifted_rsi = df['rsi'].shift(1)
shifted_rsi_ma = df['rsi_ma'].shift(1)
df["rsi_crossover_bearish"] = ((df['rsi'] <= df['rsi_ma']) & (shifted_rsi >= shifted_rsi_ma))
df["rsi_crossover_bullish"] = ((df['rsi'] >= df['rsi_ma']) & (shifted_rsi <= shifted_rsi_ma))

shifted_close = df['close'].shift(1)
shifted_close_ma = df['EMA_20'].shift(1)
df["close_ema_crossover_bearish"] = ((df['close'] <= df['EMA_20']) & (shifted_close >= shifted_close_ma))
df["close_ema_crossover_bullish"] = ((df['close'] >= df['EMA_20']) & (shifted_close <= shifted_close_ma))

df["Both_Bullish"] = df["close_ema_crossover_bullish"] & df["rsi_crossover_bullish"]

# ============================================================================
# ORIGINAL BACKTEST
# ============================================================================

backtester = StrategyBacktester(df, initial_capital=100000, position_size=1.0)
results = backtester.run_all_strategies()

# ============================================================================
# ============================================================================
#
#   PARAMETER SWEEP — SHORT INDEX STRATEGY
#
# ============================================================================
# ============================================================================

# =============================================================================
# SWEEP 1. PARAMETER GRID
# =============================================================================

SWEEP_EXIT_PARAMS = {
    'above_ema':       [50],           # EMA period for "close > EMA" exit
    'rsi_bull_thresh': [30],           # Only exit on bullish cross if RSI < thresh
    'rsi_ema_period':  [50],           # EMA period applied to RSI for crossover
    'rsi_oversold_n':  [30],           # Exit when RSI < N  (200 = exits next bar, 30 = strictest)
    'stop_loss_n':     [2],            # Multiplier in dynamic stop formula
    'atr_lookback':    [21],           # ATR lookback for stop loss
}

SWEEP_STRATEGY_PARAMS = {
    'Time_Filtered': {
        'Entry': {
            'ema':          [20],
            'volume_ratio': [1.0],
        },
        'Exit': SWEEP_EXIT_PARAMS,
    },
}

# =============================================================================
# SWEEP 2. PRECOMPUTE INDICATOR VARIANTS
# =============================================================================

def sweep_precompute_indicators(df):
    """Precompute every indicator variant the sweep grid requires."""

    # --- Collect ALL required EMA periods ---
    #     Exit: from above_ema param list
    #     Entry: ema_20 (all strategies), ema_50 (Combined_Best hardcoded)
    required_emas = set(SWEEP_EXIT_PARAMS['above_ema']) | {20, 50}

    for p in required_emas:
        col = f'ema_{p}'
        if col not in df.columns:
            df[col] = df['close'].ewm(span=p, adjust=False).mean()

    # --- ATRs for dynamic stop loss ---
    for p in set(SWEEP_EXIT_PARAMS['atr_lookback']):
        col = f'atr_{p}'
        if col not in df.columns:
            tr = pd.concat([
                df['high'] - df['low'],
                (df['high'] - df['close'].shift(1)).abs(),
                (df['low'] - df['close'].shift(1)).abs(),
            ], axis=1).max(axis=1)
            df[col] = tr.rolling(p).mean()

    # --- RSI EMAs + bullish crossovers (for exit; entry RSI is frozen) ---
    for p in set(SWEEP_EXIT_PARAMS['rsi_ema_period']):
        ema_col = f'rsi_ema_{p}'
        cross_col = f'rsi_cross_bullish_{p}'
        if cross_col not in df.columns:
            df[ema_col] = df['rsi'].ewm(span=p, adjust=False).mean()
            shifted_rsi = df['rsi'].shift(1)
            shifted_ma = df[ema_col].shift(1)
            df[cross_col] = (df['rsi'] >= df[ema_col]) & (shifted_rsi <= shifted_ma)

    # --- ADX (ensure exists) ---
    if 'adx' not in df.columns:
        high, low, close = df['high'], df['low'], df['close']
        plus_dm = high.diff().clip(lower=0)
        minus_dm = (-low.diff()).clip(lower=0)
        tr = pd.concat([
            high - low, (high - close.shift(1)).abs(), (low - close.shift(1)).abs()
        ], axis=1).max(axis=1)
        atr14 = tr.rolling(14).mean()
        plus_di = 100 * plus_dm.rolling(14).mean() / atr14
        minus_di = 100 * minus_dm.rolling(14).mean() / atr14
        dx = 100 * (plus_di - minus_di).abs() / (plus_di + minus_di)
        df['adx'] = dx.rolling(14).mean()

    # --- Volume ratio ---
    if 'volume_ratio' not in df.columns:
        df['volume_ratio'] = df['volume'] / df['volume'].rolling(20).mean()

    # --- Hour (for Time_Filtered) ---
    if 'hour' not in df.columns:
        df['hour'] = pd.to_datetime(df['datetime']).dt.hour

    return df


# =============================================================================
# SWEEP 3. NUMPY ARRAY CACHE  (eliminates DataFrame overhead in tight loop)
# =============================================================================

def sweep_build_cache(df):
    """Pack all needed columns into a flat dict of numpy arrays."""

    cache = {
        'close': df['close'].values.astype(np.float64),
        'rsi': df['rsi'].values.astype(np.float64),
        'volume_ratio': df['volume_ratio'].fillna(0).values.astype(np.float64),
        'adx': df['adx'].fillna(0).values.astype(np.float64),
        'hour': df['hour'].values.astype(np.int32),
        'rsi_crossover_bearish': df['rsi_crossover_bearish'].fillna(False).values.astype(bool),
    }

    # Cache ALL required EMAs (exit + entry-required: 20, 50)
    required_emas = set(SWEEP_EXIT_PARAMS['above_ema']) | {20, 50}
    for p in required_emas:
        cache[f'ema_{p}'] = df[f'ema_{p}'].fillna(0).values.astype(np.float64)

    for p in set(SWEEP_EXIT_PARAMS['atr_lookback']):
        cache[f'atr_{p}'] = df[f'atr_{p}'].fillna(0).values.astype(np.float64)

    for p in set(SWEEP_EXIT_PARAMS['rsi_ema_period']):
        cache[f'rsi_cross_bullish_{p}'] = df[f'rsi_cross_bullish_{p}'].fillna(False).values.astype(bool)

    cache['datetime'] = pd.to_datetime(df['datetime']).values

    # Pre-roll prices: original CM close before NM stitching (for open position PnL)
    if 'close_pre_roll' in df.columns:
        cache['close_pre_roll'] = df['close_pre_roll'].fillna(df['close']).values.astype(np.float64)
    else:
        cache['close_pre_roll'] = cache['close'].copy()

    if 'contract_expiry_pre_roll' in df.columns:
        cache['contract_expiry_pre_roll'] = df['contract_expiry_pre_roll'].values
    else:
        cache['contract_expiry'] = df['contract_expiry'].values if 'contract_expiry' in df.columns else np.empty(len(df), dtype=object)

    cache['contract_expiry'] = df['contract_expiry'].values if 'contract_expiry' in df.columns else np.empty(len(df), dtype=object)

    return cache


# =============================================================================
# SWEEP 4. ENTRY SIGNAL GENERATION  (vectorised, per strategy)
# =============================================================================

def sweep_generate_entry(cache, strategy, entry_params):
    """
    Return boolean numpy array of entry signals.
    RSI crossover and time filters are FROZEN (not swept).
    """

    ema_col = f"ema_{entry_params['ema']}"
    vol_thresh = entry_params['volume_ratio']

    # Common base: RSI bearish crossover + close < EMA
    base = cache['rsi_crossover_bearish'] & (cache['close'] < cache[ema_col])


    if strategy == 'Time_Filtered':
        return (base
                & np.isin(cache['hour'], [9, 10, 15])
                & (cache['volume_ratio'] >= vol_thresh))

# =============================================================================
# SWEEP 5. PARAMETERIZED BACKTEST
# =============================================================================

def sweep_run_backtest(cache, entry_signal, exit_params):
    """
    Short-only backtest on numpy arrays.

    Exit priority (cascading):
        1. Dynamic stop loss   →  entry_price * (1 + n * ATR / close)
        2. RSI bullish cross   →  cross detected AND rsi < threshold
        3. Close > EMA         →  close above exit-EMA
        4. RSI < N (oversold)  →  profit-taking on oversold

    Contract-aware: if entry was on CM and bars have since rolled to NM,
    uses close_pre_roll (original CM price) for PnL and stop evaluation.
    Stitched close still drives EMA/RSI exit signals (smoothed, negligible impact).
    """

    close = cache['close']                  # stitched (NM near expiry) — for signals
    close_raw = cache['close_pre_roll']     # original CM price — for open position PnL
    contract_exp = cache['contract_expiry'] # stitched contract identity per bar
    rsi = cache['rsi']
    ema_exit = cache[f"ema_{exit_params['above_ema']}"]
    rsi_bull = cache[f"rsi_cross_bullish_{exit_params['rsi_ema_period']}"]
    atr = cache[f"atr_{exit_params['atr_lookback']}"]

    sl_n = exit_params['stop_loss_n']
    bull_thresh = exit_params['rsi_bull_thresh']
    oversold_n = exit_params['rsi_oversold_n']

    n = len(close)
    position = 0  # 0 = flat, -1 = short
    entry_price = 0.0
    entry_contract = None
    entry_idx = 0
    capital = float(SWEEP_INITIAL_CAPITAL)
    peak = float(SWEEP_INITIAL_CAPITAL)
    max_dd = 0.0

    trades = 0
    wins = 0
    win_pnl = 0.0
    loss_pnl = 0.0
    ret_sum = 0.0
    hold_sum = 0
    exit_sl = exit_rsi = exit_ema = exit_os = 0

    capital_array = np.full(n, float(SWEEP_INITIAL_CAPITAL))

    for i in range(1, n):

        # ---- ENTRY ----
        if position == 0:
            if entry_signal[i]:
                position = -1
                entry_price = close[i]          # stitched is correct for new entries
                entry_contract = contract_exp[i] # remember which contract we entered
                entry_idx = i
            capital_array[i] = capital
            continue

        # ---- EXIT (position == -1) ----
        # Key fix: if contract rolled mid-trade, use pre-roll (original CM) price
        if contract_exp[i] != entry_contract:
            c = close_raw[i]
        else:
            c = close[i]

        if c <= 0:
            capital_array[i] = capital
            continue

        stop = entry_price * (1.0 + sl_n * atr[i] / c)

        if c > stop:
            reason_code = 0  # Stop Loss
        elif rsi_bull[i] and rsi[i] < bull_thresh:
            reason_code = 1  # RSI Bullish Cross
        elif c > ema_exit[i]:
            reason_code = 2  # Above EMA
        elif rsi[i] < oversold_n:
            reason_code = 3  # Oversold
        else:
            capital_array[i] = capital
            continue

        # ---- RECORD TRADE ----
        ret_pct = (entry_price - c) / entry_price * 100
        pnl = ret_pct / 100.0 * SWEEP_POSITION_SIZE * capital
        capital += pnl

        trades += 1
        ret_sum += ret_pct
        hold_sum += (i - entry_idx)

        if reason_code == 0:
            exit_sl += 1
        elif reason_code == 1:
            exit_rsi += 1
        elif reason_code == 2:
            exit_ema += 1
        else:
            exit_os += 1

        if pnl > 0:
            wins += 1
            win_pnl += pnl
        else:
            loss_pnl += abs(pnl)

        if capital > peak:
            peak = capital
        dd = (peak - capital) / peak * 100.0
        if dd > max_dd:
            max_dd = dd

        position = 0
        entry_contract = None

        capital_array[i] = capital

    # ---- ANNUALIZED METRICS ----
    total_ret = (capital - SWEEP_INITIAL_CAPITAL) / SWEEP_INITIAL_CAPITAL * 100

    cap_series = pd.Series(capital_array, index=pd.to_datetime(cache['datetime'][:n]))
    daily_cap = cap_series.resample('D').last().dropna()
    daily_returns = daily_cap.pct_change().dropna()

    days = len(daily_cap)
    years = days / 252
    ann_return = ((1 + total_ret / 100) ** (1 / years) - 1) * 100
    ann_vol = daily_returns.std() * np.sqrt(252) * 100
    sharpe = ann_return / ann_vol if ann_vol > 0 else 0
    max_dd_daily = ((daily_cap / daily_cap.cummax() - 1) * 100).min()

    return {
        'total_return_pct': total_ret,
        'annualized_return': ann_return,
        'sharpe_ratio': sharpe,
        'annual_volatility': ann_vol,
        'max_drawdown': max_dd_daily,
        'final_capital': capital,
        'total_trades': trades,
        'win_rate': (wins / trades * 100) if trades else 0,
        'profit_factor': (win_pnl / loss_pnl) if loss_pnl > 0 else np.inf,
        'avg_trade_return': (ret_sum / trades) if trades else 0,
        'avg_hold_periods': (hold_sum / trades) if trades else 0,
        'n_exit_stop_loss': exit_sl,
        'n_exit_rsi_bullish': exit_rsi,
        'n_exit_above_ema': exit_ema,
        'n_exit_oversold': exit_os,
    }


# =============================================================================
# SWEEP 6. MAIN SWEEP EXECUTION
# =============================================================================

def _sweep_count_combos():
    """Print and return total parameter combinations per strategy."""
    total = 0
    for strat, cfg in SWEEP_STRATEGY_PARAMS.items():
        n_entry = 1
        for v in cfg['Entry'].values():  n_entry *= len(v)
        n_exit = 1
        for v in cfg['Exit'].values():   n_exit *= len(v)
        strat_total = n_entry * n_exit
        total += strat_total
        print(f"  {strat:20s}:  {n_entry:>4} entry  ×  {n_exit:>5} exit  =  {strat_total:>10,}")
    return total


def run_parameter_sweep(df):
    """
    Main entry point for the parameter sweep.
    Cascading loop: Strategy → Entry combos → Exit combos.
    Entry signal recomputed only when entry params change (optimisation).
    """

    SWEEP_RESULTS_DIR.mkdir(exist_ok=True)

    print("\n" + "=" * 80)
    print("  PARAMETER SWEEP — SHORT INDEX STRATEGY")
    print("=" * 80)

    # ---- Step 1: Precompute ----
    print("\n[1/4] Precomputing indicator variants...")
    df = df.copy()  # don't mutate caller's df
    df = df.sort_values('datetime').reset_index(drop=True)  # defensive sort
    df = sweep_precompute_indicators(df)
    cache = sweep_build_cache(df)
    print(f"      Data shape: {df.shape[0]:,} bars × {df.shape[1]} columns")

    # ---- Step 2: Grid summary ----
    print("\n[2/4] Parameter grid:")
    total = _sweep_count_combos()
    print(f"\n  {'GRAND TOTAL':20s}:  {total:>10,} backtests\n")

    # ---- Step 3: Sweep ----
    print("[3/4] Running backtests...\n")
    all_results = []
    run_id = 0
    start_time = time.time()

    for strategy_name, config in SWEEP_STRATEGY_PARAMS.items():

        entry_keys = sorted(config['Entry'].keys())
        exit_keys = sorted(config['Exit'].keys())
        entry_combos = list(product(*[config['Entry'][k] for k in entry_keys]))
        exit_combos = list(product(*[config['Exit'][k] for k in exit_keys]))
        strat_total = len(entry_combos) * len(exit_combos)

        print(f"{strategy_name}  ({strat_total:,} runs)")

        pbar = tqdm(total=strat_total, desc=f"    {strategy_name}", leave=True)

        for entry_vals in entry_combos:
            entry_params = dict(zip(entry_keys, entry_vals))

            # Vectorised entry signal — computed ONCE per entry combo
            entry_signal = sweep_generate_entry(cache, strategy_name, entry_params)

            for exit_vals in exit_combos:
                exit_params = dict(zip(exit_keys, exit_vals))
                run_id += 1

                metrics = sweep_run_backtest(cache, entry_signal, exit_params)

                # Flatten into one result row
                row = {'run_id': run_id, 'strategy': strategy_name}
                row.update({f'entry_{k}': v for k, v in entry_params.items()})
                row.update({f'exit_{k}': v for k, v in exit_params.items()})
                row.update(metrics)
                all_results.append(row)

                pbar.update(1)

        pbar.close()

        elapsed = time.time() - start_time
        print(f"    ✓ Done  |  Elapsed: {elapsed / 60:.1f} min\n")

    total_time = time.time() - start_time

    # ---- Step 4: Consolidate ----
    print("[4/4] Consolidating results...")

    df_results = pd.DataFrame(all_results)
    df_results = df_results.sort_values('sharpe_ratio', ascending=False)

    output_xlsx = SWEEP_RESULTS_DIR / "consolidated_sweep_results.xlsx"
    df_results.to_excel(output_xlsx, index=False)

    # ---- Summary ----
    print(f"\n{'=' * 80}")
    print(f"PARAMETER SWEEP COMPLETE")
    print(f"{'=' * 80}")
    print(f"  Total runs:       {len(all_results):,}")
    print(f"  Total time:       {total_time / 60:.1f} min")
    print(f"  Avg per run:      {total_time / len(all_results) * 1000:.1f} ms")
    print(f"  Results saved:    {output_xlsx}")

    top_cols = ['strategy', 'total_return_pct', 'win_rate', 'profit_factor',
                'max_drawdown', 'total_trades']
    print(f"\n TOP 10 BY RETURN:")
    print(df_results[top_cols].head(10).to_string(index=False))
    print(f"\n{'=' * 80}\n")

    return df_results


# ============================================================================
# RUN THE SWEEP
# ============================================================================

df_sweep_results = run_parameter_sweep(df)


# ============================================================================
# POST-SWEEP: DETAILED ANALYSIS FOR HIGH-CALMAR RUNS
# ============================================================================

def sweep_run_detailed_backtest(cache, entry_signal, exit_params):
    """
    Same logic as sweep_run_backtest, but also collects:
    - Full trade log (entry/exit date, price, pnl, reason, hold period)
    - Bar-level capital array for equity curve
    Only called for qualifying runs, so perf cost is irrelevant.
    """

    close = cache['close']
    close_raw = cache['close_pre_roll']
    contract_exp = cache['contract_expiry']
    rsi = cache['rsi']
    dt_arr = cache['datetime']
    ema_exit = cache[f"ema_{exit_params['above_ema']}"]
    rsi_bull = cache[f"rsi_cross_bullish_{exit_params['rsi_ema_period']}"]
    atr = cache[f"atr_{exit_params['atr_lookback']}"]

    sl_n = exit_params['stop_loss_n']
    bull_thresh = exit_params['rsi_bull_thresh']
    oversold_n = exit_params['rsi_oversold_n']

    n = len(close)
    position = 0
    entry_price = 0.0
    entry_contract = None
    entry_idx = 0
    capital = float(SWEEP_INITIAL_CAPITAL)
    capital_array = np.full(n, float(SWEEP_INITIAL_CAPITAL))
    trades = []

    REASON_MAP = {0: 'Stop Loss', 1: 'RSI Bullish Cross', 2: 'Above EMA', 3: 'Oversold'}

    for i in range(1, n):
        if position == 0:
            if entry_signal[i]:
                position = -1
                entry_price = close[i]
                entry_contract = contract_exp[i]
                entry_idx = i
            capital_array[i] = capital
            continue

        # Contract-aware price selection
        if contract_exp[i] != entry_contract:
            c = close_raw[i]
        else:
            c = close[i]

        if c <= 0:
            capital_array[i] = capital
            continue

        stop = entry_price * (1.0 + sl_n * atr[i] / c)

        if c > stop:
            reason_code = 0
        elif rsi_bull[i] and rsi[i] < bull_thresh:
            reason_code = 1
        elif c > ema_exit[i]:
            reason_code = 2
        elif rsi[i] < oversold_n:
            reason_code = 3
        else:
            capital_array[i] = capital
            continue

        ret_pct = (entry_price - c) / entry_price * 100
        pnl = ret_pct / 100.0 * SWEEP_POSITION_SIZE * capital
        capital += pnl

        trades.append({
            'entry_date': dt_arr[entry_idx],
            'exit_date': dt_arr[i],
            'entry_price': entry_price,
            'exit_price': c,
            'pnl': pnl,
            'return_pct': ret_pct,
            'exit_reason': REASON_MAP[reason_code],
            'hold_periods': i - entry_idx,
        })

        position = 0
        entry_contract = None
        capital_array[i] = capital

    trades_df = pd.DataFrame(trades)

    # Daily capital series
    cap_series = pd.Series(capital_array, index=pd.to_datetime(dt_arr[:n]))
    daily_cap = cap_series.resample('D').last().dropna()

    df_daily_pnl = pd.DataFrame({
        'date': daily_cap.index,
        'total_value': daily_cap.values,
    })
    df_daily_pnl['daily_return'] = df_daily_pnl['total_value'].pct_change()
    df_daily_pnl['cumulative_return'] = (df_daily_pnl['total_value'] / SWEEP_INITIAL_CAPITAL - 1) * 100
    df_daily_pnl['drawdown'] = (df_daily_pnl['total_value'] / df_daily_pnl['total_value'].cummax() - 1) * 100

    return trades_df, df_daily_pnl, capital_array


def plot_detailed_results(trades_df, df_daily_pnl, run_dir, run_label):
    """Generate all plots — equity curve, drawdown, trade distribution, exit reasons, monthly PnL."""

    plots_dir = run_dir / "plots"
    plots_dir.mkdir(parents=True, exist_ok=True)

    # 1. Equity curve + Drawdown
    fig, axes = plt.subplots(2, 1, figsize=(14, 10))
    axes[0].plot(df_daily_pnl['date'], df_daily_pnl['total_value'], linewidth=2)
    axes[0].axhline(y=SWEEP_INITIAL_CAPITAL, color='r', linestyle='--', alpha=0.5, label='Initial Capital')
    axes[0].set_title(f'{run_label} — Equity Curve', fontsize=14, fontweight='bold')
    axes[0].set_ylabel('Capital ($)')
    axes[0].legend()
    axes[0].grid(True, alpha=0.3)

    axes[1].fill_between(df_daily_pnl['date'], 0, df_daily_pnl['drawdown'], alpha=0.3, color='red')
    axes[1].set_title('Drawdown (%)', fontsize=12, fontweight='bold')
    axes[1].set_ylabel('Drawdown (%)')
    axes[1].grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(plots_dir / 'equity_curve.png', dpi=300, bbox_inches='tight')
    plt.close()

    if len(trades_df) == 0:
        return

    # 2. Trade analysis 4-panel
    fig, axes = plt.subplots(2, 2, figsize=(14, 10))

    axes[0, 0].hist(trades_df['return_pct'], bins=50, edgecolor='black', alpha=0.7)
    axes[0, 0].axvline(x=0, color='r', linestyle='--', linewidth=2)
    axes[0, 0].set_title('Trade Returns Distribution', fontweight='bold')
    axes[0, 0].set_xlabel('Return (%)')

    axes[0, 1].plot(trades_df['pnl'].cumsum().values, linewidth=2)
    axes[0, 1].set_title('Cumulative PnL', fontweight='bold')
    axes[0, 1].set_xlabel('Trade Number')
    axes[0, 1].set_ylabel('Cumulative PnL ($)')
    axes[0, 1].grid(True, alpha=0.3)

    exit_reasons = trades_df['exit_reason'].value_counts()
    axes[1, 0].bar(exit_reasons.index, exit_reasons.values, edgecolor='black')
    axes[1, 0].set_title('Exit Reasons', fontweight='bold')
    axes[1, 0].tick_params(axis='x', rotation=45)

    trades_df['exit_month'] = pd.to_datetime(trades_df['exit_date']).dt.to_period('M')
    monthly_pnl = trades_df.groupby('exit_month')['pnl'].sum()
    axes[1, 1].bar(range(len(monthly_pnl)), monthly_pnl.values,
                   color=['g' if x > 0 else 'r' for x in monthly_pnl.values],
                   edgecolor='black', alpha=0.7)
    axes[1, 1].set_title('Monthly PnL', fontweight='bold')
    axes[1, 1].axhline(y=0, color='black', linestyle='-', linewidth=1)

    plt.tight_layout()
    plt.savefig(plots_dir / 'trade_analysis.png', dpi=300, bbox_inches='tight')
    plt.close()


def run_detailed_for_high_calmar(df_sweep_results, df, calmar_threshold=0.5):
    """
    Post-sweep: filter for Calmar > threshold, re-run with full detail.
    """

    # ---- Step 1: Compute Calmar & filter ----
    df_sweep_results['calmar_ratio'] = df_sweep_results['annualized_return'] / df_sweep_results['max_drawdown'].abs()
    df_sweep_results['calmar_ratio'] = df_sweep_results['calmar_ratio'].replace([np.inf, -np.inf], np.nan)
    # qualified = df_sweep_results[df_sweep_results['calmar_ratio'] > calmar_threshold].copy()
    qualified = df_sweep_results.nlargest(50, 'calmar_ratio')

    print(f"\n{'=' * 80}")
    print(f"  DETAILED ANALYSIS — CALMAR > {calmar_threshold}")
    print(f"{'=' * 80}")
    print(f"  Qualifying runs: {len(qualified)} / {len(df_sweep_results)}")

    if len(qualified) == 0:
        print("  No runs qualify. Done.")
        return

    # Build daily NIFTY futures closes for M2M (once, reused across all qualifying runs)
    # min_date = pd.to_datetime(qualified.iloc[0]['entry_date'] if 'entry_date' in qualified.columns
    #            else df['datetime'].min()).date() if hasattr(df['datetime'].min(), 'date') else df['datetime'].min()

    # ---- Step 2: Rebuild cache ----
    df_prep = df.copy().sort_values('datetime').reset_index(drop=True)
    df_prep = sweep_precompute_indicators(df_prep)
    cache = sweep_build_cache(df_prep)

    # Build daily futures closes for true M2M (once, reused across all runs)
    min_dt = pd.to_datetime(df['datetime']).min().date()
    max_dt = pd.to_datetime(df['datetime']).max().date()
    daily_closes = _build_daily_closes(min_dt, max_dt)
    print(f"  Daily closes: {len(daily_closes)} days")

    detail_dir = SWEEP_RESULTS_DIR / "high_calmar_detailed"
    detail_dir.mkdir(parents=True, exist_ok=True)
    
    hedged_summary_rows = []

    # ---- Step 3: Re-run each qualifying combo ----
    for idx, row in tqdm(qualified.iterrows(), total=len(qualified), desc="    Detailed runs"):

        strategy = row['strategy']

        # Reconstruct entry params
        entry_params = {c.replace('entry_', ''): row[c]
                        for c in row.index if c.startswith('entry_')}
        exit_params = {c.replace('exit_', ''): row[c]
                       for c in row.index if c.startswith('exit_')}

        # Cast types (CSV can load as float)
        entry_params = {k: v for k, v in entry_params.items() if pd.notna(v)}
        for k in ['ema', 'adx']:
            if k in entry_params:
                entry_params[k] = int(entry_params[k])

        exit_params = {k: v for k, v in exit_params.items() if pd.notna(v)}
        for k in ['above_ema', 'rsi_ema_period', 'atr_lookback']:
            if k in exit_params:
                exit_params[k] = int(exit_params[k])

        # Generate entry signal
        entry_signal = sweep_generate_entry(cache, strategy, entry_params)

        # Run detailed backtest
        trades_df, df_daily_pnl, capital_array = sweep_run_detailed_backtest(
            cache, entry_signal, exit_params
        )

        entry_str = "_".join(f"{k}{v}" for k, v in sorted(entry_params.items()))
        exit_str = "_".join(f"{k}{v}" for k, v in sorted(exit_params.items()))
        run_label = f"run{int(row['run_id'])}"
        run_dir = detail_dir / strategy / run_label
        run_dir.mkdir(parents=True, exist_ok=True)

        # True daily M2M — futures repriced to daily close (same for all OTM levels)
        fut_daily_records = []
        for _, t in trades_df.iterrows():
            t_entry_date = pd.to_datetime(t['entry_date']).date()
            t_exit_date = pd.to_datetime(t['exit_date']).date()
            prev_ref = t['entry_price']

            # Determine which contract this trade is on

            trade_days = [d for d in sorted(daily_closes.keys()) if t_entry_date <= d <= t_exit_date]
            # Track current contract — may change mid-trade for CM rollover

            if t_entry_date in daily_closes:
                entry_contract_expiry = daily_closes[t_entry_date]['contract_expiry']
            else:
                entry_contract_expiry = None

            trade_days = [d for d in sorted(daily_closes.keys()) if t_entry_date <= d <= t_exit_date]
            current_contract_expiry = entry_contract_expiry
            #####
            for d in trade_days:
                if d == t_exit_date:
                    today_val = t['exit_price']

                elif current_contract_expiry is not None and d >= current_contract_expiry:
                    # ── EXPIRY-DAY FUT ROLLOVER at 9:30:59 ──
                    # 1. Close old CM at 9:30:59
                    old_price, _ = get_futures_price(d, HEDGE_EXIT_TIME, expiry='cm')
                    if old_price is None:
                        old_price = prev_ref

                    fut_daily_records.append({
                        'date': d, 'trade_index': _, 'direction': -1,
                        'prev_close': prev_ref, 'today_close': old_price,
                        'price_change': old_price - prev_ref,
                        'fut_daily_pnl': (old_price - prev_ref) * (-1),
                    })

                    # 2. Open NM at 9:30:59 (becomes CM post-expiry)
                    new_price, new_exp = get_futures_price(d, HEDGE_EXIT_TIME, expiry='nm')
                    if new_price is not None and new_exp is not None:
                        new_eod = _get_contract_close(d, new_exp, daily_closes)
                        if new_eod is None:
                            new_eod = new_price

                        fut_daily_records.append({
                            'date': d, 'trade_index': _, 'direction': -1,
                            'prev_close': new_price, 'today_close': new_eod,
                            'price_change': new_eod - new_price,
                            'fut_daily_pnl': (new_eod - new_price) * (-1),
                        })
                        current_contract_expiry = new_exp
                        prev_ref = new_eod
                    else:
                        prev_ref = old_price

                    continue  # both legs recorded, skip normal append

                elif current_contract_expiry is not None:
                    today_val = _get_contract_close(d, current_contract_expiry, daily_closes)
                    if today_val is None:
                        today_val = prev_ref
                else:
                    today_val = daily_closes[d]['price'] if d in daily_closes else prev_ref

                fut_daily_records.append({
                    'date': d,
                    'trade_index': _,
                    'direction': -1,
                    'prev_close': prev_ref,
                    'today_close': today_val,
                    'price_change': today_val - prev_ref,
                    'fut_daily_pnl': (today_val - prev_ref) * (-1),
                })
                prev_ref = today_val
            #####

        if fut_daily_records:
            fut_raw = pd.DataFrame(fut_daily_records)
            fut_daily = fut_raw.groupby('date').agg(
                num_positions=('trade_index', 'count'),
                prev_close=('prev_close', 'first'),
                today_close=('today_close', 'first'),
                price_change=('price_change', 'first'),
                direction=('direction', 'first'),
                fut_daily_pnl=('fut_daily_pnl', 'sum'),
            ).reset_index()
        else:
            fut_daily = pd.DataFrame(
                columns=['date', 'num_positions', 'prev_close', 'today_close', 'price_change', 'direction',
                         'fut_daily_pnl'])

        # ── Overnight CE Hedge — sweep OTM levels ──
        for otm_pct in HEDGE_OTM_GRID:
            otm_label = f"OTM_{int(otm_pct * 100)}"
            otm_dir = run_dir / otm_label
            otm_dir.mkdir(parents=True, exist_ok=True)

            if len(trades_df) > 0:
                hedge_input = trades_df[['entry_date', 'exit_date', 'entry_price', 'exit_price']].copy()
                hedge_input.columns = ['Entry Time', 'Exit Time', 'Entry Price', 'Exit Price']
                hedge_input['Entry Time'] = pd.to_datetime(hedge_input['Entry Time'])
                hedge_input['Exit Time'] = pd.to_datetime(hedge_input['Exit Time'])
                hedge_input['Direction'] = -1

                hedge_trades_list = []
                for h_idx, h_row in hedge_input.iterrows():
                    entry_time = h_row['Entry Time']
                    exit_time = h_row['Exit Time']
                    current_date = entry_time.date()

                    while current_date <= exit_time.date():
                        if not is_trading_day(current_date):
                            current_date += timedelta(days=1)
                            continue
                        check_dt = datetime.combine(current_date, HEDGE_ENTRY_TIME)
                        if entry_time <= check_dt and exit_time.date() > current_date:
                            try:
                                fut_price, contract_expiry = get_futures_price(current_date, HEDGE_ENTRY_TIME)
                                if fut_price is None:
                                    current_date += timedelta(days=1)
                                    continue
                                entry_info = get_hedge_entry(current_date, fut_price, -1, contract_expiry, otm_pct,
                                                             HEDGE_EXPIRY)
                                if entry_info is None:
                                    current_date += timedelta(days=1)
                                    continue
                                next_td = get_next_trading_day(current_date)
                                exit_date = next_td if exit_time >= datetime.combine(next_td,
                                                                                     HEDGE_EXIT_TIME) else exit_time.date()
                                exit_premium, _ = get_hedge_exit(exit_date, entry_info['strike'],
                                                                 entry_info['option_type'], entry_info['expiry_label'],
                                                                 entry_info['exit_label'], entry_info['expiry_date'])
                                if exit_premium is not None:
                                    hedge_trades_list.append({
                                        'Trade_Index': h_idx,
                                        'Trade_Entry': entry_time,
                                        'Trade_Exit': exit_time,
                                        'Trade_Direction': 'SHORT',
                                        'Hedge_Date': current_date,
                                        'Hedge_Entry_Time': datetime.combine(current_date, HEDGE_ENTRY_TIME),
                                        'Hedge_Exit_Time': datetime.combine(exit_date, HEDGE_EXIT_TIME),
                                        'Exit_Reason': 'Next trading day' if exit_date == next_td else 'Main trade exit',
                                        'Hedge_Type': entry_info.get('hedge_type', 'Long Call (Upside)'),
                                        'Futures_Ref_Price': fut_price,
                                        'Strike': entry_info['strike'],
                                        'OTM_Pct': entry_info.get('otm_pct', otm_pct * 100),
                                        'Option_Type': entry_info['option_type'],
                                        'Ticker': entry_info.get('ticker', ''),
                                        'Expiry': entry_info.get('expiry_date', ''),
                                        'Expiry_Contract': entry_info.get('expiry_label', ''),
                                        'Entry_Premium': entry_info['entry_premium'],
                                        'Exit_Premium': exit_premium,
                                        'PnL_Points': exit_premium - entry_info['entry_premium'],
                                        'PnL_Pct': ((exit_premium - entry_info['entry_premium']) / entry_info[
                                            'entry_premium'] * 100) if entry_info['entry_premium'] > 0 else 0.0,
                                    })
                            except Exception as e:
                                print(f"Hedge error on {current_date}: {e}")
                                import traceback; traceback.print_exc()
                        current_date += timedelta(days=1)

                if hedge_trades_list:
                    hedge_df = pd.DataFrame(hedge_trades_list)
                    hedge_df.to_csv(otm_dir / "hedge_trades.csv", index=False)

                    # Merged trades (like Doc 5)
                    hedge_agg = hedge_df.groupby('Trade_Index').agg(
                        first_hedge_entry_premium=('Entry_Premium', 'first'),
                        first_hedge_exit_premium=('Exit_Premium', 'first'),
                        total_hedge_pnl=('PnL_Points', 'sum'),
                        total_hedge_cost=('Entry_Premium', 'sum'),
                        num_hedge_nights=('Trade_Index', 'count'),
                    ).reset_index()
                    merged = trades_df.copy()
                    merged['Trade_Index'] = merged.index
                    merged = merged.merge(hedge_agg, on='Trade_Index', how='left')
                    merged['total_hedge_pnl'] = merged['total_hedge_pnl'].fillna(0)
                    merged['total_hedge_cost'] = merged['total_hedge_cost'].fillna(0)
                    merged['num_hedge_nights'] = merged['num_hedge_nights'].fillna(0).astype(int)
                    merged['fut_pnl'] = (merged['entry_price'] - merged['exit_price'])  # short: entry - exit
                    merged['final_pnl'] = merged['fut_pnl'] + merged['total_hedge_pnl']
                    merged.to_csv(otm_dir / "merged_trades.csv", index=False)

                    hedge_daily = hedge_df.copy()

                    hedge_daily['date'] = pd.to_datetime(hedge_daily['Hedge_Exit_Time']).dt.date
                    hedge_daily = hedge_daily.groupby('date').agg(
                        hedge_entry_premium=('Entry_Premium', 'first'),
                        hedge_exit_premium=('Exit_Premium', 'first'),
                        hedge_pnl=('PnL_Points', 'sum'),
                        hedge_cost=('Entry_Premium', 'sum'),
                    ).reset_index()
                    # hedge_daily['date'] = pd.to_datetime(hedge_daily['date'])

                    all_dates = sorted(set(fut_daily['date'].tolist()) | set(hedge_daily['date'].tolist()))
                    daily_m2m = pd.DataFrame({'date': all_dates})
                    daily_m2m = daily_m2m.merge(fut_daily, on='date', how='left')
                    daily_m2m = daily_m2m.merge(hedge_daily, on='date', how='left')
                    daily_m2m = daily_m2m.fillna(0)
                    daily_m2m['total_pnl'] = daily_m2m['fut_daily_pnl'] + daily_m2m['hedge_pnl']
                    daily_m2m['cumulative_pnl'] = daily_m2m['total_pnl'].cumsum()
                    daily_m2m.to_csv(otm_dir / "daily_pnl.csv", index=False)
                    
                    # Store metrics for consolidated sheet
                    final_pnl = daily_m2m['cumulative_pnl'].iloc[-1]
                    equity_curve = SWEEP_INITIAL_CAPITAL + daily_m2m['cumulative_pnl']
                    returns = equity_curve.pct_change().dropna()
                    sharpe = (returns.mean() / returns.std() * np.sqrt(252)) if returns.std() > 0 else 0
                    drawdown = (equity_curve / equity_curve.cummax() - 1)
                    max_dd = drawdown.min() * 100
                    ann_ret = (equity_curve.iloc[-1] / SWEEP_INITIAL_CAPITAL) ** (252 / len(equity_curve)) - 1 if len(equity_curve) > 0 else 0
                    calmar = ann_ret / abs(drawdown.min()) if drawdown.min() < 0 else 0
                    
                    row_dict = row.to_dict()
                    row_dict['otm_pct'] = otm_pct * 100
                    row_dict['hedged_final_capital'] = equity_curve.iloc[-1]
                    row_dict['hedged_total_return_pct'] = (equity_curve.iloc[-1] / SWEEP_INITIAL_CAPITAL - 1) * 100
                    row_dict['hedged_sharpe'] = sharpe
                    row_dict['hedged_max_dd'] = max_dd
                    row_dict['hedged_calmar'] = calmar
                    hedged_summary_rows.append(row_dict)
                else:
                    no_hedge = fut_daily.copy()
                    no_hedge['hedge_pnl'] = 0
                    no_hedge['hedge_entry_premium'] = 0
                    no_hedge['hedge_exit_premium'] = 0
                    no_hedge['hedge_cost'] = 0
                    no_hedge['total_pnl'] = no_hedge['fut_daily_pnl']
                    no_hedge['cumulative_pnl'] = no_hedge['total_pnl'].cumsum()
                    no_hedge.to_csv(otm_dir / "daily_pnl.csv", index=False)
                    
                    final_pnl = no_hedge['cumulative_pnl'].iloc[-1]
                    equity_curve = SWEEP_INITIAL_CAPITAL + no_hedge['cumulative_pnl']
                    returns = equity_curve.pct_change().dropna()
                    sharpe = (returns.mean() / returns.std() * np.sqrt(252)) if returns.std() > 0 else 0
                    drawdown = (equity_curve / equity_curve.cummax() - 1)
                    max_dd = drawdown.min() * 100
                    ann_ret = (equity_curve.iloc[-1] / SWEEP_INITIAL_CAPITAL) ** (252 / len(equity_curve)) - 1 if len(equity_curve) > 0 else 0
                    calmar = ann_ret / abs(drawdown.min()) if drawdown.min() < 0 else 0

                    row_dict = row.to_dict()
                    row_dict['otm_pct'] = otm_pct * 100
                    row_dict['hedged_final_capital'] = equity_curve.iloc[-1]
                    row_dict['hedged_total_return_pct'] = (equity_curve.iloc[-1] / SWEEP_INITIAL_CAPITAL - 1) * 100
                    row_dict['hedged_sharpe'] = sharpe
                    row_dict['hedged_max_dd'] = max_dd
                    row_dict['hedged_calmar'] = calmar
                    hedged_summary_rows.append(row_dict)

        # Trade log
        trades_df.to_csv(run_dir / "trades.csv", index=False)

        # Daily PnL
        df_daily_pnl.to_csv(run_dir / "daily_pnl.csv", index=False)

        # Parameters JSON
        params_info = {
            'run_id': int(row['run_id']),
            'strategy': strategy,
            'calmar_ratio': float(row['calmar_ratio']),
            'annualized_return': float(row['annualized_return']),
            'sharpe_ratio': float(row['sharpe_ratio']),
            'annual_volatility': float(row['annual_volatility']),
            'max_drawdown': float(row['max_drawdown']),
            'total_return_pct': float(row['total_return_pct']),
            'final_capital': float(row['final_capital']),
            'total_trades': int(row['total_trades']),
            'win_rate': float(row['win_rate']),
            'profit_factor': float(row['profit_factor']),
            'avg_trade_return': float(row['avg_trade_return']),
            'avg_hold_periods': float(row['avg_hold_periods']),
            'entry_params': {k: float(v) for k, v in entry_params.items()},
            'exit_params': {k: float(v) for k, v in exit_params.items()},
        }
        with open(run_dir / "params_and_metrics.json", 'w') as f:
            json.dump(params_info, f, indent=4)

        # Plots
        run_title = (f"{strategy} | Run {int(row['run_id'])} | "
                     f"Calmar: {row['calmar_ratio']:.2f} | "
                     f"Sharpe: {row['sharpe_ratio']:.2f} | "
                     f"Ann. Ret: {row['annualized_return']:.1f}%")
        plot_detailed_results(trades_df, df_daily_pnl, run_dir, run_title)

    # ---- Step 5: Save qualified summary ----
    qualified.to_excel(detail_dir / "high_calmar_unhedged_summary.xlsx", index=False)
    
    if hedged_summary_rows:
        df_hedged = pd.DataFrame(hedged_summary_rows)
        # Put otm_pct, hedged metrics first for visibility
        cols = ['run_id', 'strategy', 'otm_pct', 'hedged_total_return_pct', 'hedged_calmar', 'hedged_sharpe', 'hedged_max_dd']
        other_cols = [c for c in df_hedged.columns if c not in cols]
        df_hedged = df_hedged[cols + other_cols]
        df_hedged.to_excel(detail_dir / "high_calmar_hedged_summary.xlsx", index=False)

    print(f"\n  ✅ Detailed results saved: {detail_dir}")
    print(f"  Files per run: trades.csv, daily_pnl.csv, params_and_metrics.json, plots/")
    print(f"  Unhedged Summary:       high_calmar_unhedged_summary.xlsx")
    print(f"  Hedged Summary:         high_calmar_hedged_summary.xlsx")
    print(f"{'=' * 80}\n")

    # Base outputs (no hedge)
    # trades_df.to_csv(run_dir / "trades.csv", index=False)
    # df_daily_pnl.to_csv(run_dir / "daily_pnl_base.csv", index=False)


# ============================================================================
# RUN IT
# ============================================================================

run_detailed_for_high_calmar(df_sweep_results, df, calmar_threshold=0.5)

 