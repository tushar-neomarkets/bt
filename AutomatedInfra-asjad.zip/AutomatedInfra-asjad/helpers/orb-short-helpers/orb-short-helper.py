#!/usr/bin/env python3
"""
══════════════════════════════════════════════════════════════════════════════
  Opening Range Breakdown Short — NIFTY Weekly Options Signal Generator
══════════════════════════════════════════════════════════════════════════════

Strategy summary
────────────────
Build an opening range (OR) on 1-min option data between 9:15:59–11:15:59
for the CE and PE strikes closest to ±1 % of the index spot price.
After the range is locked, monitor every 1-min bar:
  • If CE LTP breaks BELOW the CE range low  → short the CE
  • If PE LTP breaks BELOW the PE range low  → short the PE

Only one position per side (CE / PE) is allowed at a time.

Strike selection : nearest strike to  spot × 1.01  for CE
                   nearest strike to  spot × 0.99  for PE
                   (using the index close at the range-open bar 9:15:59)

Range window     : 9:15:59 – 11:15:59  (inclusive, 1-min bars)
Signal window    : 11:16:00 – 14:59:59

SL / TP          : 20 % of entry premium
  • TP  : LTP ≤ entry_prem × (1 − TP_PCT)   → close position
  • SL  : LTP ≥ entry_prem × (1 + SL_PCT)   → close position
  • Hard exit  : 15:00:00

Rollover         : Same logic as TGS — use NW expiry when
                   (CW expiry date − trade_date).days ≤ ROLLOVER_DAYS_BEFORE

Output           : signal_orb_short.csv
══════════════════════════════════════════════════════════════════════════════
"""

import pandas as pd
import numpy as np
from datetime import datetime, date, time, timedelta
from marketdata import Index, FnO
from tqdm import tqdm

# ═══════════════════════════════════════════════════════════════════════════
# 1.  CONFIGURATION
# ═══════════════════════════════════════════════════════════════════════════

START_DATE   = "2019-07-30"
END_DATE     = "2026-03-10"
TICKER       = "NIFTY"
INDEX_NAME   = "NIFTY 50"
OUTPUT_PATH  = "signal_orb_short_120_bps.csv"

EXPIRY_FILE  = r"\\10.211.8.76\GFD MBM Data\Auxiliary Data\Expiry File_2025 Interchange.xlsx"
EXPIRY_SHEET = "Nifty 50"

# ── Bar / monitoring interval ─────────────────────────────────────────────
MONITOR_INTERVAL = "1m"           # only 1m data used in this strategy

# ── Rollover ──────────────────────────────────────────────────────────────
ROLLOVER_DAYS_BEFORE = 0          # same as TGS

# ── Strike selection ──────────────────────────────────────────────────────
# Target premium = 1% of spot price (e.g. spot 11000 → target ₹110).
# The strike whose first-bar LTP is closest to this target is selected.
PREMIUM_TARGET_PCT = 0.012         # target premium as fraction of spot

# ── Opening range window ──────────────────────────────────────────────────
RANGE_START  = time(9, 15, 59)   # first bar included in range
RANGE_END    = time(11, 15, 59)  # last  bar included in range

# ── Signal / exit times ───────────────────────────────────────────────────
SIGNAL_START = time(11, 16, 59)   # first bar eligible for entry/monitoring
HARD_EXIT_T  = time(15, 15, 59)   # close everything at or after this time

# ── SL / TP ───────────────────────────────────────────────────────────────
SL_PCT = 0.20                     # exit if LTP rises  20 % above entry prem
TP_PCT = 1.00                     # exit if LTP falls  20 % below entry prem


# ═══════════════════════════════════════════════════════════════════════════
# 2.  DATA FETCHING UTILITIES  (identical helpers to TGS)
# ═══════════════════════════════════════════════════════════════════════════

def _strip_tz(df: pd.DataFrame, col: str = "timestamp") -> pd.DataFrame:
    """Convert UTC timestamps → IST → naive."""
    df[col] = (
        pd.to_datetime(df[col], utc=True)
        .dt.tz_convert("Asia/Kolkata")
        .dt.tz_localize(None)
    )
    return df


def fetch_index_1m(trade_date: date) -> pd.DataFrame:
    """
    Fetch 1-min index bars for a single trading day.
    We only need the 9:15 spot price to compute target strikes.
    """
    idx = Index()
    ds  = trade_date.strftime("%Y-%m-%d")
    try:
        df = idx.get_prices(
            INDEX_NAME,
            start_date = ds,
            end_date   = ds,
            interval   = MONITOR_INTERVAL,
            columns    = "ohlc",
        )
        if df is None or df.empty:
            return pd.DataFrame()
        df = _strip_tz(df)
        df.sort_values("timestamp", inplace=True)
        df.set_index("timestamp", inplace=True)
        return df
    except Exception as e:
        print(f"  ⚠ Index 1m {ds} failed: {e}")
        return pd.DataFrame()


def fetch_option_chain(trade_date: date, kind: str, expiry_date: date) -> pd.DataFrame:
    """
    Fetch full 1-min option chain (all strikes) for *kind* on *trade_date*.
    Returns tz-naive DataFrame with columns [timestamp, strike_price, close, …].
    """
    fno = FnO()
    ds  = trade_date.strftime("%Y-%m-%d")
    exp = expiry_date.strftime("%Y-%m-%d")
    try:
        df = fno.get_prices(
            TICKER,
            start_date = ds,
            end_date   = ds,
            interval   = MONITOR_INTERVAL,
            expiry     = exp,
            kind       = kind,
            columns    = "all",
        )
        if df is None or df.empty:
            return pd.DataFrame()
        df = _strip_tz(df)
        df.sort_values("timestamp", inplace=True)

        # Keep only the requested side
        if "option_type" in df.columns:
            df = df.loc[df["option_type"] == kind].copy()
        elif "type" in df.columns:
            df = df.loc[df["type"] == kind].copy()
        else:
            print(f"  ⚠ No option_type column found – columns: {df.columns.tolist()}")

        df.drop_duplicates(subset=["timestamp", "strike_price"], keep="last", inplace=True)
        return df
    except Exception as e:
        print(f"  ⚠ Opt 1m {ds} {kind} exp={exp} failed: {e}")
        return pd.DataFrame()


# ═══════════════════════════════════════════════════════════════════════════
# 3.  EXPIRY CALENDAR
# ═══════════════════════════════════════════════════════════════════════════

def load_expiry_maps() -> tuple[dict, dict]:
    df = pd.read_excel(EXPIRY_FILE, sheet_name=EXPIRY_SHEET)
    df.columns = df.columns.str.strip()
    df["Date"]         = pd.to_datetime(df["Date"],         dayfirst=True)
    df["Current Week"] = pd.to_datetime(df["Current Week"], dayfirst=True)
    df["Next Week"]    = pd.to_datetime(df["Next Week"],    dayfirst=True)

    cw_map = dict(zip(df["Date"].dt.date, df["Current Week"].dt.date))
    nw_map = dict(zip(df["Date"].dt.date, df["Next Week"].dt.date))
    return cw_map, nw_map


# ═══════════════════════════════════════════════════════════════════════════
# 4.  STRIKE SELECTION HELPERS
# ═══════════════════════════════════════════════════════════════════════════

def select_strike_by_premium(
    chain: pd.DataFrame,
    target_premium: float,
    at_time,
) -> tuple[float | None, float | None]:
    """
    From the chain snapshot at *at_time*, find the strike whose LTP (close)
    is closest to *target_premium*.

    Returns (strike, ltp) or (None, None) if no data available.
    """
    if chain.empty:
        return None, None

    snap = chain.loc[chain["timestamp"] == at_time]
    if snap.empty:
        # Fallback: use the last available bar at or before at_time
        past = chain.loc[chain["timestamp"] <= at_time]
        if past.empty:
            return None, None
        latest_ts = past["timestamp"].max()
        snap = chain.loc[chain["timestamp"] == latest_ts]

    if snap.empty:
        return None, None

    snap = snap.copy()
    snap["_diff"] = (snap["close"] - target_premium).abs()
    best = snap.loc[snap["_diff"].idxmin()]
    return float(best["strike_price"]), float(best["close"])


def get_strike_series(chain: pd.DataFrame, strike: float) -> pd.DataFrame:
    """
    Filter *chain* to a single strike and return a timestamp-indexed
    DataFrame with no duplicate timestamps.
    """
    s = chain.loc[chain["strike_price"] == strike].copy()
    s = s.drop_duplicates(subset=["timestamp"]).set_index("timestamp").sort_index()
    return s


# ═══════════════════════════════════════════════════════════════════════════
# 5.  SIGNAL-ROW HELPERS
# ═══════════════════════════════════════════════════════════════════════════

def _entry_row(ts, kind: str, csv_expiry: str, strike: float, premium: float) -> dict:
    return {
        "timestamp":     str(ts)[:19],
        "ticker":        TICKER,
        "entry_long":    0,  "exit_long":  0,
        "entry_short":   1,  "exit_short": 0,
        "instrument":    kind,
        "expiry":        csv_expiry,
        "strike":        strike,
        "weight":        1.0,
        "entry_premium": round(premium, 2),
    }


def _exit_row(ts, pos: dict) -> dict:
    return {
        "timestamp":     str(ts)[:19],
        "ticker":        TICKER,
        "entry_long":    0,  "exit_long":  0,
        "entry_short":   0,  "exit_short": 1,
        "instrument":    pos["kind"],
        "expiry":        pos["csv_expiry"],
        "strike":        pos["strike"],
        "weight":        1.0,
        "entry_premium": "",
    }


# ═══════════════════════════════════════════════════════════════════════════
# 6.  SINGLE-DAY PROCESSOR
# ═══════════════════════════════════════════════════════════════════════════

def process_day(
    trade_date: date,
    cw_map: dict,
    nw_map: dict,
) -> list[dict]:
    """
    Full day processing for the ORB Short strategy.

    Phase 1 – Range build   : 9:15:59 – 11:15:59
      • Determine CE/PE strikes at 1 % OTM from the first available spot.
      • Track high/low of each option's 1-min close inside the window.

    Phase 2 – Signal monitor : 11:16:00 – 14:59:59
      • If option LTP < range_low for that side → short entry (once per side).
      • Monitor each open position every minute for SL/TP/hard exit.
    """

    # ── expiry for today ──────────────────────────────────────────────────
    cw_exp = cw_map.get(trade_date)
    nw_exp = nw_map.get(trade_date)
    if cw_exp is None or nw_exp is None:
        return []

    days_to_cw = (cw_exp - trade_date).days
    use_nw     = days_to_cw <= ROLLOVER_DAYS_BEFORE
    api_expiry = nw_exp if use_nw else cw_exp
    csv_expiry = "nw"  if use_nw else "cw"

    # ── fetch index 1m data (for spot price) ─────────────────────────────
    idx_1m = fetch_index_1m(trade_date)
    if idx_1m.empty:
        print(f"  ⚠ {trade_date}: no index 1m data – skipping")
        return []

    # Spot price = close of the first bar at or after 9:15
    range_bars = idx_1m.loc[idx_1m.index.map(lambda x: x.time() >= RANGE_START)]
    if range_bars.empty:
        print(f"  ⚠ {trade_date}: no index bars in range window – skipping")
        return []

    spot = float(range_bars.iloc[0]["close"])
    target_premium = round(spot * PREMIUM_TARGET_PCT, 2)

    # ── fetch full option chains ──────────────────────────────────────────
    ce_chain = fetch_option_chain(trade_date, "CE", api_expiry)
    pe_chain = fetch_option_chain(trade_date, "PE", api_expiry)

    if ce_chain.empty and pe_chain.empty:
        print(f"  ⚠ {trade_date}: no option chain data – skipping")
        return []

    # Strike selection: pick the strike whose premium ≈ 1% of spot,
    # evaluated at the first bar of the range window.
    first_range_ts = range_bars.index[0]   # first 1m timestamp ≥ RANGE_START

    ce_strike, ce_entry_snap = select_strike_by_premium(ce_chain, target_premium, first_range_ts)
    pe_strike, pe_entry_snap = select_strike_by_premium(pe_chain, target_premium, first_range_ts)

    print(f"  {trade_date}  spot={spot:.0f}  target_prem={target_premium:.1f}  "
          f"CE_strike={ce_strike}(ltp≈{ce_entry_snap})  "
          f"PE_strike={pe_strike}(ltp≈{pe_entry_snap})  exp={csv_expiry}")

    # Per-strike 1m series (timestamp-indexed)
    ce_s = get_strike_series(ce_chain, ce_strike) if (not ce_chain.empty and ce_strike is not None) else pd.DataFrame()
    pe_s = get_strike_series(pe_chain, pe_strike) if (not pe_chain.empty and pe_strike is not None) else pd.DataFrame()

    # ── Phase 1 : build opening range ─────────────────────────────────────
    def build_range(series: pd.DataFrame) -> tuple[float | None, float | None]:
        """Return (range_high, range_low) from bars within the OR window."""
        if series.empty:
            return None, None
        mask = series.index.map(
            lambda x: RANGE_START <= x.time() <= RANGE_END
        )
        window = series.loc[mask]
        if window.empty:
            return None, None
        return float(window["close"].max()), float(window["close"].min())

    ce_hi, ce_lo = build_range(ce_s)
    pe_hi, pe_lo = build_range(pe_s)

    print(f"    CE range: lo={ce_lo}  hi={ce_hi}")
    print(f"    PE range: lo={pe_lo}  hi={pe_hi}")

    # ── Phase 2 : signal monitoring ───────────────────────────────────────
    signals:    list[dict] = []
    ce_pos:     dict | None = None   # open CE short position
    pe_pos:     dict | None = None   # open PE short position
    ce_traded   = False              # once-per-side flag
    pe_traded   = False

    # Build a unified list of 1m timestamps inside the signal window
    all_ts: list = []
    for s in [ce_s, pe_s]:
        if not s.empty:
            sig_ts = s.loc[s.index.map(lambda x: x.time() >= SIGNAL_START)].index
            all_ts.extend(sig_ts.tolist())

    all_ts = sorted(set(all_ts))

    for ts in all_ts:
        t = ts.time()

        # ── hard exit ────────────────────────────────────────────────────
        if t >= HARD_EXIT_T:
            if ce_pos:
                signals.append(_exit_row(ts, ce_pos))
                ce_pos = None
            if pe_pos:
                signals.append(_exit_row(ts, pe_pos))
                pe_pos = None
            break

        # ── monitor CE position ───────────────────────────────────────────
        if ce_pos and not ce_s.empty and ts in ce_s.index:
            ltp = float(ce_s.at[ts, "close"])
            ep  = ce_pos["entry_prem"]

            if ltp <= ep * (1 - TP_PCT):          # TP hit
                print(f"    CE TP  {ts.time()}  LTP={ltp:.1f}  entry={ep:.1f}")
                signals.append(_exit_row(ts, ce_pos))
                ce_pos = None
            elif ltp >= ep * (1 + SL_PCT):         # SL hit
                print(f"    CE SL  {ts.time()}  LTP={ltp:.1f}  entry={ep:.1f}")
                signals.append(_exit_row(ts, ce_pos))
                ce_pos = None

        # ── monitor PE position ───────────────────────────────────────────
        if pe_pos and not pe_s.empty and ts in pe_s.index:
            ltp = float(pe_s.at[ts, "close"])
            ep  = pe_pos["entry_prem"]

            if ltp <= ep * (1 - TP_PCT):
                print(f"    PE TP  {ts.time()}  LTP={ltp:.1f}  entry={ep:.1f}")
                signals.append(_exit_row(ts, pe_pos))
                pe_pos = None
            elif ltp >= ep * (1 + SL_PCT):
                print(f"    PE SL  {ts.time()}  LTP={ltp:.1f}  entry={ep:.1f}")
                signals.append(_exit_row(ts, pe_pos))
                pe_pos = None

        # ── CE entry : breakdown below range low ──────────────────────────
        if (
            not ce_traded
            and ce_pos is None
            and ce_lo is not None
            and not ce_s.empty
            and ts in ce_s.index
        ):
            ltp = float(ce_s.at[ts, "close"])
            if ltp < ce_lo:
                print(f"    CE ENTRY  {ts.time()}  strike={ce_strike}  prem={ltp:.1f}  range_lo={ce_lo:.1f}")
                signals.append(_entry_row(ts, "CE", csv_expiry, ce_strike, ltp))
                ce_pos = {
                    "kind":       "CE",
                    "csv_expiry": csv_expiry,
                    "strike":     ce_strike,
                    "entry_prem": ltp,
                }
                ce_traded = True   # only one entry per side per day

        # ── PE entry : breakdown below range low ──────────────────────────
        if (
            not pe_traded
            and pe_pos is None
            and pe_lo is not None
            and not pe_s.empty
            and ts in pe_s.index
        ):
            ltp = float(pe_s.at[ts, "close"])
            if ltp < pe_lo:
                print(f"    PE ENTRY  {ts.time()}  strike={pe_strike}  prem={ltp:.1f}  range_lo={pe_lo:.1f}")
                signals.append(_entry_row(ts, "PE", csv_expiry, pe_strike, ltp))
                pe_pos = {
                    "kind":       "PE",
                    "csv_expiry": csv_expiry,
                    "strike":     pe_strike,
                    "entry_prem": ltp,
                }
                pe_traded = True

    # ── end-of-day force-close ────────────────────────────────────────────
    eod_ts = all_ts[-1] if all_ts else None
    if eod_ts:
        if ce_pos:
            signals.append(_exit_row(eod_ts, ce_pos))
            print(f"  ⚠ {trade_date}: CE orphan force-closed at {eod_ts.time()}")
        if pe_pos:
            signals.append(_exit_row(eod_ts, pe_pos))
            print(f"  ⚠ {trade_date}: PE orphan force-closed at {eod_ts.time()}")

    return signals


# ═══════════════════════════════════════════════════════════════════════════
# 7.  MAIN ENTRY POINT
# ═══════════════════════════════════════════════════════════════════════════

def generate_signals():
    print("=" * 70)
    print("  Opening Range Breakdown Short — Signal Generator")
    print("=" * 70)

    # ── 7a.  Load expiry calendar ─────────────────────────────────────────
    print("\n[1/2] Loading expiry calendar …")
    cw_map, nw_map = load_expiry_maps()
    print(f"  CW entries: {len(cw_map):,}   NW entries: {len(nw_map):,}")

    # ── 7b.  Build trading day list ───────────────────────────────────────
    start_d = date.fromisoformat(START_DATE)
    end_d   = date.fromisoformat(END_DATE)

    # All calendar dates in range; we skip weekends and rely on the expiry
    # map to skip non-trading days (process_day returns [] if date missing).
    all_dates = [
        start_d + timedelta(days=i)
        for i in range((end_d - start_d).days + 1)
        if (start_d + timedelta(days=i)).weekday() < 5
    ]

    print(f"\n[2/2] Processing up to {len(all_dates):,} calendar days …\n")

    all_signals: list[dict] = []
    skipped_days = 0

    for td in tqdm(all_dates, desc="Signal generation", unit="day"):
        day_sigs = process_day(td, cw_map, nw_map)
        if day_sigs:
            all_signals.extend(day_sigs)
        else:
            skipped_days += 1

    # ── 7c.  Write CSV ────────────────────────────────────────────────────
    if not all_signals:
        print("\n  ⚠  No signals generated — check data & config.")
        return

    df_out = pd.DataFrame(all_signals)
    df_out.to_csv(OUTPUT_PATH, index=False)

    # ── 7d.  Sanity summary ───────────────────────────────────────────────
    n_entry = int(df_out["entry_short"].sum())
    n_exit  = int(df_out["exit_short"].sum())
    instr_counts  = df_out.loc[df_out["entry_short"] == 1, "instrument"].value_counts()
    expiry_counts = df_out.loc[df_out["entry_short"] == 1, "expiry"].value_counts()

    print(f"\n{'=' * 70}")
    print(f"  SIGNAL GENERATION COMPLETE")
    print(f"{'=' * 70}")
    print(f"  Output file       : {OUTPUT_PATH}")
    print(f"  Total rows        : {len(df_out):,}")
    print(f"  Calendar days     : {len(all_dates):,}  (skipped {skipped_days})")
    print(f"  ─────────────────────────────────────────────")
    print(f"  Short entries     : {n_entry:,}")
    print(f"  Short exits       : {n_exit:,}")
    print(f"  Entry/Exit match  : {'✓' if n_entry == n_exit else '✗  MISMATCH!'}")
    print(f"  ─────────────────────────────────────────────")
    print(f"  Instrument split  :")
    for inst, cnt in instr_counts.items():
        print(f"      {inst:4s} : {cnt:,}")
    print(f"  Expiry split      :")
    for exp, cnt in expiry_counts.items():
        print(f"      {exp:4s} : {cnt:,}")
    print(f"  ─────────────────────────────────────────────")
    print(f"  Date range        : {df_out['timestamp'].min()}  →  "
          f"{df_out['timestamp'].max()}")
    print(f"{'=' * 70}")


# ═══════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    generate_signals()