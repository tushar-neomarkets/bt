#!/usr/bin/env python3
"""
══════════════════════════════════════════════════════════════════════════════
  Put Bear Spread — NIFTY Weekly Options Signal Generator  (Parameter Sweep)
══════════════════════════════════════════════════════════════════════════════

Runs ONLY on NIFTY weekly CW expiry days.

─── Parameters ───────────────────────────────────────────────────────────────

  PCR_MODE      : "oi" | "volume" | "both" | "either" | "none"
  PCR_THRESHOLD : float  — trade only when ratio < this value
  PCR_STRIKES   : "all" | "atm"
  PCR_TIMING    : "intraday" | "open"

  N_STRADDLES    : float  -- short strike = round_to_50(forward - N x straddle)
                   e.g. 2.0 = 2 straddles away (original), 1.5, 3.0 etc.

  LONG_OFFSET    : int    -- how many strikes away from ATM for the long put leg
                   0  = ATM (default)
                   1+ = move LONG_DIRECTION strikes away from ATM

  LONG_DIRECTION : "itm" | "otm"
                   "otm" -> move to lower strike  (cheaper, more OTM put)
                   "itm" -> move to higher strike (more expensive, more ITM put)
                   ignored when LONG_OFFSET = 0

  SL_PCT        : float  — exit when spread_value ≤ net_debit × (1 − SL_PCT)
                  e.g. 0.50 = exit when 50% of net debit is lost
                  Set to None to disable intraday SL.

  TP_MULT       : float  — exit when spread_value ≥ net_debit × (1 + TP_MULT)
                  e.g. 2.0 = exit at 2R (2× risk as profit)
                  Set to None to disable intraday TP.

  TIME_STOP     : time   — exit both legs at this time regardless of P&L.
                  Set to None to disable (only HARD_EXIT_T applies).

  HARD_EXIT_T   : time   — absolute last exit, no matter what.

─── Exit priority (evaluated every 3m bar after entry) ───────────────────────
  1. HARD_EXIT_T  (absolute, always fires)
  2. TIME_STOP    (if set, fires regardless of P&L)
  3. SL           (spread value dropped to net_debit × (1 − SL_PCT))
  4. TP           (spread value rose   to net_debit × (1 + TP_MULT))

  Spread value monitored = long_leg_LTP − short_leg_LTP on each 3m bar.

─── Sizing note ──────────────────────────────────────────────────────────────
  net_debit          = long_entry_prem − short_entry_prem
  max_loss_per_lot   = net_debit × LOT_SIZE
  quantity           = floor(RUPEE_RISK / max_loss_per_lot)
  (LOT_SIZE and RUPEE_RISK are logged but sizing is informational only —
   the signal CSV uses weight=1.0; multiply externally for actual sizing.)

══════════════════════════════════════════════════════════════════════════════
"""

import pandas as pd
import numpy as np
from datetime import date, time, timedelta
from typing import Literal, Optional
from marketdata import FnO

# ── Trading-day calendar (ported from ttm_helper.py) ────────────────────────
_CALENDAR_PATH = r"\\10.211.8.76\GFD_Data\Auxiliary\Calendar.xlsx"
_HOLIDAYS: Optional[dict[date, date]] = None
_EXTRAS:   Optional[dict[date, date]] = None

def _load_calendar() -> tuple[dict[date, date], dict[date, date]]:
    holidays: dict[date, date] = {}
    extras:   dict[date, date] = {}
    try:
        xl = pd.ExcelFile(_CALENDAR_PATH)
        if "Holidays" in xl.sheet_names:
            for _, row in xl.parse("Holidays").iterrows():
                try:
                    holidays[pd.to_datetime(row["date"]).date()] = pd.to_datetime(row["announced_on"]).date()
                except Exception:
                    continue
        if "Special" in xl.sheet_names:
            for _, row in xl.parse("Special").iterrows():
                try:
                    extras[pd.to_datetime(row["date"]).date()] = pd.to_datetime(row["announced_on"]).date()
                except Exception:
                    continue
    except Exception:
        pass
    return holidays, extras

def _get_holidays() -> tuple[dict[date, date], dict[date, date]]:
    global _HOLIDAYS, _EXTRAS
    if _HOLIDAYS is None or _EXTRAS is None:
        _HOLIDAYS, _EXTRAS = _load_calendar()
    return _HOLIDAYS, _EXTRAS

def _is_trading_day(d: date, as_on: date, holidays: dict, extras: dict) -> bool:
    if extras.get(d, date.max) < as_on:
        return True
    if d.weekday() >= 5:
        return False
    if holidays.get(d, date.max) < as_on:
        return False
    return True

def _count_trading_days(start: date, end_excl: date) -> int:
    """Count trading days in [start, end_excl)."""
    holidays, extras = _get_holidays()
    count, d = 0, start
    while d < end_excl:
        if _is_trading_day(d, as_on=d, holidays=holidays, extras=extras):
            count += 1
        d += timedelta(days=1)
    return count
# ────────────────────────────────────────────────────────────────────────────
from tqdm import tqdm
import math
from itertools import product
import os

# ═══════════════════════════════════════════════════════════════════════════
# 1.  CONFIGURATION
# ═══════════════════════════════════════════════════════════════════════════

START_DATE   = "2019-07-30"
END_DATE     = "2026-03-10"
TICKER       = "NIFTY"

EXPIRY_FILE  = r"\\10.211.8.76\GFD MBM Data\Auxiliary Data\Expiry File_Master.xlsx"
EXPIRY_SHEET = "Nifty 50"

# ── Timing ────────────────────────────────────────────────────────────────
MONITOR_INTERVAL = "3m"
OPEN_BAR         = time(9, 16, 59)    # used when PCR_TIMING = "open"
ENTRY_CUTOFF     = time(14, 59, 59)   # last bar eligible for entry (intraday)
HARD_EXIT_T      = time(15, 15, 59)   # absolute last exit — always fires

# ── Strike grid ───────────────────────────────────────────────────────────
STRIKE_STEP = 50

# ── Sizing info (informational only, not written to CSV) ──────────────────
LOT_SIZE    = 65          # current NIFTY lot size
RUPEE_RISK  = 10_000      # max rupee risk per trade (for quantity logging)

# =============================================================================
# PARAMETER SWEEP GRID  <- expand lists to sweep across values
# =============================================================================

PARAMETER_GRID = {
    'PCR_MODE':       ["oi", "volume"],
    'PCR_THRESHOLD':  [1.0, 1.5],
    'PCR_STRIKES':    ["all", "atm"],
    'PCR_TIMING':     ["intraday", "open"],
    'N_STRADDLES':    [1.0, 1.5, 2.0],
    'LONG_OFFSET':    [0, 1, 2],
    'LONG_DIRECTION': ["otm", "itm"],
    'SL_PCT':         [0.50, 0.75],
    'TP_MULT':        [1.0, 2.0, 3.0, 100.0],
    'TIME_STOP':      [time(15, 14, 59)],
}

BASE_RESULTS_DIR = "put_spread_sweep_results"
os.makedirs(BASE_RESULTS_DIR, exist_ok=True)


# ═══════════════════════════════════════════════════════════════════════════
# 2.  UTILITIES
# ═══════════════════════════════════════════════════════════════════════════

def _strip_tz(df: pd.DataFrame, col: str = "timestamp") -> pd.DataFrame:
    df[col] = (
        pd.to_datetime(df[col], utc=True)
        .dt.tz_convert("Asia/Kolkata")
        .dt.tz_localize(None)
    )
    return df


def _to_pandas(df) -> pd.DataFrame:
    return df if isinstance(df, pd.DataFrame) else df.to_pandas()


def round_to_strike(value: float, step: int = STRIKE_STEP) -> float:
    return float(round(value / step) * step)


def _col_name(df: pd.DataFrame, candidates: list) -> str | None:
    return next((c for c in candidates if c in df.columns), None)


def resolve_long_strike(pe_snap: pd.DataFrame, atm_strike: float,
                        long_offset: int, long_direction: str) -> tuple:
    # Return (long_strike, long_entry_prem) for the long put leg.
    # long_offset=0 -> ATM. long_offset>0 -> Nth strike in long_direction.
    #   "otm" -> lower strike (more OTM for put)
    #   "itm" -> higher strike (more ITM for put)
    # Returns (None, None) if target not available.
    if long_offset == 0:
        row = pe_snap.loc[pe_snap["strike_price"] == atm_strike]
        if row.empty:
            return None, None
        return atm_strike, float(row["close"].iloc[0])

    available = sorted(pe_snap["strike_price"].unique())
    if atm_strike not in available:
        return None, None
    atm_idx = available.index(atm_strike)

    target_idx = atm_idx - long_offset if long_direction == "otm" else atm_idx + long_offset
    if target_idx < 0 or target_idx >= len(available):
        return None, None

    target_strike = available[target_idx]
    row = pe_snap.loc[pe_snap["strike_price"] == target_strike]
    if row.empty:
        return None, None
    return float(target_strike), float(row["close"].iloc[0])


def _snap(df: pd.DataFrame, ts: pd.Timestamp) -> pd.DataFrame:
    return df.loc[df["timestamp"] == ts]


# ═══════════════════════════════════════════════════════════════════════════
# 3.  EXPIRY CALENDAR
# ═══════════════════════════════════════════════════════════════════════════

def load_expiry_maps() -> tuple[dict, dict]:
    df = pd.read_excel(EXPIRY_FILE, sheet_name=EXPIRY_SHEET)
    df.columns = df.columns.str.strip()
    df["Date"]         = pd.to_datetime(df["Date"],         dayfirst=True)
    df["Current Week"] = pd.to_datetime(df["Current Week"], dayfirst=True)
    df["Next Week"]    = pd.to_datetime(df["Next Week"],    dayfirst=True)
    cw_map = dict(zip(df["Date"].dt.date, df["Current Week"].dt.date))
    nw_map = dict(zip(df["Date"].dt.date, df["Next Week"].dt.date))
    return cw_map, nw_map


def build_expiry_day_set(cw_map: dict) -> set:
    return {td for td, exp in cw_map.items() if td == exp}


# ═══════════════════════════════════════════════════════════════════════════
# 4.  DATA FETCHING  (with caching for parameter sweep)
# ═══════════════════════════════════════════════════════════════════════════

_chain_cache:    dict = {}   # (trade_date, api_expiry) -> (ce_df, pe_df)
_straddle_cache: dict = {}   # (trade_date, api_expiry) -> straddle_df


def fetch_chain_3m(trade_date: date, api_expiry: date) -> tuple[pd.DataFrame, pd.DataFrame]:
    """
    Full-day 3m chain for CE and PE (all strikes, columns=all, greeks=True).
    Used for: PCR (OI + volume), forward price, all strike premiums.
    Results are cached so repeated sweep runs don't re-fetch.
    """
    key = (trade_date, api_expiry)
    if key in _chain_cache:
        return _chain_cache[key]

    fno = FnO()
    ds  = trade_date.strftime("%Y-%m-%d")
    exp = api_expiry.strftime("%Y-%m-%d")
    out = {}
    for kind in ("CE", "PE"):
        try:
            df = fno.get_prices(
                TICKER,
                start_date=ds, end_date=ds,
                interval=MONITOR_INTERVAL,
                expiry=exp, kind=kind,
                columns="all", include_greeks=True,
            )
            if df is None or len(df) == 0:
                out[kind] = pd.DataFrame()
                continue
            df = _to_pandas(df)
            df = _strip_tz(df)

            # Explicitly filter to the requested option_type.
            # get_prices(kind=) does not always filter server-side.
            oc = "option_type" if "option_type" in df.columns else "type"
            if oc in df.columns:
                before = len(df)
                df = df.loc[df[oc] == kind].copy()
                if len(df) == 0:
                    print(f"  WARNING fetch_chain_3m {kind} {ds}: "
                          f"0 rows after option_type filter (had {before} rows).")
                    out[kind] = pd.DataFrame()
                    continue
            else:
                print(f"  WARNING fetch_chain_3m {kind} {ds}: "
                      f"no option_type column. Columns: {df.columns.tolist()}")

            df.sort_values("timestamp", inplace=True)
            df.reset_index(drop=True, inplace=True)
            out[kind] = df
        except Exception as e:
            print(f"  WARNING fetch_chain_3m {kind} {ds}: {e}")
            out[kind] = pd.DataFrame()

    result = (out.get("CE", pd.DataFrame()), out.get("PE", pd.DataFrame()))
    _chain_cache[key] = result
    return result


def fetch_straddle_3m(trade_date: date, api_expiry: date) -> pd.DataFrame:
    """Full-day 3m ATM straddle (offset=0): CE/PE close + ATM strike at every bar.
    Results are cached so repeated sweep runs don't re-fetch."""
    key = (trade_date, api_expiry)
    if key in _straddle_cache:
        return _straddle_cache[key]

    fno = FnO()
    ds  = trade_date.strftime("%Y-%m-%d")
    exp = api_expiry.strftime("%Y-%m-%d")
    try:
        df = fno.get_strangle(
            TICKER, ds,
            expiry=exp, offset=0,
            columns="close",
            interval=MONITOR_INTERVAL,
        )
        if df is None or len(df) == 0:
            _straddle_cache[key] = pd.DataFrame()
            return pd.DataFrame()
        df = _to_pandas(df)
        df = _strip_tz(df)
        df.sort_values("timestamp", inplace=True)
        df.reset_index(drop=True, inplace=True)
        _straddle_cache[key] = df
        return df
    except Exception as e:
        print(f"  WARNING fetch_straddle_3m {ds}: {e}")
        _straddle_cache[key] = pd.DataFrame()
        return pd.DataFrame()


# ═══════════════════════════════════════════════════════════════════════════
# 5.  PCR COMPUTATION
# ═══════════════════════════════════════════════════════════════════════════

def compute_pcr_at(
    ce_df: pd.DataFrame,
    pe_df: pd.DataFrame,
    straddle_df: pd.DataFrame,
    ts: pd.Timestamp,
    pcr_strikes: str,
    verbose: bool = False,
) -> dict:
    ce_snap = _snap(ce_df, ts)
    pe_snap = _snap(pe_df, ts)

    if verbose:
        print(f"      [diag] ts={ts.time()}  ce_rows={len(ce_snap)}  pe_rows={len(pe_snap)}")
        print(f"      [diag] ce cols: {ce_df.columns.tolist()}")
        print(f"      [diag] pe cols: {pe_df.columns.tolist()}")

    if pcr_strikes == "atm":
        strad_snap = _snap(straddle_df, ts)
        ce_strad   = strad_snap.loc[strad_snap["option_type"] == "CE"]
        if ce_strad.empty:
            if verbose:
                print(f"      [diag] ATM mode: no CE straddle row -> n/a")
            return {"oi_pcr": None, "volume_pcr": None}
        atm = float(ce_strad["strike_price"].iloc[0])
        ce_snap = ce_snap.loc[ce_snap["strike_price"] == atm]
        pe_snap = pe_snap.loc[pe_snap["strike_price"] == atm]
        if verbose:
            print(f"      [diag] ATM={atm}  ce_rows={len(ce_snap)}  pe_rows={len(pe_snap)}")

    def _ratio(col_candidates, label):
        ce_col = _col_name(ce_df, col_candidates)
        pe_col = _col_name(pe_df, col_candidates)
        if verbose:
            print(f"      [diag] {label}: ce_col={ce_col!r}  pe_col={pe_col!r}")
        if ce_col is None or pe_col is None:
            if verbose:
                print(f"      [diag] {label}: column not found -> n/a")
            return None
        try:
            pe_val = float(pe_snap[pe_col].dropna().sum())
            ce_val = float(ce_snap[ce_col].dropna().sum())
            ratio  = (pe_val / ce_val) if ce_val != 0 else None
            if verbose:
                print(f"      [diag] {label}: PE={pe_val:.0f}  CE={ce_val:.0f}  "
                      f"ratio={f'{ratio:.4f}' if ratio is not None else 'n/a (CE=0)'}")
            return ratio
        except Exception as exc:
            if verbose:
                print(f"      [diag] {label}: exception -> {exc}")
            return None

    return {
        "oi_pcr":     _ratio(["oi", "open_interest"], "OI"),
        "volume_pcr": _ratio(["volume", "vol"],       "Volume"),
    }


def pcr_filter_passes(pcr: dict, pcr_mode: str, pcr_threshold: float) -> bool:
    if pcr_mode == "none":
        return True
    oi_ok  = pcr["oi_pcr"]     is not None and pcr["oi_pcr"]     < pcr_threshold
    vol_ok = pcr["volume_pcr"] is not None and pcr["volume_pcr"] < pcr_threshold
    if pcr_mode == "oi":     return oi_ok
    if pcr_mode == "volume": return vol_ok
    if pcr_mode == "both":   return oi_ok and vol_ok
    if pcr_mode == "either": return oi_ok or  vol_ok
    raise ValueError(f"Unknown pcr_mode: {pcr_mode!r}")


# ═══════════════════════════════════════════════════════════════════════════
# 6.  SIGNAL ROW HELPERS
# ═══════════════════════════════════════════════════════════════════════════

def _entry_row(ts, action, kind, csv_expiry, strike, premium) -> dict:
    row = {
        "timestamp":     str(ts)[:19],
        "ticker":        TICKER,
        "entry_long":    0, "exit_long":    0,
        "entry_short":   0, "exit_short":   0,
        "instrument":    kind,
        "expiry":        csv_expiry,
        "strike":        strike,
        "weight":        1.0,
        "entry_premium": round(premium, 2),
    }
    row[action] = 1
    return row


def _exit_row(ts, pos: dict, action: str, reason: str = "") -> dict:
    row = {
        "timestamp":     str(ts)[:19],
        "ticker":        TICKER,
        "entry_long":    0, "exit_long":    0,
        "entry_short":   0, "exit_short":   0,
        "instrument":    pos["kind"],
        "expiry":        pos["csv_expiry"],
        "strike":        pos["strike"],
        "weight":        1.0,
        "entry_premium": "",
        "exit_reason":   reason,
    }
    row[action] = 1
    return row


# ═══════════════════════════════════════════════════════════════════════════
# 7.  ENTRY RESOLUTION
# ═══════════════════════════════════════════════════════════════════════════

def resolve_entry_bar(
    ce_df: pd.DataFrame,
    pe_df: pd.DataFrame,
    straddle_df: pd.DataFrame,
    pcr_mode: str,
    pcr_threshold: float,
    pcr_strikes: str,
    pcr_timing: str,
) -> pd.Timestamp | None:
    chain_ts    = set(ce_df["timestamp"].unique()) & set(pe_df["timestamp"].unique())
    straddle_ts = set(straddle_df["timestamp"].unique())
    all_ts      = sorted(chain_ts & straddle_ts)

    if not all_ts:
        return None

    if pcr_timing == "open":
        candidates = [ts for ts in all_ts if ts.time() <= OPEN_BAR]
        if not candidates:
            return None
        check_ts = [candidates[-1]]
    else:
        check_ts = [ts for ts in all_ts if ts.time() <= ENTRY_CUTOFF]

    for i, ts in enumerate(check_ts):
        pcr       = compute_pcr_at(ce_df, pe_df, straddle_df, ts, pcr_strikes,
                                   verbose=(i == 0))
        oi_str    = f"{pcr['oi_pcr']:.4f}"     if pcr["oi_pcr"]     is not None else "n/a"
        vol_str   = f"{pcr['volume_pcr']:.4f}" if pcr["volume_pcr"] is not None else "n/a"
        oi_ok     = pcr["oi_pcr"]     is not None and pcr["oi_pcr"]     < pcr_threshold
        vol_ok    = pcr["volume_pcr"] is not None and pcr["volume_pcr"] < pcr_threshold

        def _reason(oi_ok=oi_ok, vol_ok=vol_ok, oi_str=oi_str, vol_str=vol_str):
            parts = []
            if pcr_mode in ("oi", "both", "either"):
                parts.append(f"OI={oi_str} (need <{pcr_threshold}) "
                             f"[{'PASS' if oi_ok else 'FAIL'}]")
            if pcr_mode in ("volume", "both", "either"):
                parts.append(f"Vol={vol_str} (need <{pcr_threshold}) "
                             f"[{'PASS' if vol_ok else 'FAIL'}]")
            if pcr_mode == "none":
                parts.append("pcr_mode=none (always pass)")
            return "  ".join(parts)

        if pcr_filter_passes(pcr, pcr_mode, pcr_threshold):
            print(f"  PCR PASSED @ {ts.time()}  {_reason()}")
            return ts
        else:
            indent = "    " if pcr_timing == "intraday" else "  "
            print(f"{indent}{ts.time()}  {_reason()}  -- no trigger")

    return None


# ═══════════════════════════════════════════════════════════════════════════
# 8.  INTRADAY EXIT MONITOR
# ═══════════════════════════════════════════════════════════════════════════

def monitor_exit(
    pe_df: pd.DataFrame,
    entry_ts: pd.Timestamp,
    long_strike: float,
    short_strike: float,
    net_debit: float,
    long_pos: dict,
    short_pos: dict,
    sl_pct: float | None,
    tp_mult: float | None,
    time_stop_val: time | None,
    forward_price: float,
) -> tuple[list[dict], dict]:
    """
    Walk every 3m bar AFTER entry_ts.
    At each bar compute spread_value = long_LTP - short_LTP and check:
      1. HARD_EXIT_T  — always exit
      2. TIME_STOP    — exit regardless of P&L
      3. SL           — spread_value <= net_debit * (1 - sl_pct)
      4. TP           — spread_value >= net_debit * (1 + tp_mult)

    Returns (exit_signal_rows, trade_dict).
    Falls back to last available bar if no bar is found at the trigger time.
    """
    # All 3m PE bars after entry, for both strikes
    all_ts = sorted(
        ts for ts in pe_df["timestamp"].unique()
        if ts > entry_ts
    )

    # Pre-compute thresholds
    sl_threshold = (net_debit * (1 - sl_pct))  if sl_pct  is not None else None
    tp_threshold = (net_debit * (1 + tp_mult)) if tp_mult is not None else None

    exit_ts     = None
    exit_reason = "hard_exit"

    for ts in all_ts:
        t = ts.time()

        # 1. Hard exit
        if t >= HARD_EXIT_T:
            exit_ts     = ts
            exit_reason = "hard_exit"
            break

        # 2. Time stop
        if time_stop_val is not None and t >= time_stop_val:
            exit_ts     = ts
            exit_reason = "time_stop"
            break

        # Get LTPs at this bar
        long_snap  = pe_df.loc[(pe_df["timestamp"] == ts) &
                               (pe_df["strike_price"] == long_strike)]
        short_snap = pe_df.loc[(pe_df["timestamp"] == ts) &
                               (pe_df["strike_price"] == short_strike)]

        if long_snap.empty or short_snap.empty:
            continue

        long_ltp  = float(long_snap["close"].iloc[0])
        short_ltp = float(short_snap["close"].iloc[0])
        spread_val = long_ltp - short_ltp

        # 3. SL
        if sl_threshold is not None and spread_val <= sl_threshold:
            print(f"    SL hit @ {t}  spread={spread_val:.2f}  "
                  f"threshold={sl_threshold:.2f}  net_debit={net_debit:.2f}")
            exit_ts     = ts
            exit_reason = "sl"
            break

        # 4. TP
        if tp_threshold is not None and spread_val >= tp_threshold:
            print(f"    TP hit @ {t}  spread={spread_val:.2f}  "
                  f"threshold={tp_threshold:.2f}  net_debit={net_debit:.2f}")
            exit_ts     = ts
            exit_reason = "tp"
            break

    # Fallback: if we never hit any exit (e.g. no bars after entry), use last bar
    if exit_ts is None:
        if all_ts:
            exit_ts     = all_ts[-1]
            exit_reason = "hard_exit_fallback"
        else:
            exit_ts     = entry_ts
            exit_reason = "no_bars_fallback"

    print(f"  EXIT @ {exit_ts.time()}  reason={exit_reason}")

    # --- Compute exit premiums and PnL ---
    long_exit_snap  = pe_df.loc[(pe_df["timestamp"] == exit_ts) &
                                (pe_df["strike_price"] == long_strike)]
    short_exit_snap = pe_df.loc[(pe_df["timestamp"] == exit_ts) &
                                (pe_df["strike_price"] == short_strike)]

    long_exit_prem  = float(long_exit_snap["close"].iloc[0])  if not long_exit_snap.empty  else long_pos["entry_prem"]
    short_exit_prem = float(short_exit_snap["close"].iloc[0]) if not short_exit_snap.empty else short_pos["entry_prem"]

    exit_spread   = long_exit_prem - short_exit_prem
    gross_pnl_pts = exit_spread - net_debit
    # 20 bps transcost + 20 bps slippage on each of entry and exit legs
    entry_tcost   = 0.0040 * (long_pos["entry_prem"] + short_pos["entry_prem"])
    exit_tcost    = 0.0040 * (long_exit_prem + short_exit_prem)
    pnl_pts       = gross_pnl_pts - entry_tcost - exit_tcost
    pnl_pct       = (pnl_pts / forward_price * 100) if forward_price > 0 else 0.0

    trade = {
        "trade_date":    str(entry_ts.date()),
        "entry_time":    str(entry_ts)[:19],
        "exit_time":     str(exit_ts)[:19],
        "long_strike":   long_strike,
        "short_strike":  short_strike,
        "forward_price": round(forward_price, 2),
        "long_entry":    round(long_pos["entry_prem"], 2),
        "short_entry":   round(short_pos["entry_prem"], 2),
        "net_debit":     round(net_debit, 2),
        "long_exit":     round(long_exit_prem, 2),
        "short_exit":    round(short_exit_prem, 2),
        "pnl_points":    round(pnl_pts, 2),
        "pnl_pct":       round(pnl_pct, 4),
        "exit_reason":   exit_reason,
    }

    exit_rows = [
        _exit_row(exit_ts, long_pos,  "exit_long",  exit_reason),
        _exit_row(exit_ts, short_pos, "exit_short", exit_reason),
    ]
    return exit_rows, trade


# ═══════════════════════════════════════════════════════════════════════════
# 9.  SINGLE-DAY PROCESSOR
# ═══════════════════════════════════════════════════════════════════════════

def process_day(trade_date: date, cw_map: dict, params: dict) -> tuple[list[dict], list[dict]]:
    api_expiry = cw_map[trade_date]
    csv_expiry = "cw"

    # Extract params
    pcr_mode       = params['PCR_MODE']
    pcr_threshold  = params['PCR_THRESHOLD']
    pcr_strikes    = params['PCR_STRIKES']
    pcr_timing     = params['PCR_TIMING']
    n_straddles    = params['N_STRADDLES']
    long_offset    = params['LONG_OFFSET']
    long_direction = params['LONG_DIRECTION']
    sl_pct         = params['SL_PCT']
    tp_mult        = params['TP_MULT']
    time_stop_val  = params['TIME_STOP']

    print(f"\n{'─'*60}")
    print(f"  {trade_date}  exp={api_expiry}  "
          f"pcr={pcr_mode!r}/{pcr_strikes!r}/{pcr_timing!r}  "
          f"N={n_straddles}  SL={sl_pct}  TP={tp_mult}x  "
          f"TSTOP={time_stop_val}")

    # -- Fetch full-day 3m data (cached across sweep runs) --------------------
    ce_df, pe_df = fetch_chain_3m(trade_date, api_expiry)
    if ce_df.empty or pe_df.empty:
        print(f"  WARNING: missing chain data -- skipping")
        return [], []

    straddle_df = fetch_straddle_3m(trade_date, api_expiry)
    if straddle_df.empty:
        print(f"  WARNING: missing straddle data -- skipping")
        return [], []

    # -- Find entry bar -------------------------------------------------------
    entry_ts = resolve_entry_bar(ce_df, pe_df, straddle_df,
                                 pcr_mode, pcr_threshold, pcr_strikes, pcr_timing)
    if entry_ts is None:
        print(f"  No entry -- PCR never triggered")
        return [], []

    # -- Straddle at entry bar ------------------------------------------------
    strad_snap = _snap(straddle_df, entry_ts)
    ce_strad   = strad_snap.loc[strad_snap["option_type"] == "CE"]
    pe_strad   = strad_snap.loc[strad_snap["option_type"] == "PE"]
    if ce_strad.empty or pe_strad.empty:
        print(f"  WARNING: incomplete straddle at {entry_ts.time()} -- skipping")
        return [], []

    ce_close       = float(ce_strad["close"].iloc[0])
    pe_close       = float(pe_strad["close"].iloc[0])
    atm_strike     = float(ce_strad["strike_price"].iloc[0])
    straddle_price = ce_close + pe_close
    print(f"  Straddle @ {entry_ts.time()}  ATM={atm_strike}  "
          f"CE={ce_close:.2f}  PE={pe_close:.2f}  total={straddle_price:.2f}")

    # -- Forward at entry bar -------------------------------------------------
    pe_entry_snap = _snap(pe_df, entry_ts)
    fwd_col = _col_name(pe_df, ["forward", "fwd"])
    if fwd_col is None or pe_entry_snap[fwd_col].dropna().empty:
        print(f"  WARNING: forward unavailable -- skipping")
        return [], []
    forward = float(pe_entry_snap[fwd_col].dropna().iloc[0])
    print(f"  Forward={forward:.2f}")

    # -- Long put strike (ATM or offset) -------------------------------------
    long_strike, long_entry_prem = resolve_long_strike(
        pe_entry_snap, atm_strike, long_offset, long_direction)
    if long_strike is None:
        offset_desc = (f"{long_offset} strike(s) {long_direction} of ATM={atm_strike}"
                       if long_offset > 0 else f"ATM={atm_strike}")
        print(f"  WARNING: long strike ({offset_desc}) not in PE chain -- skipping")
        return [], []

    # -- Short put strike (N straddles from forward) --------------------------
    short_strike = round_to_strike(forward - n_straddles * straddle_price)
    offset_label = (f"ATM{'-' if long_direction=='otm' else '+'}{long_offset*STRIKE_STEP}"
                    if long_offset > 0 else "ATM")
    print(f"  Long  put={long_strike} ({offset_label})  "
          f"Short put=round({forward:.2f} - {n_straddles}x{straddle_price:.2f})={short_strike}")

    if short_strike >= long_strike:
        print(f"  WARNING: invalid spread (short={short_strike} >= long={long_strike}) -- skipping")
        return [], []

    # -- Short put premium ----------------------------------------------------
    short_snap = pe_entry_snap.loc[pe_entry_snap["strike_price"] == short_strike]
    if short_snap.empty:
        print(f"  WARNING: no data for short strike {short_strike} -- skipping")
        return [], []
    short_entry_prem = float(short_snap["close"].iloc[0])

    net_debit    = long_entry_prem - short_entry_prem
    max_loss_rs  = net_debit * LOT_SIZE
    quantity     = math.floor(RUPEE_RISK / max_loss_rs) if max_loss_rs > 0 else 0
    max_profit   = (long_strike - short_strike - net_debit) * LOT_SIZE

    print(f"  ENTRY ts={entry_ts.time()}  "
          f"long_prem={long_entry_prem:.2f}  short_prem={short_entry_prem:.2f}  "
          f"net_debit={net_debit:.2f}")
    print(f"  Risk/lot=₹{max_loss_rs:.0f}  "
          f"MaxProfit/lot=₹{max_profit:.0f}  "
          f"Qty@₹{RUPEE_RISK}risk={quantity} lots")
    if sl_pct is not None:
        print(f"  SL level = {net_debit*(1-sl_pct):.2f}  "
              f"(spread drops to {(1-sl_pct)*100:.0f}% of net_debit)")
    if tp_mult is not None:
        print(f"  TP level = {net_debit*(1+tp_mult):.2f}  "
              f"({tp_mult}R = {tp_mult}× net_debit)")

    signals: list[dict] = []
    signals.append(_entry_row(entry_ts, "entry_long",  "PE",
                              csv_expiry, long_strike,  long_entry_prem))
    signals.append(_entry_row(entry_ts, "entry_short", "PE",
                              csv_expiry, short_strike, short_entry_prem))

    long_pos  = {"kind": "PE", "csv_expiry": csv_expiry, "strike": long_strike,
                 "entry_prem": long_entry_prem}
    short_pos = {"kind": "PE", "csv_expiry": csv_expiry, "strike": short_strike,
                 "entry_prem": short_entry_prem}

    # -- Exit monitoring on 3m PE chain ---------------------------------------
    exit_rows, trade = monitor_exit(
        pe_df=pe_df,
        entry_ts=entry_ts,
        long_strike=long_strike,
        short_strike=short_strike,
        net_debit=net_debit,
        long_pos=long_pos,
        short_pos=short_pos,
        sl_pct=sl_pct,
        tp_mult=tp_mult,
        time_stop_val=time_stop_val,
        forward_price=forward,
    )
    signals.extend(exit_rows)
    return signals, [trade]


# ═══════════════════════════════════════════════════════════════════════════
# 10.  GENERATE SIGNALS  (per sweep run)
# ═══════════════════════════════════════════════════════════════════════════

def generate_signals(params: dict, run_id: int, trade_dates: list, cw_map: dict, total_trading_days: int = 0):
    run_name = (f"PCR_{params['PCR_MODE']}_"
                f"THR_{params['PCR_THRESHOLD']}_"
                f"STK_{params['PCR_STRIKES']}_"
                f"TIM_{params['PCR_TIMING']}_"
                f"N_{params['N_STRADDLES']}_"
                f"LOFF_{params['LONG_OFFSET']}{params['LONG_DIRECTION']}_"
                f"SL_{params['SL_PCT']}_"
                f"TP_{params['TP_MULT']}")
    run_dir = os.path.join(BASE_RESULTS_DIR, run_name)
    os.makedirs(run_dir, exist_ok=True)
    print(f"\n--- Run {run_id}: {run_name} ---")

    all_signals: list[dict] = []
    all_trades:  list[dict] = []
    skipped = 0

    for td in tqdm(trade_dates, desc=run_name, unit="day"):
        day_sigs, day_trades = process_day(td, cw_map, params)
        if day_sigs:
            all_signals.extend(day_sigs)
            all_trades.extend(day_trades)
        else:
            skipped += 1

    if not all_signals:
        print("  ⚠ No signals.")
        return None

    df_out = pd.DataFrame(all_signals)
    df_out.to_csv(os.path.join(run_dir, "signal_bear_spread.csv"), index=False)

    df_trades = pd.DataFrame(all_trades)
    df_trades.to_csv(os.path.join(run_dir, "trade_log.csv"), index=False)

    n_el = int(df_out["entry_long"].sum())
    n_xl = int(df_out["exit_long"].sum())
    n_es = int(df_out["entry_short"].sum())
    n_xs = int(df_out["exit_short"].sum())

    # --- Summary stats (matching gex-strat style) ---
    has_pnl    = df_trades["pnl_points"].notna()
    total_pnl  = df_trades.loc[has_pnl, "pnl_points"].sum()  if has_pnl.any() else 0
    avg_pnl    = df_trades.loc[has_pnl, "pnl_points"].mean() if has_pnl.any() else 0
    win_rate   = (df_trades.loc[has_pnl, "pnl_points"] > 0).mean() * 100 if has_pnl.any() else 0
    avg_entry  = df_trades["net_debit"].mean() if not df_trades.empty else 0
    reason_cts = df_trades["exit_reason"].value_counts().to_dict() if not df_trades.empty else {}

    # Calmar, Sharpe, Max Drawdown
    pnl_pcts = df_trades["pnl_pct"].dropna().values
    if len(pnl_pcts) > 0:
        total_pnl_pct = pnl_pcts.sum()
        # Equity curve: B_i = 100 + cumsum(pnl_pct) * 100
        equity      = 100.0 + (100 * np.cumsum(pnl_pcts))
        running_max = np.maximum.accumulate(equity)
        # Drawdown series: (B - C) / 100
        dd_series   = (equity - running_max) / 100.0
        max_dd      = dd_series.min()                    # most negative value
        T_days       = total_trading_days if total_trading_days > 0 else len(trade_dates)
        total_return = (equity[-1] - 100.0) / 100.0
        cagr         = (1 + total_return) ** (252.0 / T_days) - 1 if T_days > 0 else 0.0
        daily_pnl    = df_trades.dropna(subset=["pnl_pct"]).groupby("trade_date")["pnl_pct"].sum()
        ann_std      = float(daily_pnl.std() * np.sqrt(252)) if len(daily_pnl) > 1 else 0.0
        calmar       = cagr / abs(max_dd) if max_dd != 0 else np.nan
        sharpe       = cagr / ann_std     if ann_std  > 0 else 0.0
    else:
        total_pnl_pct = 0.0
        cagr    = 0.0
        ann_std = 0.0
        max_dd  = 0.0
        calmar  = np.nan
        sharpe  = 0.0

    print(f"\n{'=' * 70}")
    print(f"  COMPLETE  —  Run {run_id}: {run_name}")
    print(f"{'=' * 70}")
    print(f"  Days traded   : {len(trade_dates) - skipped:,}  "
          f"(skipped/no-trigger: {skipped})")
    print(f"  Long  entry/exit : {n_el:,} / {n_xl:,}  "
          f"{'✓' if n_el == n_xl else '✗'}")
    print(f"  Short entry/exit : {n_es:,} / {n_xs:,}  "
          f"{'✓' if n_es == n_xs else '✗'}")
    print(f"  Total PnL: {total_pnl:+.2f}  |  Avg PnL: {avg_pnl:+.2f}  |  Win%: {win_rate:.1f}%")
    print(f"  MaxDD: {max_dd:.4f}  |  Calmar: {calmar:.2f}  |  Sharpe: {sharpe:.2f}")
    print(f"  Exit reasons: {reason_cts}")
    print(f"{'=' * 70}")

    return {
        'run_id': run_id,
        'run_name': run_name,
        **params,
        'num_entries': n_el,
        'num_exits': n_xl,
        'match': n_el == n_xl,
        'total_pnl_pts': round(total_pnl, 2),
        'total_pnl_pct': round(total_pnl_pct, 4),
        'avg_pnl': round(avg_pnl, 2),
        'avg_net_debit': round(avg_entry, 2),
        'win_rate_pct': round(win_rate, 2),
        'cagr': round(cagr, 6),
        'ann_std': round(ann_std, 6),
        'max_dd': round(max_dd, 6),
        'calmar': round(calmar, 4) if not np.isnan(calmar) else np.nan,
        'sharpe': round(sharpe, 4),
        **{f"exit_{k}": v for k, v in reason_cts.items()},
    }


# ═══════════════════════════════════════════════════════════════════════════
# 11.  DIAGNOSTIC
# ═══════════════════════════════════════════════════════════════════════════

def diagnose_day(trade_date_str: str):
    """
    Call manually to inspect raw data for a single day.
    Usage: diagnose_day("2024-01-04")
    """
    from datetime import date as _date
    cw_map, _ = load_expiry_maps()
    td = _date.fromisoformat(trade_date_str)
    if td not in cw_map:
        print(f"  {td} not in expiry map"); return
    api_expiry = cw_map[td]
    print(f"\n{'='*70}\n  DIAGNOSTIC: {td}  exp={api_expiry}\n{'='*70}")

    ce_df, pe_df = fetch_chain_3m(td, api_expiry)
    for label, df in [("CE", ce_df), ("PE", pe_df)]:
        print(f"\n--- {label} chain ---")
        print(f"  shape: {df.shape}  cols: {df.columns.tolist()}")
        if not df.empty and "option_type" in df.columns:
            print(f"  option_type unique: {df['option_type'].unique().tolist()}")

    oi_col  = _col_name(ce_df, ["oi", "open_interest"])
    vol_col = _col_name(ce_df, ["volume", "vol"])
    if oi_col and not ce_df.empty:
        print(f"\n--- OI variability (does it change across bars?) ---")
        ce_oi = ce_df.groupby("timestamp")[oi_col].sum().rename("ce_oi")
        pe_oi = pe_df.groupby("timestamp")[oi_col].sum().rename("pe_oi")
        merged = pd.concat([ce_oi, pe_oi], axis=1).reset_index()
        merged["pcr"] = (merged["pe_oi"] / merged["ce_oi"]).round(4)
        print(merged.head(10).to_string(index=False))
        if merged["ce_oi"].nunique() == 1:
            print("  *** CE OI CONSTANT — likely EOD-only data ***")
    if vol_col and not ce_df.empty:
        print(f"\n--- Volume variability ---")
        ce_v = ce_df.groupby("timestamp")[vol_col].sum().rename("ce_vol")
        pe_v = pe_df.groupby("timestamp")[vol_col].sum().rename("pe_vol")
        merged_v = pd.concat([ce_v, pe_v], axis=1).reset_index()
        merged_v["vol_pcr"] = (merged_v["pe_vol"] / merged_v["ce_vol"]).round(4)
        print(merged_v.head(10).to_string(index=False))
    print(f"\n{'='*70}")


# ═══════════════════════════════════════════════════════════════════════════
# 12.  SWEEP ENTRY POINT
# ═══════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    print("=" * 70)
    print("  Put Bear Spread — Parameter Sweep")
    print("=" * 70)

    print("\n[1/2] Loading expiry calendar ...")
    cw_map, _ = load_expiry_maps()
    expiry_days = build_expiry_day_set(cw_map)
    start_d     = date.fromisoformat(START_DATE)
    end_d       = date.fromisoformat(END_DATE)
    trade_dates = sorted(d for d in expiry_days if start_d <= d <= end_d)
    total_trading_days = _count_trading_days(start_d, end_d + timedelta(days=1))
    print(f"  Expiry days in range: {len(trade_dates):,}")

    p_keys = sorted(PARAMETER_GRID.keys())
    param_combinations = [
        dict(zip(p_keys, vals))
        for vals in product(*[PARAMETER_GRID[k] for k in p_keys])
    ]
    print(f"\n[2/2] Sweeping {len(param_combinations)} parameter combinations ...\n")

    all_results = []
    for i, params in enumerate(tqdm(param_combinations, desc="Parameter Sweep")):
        try:
            result = generate_signals(params, run_id=i + 1,
                                      trade_dates=trade_dates, cw_map=cw_map,
                                      total_trading_days=total_trading_days)
            if result is not None:
                all_results.append(result)
        except Exception as e:
            print(f"\n  ERROR in run {i + 1}: {str(e)}")
            continue

    if all_results:
        df_results = pd.DataFrame(all_results)
        df_results = df_results.sort_values('calmar', ascending=False, na_position='last')
        df_results.to_excel(
            os.path.join(BASE_RESULTS_DIR, "consolidated_results.xlsx"),
            index=False,
        )
        print(f"\n{'='*70}")
        print(f"  Done! {len(all_results)}/{len(param_combinations)} runs completed.")
        print(f"  Results: {BASE_RESULTS_DIR}/consolidated_results.xlsx")
        summary_cols = ['run_name', 'num_entries', 'total_pnl_pct', 'max_dd',
                        'calmar', 'sharpe', 'win_rate_pct']
        print(f"\nTop 10 by Calmar:")
        print(df_results[summary_cols].head(10).to_string(index=False))
        print(f"{'='*70}")
    else:
        print("  ⚠ No results from any run.")