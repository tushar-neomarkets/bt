from marketdata.fno_service import FnO
import pandas as pd
import numpy as np
df = pd.read_csv(r"C:\Users\Admin\Desktop\Strategy\Index_Trend\NIFTY_EMA50_15m_breathing_sorted_open_RiderBacktest_trades.csv")
df



entry_futures = []
exit_futures = []

fno = FnO()
problems = []

df["Exact Entry Time"] = pd.to_datetime(df["Exact Entry Time"])
df["Exact Exit Time"] = pd.to_datetime(df["Exact Exit Time"])

for index, row in df.iterrows():

    df_row_data_entry = fno.get_prices("NIFTY", start_date=row["Exact Entry Time"].strftime("%Y-%m-%d"), kind="futures", interval="1m", expiry="fm")
    exact_time = pd.to_datetime(row["Exact Entry Time"])
    df_row_data_entry = df_row_data_entry[df_row_data_entry["timestamp"] == exact_time]
    entry_expiry = df_row_data_entry["expiry_date"]
    df_row_data_exit = fno.get_prices("NIFTY", start_date=row["Exact Exit Time"].strftime("%Y-%m-%d"), kind="futures", interval="1m", expiry="fm")
    exact_time = pd.to_datetime(row["Exact Exit Time"])
    df_row_data_exit = df_row_data_exit[df_row_data_exit["timestamp"] == exact_time]
    exit_expiry = df_row_data_exit["expiry_date"]
    vol = fno.get_atm_iv("NIFTY", row["Exact Exit Time"].strftime("%Y-%m-%d"), interval="1m", expiry="nm")
    exact_time = pd.to_datetime(row["Exact Exit Time"])
    vol = vol.loc[vol["timestamp"] == exact_time, "atm_iv"]
    df_row_data_entry["iv"] = vol.values[0]

    if entry_expiry.iloc[0] != exit_expiry.iloc[0]:
        df_row_data_exit = fno.get_prices("NIFTY", start_date=row["Exact Exit Time"].strftime("%Y-%m-%d"),
                                          kind="futures", interval="1m", expiry="nm")
        exact_time = pd.to_datetime(row["Exact Exit Time"])
        df_row_data_exit = df_row_data_exit[df_row_data_exit["timestamp"] == exact_time]
        exit_expiry = df_row_data_exit["expiry_date"]
        vol = fno.get_atm_iv("NIFTY", row["Exact Exit Time"].strftime("%Y-%m-%d"), interval="1m", expiry="nm")
        exact_time = pd.to_datetime(row["Exact Exit Time"])
        vol = vol.loc[vol["timestamp"] == exact_time, "atm_iv"]
        df_row_data_entry["iv"] = vol.values[0]
        if entry_expiry.iloc[0] != exit_expiry.iloc[0]:
            df_row_data_exit = fno.get_prices("NIFTY", start_date=row["Exact Exit Time"].strftime("%Y-%m-%d"),
                                              kind="futures", interval="1m", expiry="cm")
            exact_time = pd.to_datetime(row["Exact Exit Time"])
            df_row_data_exit = df_row_data_exit[df_row_data_exit["timestamp"] == exact_time]
            exit_expiry = df_row_data_exit["expiry_date"]
            vol = fno.get_atm_iv("NIFTY", row["Exact Exit Time"].strftime("%Y-%m-%d"), interval="1m", expiry="nm")
            exact_time = pd.to_datetime(row["Exact Exit Time"])
            vol = vol.loc[vol["timestamp"] == exact_time, "atm_iv"]
            df_row_data_entry["iv"] = vol.values[0]
        else:
            print("Good to go: ", index, row["Exact Exit Time"])
    else:
        print("Good to go: ", index, row["Exact Exit Time"])

    entry_futures.append(df_row_data_entry)
    exit_futures.append(df_row_data_exit)

entry_data = pd.concat(entry_futures)
exit_data = pd.concat(exit_futures)
futures_data = pd.concat([entry_data.reset_index(), exit_data.reset_index().rename(columns={
    "timestamp": "exit_timetamp",
    "ticker": "exit_ticker",
    "expiry_date": "exit_expiry_date",
    "strike_price": "exit_strike",
    "option_type": "exit_option_type",
    "close": "exit_close",
    "volume": "exit_volume",
    "oi": "exit_oi",
    "forward": "exit_forward",
    "ttm": "exit_ttm",
    "iv": "exit_iv"
})], axis = 1)
all_data = pd.concat([df, futures_data], axis = 1)
all_data["futures_pnl"] = ((all_data["exit_close"] - all_data["close"])/all_data["close"]* all_data["Direction"]) - 0.0007
all_data["date"] = pd.to_datetime(all_data["Exit Time"]).dt.date
all_data.to_csv("futures_trades_near_month_and_future_month_trade.csv", index=False)
