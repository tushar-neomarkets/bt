import pandas as pd
import datetime as dt
import numpy as np
from marketdata import FnO
from marketdata import Index
import quantstats_lumi as qs

fno = Index()
from datetime import datetime, timedelta


def fetch_full_history(index_name, start_date="2016-01-01", end_date="2026-01-20"):
    start = pd.to_datetime(start_date)
    end = pd.to_datetime(end_date)

    dfs = []


    current_start = start
    while current_start < end:
        # 1 year window
        current_end = min(current_start + pd.DateOffset(years=1) - pd.Timedelta(days=1), end)

        print(f"Fetching: {current_start.date()} → {current_end.date()}")

        df_part = fno.get_prices(
            "NIFTY 50",
            current_start.strftime("%Y-%m-%d"),
            current_end.strftime("%Y-%m-%d"),
            # expiry="cm",
            # kind="futures",
            interval="1h",
            columns="ohlc"
        )

        if df_part is not None and len(df_part) > 0:
            df_part = df_part.rename({"timestamp": "datetime"}, axis=1)
            dfs.append(df_part)

        # Move to next block
        current_start = current_end + timedelta(days=1)

    # Merge all
    if len(dfs) == 0:
        return pd.DataFrame()

    full_df = pd.concat(dfs, ignore_index=True)

    # Sort
    full_df.sort_values("datetime", inplace=True)

    return full_df


# df = fetch_full_history(index_name="NIFTY")  # or whatever index
# print(df)

def find_time(datetime, price, find_high=False, is_entry=False):
    hour_interval = datetime - pd.Timedelta(hours=1)
    # hour_interval_dt = pd.to_datetime(hour_interval.)

    useful_data = fno.get_prices("NIFTY 50",
                                 hour_interval.strftime("%Y-%m-%d"),
                                 datetime.strftime("%Y-%m-%d"), columns="ohlc", interval="1m")

    # mask = useful_data["timestamp"].dt.time.between(
    #     dt.time(9, 15, 59),
    #     dt.time(15, 14, 59)
    # )

    # mask = useful_data["timestamp"].dt.time.between(
    #     hour_interval.time(),
    #     datetime.time(),
    # )

    mask = (useful_data["timestamp"] >= hour_interval) & (useful_data["timestamp"] <= datetime)

    useful_data = useful_data[mask]
    useful_data = useful_data.sort_values("timestamp")

    for index, row in useful_data.iterrows():
        if is_entry:
            if find_high:
                if row['high'] >= price:
                    return row['timestamp']
            else:
                if row['low'] <= price:
                    return row['timestamp']
        else:
            if find_high:
                if row['high'] >= price:
                    return row['timestamp']
            else:
                if row['low'] <= price:
                    return row['timestamp']
    return datetime

def main(index_name, EMA):
    print(index_name)
    df = fetch_full_history(index_name="NIFTY", start_date="2016-01-01", end_date="2026-01-23")
    df = df.rename({
        "timestamp": "datetime",

    }, axis=1)
    print(df)
    df.sort_values('datetime', inplace=True)

    new_df = df
    # build 40 EMA
    new_df['EMA'] = new_df['close'].ewm(span=EMA, adjust=False).mean()

    trigger = 0
    position = 0
    trades = []
    entry_times_min = []
    exit_times_min = []
    for index, row in new_df.iterrows():
        print(row['datetime'])
        if position == 1:
            if row['open'] <= sl_price and row['datetime'].time() == dt.time(10, 14, 59):
                position = 0
                exit_time = row['datetime']
                exit_price = row['open']
                trade_dict = {
                    'Entry Time': entry_time,
                    "Entry Price": entry_price,
                    'Exit Time': exit_time,
                    'Exit Price': exit_price,
                    # 'Ticker':row['Ticker'],
                    'Direction': 1,
                    'SL Type': 'Open'
                }
                trades.append(trade_dict)
                exit_times_min.append(row['datetime'])
                position = 0
                trigger = 0
            elif row['low']*(1 + 0.000) <= sl_price:
                position = 0
                exit_time = row['datetime']
                exit_price = sl_price/(1 + 0.000)
                trade_dict = {
                    'Entry Time': entry_time,
                    "Entry Price": entry_price,
                    'Exit Time': exit_time,
                    'Exit Price': exit_price,
                    # 'Ticker':row['ticker'],
                    'Direction': 1,
                    'SL Type': 'EMA'
                }
                trades.append(trade_dict)
                exit_min = find_time(row["datetime"], sl_price*(1 + 0.000), find_high=False)
                exit_times_min.append(exit_min)
                position = 0
                trigger = 0
            else:
                if row['datetime'].date() != entry_time.date():
                    sl_price = row['EMA'] - 1
        elif position == -1:
            if row['open'] >= sl_price and row['datetime'].time() == dt.time(10, 14, 59):
                position = 0
                exit_time = row['datetime']
                exit_price = row['open']
                trade_dict = {
                    'Entry Time': entry_time,
                    "Entry Price": entry_price,
                    'Exit Time': exit_time,
                    'Exit Price': exit_price,
                    # 'Ticker':row['Ticker'],
                    'Direction': -1,
                    'SL Type': 'Open'
                }
                trades.append(trade_dict)
                exit_times_min.append(row['datetime'])
                position = 0
                trigger = 0
            elif row['high'] >= sl_price*(1 + 0.000):
                position = 0
                exit_time = row['datetime']
                exit_price = sl_price*(1 + 0.000)
                trade_dict = {
                    'Entry Time': entry_time,
                    "Entry Price": entry_price,
                    'Exit Time': exit_time,
                    'Exit Price': exit_price,
                    # 'Ticker':row['Ticker'],
                    'Direction': -1,
                    'SL Type': 'EMA'
                }
                trades.append(trade_dict)
                exit_min = find_time(row["datetime"], sl_price*(1 + 0.000), find_high=True)
                exit_times_min.append(exit_min)
                position = 0
                trigger = 0
            else:
                if row['datetime'].date() != entry_time.date():
                    sl_price = row['EMA'] + 1

        if position == 0:
            if trigger == 0:
                if row['close'] > row['EMA']:
                    trigger = 1
                    data_till_date = new_df[new_df.datetime <= row['datetime']]
                    data_till_date = data_till_date[data_till_date.datetime.dt.date == row['datetime'].date()]
                    day_high = data_till_date['high'].max()
                    day_low = data_till_date['low'].min()
                    ema_trigger = row['EMA']
                    high_trigger = day_high + 1
                elif row['close'] < row['EMA']:
                    trigger = -1
                    data_till_date = new_df[new_df.datetime <= row['datetime']]
                    data_till_date = data_till_date[data_till_date.datetime.dt.date == row['datetime'].date()]
                    day_low = data_till_date['low'].min()
                    day_high = data_till_date['high'].max()
                    low_trigger = day_low - 1
                    ema_trigger = row['EMA']
                else:
                    print("No Trigger")
            elif trigger == 1:
                if row['high'] >= high_trigger:
                    position = 1
                    entry_time = row['datetime']
                    entry_price = high_trigger
                    sl_price = min(day_low - 1, ema_trigger)
                    entry_min = find_time(row["datetime"], entry_price - 1, find_high=True, is_entry = True)
                    entry_times_min.append(entry_min)



                elif row['close'] < row['EMA']:
                    trigger = -1
                    data_till_date = new_df[new_df.datetime <= row['datetime']]
                    data_till_date = data_till_date[data_till_date.datetime.dt.date == row['datetime'].date()]
                    day_low = data_till_date['low'].min()
                    day_high = data_till_date['high'].max()
                    low_trigger = day_low - 1
                    ema_trigger = row['EMA']
                else:
                    print("No Trigger")
            elif trigger == -1:
                if row['low'] <= low_trigger:
                    position = -1
                    entry_time = row['datetime']
                    entry_price = low_trigger
                    sl_price = max(day_high + 1, ema_trigger)
                    entry_min = find_time(row["datetime"], entry_price + 1, find_high=False, is_entry = True)
                    entry_times_min.append(entry_min)


                elif row['close'] > row['EMA']:
                    trigger = 1
                    data_till_date = new_df[new_df.datetime <= row['datetime']]
                    data_till_date = data_till_date[data_till_date.datetime.dt.date == row['datetime'].date()]
                    day_high = data_till_date['high'].max()
                    day_low = data_till_date['low'].min()
                    ema_trigger = row['EMA']
                    high_trigger = day_high + 1
                else:
                    print("No Trigger")
            if position == 0 and row['datetime'].time() == dt.time(15, 14, 59):
                trigger = 0

    trades_df = pd.DataFrame(trades)
    trades_df['PNL'] = ((trades_df['Exit Price'] - trades_df['Entry Price']) * trades_df['Direction']) / (trades_df['Entry Price'] - 0.0007)
    trades_df.set_index('Entry Time', inplace=True)
    pnl = trades_df.resample('D').agg(
        {
            'PNL': 'sum'
        }
    )

    qs.reports.html(pnl['PNL'], output=f'{index_name.upper()}_EMA{EMA}_5m_RiderBacktest.html',
                    title=f'{index_name.upper()} EMA{EMA} RiderBacktest')
    # return trades_df
    trades_df.index = trades_df.index.tz_localize(None)
    trades_df['Exit Time'] = pd.to_datetime(trades_df['Exit Time']).dt.tz_localize(None)
    trades_df["Exact Entry Time"] = entry_times_min[:-1]
    trades_df["Exact Exit Time"] = exit_times_min
    # trades_df['Entry Time'] = trades_df['Entry Time'].tz_localize(None)
    # trades_df['Exit Time'] = trades_df['Exit Time'].tz_localize(None)
    print(trades_df)
    trades_df.to_csv(f'{index_name.upper()}_EMA{EMA}_15m_breathing_sorted_open_RiderBacktest_trades.csv', index=True)
    pnl.index = pnl.index.tz_localize(None)
    pnl.to_csv(f'{index_name.upper()}_EMA{EMA}_15m_breathing_sorted_open_RiderBacktest_pnl.csv', index=True)


if __name__ == '__main__':
    main('NIFTY', EMA=50)
    # main('BANKNIFTY', EMA=55)

