# Trading Platform Architecture

## Goal
Build a Django-based automated trading platform supporting:
 - Live trading
For systematic options & futures strategies.


## Core Principles
- Strategy logic is stateless where possible
- Execution, data, and strategy are strictly separated
- No strategy directly places orders

## Apps & Responsibilities

### datafeeds
- Market data ingestion (websocket and REST api)
- Normalized Data irrespective of brokers/datavendors

### instruments
- Symbols, contracts, expiries, strikes
- Broker instrument mappings

### strategy
- Signal generation only
- No broker or API calls

### orders
- Place and Track Broker Orders

### accounts
- Track and Monitor Accounts
- Margin API, Positions API, OrderBook API

### utils
- Misc Util Functions which can be used across the app

### dump
- Misc Files Needed (csv json etc)
